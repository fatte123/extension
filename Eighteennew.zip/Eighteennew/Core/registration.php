<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_Core
 */
 
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Eighteen_Core', __DIR__);
