<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_Core
 */
namespace Eighteen\Core\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Helper\Context;
use \Magento\Store\Model\ScopeInterface;
use \Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{
    /**
     * @var TimezoneInterface
     */
    protected $_timezoneinterface;
    
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param TimezoneInterface $timezoneinterface
     * @param ScopeConfigInterface $scopeConfig
     **/
    public function __construct(
        Context $context,
        TimezoneInterface $timezoneinterface,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_timezoneinterface = $timezoneinterface;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    /*
     * Get config value
     * return String
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    
    /*
     * Get general config value
     * return String
     */
    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->getConfigValue($code, $storeId);
    }
}
