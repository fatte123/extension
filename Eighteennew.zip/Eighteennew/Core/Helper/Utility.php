<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_Core
 */
namespace Eighteen\Core\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Helper\Context;
use \Magento\Store\Model\ScopeInterface;
use \Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;

class Utility extends AbstractHelper
{
    /**
     * @var TimezoneInterface
     */
    protected $_timezoneinterface;
    
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param TimezoneInterface $timezoneinterface
     * @param ScopeConfigInterface $scopeConfig
     **/
    public function __construct(
        Context $context,
        TimezoneInterface $timezoneinterface,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_timezoneinterface = $timezoneinterface ?: ObjectManager::getInstance()
            ->get(TimezoneInterface::class);
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    /**
     * Get format date
     */
    public function getFormatDate($CreatedAt)
    {
        /*$dateModel = $this->_timezoneinterface->create();
        return $dateModel->gmtDate('M j, Y, g:i:s a',$CreatedAt);*/
        if($CreatedAt)
			return $this->_timezoneinterface->date(new \DateTime($CreatedAt))->format('M j, Y,g:i:s a');
		return false;
    }
}
