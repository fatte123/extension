<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_Core
 */
namespace Eighteen\Core\Helper;

class CoreConstants
{
    // log
    const EIGHTEEN_LOG_DIR = "/sleepyheadlog/";
    const EIGHTEEN_INVOICE_PDF_DIR = "/customer_invoice_pdf/";
    const CORE_LOG_FILE = "base";
    const CLEAR_LOG_DAYS = 5;
    const CLEAR_PROCESS_LOG_FILE = "cleanprocess";
    const CONFIG_MODULE_CLEAR_LOG_ENABLE = "clear_process/clear_process_logs/enable";
}
