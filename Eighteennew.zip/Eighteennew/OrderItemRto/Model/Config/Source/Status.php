<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
 
namespace Eighteen\OrderItemRto\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Status implements ArrayInterface
{
    /**
     * Process Status
     */
    const STATUS_INPROGRESS = 'pending';
    const STATUS_COMPLETE = 'completed';

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
        self::STATUS_INPROGRESS => __('Pending'),
        self::STATUS_COMPLETE => __('Completed')
        ];
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $result = [];
        foreach (self::toArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }
}
