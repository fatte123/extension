<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */

namespace Eighteen\OrderItemRto\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\SalesSequence\Model\Manager;

class SalesOrderCreditMemoItem extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    /**
     * Eav configuration model
     *
     * @var Manager
     */
    protected $sequenceManager;

    /**
     * @param Context $context
     * @param Manager $sequenceManager
     */
    public function __construct(
        Context $context,
        Manager $sequenceManager,
        $connectionName = null
    ) {
        
        $this->sequenceManager = $sequenceManager;
        parent::__construct($context, $connectionName);
    }

    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('msh_creditmemo_order_items', 'entity_id');
    }
}
