<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */

namespace Eighteen\OrderItemRto\Model;

use Eighteen\Core\Logger\Logger;
use Eighteen\OrderItemRto\Helper\OrderItemRtoConstant;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\App\ResourceConnection;
use Eighteen\OrderItemRto\Helper\OrderItemCancel as OrderItemCancelHelper;

class OrderItemCancel
{
    /**
     * @var Logger
     */
    protected $_logger;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;
    
    /**
     * @var TimezoneInterface
     */
    protected $resourceConnection;
    
    /**
     * @var OrderFactory
     */
    protected $orderFactory;
    
    /**
     * @var OrderItemCancelHelper
     */
    protected $cancelOrderItemtHelper;

    /**
     * @param Logger $logger
     **/
    public function __construct(
        Logger $logger,
        TimezoneInterface $timezone,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        OrderItemCancelHelper $cancelOrderItemtHelper,
        ResourceConnection $resourceConnection
    ) {
        $this->_logger = $logger;
        $this->timezone = $timezone;
        $this->orderFactory = $orderFactory;
        $this->cancelOrderItemtHelper = $cancelOrderItemtHelper;
        $this->resourceConnection = $resourceConnection;
        $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_RTO_LOG_FILE);
    }

    /**
     * Cancel Order Items
     **/
    //phpcs:ignore
    public function cancelOrderItems($cancelData)
    {
        $orderId = '';
        $response = false;
        $this->_logger->writeLog('--------------------------------------');
        $this->_logger->writeLog('Cancel Order Item process started.');
        $this->_logger->writeLog('--------------------------------------');
        $this->_logger->writeLog("Started at ".$this->getTodayDate());
        $this->_logger->writeLog("cancelData ". json_encode($cancelData));
        $orderIncrementId = $cancelData['orderId'];
        $orderData = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);
        $orderId = $orderData->getId();
        $cancelArray = $cancelData['cancelItems'];
        $cancelData['orderId'] = $orderId;
        if ($orderId && $cancelArray) {
            //validate cancel array
            $validData = $this->validateCancelData($orderData ,$cancelData);
            if ($orderData != false && $validData == true) {
                $response = true;
                //$this->sendCancelSms($order, $cancelArray);
                //add consignment rto and rto item
                try {
                    $rtoId = $this->cancelOrderItemtHelper->addCancelOrderRtoEntry($orderId);
                    $this->cancelOrderItemtHelper->addCancelOrderRtoItemEntry($rtoId, $orderData, $cancelArray);
                    $this->cancelOrderItemtHelper->initCancelRto($rtoId);
                } catch(\Exception $e) {
                    $this->_logger->writeLog($e->getMessage());
                    $response = false;
                }
            } else {
                $this->_logger->writeLog('Order not found.');
                $response = false;
            }
        }
        $this->_logger->writeLog("Stopped at ".$this->getTodayDate());
        $this->_logger->writeLog('--------------------------------------');
        $this->_logger->writeLog('Cancel Order Item process ended.');
        $this->_logger->writeLog('--------------------------------------');
        return $response;
    }

    public function validateCancelData($orderData ,$cancelData)
    {
        $validData = true;
        foreach ($orderData->getAllVisibleItems() as $item) {
            foreach ($cancelData['cancelItems'] as $sku => $qty) {
                if ($item->getSku() == $sku) {
                    $orderedQty = $item->getQtyOrdered();
                    $updatedCancelQty = $item->getQtyCanceled() + $qty;
                    if ($updatedCancelQty > $orderedQty) {
                        $this->_logger->writeLog('Cancel Qty greater than ordered Qty.');
                        $validData = false;
                    }              
                }
            }
        }
        return $validData;
    }

    /**
     *  Get today date
     */
    public function getTodayDate()
    {
        return $this->timezone->date()->format('Y-m-d H:i:s');
    }

    /**
     * To get resource connection
     * @return Object
     */
    public function getResourceConn()
    {
        return $this->resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
    }
}
