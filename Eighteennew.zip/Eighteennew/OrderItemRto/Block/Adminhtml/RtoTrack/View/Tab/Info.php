<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Block\Adminhtml\RtoTrack\View\Tab;

use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\AuthorizationInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Text\ListText;
use Magento\Sales\Model\Order;

/**
 * Consignment history tab
 *
 * @api
 * @since 100.0.2
 */
class Info extends \Magento\Backend\Block\Template implements TabInterface
{
    /**
     * @var _coreRegistry
     */
    protected $_coreRegistry = null;

    /**
     * @var AuthorizationInterface
     */
    private $authorization;

    /**
     * @var Address\Renderer
     */
    protected $addressRenderer;

    /**
     * @var commonHelper
     */
    protected $commonHelper;

    /**
    * @var $utility
    */
    protected $utility;

    /**
     * Collection factory
     *
     * @param Context $context
     * @param Registry $coreRegistry
     * @param \Magento\Sales\Model\Order\Address\Renderer $addressRenderer
     * @param \Wildcraft\Consignment\Helper\Common $commonHelper
     * @param SalesConsignmentRtoTrackFactory $salesConsignmentRtoItemFactory
     * @param \Wildcraft\Core\Helper\Utility $utility
     * @param array $data
     * @param AuthorizationInterface|null $authorization
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        Registry $coreRegistry,
        \Magento\Sales\Model\Order\Address\Renderer $addressRenderer,
        array $data = [],
        ?AuthorizationInterface $authorization = null
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->addressRenderer = $addressRenderer;
        $this->authorization = $authorization ?? ObjectManager::getInstance()->get(AuthorizationInterface::class);
        parent::__construct($context, $data);
    }

    /**
     * Get Order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrderRtoItem()
    {
        return $this->_coreRegistry->registry('msh_rto_item');
    }

    /**
     * @inheritdoc
     */
    public function getTabLabel()
    {
        return __('Items Informations');
    }

    /**
     * @inheritdoc
     */
    public function getTabTitle()
    {
        return __('Items Informations');
    }

    /**
     * @inheritdoc
     */
    public function canShowTab()
    {
        return $this->authorization->isAllowed('Eighteen_OrderItemRto::orderitemrto_info');
    }

    /**
     * @inheritdoc
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Returns string with formatted address
     *
     * @param Address $address
     * @return null|string
     */
    public function getFormattedAddress($address)
    {
        return $this->addressRenderer->format($address, 'html');
    }
}
