<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Helper;

use Magento\Framework\App\ResourceConnection;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Model\OrderFactory;
use Eighteen\Core\Logger\Logger;

class DeleteInvoice
{
	const TAG = 'DeleteInvoice: ';
	
    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var InvoiceRepositoryInterface
     */
    protected $invoiceRepository;

    /**
     * @var OrderFactory
     */
    protected $orderFactory;
    
    /**
     * @var Logger
     */
    protected $_logger;


    /**
     * Delete constructor.
     * @param ResourceConnection $resource
     * @param InvoiceRepositoryInterface $invoiceRepository
     * @param OrderFactory $order
     * @param Data $dataHelper
     * @param Logger $logger
     */
    public function __construct(
        ResourceConnection $resource,
        InvoiceRepositoryInterface $invoiceRepository,
        OrderFactory $order,
        Logger $logger
    ) {
        $this->resource = $resource;
        $this->invoiceRepository = $invoiceRepository;
        $this->orderFactory = $order;
        $this->_logger = $logger;
    }

    /**
     * @param $invoiceId
     * @return \Magento\Sales\Model\Order
     * @throws \Exception
     */
    public function deleteInvoice($invoiceId, $logger = null)
    {
        if($logger == null) {
            $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_RTO_LOG_FILE);
            $logger = $this->_logger;
        }
		
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        $invoiceGridTable = $connection->getTableName('sales_invoice_grid');
        $invoiceTable = $connection->getTableName('sales_invoice');
        $invoice = $this->invoiceRepository->get($invoiceId);
        $orderId = $invoice->getOrder()->getId();
        $order = $this->orderFactory->create()->load($orderId);
        $orderItems = $order->getAllItems();
        $invoiceItems = $invoice->getAllItems();
	
		$logger->writeLog(self::TAG . "Delete invoice init for orderid #{$orderId} and invoiceid #{$invoiceId}");
		
        // revert item in order
        foreach ($orderItems as $item) {
            foreach ($invoiceItems as $invoiceItem) {
                if ($invoiceItem->getOrderItemId() == $item->getItemId()) {
					$logger->writeLog(self::TAG . "order itemid: {$item->getItemId()}, invoice itemid: {$invoiceItem->getOrderItemId()}");
					$logger->writeLog(self::TAG . "getQtyInvoiced: {$item->getQtyInvoiced()}, invoiceqty: {$invoiceItem->getQty()} ");
					$logger->writeLog(self::TAG . "Set qty invoice: ". ($item->getQtyInvoiced() - $invoiceItem->getQty()));
                    $item->setQtyInvoiced($item->getQtyInvoiced() - $invoiceItem->getQty());
                    $item->setTaxInvoiced($item->getTaxInvoiced() - $invoiceItem->getTaxAmount());
                    $item->setBaseTaxInvoiced($item->getBaseTaxInvoiced() - $invoiceItem->getBaseTaxAmount());
                    $item->setDiscountTaxCompensationInvoiced(
                        $item->getDiscountTaxCompensationInvoiced() - $invoiceItem->getDiscountTaxCompensationAmount()
                    );
                    $baseDiscountTaxItem = $item->getBaseDiscountTaxCompensationInvoiced();
                    $baseDiscountTaxInvoice = $invoiceItem->getBaseDiscountTaxCompensationAmount();
                    $item->setBaseDiscountTaxCompensationInvoiced(
                        $baseDiscountTaxItem - $baseDiscountTaxInvoice
                    );

                    $item->setDiscountInvoiced($item->getDiscountInvoiced() - $invoiceItem->getDiscountAmount());
                    $item->setBaseDiscountInvoiced(
                        $item->getBaseDiscountInvoiced() - $invoiceItem->getBaseDiscountAmount()
                    );

                    $item->setRowInvoiced($item->getRowInvoiced() - $invoiceItem->getRowTotal());
                    $item->setBaseRowInvoiced($item->getBaseRowInvoiced() - $invoiceItem->getBaseRowTotal());
                }
            }
        }
        // revert info in order
        $order->setTotalInvoiced($order->getTotalInvoiced() - $invoice->getGrandTotal());
        $order->setBaseTotalInvoiced($order->getBaseTotalInvoiced() - $invoice->getBaseGrandTotal());

        $order->setSubtotalInvoiced($order->getSubtotalInvoiced() - $invoice->getSubtotal());
        $order->setBaseSubtotalInvoiced($order->getBaseSubtotalInvoiced() - $invoice->getBaseSubtotal());

        $order->setTaxInvoiced($order->getTaxInvoiced() - $invoice->getTaxAmount());
        $order->setBaseTaxInvoiced($order->getBaseTaxInvoiced() - $invoice->getBaseTaxAmount());

        $order->setDiscountTaxCompensationInvoiced(
            $order->getDiscountTaxCompensationInvoiced() - $invoice->getDiscountTaxCompensationAmount()
        );
        $order->setBaseDiscountTaxCompensationInvoiced(
            $order->getBaseDiscountTaxCompensationInvoiced() - $invoice->getBaseDiscountTaxCompensationAmount()
        );
        $order->setShippingTaxInvoiced($order->getShippingTaxInvoiced() - $invoice->getShippingTaxAmount());
        $order->setBaseShippingTaxInvoiced($order->getBaseShippingTaxInvoiced() - $invoice->getBaseShippingTaxAmount());

        $order->setShippingInvoiced($order->getShippingInvoiced() - $invoice->getShippingAmount());
        $order->setBaseShippingInvoiced($order->getBaseShippingInvoiced() - $invoice->getBaseShippingAmount());

        $order->setDiscountInvoiced($order->getDiscountInvoiced() - $invoice->getDiscountAmount());
        $order->setBaseDiscountInvoiced($order->getBaseDiscountInvoiced() - $invoice->getBaseDiscountAmount());
        $order->setBaseTotalInvoicedCost($order->getBaseTotalInvoicedCost() - $invoice->getBaseCost());

        $method = $order->getPayment()->getMethodInstance()->getTitle();
        //$codTitle = $this->_dataHelper->getCodPaymentTitle();
        //if ($method == '') {
            $order->setTotalPaid($order->getTotalPaid() - $invoice->getGrandTotal());
            $order->setBaseTotalPaid($order->getBaseTotalPaid() - $invoice->getBaseGrandTotal());
        //}
        // delete invoice info
        $connection->rawQuery('DELETE FROM `'.$invoiceGridTable.'` WHERE entity_id='.$invoiceId);
        $connection->rawQuery('DELETE FROM `'.$invoiceTable.'` WHERE entity_id='.$invoiceId);
        $order->save();
        return true;
    }
}
