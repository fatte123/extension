<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Helper;

use Eighteen\Core\Logger\Logger;
use \Magento\Framework\App\Helper\AbstractHelper;
use Eighteen\OrderItemRto\Model\SalesOrderCreditMemoFactory;
use Eighteen\OrderItemRto\Model\SalesOrderCreditMemoItemFactory;
use Magento\Framework\App\ResourceConnection;
use Eighteen\OrderItemRto\Helper\DeleteInvoice;
use Magento\Sales\Api\CreditmemoRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

// phpcs:disable Generic.Files.LineLength
class OrderItemCreditMemo extends AbstractHelper
{
    /**
     * @var Logger
     */
    protected $_logger;
    
    /**
     * @var \Magento\Sales\Api\CreditmemoManagementInterface
     */
    protected $creditmemoManagement;
    
    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender
     */
    protected $creditmemoSender;
    
    /**
     * @var \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader
     */
    protected $creditmemoLoader;

    /**
     * @var deleteInvoiceHelper
     */
    protected $deleteInvoiceHelper;

    protected $_orderRepository;

    protected $_transaction;

    protected $_invoiceService;

    protected $_resourceConnection;

    protected $orderId;

    protected $cancelQtyArray;

    protected $refundQtyArray;

    protected $memoType;

    protected $cancelBy;

    protected $helperGupshup;

    protected $customerRepository;

    protected $salesOrderCreditMemo;

    protected $salesOrderCreditMemoItem;

    protected $state;

    /**
     * @var CreditmemoRepositoryInterface
     */
    private $creditmemoRepository;

    protected $invoiceItemFactory;

    public function __construct(
        Logger $logger,
        SalesOrderCreditMemoFactory $salesOrderCreditMemo,
        SalesOrderCreditMemoItemFactory $salesOrderCreditMemoItem,
        \Magento\Sales\Api\CreditmemoManagementInterface $creditmemoManagement,
        \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender $creditmemoSender,
        \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader $creditmemoLoader,
        DeleteInvoice $deleteInvoiceHelper,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\Transaction $transaction,
        ResourceConnection $resourceConnection,
        CreditmemoRepositoryInterface $creditmemoRepository,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Sales\Model\Order\Invoice\ItemFactory $invoiceItemFactory,
        \Magento\Framework\App\State $state
    ) {
        $this->_logger = $logger;
        $this->salesOrderCreditMemo = $salesOrderCreditMemo;
        $this->salesOrderCreditMemoItem = $salesOrderCreditMemoItem;
        $this->creditmemoManagement = $creditmemoManagement;
        $this->creditmemoSender = $creditmemoSender;
        $this->creditmemoLoader = $creditmemoLoader;
        $this->deleteInvoiceHelper = $deleteInvoiceHelper;
        $this->_orderRepository = $orderRepository;
        $this->_invoiceService = $invoiceService;
        $this->_transaction = $transaction;
        $this->_resourceConnection = $resourceConnection;
        $this->creditmemoRepository = $creditmemoRepository;
        $this->customerRepository = $customerRepository;
        $this->invoiceItemFactory = $invoiceItemFactory;
        $this->state = $state;
        $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_CREDITMEMO_LOG_FILE);
    }

    /**
     * Init cancal process
     */
    public function initCreateCreditMemo()
    {
        try {
            $invoiceFound = false;
            $response = false;
            $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_CREDITMEMO_LOG_FILE);
            $collections = $this->getCollection();
            if ($collections->getSize() > 0) {
                $this->_logger->writeLog("Found 1 order(s).");
                $creditmemoArray = $this->prepareCreditMemoArray($collections);
                $this->_logger->writeLog("creditmemoArray ".json_encode($creditmemoArray));
                foreach ($creditmemoArray as $orderid => $creditmemoData) {
                    $this->orderId  = $orderid;
                    $order = $this->setCancelQtyNull($orderid, $creditmemoData);
                    $invoiceFound = $this->checkIfInvoiceAlreadyCreated($order, $creditmemoData);
                    if ($invoiceFound) {
                        $response = $this->prepareCreateCreditMemo($creditmemoData);
                    } else {
                        $invoiceId = $this->createCreditMemoInvoice($creditmemoData);
                        if ($invoiceId) {
                            $this->updateTempInvoiceId($this->orderId, $invoiceId, $collections);
                            $response = $this->prepareCreateCreditMemo($creditmemoData, $invoiceId);
                        }
                    }
                    if ($response) {
                        $this->updateCreditMemoStatus($this->orderId, $response, $collections);
                    }
                    //update refund/cancel qty
                    $this->resetCancelAndRefundQty($this->orderId);
                    //update attempt count
                    $this->appendAttemptCount($collections);
                }
            } else {
                $this->_logger->writeLog("Found 0 order(s).");
            }
        } catch (\Exception $e) {
            $this->_logger->writeLog($e->getMessage());
        }
    }

    public function checkIfInvoiceAlreadyCreated($order, $creditmemoData)
    {
        $invoiceFound = false;
        foreach ($order->getAllVisibleItems() as $item) {
            foreach ($creditmemoData as $sku => $qty) {
                if ($item->getSku() == $sku){
                    $orderItemId = $item->getItemId();
                    break;
                }
            }
        }
        $invoiceCollection = $this->invoiceItemFactory->create()->getCollection()->addFieldToFilter('order_item_id', $orderItemId);
        if ($invoiceCollection->getSize() > 0) {
            $invoiceFound = true;
        }
        return $invoiceFound;
    }

    /**
     * To get collection data
     * @return Object
     */
    public function getCollection()
    {
        $failedAttempt = OrderItemRtoConstant::CREDITMEMO_FAILED_COUNT;
        $collection = $this->salesOrderCreditMemo->create()->getCollection()
            ->addFieldToFilter('status', OrderItemRtoConstant::ORDERITEM_PENDING_STATUS)->addFieldToFilter('process_count', ['lt'=>$failedAttempt])->setPageSize(1)->setCurPage(1);
        return $collection;
    }

    public function resetCancelAndRefundQty($orderId)
    {
        if ($orderId) {
            $order = $this->getOrderDataById($orderId);
            $this->_logger->writeLog("Init resetCancelAndRefundQty");
            //cancel case
            foreach ($order->getAllVisibleItems() as $itemData) {
                foreach ($this->cancelQtyArray as $sku => $qty) {
                    if ($itemData->getSku() == $sku) {
                        $this->_logger->writeLog("reset item {$sku} with cancel qty {$qty}");
                        $itemData->setQtyCanceled($qty);
                        $itemData->save();
                    }
                }
            }
        }
    }

    public function setCancelQtyNull($orderid, $creditmemoData)
    {
        $order = $this->getOrderDataById($orderid);
        $orderRecievedStatus = 'order_received';
        $newState = 'new';
        $this->_logger->writeLog("Order status : {$order->getStatus()}");
        if ($order->getStatus() == 'closed' || $order->getStatus() == 'canceled' || $order->getState() == 'canceled') {
            $this->_logger->writeLog("Updating order status closed to received");
            $order->setStatus($orderRecievedStatus);
            $order->setState($newState);
            $order->save();
        }
        $cancelArray = $this->prepareCancelArray($creditmemoData);
        foreach ($order->getAllVisibleItems() as $itemData) {
            foreach ($cancelArray as $sku => $qty) {
                if ($itemData->getSku() == $sku) {
                    $this->cancelQtyArray[$sku] = $itemData->getQtyCanceled();
                    $itemData->setQtyCanceled(0);
                    $itemData->save();
                }
            }
        }
        $this->_logger->writeLog("Reset Cancel Array :".json_encode($this->cancelQtyArray));
        $this->_logger->writeLog("Reset Return Array :".json_encode($this->refundQtyArray));
        return $order;
    }
     
    /**
     * To update attempt count
     * @return Object
     */
    public function appendAttemptCount($collections)
    {
        $this->_logger->writeLog("Init Update process count");
        foreach ($collections as $collection) {
            $previousAttempt = $collection->getProcessCount();
            $collection->setProcessCount($previousAttempt + 1);
            $collection->save();
        }
    }

    public function prepareCreditMemoArray($collections)
    {
        $defaultValue = null;
        $creditmemoArray = [];
        $this->_logger->writeLog("Init delete temp invoice if created.");
        foreach ($collections as $collection) {
            $this->_logger->writeLog("Entity Id".$collection->getEntityId());
            $this->memoType = $collection->getType();
            $this->cancelBy = $collection->getCancelBy();
            $itemCollection = $this->salesOrderCreditMemoItem->create()->getCollection()
            ->addFieldToFilter('parent_id', $collection->getEntityId());
            foreach ($itemCollection as $creditmemoItem) {
                $creditmemoArray[$collection->getOrderId()][$creditmemoItem->getSku()][] = $creditmemoItem->getQty();
            }
            if($collection->getTempInvoiceId() != null) {
                $this->deleteInvoiceHelper->deleteInvoice($collection->getTempInvoiceId(), $this->_logger);
                $this->_logger->writeLog("Temp invoice Id {$collection->getTempInvoiceId()} deleted.");
                $collection->setTempInvoiceId($defaultValue);
                $collection->save();
            }
        }
        return $creditmemoArray;
    }

    public function prepareCancelArray($creditmemoData)
    {
        $cancelArray = [];
        foreach ($creditmemoData as $sku => $value) {
            foreach ($value as $key => $qty) {
                if (array_key_exists($sku,$cancelArray)){
                    $oldQty = $cancelArray[$sku];
                    $cancelArray[$sku] = $oldQty + $qty;
                } else {
                    $cancelArray[$sku] = $qty;
                }
            }
        }
        return $cancelArray;
    }

    public function createCreditMemoInvoice($creditmemoData)
    {
        $this->_logger->writeLog("INIT createCreditMemoInvoice");
        $this->_logger->writeLog("creditmemoData ".json_encode($creditmemoData));
        $cancelArray = $this->prepareCancelArray($creditmemoData);
        $this->_logger->writeLog("cancelArray ".json_encode($cancelArray));
        $calucateTotal = 0;
        $discountTotal = 0;
        $invoiceItems = [];
        $order = $this->getOrderDataById($this->orderId);
        if ($order) {
            foreach ($order->getAllVisibleItems() as $itemData) {
                foreach ($cancelArray as $sku => $qty) {
                    if ($itemData->getSku() == $sku) {
                        $itemPrice = $itemData->getRowTotal()/$itemData->getQtyOrdered();
                        $itemDiscount = round($itemData->getDiscountAmount()/$itemData->getQtyOrdered(), 2);
                        $discountTotal = $discountTotal + $itemDiscount * (int)$qty;
                        $totalPrice = $itemPrice * (int)$qty;
                        $calucateTotal = $calucateTotal + $totalPrice;
                        $invoiceItems[$itemData->getItemId()] = (int)$qty;
                    }
                }
            }
        }
        $this->_logger->writeLog("invoiceItems ".json_encode($invoiceItems));
        if ($invoiceItems) {
            try {
                $invoice = $this->_invoiceService->prepareInvoice($order, $invoiceItems);
                $grandTotal = $calucateTotal  - $discountTotal;
                $baseGrandTotal = $calucateTotal - $discountTotal;
                $invoice->setSubtotal($calucateTotal);
                $invoice->setBaseSubtotal($calucateTotal);
                $invoice->setGrandTotal($grandTotal);
                $invoice->setBaseGrandTotal($baseGrandTotal);
                $invoice->register();

                $transactionSave = $this->_transaction->addObject(
                    $invoice
                )->addObject(
                    $invoice->getOrder()
                );
                $transactionSave->save();
                $this->_logger->writeLog("Invoice Created {$invoice->getId()}");
                $order->setTotalPaid($order->getGrandTotal());
                $order->save();
                return $invoice->getId();

            } catch (\Exception $e) {
                $this->_logger->writeLog($e->getMessage());
                return false;
            }
        }
        return false;
    }

    public function updateTempInvoiceId($orderId, $invoiceId, $collection)
    {
        $this->_logger->writeLog("Updating temp invoice ID in creditmemo items with order Id {$orderId}");
        foreach ($collection as $creditmemo) {
            $creditmemo->setTempInvoiceId($invoiceId);
            $creditmemo->save();
        }
        $this->_logger->writeLog("Updated Temp Invoice Id {$invoiceId}");
        return $collection;
    }

    public function getOrderDataById($orderId)
    {
        if ($orderId) {
            $order = $this->_orderRepository->get($orderId);
            return $order;
        }
        return false;
    }

    public function prepareCreateCreditMemo($creditmemoData, $invoiceId = null)
    {
        $refundOffline = false;
        $order = $this->getOrderDataById($this->orderId);
        $cancelArray = $this->prepareCancelArray($creditmemoData);
        foreach ($order->getAllVisibleItems() as $itemData) {
            foreach ($cancelArray as $sku => $qty) {
                if ($itemData->getSku() == $sku) {
                    $orderItemData[$itemData->getItemId()] = ['qty'=> (int)$qty];
                }
            }
        }
        $this->_logger->writeLog("Refund Order Data :".json_encode($orderItemData));
        $method = $order->getPayment()->getMethodInstance()->getTitle();
        if ($invoiceId == null) {
            $refundOffline = true;
            $creditmemoResponse = $this->createCreditMemo($order, $orderItemData, $refundOffline);
        } else {
            $creditmemoResponse = $this->createCreditMemo($order, $orderItemData, $refundOffline, $invoiceId);
        }
        return $creditmemoResponse;
    }

    /**
     * Init Create consignment credit memo
     * @return Object
     */
    public function createCreditMemo($order, $orderItemData, $refundOffline, $invoiceId = null)
    {
        $orderId = $order->getId();
        $this->_logger->writeLog("CreditMemo initiated for orderId #".$orderId."");
        $creditMemoData = [];
        $creditMemoData['do_offline'] = 1;
        $creditMemoData['refund_customerbalance_return_enable'] = 0;
        $creditMemoData['adjustment_positive'] = 0;
        $creditMemoData['adjustment_negative'] = 0;
        $creditMemoData['shipping_amount'] = 0;
        $creditMemoData['comment_text'] = 'CreditMemo created';
        $creditMemoData['send_email'] = 0;
        $creditMemoData['items'] = $orderItemData;
        try {
            $this->creditmemoLoader->setOrderId($orderId); //pass order id
            $this->creditmemoLoader->setCreditmemo($creditMemoData);
            if ($refundOffline == false) {
                $this->_logger->writeLog("Invoice Id {$invoiceId}");
                $this->creditmemoLoader->setInvoiceId($invoiceId);
            }

            $creditmemo = $this->creditmemoLoader->load();
            if ($creditmemo) {
                $this->_logger->writeLog('load creditmemo');
                if (!$creditmemo->isValidGrandTotal()) {
                    $this->_logger->writeLog('The credit memo\'s total must be positive.');
                }

                if (!empty($creditMemoData['comment_text'])) {
                    $creditmemo->addComment(
                        $creditMemoData['comment_text'],
                        isset($creditMemoData['comment_customer_notify']),
                        isset($creditMemoData['is_visible_on_front'])
                    );

                    $creditmemo->setCustomerNote($creditMemoData['comment_text']);
                    $creditmemo->setCustomerNoteNotify(isset($creditMemoData['comment_customer_notify']));
                }
                $creditmemo->getOrder()->setCustomerNoteNotify(!empty($creditMemoData['send_email']));
                if ($this->memoType == 'return') {
                    $return = 1;
                    $creditmemo->setCreditmemoType($return);
                } else {
                    $cancel = 0;
                    $creditmemo->setCreditmemoType($cancel);
                }
                if ($this->cancelBy == 1 || $this->cancelBy == 2) {
                    $creditmemo->setCancelBy($this->cancelBy);
                }
                $offline = true;
                $this->creditmemoManagement->refund($creditmemo, (bool)$offline);
                $this->_logger->writeLog("CreditMemo created successfully");
                return $creditmemo->getEntityId();
            }
            return false;
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->_logger->writeLog($e->getMessage());
            return false;
        } catch (\Exception $e) {
            $this->_logger->writeLog($e->getMessage());
            return false;
        }
    }

    public function updateCreditMemoStatus($orderId, $creditmemoId, $collection)
    {
        foreach ($collection as $creditmemo) {
            $itemCollection = $this->salesOrderCreditMemoItem->create()->getCollection()
            ->addFieldToFilter('parent_id', $creditmemo->getEntityId());
            $creditmemo->setStatus(OrderItemRtoConstant::ORDERITEM_COMPLETED_STATUS);
            $creditmemo->save();
            $this->_logger->writeLog("Update credit memo status to completed with order Id {$orderId}");
            foreach ($itemCollection as $creditmemoItem) {
                $creditmemoItem->setCreditmemoId($creditmemoId);
                $creditmemoItem->save();
                $this->_logger->writeLog("Updated CreditMemo Order Item's creditmemo_id {$creditmemoId}");
            }
        }
        return $collection;
    }

    /**
     * To get resource connection
     * @return Object
     */
    private function getResourceConn()
    {
        return $this->_resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
    }
}
