<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Helper;

use Eighteen\OrderItemRto\Helper\OrderItemRtoConstant;
use Eighteen\Core\Logger\Logger;
use \Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Eighteen\OrderItemRto\Model\SalesOrderRtoFactory;
use Eighteen\OrderItemRto\Model\SalesOrderRtoItemFactory;
use Eighteen\OrderItemRto\Model\SalesOrderCreditMemoFactory;
use Eighteen\OrderItemRto\Model\SalesOrderCreditMemoItemFactory;

// phpcs:disable Generic.Files.LineLength
class OrderItemCancel extends AbstractHelper
{

    protected $orderId;

    protected $rtoId;
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;
    
    /**
     * @var SalesOrderRtoFactory
     */
    protected $salesOrderRtoFactory;
    
    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @var SalesOrderRtoItemFactory
     */
    protected $salesOrderRtoItemFactory;
    
    /**
     * @var SalesOrderCreditMemoFactory
     */
    protected $salesOrderCreditMemoFactory;
    
    /**
     * @var SalesOrderCreditMemoItemFactory
     */
    protected $salesOrderCreditMemoItemFactory;

    /**
     * @var Curl
     */
    protected $curl;

    /**
     * @param Logger $logger
     * @param TimezoneInterface $timezone
     **/
    public function __construct(
        Logger $logger,
        SalesOrderRtoFactory $salesOrderRtoFactory,
        SalesOrderRtoItemFactory $salesOrderRtoItemFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        SalesOrderCreditMemoFactory $salesOrderCreditMemoFactory,
        SalesOrderCreditMemoItemFactory $salesOrderCreditMemoItemFactory,
        \Magento\Framework\HTTP\Client\Curl $curl,
        TimezoneInterface $timezone
    ) {
        $this->_logger = $logger;
        $this->salesOrderRtoFactory = $salesOrderRtoFactory;
        $this->salesOrderRtoItemFactory = $salesOrderRtoItemFactory;
        $this->orderRepository = $orderRepository;
        $this->salesOrderCreditMemoFactory = $salesOrderCreditMemoFactory;
        $this->salesOrderCreditMemoItemFactory = $salesOrderCreditMemoItemFactory;
        $this->curl = $curl;
        $this->timezone = $timezone;
        $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_RTO_LOG_FILE);
    }

    public function initCancelRto($rtoId = '')
    {
        try {
            $collections = $this->getCollection($rtoId ?? '');
            $this->_logger->writeLog("Found {$collections->getSize()} rto(s).");
            if ($collections->getSize() > 0) {
                foreach ($collections as $collection) {
                    $this->orderId = $collection->getOrderId();
                    $this->rtoId  = $collection->getEntityId();
                    $this->_logger->writeLog("Creating RTO Cancel for rto Id {$this->rtoId}");
                    $rtoItemData = $this->getPendingRtoItem($collection->getEntityId());
                    foreach ($rtoItemData as $rtoItem) {
                         $this->_logger->writeLog("Found status {$rtoItem->getRtoItemStatus()} for rto Item {$rtoItem->getEntityId()}");
                        $this->initCancelRtoItemProcess($rtoItem, $this->orderId, $this->rtoId);
                    }
                    $this->updateRtoStatus($this->rtoId);
                }
            }
        } catch (\Exception $e) {
            $this->_logger->writeLog($e->getMessage());
        }
    }

    public function getCollection($rtoId = '')
    {
        $collection = $this->salesOrderRtoFactory->create()->getCollection()->addFieldToFilter('status', OrderItemRtoConstant::ORDERITEM_PENDING_STATUS);
        if ($rtoId) {
            $collection->addFieldToFilter('entity_id', $rtoId);
        }
        return $collection;
    }

    public function getPendingRtoItem($rtoId)
    {
        $collection = $this->salesOrderRtoItemFactory->create()->getCollection()
            ->addFieldToFilter('parent_id', $rtoId)->addFieldToFilter('rto_item_status', ['neq' => OrderItemRtoConstant::ORDERITEM_COMPLETED_STATUS]);
        return $collection;
    }

    public function initCancelRtoItemProcess($rtoItem, $orderId, $rtoId)
    {
        switch ($rtoItem->getRtoItemStatus()) {
            case "pending":
                $updateOrderResponse = $this->updateOrderItem($rtoItem, $orderId);
                if ($updateOrderResponse) {
                    $creditmemoResponse = $this->addCancelCreditMemoQueue($rtoItem, $orderId, $rtoId);
                    if($creditmemoResponse == true) {
                        $this->updateRtoItemCompleteStatus($rtoItem);
                    }
                }
                break;
            case 'update_order_item':
                $creditmemoResponse = $this->addCancelCreditMemoQueue($rtoItem, $orderId, $rtoId);
                if($creditmemoResponse == true) {
                    $this->updateRtoItemCompleteStatus($rtoItem);
                }
                break;
            case 'update_order_item_failed':
                $updateOrderResponse = $this->updateOrderItem($rtoItem, $orderId);
                if ($updateOrderResponse) {
                    $creditmemoResponse = $this->addCancelCreditMemoQueue($rtoItem, $orderId, $rtoId);
                    if($creditmemoResponse == true) {
                        $this->updateRtoItemCompleteStatus($rtoItem);
                    }
                }
                break;
            case 'save_queue_creditmemo':
                $this->updateRtoItemCompleteStatus($rtoItem);
                break;
            case 'save_queue_creditmemo_failed':
                $creditmemoResponse = $this->addCancelCreditMemoQueue($rtoItem, $orderId, $rtoId);
                if($creditmemoResponse == true) {
                    $this->updateRtoItemCompleteStatus($rtoItem);
                }
                break;
            default:
                $this->updateRtoItemCompleteStatus($rtoItem);
        }
    }

    public function getOrderDataById($orderId)
    {
        if ($orderId) {
            $order = $this->orderRepository->get($orderId);
            return $order;
        }
        return false;
    }

    public function updateOrderItem($rtoItem, $orderId)
    {
        try {
            $rtoItem = $this->getRtoItemDataById($rtoItem->getEntityId());
            $this->_logger->writeLog("init updateOrderItem()");
            $order = $this->getOrderDataById($orderId);
            foreach ($order->getAllItems() as $item) {
                if ($item->getItemId() == $rtoItem->getItemId() || $item->getParentItemId() == $rtoItem->getItemId()) {
                    $cancelQty = $item->getQtyCanceled();
                    $updatedCancelQty = $cancelQty + $rtoItem->getQty();
                    $this->_logger->writeLog("Updating Order Item {$item->getItemId()} cancelQty to {$updatedCancelQty}");
                    $item->setQtyCanceled($updatedCancelQty);
                    $item->save();
                }
            }
            $this->_logger->writeLog("Updated Rto Item Status {$rtoItem->getEntityId()} - update_order_item");
            $rtoItem->setRtoItemStatus('update_order_item');
            $rtoItem->save();
            return true;
        } catch (\Exception $e) {
            $this->_logger->writeLog($e->getMessage());
            $this->_logger->writeLog("Updated Rto Item Status {$rtoItem->getEntityId()} - update_order_item_failed");
            $rtoItem->setRtoItemStatus('update_order_item_failed');
            $rtoItem->save();
            return false;
        }
    }

    public function addCancelCreditMemoQueue($rtoItem, $orderId, $rtoId)
    {
        try {
            $rtoItem = $this->getRtoItemDataById($rtoItem->getEntityId());
            $cancelCreditMemoOrder = $this->salesOrderCreditMemoFactory->create()->getCollection()->addFieldToFilter("order_id", $orderId)->addFieldToFilter('status', OrderItemRtoConstant::ORDERITEM_PENDING_STATUS)->getFirstItem();
            if ($cancelCreditMemoOrder->getEntityId()) {
                $creditMemoId = $cancelCreditMemoOrder->getEntityId();
            } else {
                $cancelCreditMemoModel = $this->salesOrderCreditMemoFactory->create();
                $cancelCreditMemoModel->setData("order_id", $orderId);
                $cancelCreditMemoModel->setData("type", OrderItemRtoConstant::CREDITMEMO_CANCEL_TYPE);
                $cancelCreditMemoModel->setData("status", OrderItemRtoConstant::ORDERITEM_PENDING_STATUS);
                $cancelCreditMemoModel->setData("rto_rtv_id", $rtoId);
                //$cancelCreditMemoModel->setData("cancel_by", $rtoItem->getCancelBy());
                $cancelCreditMemoModel->save();
                $creditMemoId = $cancelCreditMemoModel->getEntityId();
            }
            $cancelCreditMemoItemModel = $this->salesOrderCreditMemoItemFactory->create();
            $cancelCreditMemoItemModel->setData("parent_id", $creditMemoId);
            $cancelCreditMemoItemModel->setData("sku", $rtoItem->getSku());
            $cancelCreditMemoItemModel->setData("qty", $rtoItem->getQty());
            $cancelCreditMemoItemModel->save();
            $rtoItem->setRtoItemStatus('save_queue_creditmemo');
            $rtoItem->save();
            $this->_logger->writeLog("Updated Rto Status - save_queue_creditmemo");
            return true;
        } catch (\Exception $e) {
            $this->_logger->writeLog($e->getMessage());
            $rtoItem->setRtoItemStatus('save_queue_creditmemo_failed');
            $rtoItem->save();
            $this->_logger->writeLog("Updated Rto Status - save_queue_creditmemo_failed");
            return false;
        }
        return true;
    }

    public function getRtoItemDataById($itemId)
    {
        $rtoItem = $this->salesOrderRtoItemFactory->create()->getCollection()
            ->addFieldToFilter('entity_id', $itemId)->getFirstItem();
        return $rtoItem;
    }

    public function updateRtoItemCompleteStatus($rtoItem)
    {
        $rtoItem->setRtoItemStatus(OrderItemRtoConstant::ORDERITEM_COMPLETED_STATUS);
        $rtoItem->save();
        $this->_logger->writeLog("Updated Rto Item{$rtoItem->getEntityId()} to completed");
    }

    public function updateRtoStatus($rtoId)
    {
        $rtoCollection = $this->salesOrderRtoFactory->create()->getCollection()->addFieldToFilter('entity_id', $rtoId)->getFirstItem();
        $itemPending = false;
        $rtoItemCollection = $this->salesOrderRtoItemFactory->create()->getCollection()
            ->addFieldToFilter('parent_id', $rtoId);
        foreach ($rtoItemCollection as $rtoItem) {
            if ($rtoItem->getRtoItemStatus() != 'completed') {
                $itemPending = true;
            }
        }
        if ($itemPending == false) {
            $rtoCollection->setData('status', OrderItemRtoConstant::ORDERITEM_COMPLETED_STATUS);
            $rtoCollection->save();
            $this->_logger->writeLog("Updated RTO status for {$rtoCollection->getEntityId()} to completed.");
        }

    }

    public function addCancelOrderRtoEntry($orderId)
    {
        $orderRtoModel = $this->salesOrderRtoFactory->create();
        $orderRtoModel->setData("order_id", $orderId);
        $orderRtoModel->setData("status", OrderItemRtoConstant::ORDERITEM_PENDING_STATUS);
        $orderRtoModel->save();
        $this->_logger->writeLog("Created RTO with Id {$orderRtoModel->getEntityId()}");
        return $orderRtoModel->getEntityId();
    }

    public function addCancelOrderRtoItemEntry($rtoId, $order, $cancelArray, $customerCancel = true)
    {
        $this->_logger->writeLog("init addCancelOrderRtoItemEntry()");
        $this->_logger->writeLog(print_r($cancelArray, true));
        foreach ($order->getAllVisibleItems() as $_item) {
            foreach ($cancelArray as $sku => $qty) {
                if ($_item->getSku() == $sku) {
                    if ($_item->getParentItemId()):
                        continue;
                    endif;
                    $orderRtoItemModel = $this->salesOrderRtoItemFactory->create();
                    $orderRtoItemModel->setData("parent_id", $rtoId);
                    $orderRtoItemModel->setData("sku", $sku);
                    $orderRtoItemModel->setData("qty", $qty);
                    $orderRtoItemModel->setData("item_id", $_item->getItemId());
                    $orderRtoItemModel->setData("rto_item_status", OrderItemRtoConstant::ORDERITEM_PENDING_STATUS);
                    $cancelBy = ($customerCancel) ? 0 : 1;
                    $orderRtoItemModel->setData('cancel_by' , $cancelBy);
                    $orderRtoItemModel->save();
                }                    
            }
        }
    }

}