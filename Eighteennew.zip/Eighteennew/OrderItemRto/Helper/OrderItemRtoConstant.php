<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Helper;

class OrderItemRtoConstant
{
    const ORDERITEM_RTO_LOG_FILE = "orderItem_rto";
    const ORDERITEM_PENDING_STATUS = "pending";
    const ORDERITEM_COMPLETED_STATUS = "completed";
    const ORDERITEM_CANCELED_STATUS = "canceled";
    const CREDITMEMO_CANCEL_TYPE = "cancel";
    const ORDERITEM_CREDITMEMO_LOG_FILE = 'orderItem_creditmemo';
    const CREDITMEMO_FAILED_COUNT = 3;
}
