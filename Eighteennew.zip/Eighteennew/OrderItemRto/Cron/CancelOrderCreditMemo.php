<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */

namespace Eighteen\OrderItemRto\Cron;

use Eighteen\OrderItemRto\Helper\OrderItemRtoConstant;
use Eighteen\Core\Logger\Logger;
use Eighteen\OrderItemRto\Helper\OrderItemCreditMemo;

class CancelOrderCreditMemo
{

    /**
     * @var OrderItemCreditMemo
     */
    protected $creditmemoHelper;
    
    /**
     * @var Logger
     */
    protected $_logger;
    
    /**
     * @param Logger $logger
     * @param OrderItemCreditMemo $creditmemoHelper
     */
    public function __construct(
        Logger $logger,
        OrderItemCreditMemo $creditmemoHelper
    ) {
        $this->_logger = $logger;
        $this->creditmemoHelper = $creditmemoHelper;
    }
    
    /**
     * Execute cron method
     */
    public function execute()
    {
        $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_CREDITMEMO_LOG_FILE);
        $this->_logger->writeLog('----------------------------');
        $this->_logger->writeLog('Cron - Initilize Cancel CreditMemo process');
        $this->_logger->writeLog('----------------------------');
        $this->creditmemoHelper->initCreateCreditMemo();
        $this->_logger->writeLog('------------------------------');
        $this->_logger->writeLog('Cron - Cancel CreditMemo process end');
        $this->_logger->writeLog('------------------------------');
       
        return true;
    }
}
