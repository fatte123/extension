<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */

namespace Eighteen\OrderItemRto\Cron;

use Eighteen\OrderItemRto\Helper\OrderItemRtoConstant;
use Eighteen\Core\Logger\Logger;
use Eighteen\OrderItemRto\Helper\OrderItemCancel;

class CancelOrderRto
{

    /**
     * @var OrderItemCancel
     */
    protected $_cancelRtoHelper;
    
    /**
     * @var Logger
     */
    protected $_logger;
    
    /**
     * @param Logger $logger
     * @param OrderItemCancel $cancelRtoHelper
     */
    public function __construct(
        Logger $logger,
        OrderItemCancel $cancelRtoHelper
    ) {
        $this->_logger = $logger;
        $this->_cancelRtoHelper = $cancelRtoHelper;
    }
    
    /**
     * Execute cron method
     */
    public function execute()
    {
        $this->_logger->initLog(OrderItemRtoConstant::ORDERITEM_RTO_LOG_FILE);
        $this->_logger->writeLog('----------------------------');
        $this->_logger->writeLog('Cron - Initilize Cancel Rto process');
        $this->_logger->writeLog('----------------------------');
        $this->_cancelRtoHelper->initCancelRto();
        $this->_logger->writeLog('------------------------------');
        $this->_logger->writeLog('Cron - Cancel Rto process end');
        $this->_logger->writeLog('------------------------------');
       
        return true;
    }
}
