<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Controller\Adminhtml\CreditMemo;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Eighteen\OrderItemRto\Model\SalesOrderCreditMemoFactory;

class View extends Action
{
    public const ADMIN_RESOURCE = 'Eighteen_OrderItemRto:actions_view';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory = false;
    
    /**
     * @var SalesOrderCreditMemoFactory
     */
    protected $salesOrderCreditMemoFactory;

    /**
     * @var _coreRegistry
     */
    protected $_coreRegistry = null;
   
    /**
     * @var commonHelper
     */
    protected $commonHelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param SalesOrderCreditMemoFactory $salesOrderCreditMemoFactory
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        SalesOrderCreditMemoFactory $salesOrderCreditMemoFactory,
        \Magento\Framework\Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->salesOrderCreditMemoFactory = $salesOrderCreditMemoFactory;
        $this->_coreRegistry = $coreRegistry;
    }

    /**
     * Exeute method
     *
     * @return array
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultRedirect = $this->resultRedirectFactory->create();
        $creditMemoId = $this->getRequest()->getParam('entity_id');
        
        if ($creditMemoId) {
          try{
            $creditMemo = $this->salesOrderCreditMemoFactory->create()->getCollection()->addFieldToFilter('entity_id', $creditMemoId)->getFirstItem();
            if(!($creditMemo->getEntityId())){
              $this->messageManager->addErrorMessage(__('This CreditMemo no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/creditmemo/', ['_current' => true]);
            }
          } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('This CreditMemo no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/creditmemo/', ['_current' => true]);
          }
            $resultPage->getConfig()->getTitle()->prepend((__('CreditMemo Id #%1', $creditMemo->getEntityId())));
            $this->_coreRegistry->register('msh_creditmemo_order', $creditMemo);
            return $resultPage;
        } else {
            $this->messageManager->addErrorMessage(__('CreditMemo no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/creditmemo/', ['_current' => true]);
        }
    }

     /**
      * Allow modules
      *
      * @return Int
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eighteen_OrderItemRto::viewrtogrid');
    }
}
