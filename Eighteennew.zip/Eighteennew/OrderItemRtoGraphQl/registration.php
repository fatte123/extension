<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRtoGraphQl
 */
 
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Eighteen_OrderItemRtoGraphQl', __DIR__);
