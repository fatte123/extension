<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRtoGraphQl
 */
declare(strict_types=1);

namespace Eighteen\OrderItemRtoGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\GraphQl\Helper\Error\AggregateExceptionMessageFormatter;
use Eighteen\Core\Logger\Logger;

// phpcs:disable Generic.Files.LineLength
class CancelItems implements ResolverInterface
{
    /**
     * @var curl
     */
    protected $curl;

     /**
      * @var jsonSerializer
      */
    protected $jsonSerializer;

    /**
     * @var orderItemCancel
     */
    protected $orderItemCancel;

    /**
     * @var _logger
     */
    protected $_logger;

     /**
      * @param Logger $logger
      * @param \Magento\Framework\HTTP\Client\Curl $curl
      * @param \Magento\Framework\Serialize\Serializer\Json $jsonSerializer
      * @param \Eighteen\OrderItemRto\Model\OrderItemCancel $orderItemCancel
      * @return array|\Magento\Framework\GraphQl\Query\Resolver\Value|mixed
      * @throws GraphQlInputException
      */
    public function __construct(
        Logger $logger,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Framework\Serialize\Serializer\Json $jsonSerializer,
        \Eighteen\OrderItemRto\Model\OrderItemCancel $orderItemCancel
    ) {
        $this->_logger = $logger;
        $this->curl = $curl;
        $this->jsonSerializer = $jsonSerializer;
        $this->orderItemCancel = $orderItemCancel;
    }

    /**
     * @inheritdoc
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $result['message'] = "";
        $orderItemCancelOrderIds = [];
        $orderItemCancelArray = [];
        $response = "";

        $this->_logger->initLog("orderitem_rto");
        $this->_logger->writeLog('*** Start order item rto log ***');

        try {

            if (!isset($args['orderId']) || empty($args['orderId'])) {
                throw new GraphQlInputException(__('Invalid parameter list.'));
            }
            
            $this->_logger->writeLog('Order id :'.$args['orderId']);
            $orderItemCancelOrderIds['orderId'] = $args['orderId'];

            if (!empty($args['input'])) {
                foreach ($args['input'] as $items) {
                    //$this->_logger->writeLog('items array :'.print_r($items,true));
                    $orderItemCancelArray[$items['sku']] = $items['qtyCancel'];
                }

                $orderItemCancelOrderIds['cancelItems'] = $orderItemCancelArray;
                $response = $this->orderItemCancel->cancelOrderItems($orderItemCancelOrderIds);
                $response = 1;
            }

            $this->_logger->writeLog('Response :'.$response);

            if ($response == 1) {
                //$result['status'] = $response;
                $result['message'] = "Cancellation request has been accepted.";
                return $result;
            } else {
                throw new GraphQlInputException(__("Order is in transit. Hence cancellation can not happen."));
            }

        } catch (\Exception $e) {
            throw new GraphQlInputException(__($e->getMessage()), $e);
        }
    }
}
