<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Controller\Adminhtml\RtoHistory;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Eighteen\OrderItemRto\Model\SalesOrderRtoItemFactory;

class View extends Action
{
    public const ADMIN_RESOURCE = 'Eighteen_OrderItemRto:actions_view';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory = false;
    
    /**
     * @var SalesOrderRtoItemFactory
     */
    protected $salesOrderRtoItemFactory;

    /**
     * @var _coreRegistry
     */
    protected $_coreRegistry = null;
   
    /**
     * @var commonHelper
     */
    protected $commonHelper;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param SalesOrderRtoItemFactory $salesOrderRtoItemFactory
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        SalesOrderRtoItemFactory $salesOrderRtoItemFactory,
        \Magento\Framework\Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->salesOrderRtoItemFactory = $salesOrderRtoItemFactory;
        $this->_coreRegistry = $coreRegistry;
    }

    /**
     * Exeute method
     *
     * @return array
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultRedirect = $this->resultRedirectFactory->create();
        $rtoItemId = $this->getRequest()->getParam('entity_id');
        
        if ($rtoItemId) {
          try{
            $rtoItem = $this->salesOrderRtoItemFactory->create()->getCollection()->addFieldToFilter('entity_id', $rtoItemId)->getFirstItem();
            if(!($rtoItem->getEntityId())){
              $this->messageManager->addErrorMessage(__('This Rto Item no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/rtohistory/', ['_current' => true]);
            }
          } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('This Rto Item no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/rtohistory/', ['_current' => true]);
          }
            $resultPage->getConfig()->getTitle()->prepend((__('Rto Item Id #%1', $rtoItem->getEntityId())));
            $this->_coreRegistry->register('msh_rto_item', $rtoItem);
            return $resultPage;
        } else {
            $this->messageManager->addErrorMessage(__('Rto Item no longer exists.'));
            return $this->resultRedirectFactory->create()->setPath('orderitemrto/rtohistory/', ['_current' => true]);
        }
    }

     /**
      * Allow modules
      *
      * @return Int
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eighteen_OrderItemRto::viewrtogrid');
    }
}
