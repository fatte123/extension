<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2022 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Block\Adminhtml\Index\View;

/**
 * Adminhtml ConsignmentRto index view plane
 *
 * @author Magento Core Team <core@magentocommerce.com>
 */
class Form extends \Magento\Backend\Block\Template
{
    /**
     * @var _template
     */
    protected $_template = 'Eighteen_OrderItemRto::view/form.phtml';
}
