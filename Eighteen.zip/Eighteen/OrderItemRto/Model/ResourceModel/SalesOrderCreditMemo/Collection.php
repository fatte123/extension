<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
namespace Eighteen\OrderItemRto\Model\ResourceModel\SalesOrderCreditMemo;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     * phpcs:disable
     */
    protected function _construct()
    {
        $this->_init(\Eighteen\OrderItemRto\Model\SalesOrderCreditMemo::class, \Eighteen\OrderItemRto\Model\ResourceModel\SalesOrderCreditMemo::class);
    }
    /** phpcs:enable */
}
