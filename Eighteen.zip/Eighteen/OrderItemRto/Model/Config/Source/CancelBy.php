<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */
 
namespace Eighteen\OrderItemRto\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class CancelBy implements ArrayInterface
{
    /**
     * Process Status
     */
    const STATUS_INPROGRESS = 0;
    const STATUS_COMPLETE = 1;
    const STATUS_RTO_CANCEL = 2;

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
        self::STATUS_INPROGRESS => __('Customer'),
        self::STATUS_COMPLETE => __('Admin'),
        self::STATUS_RTO_CANCEL => __('Cancel-RTO')
        ];
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $result = [];
        foreach (self::toArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }
}
