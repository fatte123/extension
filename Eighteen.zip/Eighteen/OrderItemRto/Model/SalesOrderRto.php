<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2023 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteen_OrderItemRto
 */

namespace Eighteen\OrderItemRto\Model;

class SalesOrderRto extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init(\Eighteen\OrderItemRto\Model\ResourceModel\SalesOrderRto::class);
    }
}
