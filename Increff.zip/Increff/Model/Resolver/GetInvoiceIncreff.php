<?php

namespace Eighteentech\Increff\Model\Resolver;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\LocalizedException;
use Eighteentech\FeaturedSale\Model\FeaturedSaleFactory;
use Eighteentech\Increff\Logger\Logger as CustomeLogger;
use Eighteentech\Increff\Helper\Data;

class GetInvoiceIncreff implements ResolverInterface
{    
    /**
     * @var \Eighteentech\Increff\Logger\Logger
     */
    protected $customLogger;

    /**
     *
     * @var \Eighteentech\FeaturedSale\Helper\Data
     */
    protected $helperData;

    /**
     * GetInvoiceIncreff constructor.
     *
     * @param Data $helperData
     * @param \Eighteentech\Increff\Logger\Logger $customLogger
     */

    public function __construct(
        CustomeLogger $customLogger,
        Data $helperData
    ) {
        $this->customLogger = $customLogger;
        $this->helperData = $helperData;
    }
    
    /**
     * GetInvoiceIncreff Resolver
     *
     * @param Field $field
     * @param ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array
     * @throws GraphQlInputException
     */

    public function resolve(
        Field $field,
        $context,
        ResolveInfo
        $info,
        array $value = null,
        array $args = null
    ) {
        
        try {
            
            $responseData = [];

            $this->customLogger->info('start Increff Invoice Getting.');
            $this->vaildateData($args);
            
            if (!empty($args)) {
                
                $orderCode = $args['orderCode'];

                $method = 'GET';
                $endPoint = '/invoice/invoice-pdf';
                $queryParams = [
                    'referenceNo' => $orderCode
                ];
                
                $response = $this->helperData->makeRmsCurlRequest($method,$endPoint,$queryParams);
                $response = json_decode($response,true);
                if(isset($response['orderCode']) && 
                   isset($response['invoiceId']) &&
                   isset($response['documentUrl']) &&
                   isset($response['invoiceDate'])
                ){
                    $responseData['orderCode']    = $response['orderCode'];
                    $responseData['invoiceId']    = $response['invoiceId'];
                    $responseData['documentUrl']  = $response['documentUrl'];
                    $responseData['invoiceDate']  = $response['invoiceDate'];
                    $responseData['documentType'] = $response['documentType'];
                    $responseData['invoiceStatus'] = $response['invoiceStatus'];
                }
                return $responseData;

            }

        } catch (LocalizedException $e) {
            
            $this->customLogger->info(
                'Error : '.
                $e->getMessage() . ', orderCode: ' . $args['orderCode']
            );
            throw new GraphQlInputException(__($e->getMessage()));
        }
        
        $this->loggerHelper->writeLog('info', 'end Increff Invoice Getting');
    }
    
    /**
     * GetInvoiceIncreff vaildateData
     *
     * @param void $data check validate data.
     */
    private function vaildateData($data) :void
    {   
        $this->customLogger->info('Increff Invoice Validation Request.');
        $isEnabled = $this->helperData->isEnabled();
        
        if ($isEnabled == false) {
            $this->customLogger->info('warn : '.'This feature has been disable. Please contact to service provider');
            throw new GraphQlInputException(__('This feature has been disable. Please contact to service provider.'));
        }
        
        if (empty($data)) {
            $this->customLogger->info('warn : '.'Input value should be specified');
            throw new GraphQlInputException(__('"Input" value should be specified'));
        }

        if (!isset($data['orderCode']) ||
            $data['orderCode'] == "" ||  
            $data['orderCode'] == null  
        ) {

            $this->customLogger->info('warn : '.'Must be set required data');
            throw new LocalizedException(__('Must be set required data'));
        }

        $this->customLogger->info('end Increff Invoice Validation Request.');
    }
}
