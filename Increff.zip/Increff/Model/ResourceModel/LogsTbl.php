<?php

namespace Eighteentech\Increff\Model\ResourceModel;

/**
 * Increff Resource Model
 */
class LogsTbl extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('tbl_increff_log', 'log_id');
    }
}
