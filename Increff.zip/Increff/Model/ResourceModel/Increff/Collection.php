<?php

/**
 * Increff Resource Collection
 */
namespace Eighteentech\Increff\Model\ResourceModel\Increff;

use Eighteentech\Increff\Model\LogsTbl;
use Eighteentech\Increff\Model\ResourceModel\LogsTbl as IncreffSaleResource;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(LogsTbl::class, IncreffSaleResource::class);
    }
}
