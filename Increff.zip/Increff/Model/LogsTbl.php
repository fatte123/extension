<?php

namespace Eighteentech\Increff\Model;

use Eighteentech\Increff\Model\ResourceModel\LogsTbl as IncreffResourcedata;

/**
 * Increff Model
 *
 * @method \Eighteentech\Increff\Model\Resource\Page _getResource()
 * @method \Eighteentech\Increff\Model\Resource\Page getResource()
 */
class LogsTbl extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(IncreffResourcedata::class);
    }
}
