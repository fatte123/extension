<?php
namespace Eighteentech\Increff\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

class Logger extends AbstractHelper
{
    /**
     * Write log into the file
     *
     * @param string $type
     * @param string $errorMessage
     * @return void
     */
    public function writeLog($type, $errorMessage)
    {
        try {
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/Increff.log');
        } catch (\Zend_Log_Exception $e) {
            return false;
        }

        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        switch ($type) {
            case 'info':
                $logger->info($errorMessage);
                break;

            case 'warn':
                $logger->warn($errorMessage);
                break;

            case 'error':
                $logger->err($errorMessage);
                break;
            
            default:
                $logger->info($errorMessage);
                break;
        }
    }
}
