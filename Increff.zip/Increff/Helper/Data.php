<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 *
 * @category Eighteentech
 * @package  Eighteentech_Increff
 *
 */

namespace Eighteentech\Increff\Helper;

use Psr\Log\LoggerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Sales\Exception\CouldNotShipException;
use Magento\InventoryApi\Api\GetSourceItemsBySkuInterface;
use Magento\Framework\Json\Helper\Data as JsonData;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * Initialize Constants
     */
    const XML_PATH_SYSTEMCONFIG = 'eighteenincreff_section';
    const XML_INCREFF_ENABLED = 'eighteenincreff_section/general/enable';
    const XML_INCREFF_VIN_CODE = 'eighteenincreff_section/increff/vin_code';
    const XML_INCREFF_AIL_CODE = 'eighteenincreff_section/increff/ail_code';
    const XML_INCREFF_INTL_CODE = 'eighteenincreff_section/increff/intl_code';
    const XML_INCREFF_AIL_API_URL = 'eighteenincreff_section/increff/increrff_api_url';
    const XML_INCREFF_AIL_API_USER = 'eighteenincreff_section/increff/increrff_api_user';
    const XML_INCREFF_AIL_API_PASS = 'eighteenincreff_section/increff/increrff_api_pass';
    const XML_INCREFF_API_SOURCE = 'eighteenincreff_section/increff/source';
    const XML_INCREFF_CHANNEL_ID = 'eighteenincreff_section/increff/channel_id';
    const XML_INCREFF_MARKET_NAME = 'eighteenincreff_section/increff/marketplace_name';
    const XML_INCREFF_LOCATION_CODE = 'eighteenincreff_section/increff/locationCode';
    const XML_INCREFF_CLUSTER_ID = 'eighteenincreff_section/increff/cluster_id';
    const XML_INCREFF_WAREHOUSE_ID = 'eighteenincreff_section/increff/warehouse_id';
    const XML_SYNC_RMA_START_DATE = 'eighteenincreff_section/rmasync/start_date';
    const XML_SYNC_RMA_ALL_STOR = 'eighteenincreff_section/rmasync/allowed_stores';
    const XML_SYNC_RMA_EMAIL_TPL = 'eighteenincreff_section/rmasync/email_template';
    const XML_STORE_GENERAL_EMAIL = 'trans_email/ident_general/email';
    const XML_INCREFF_INVOICE_DOMAIN_NAME = 'eighteenincreff_section/rmssync/increrff_domain_name';
    const XML_INCREFF_INVOICE_API_URL = 'eighteenincreff_section/rmssync/increrff_invoice_api_url';
    const XML_INCREFF_INVOICE_API_USER = 'eighteenincreff_section/rmssync/increrff_invoice_api_user';
    const XML_INCREFF_INVOICE_API_PASS = 'eighteenincreff_section/rmssync/increrff_invoice_api_pass';


    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $curl;

    /*
     * \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManagerInterface;

    /**
     * @var GetSourceItemsBySkuInterface
     */
    protected $sourceItemsBySku;

    /**
     * @var JsonData
     */
    protected $jsonHelper;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var PincodeManagement
     */
    protected $pincodeManagement;

    /**
     * @var \Eighteentech\Increff\Logger\Logger
     */
    protected $customLogger;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Magento\Store\Model\StoreManagerInterface $storeManagerInterface
     * @param GetSourceItemsBySkuInterface $sourceItemsBySku
     * @param JsonData $jsonHelper
     * @param LoggerInterface $logger
     * @param PincodeManagement $pincodeManagement
     * @param \Eighteentech\Increff\Logger\Logger $customLogger
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Store\Model\StoreManagerInterface $storeManagerInterface,
        GetSourceItemsBySkuInterface $sourceItemsBySku,
        JsonData $jsonHelper,
        LoggerInterface $logger,
        \Eighteentech\Increff\Logger\Logger $customLogger
    ) {

        $this->scopeConfig = $scopeConfig;
        $this->curl = $curl;
        $this->_storeManagerInterface = $storeManagerInterface;
        $this->sourceItemsBySku = $sourceItemsBySku;
        $this->jsonHelper = $jsonHelper;
        $this->logger = $logger;
        $this->customLogger = $customLogger;
        parent::__construct($context);
    }

    /**
     * Get system configuration value
     */
    public function getConfigValue($field, $storeId = null)
    {

        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * Is Increff enabled
     */
    public function isEnabled()
    {

        return $this->scopeConfig->getValue(
            self::XML_INCREFF_ENABLED,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get RMA sync status
     *
     * @return boolean|null
     */
    public function isRmaSyncEnabled($storeId = null)
    {

        return $this->getConfigValue(
            self::XML_PATH_SYSTEMCONFIG . '/rmasync/enable',
            $storeId
        );
    }

    /**
     * Get Stock code
     */
    public function getStockCode($stock = '')
    {

        if ($stock == 'vin') {

            return $this->scopeConfig->getValue(
                self::XML_INCREFF_VIN_CODE,
                ScopeInterface::SCOPE_STORE
            );
        } elseif ($stock == 'ail') {

            return $this->scopeConfig->getValue(
                self::XML_INCREFF_AIL_CODE,
                ScopeInterface::SCOPE_STORE
            );
        } else {

            return '';
        }
    }

    /**
     * cURL request to interact with the Increff
     */
    public function oldmakeCurlRequest(
        $method,
        $endPoint,
        $data = []
    ) {

        $ailApiUrl = $this->scopeConfig->getValue(
            self::XML_INCREFF_AIL_API_URL,
            ScopeInterface::SCOPE_STORE
        );
        $ailApiKey = $this->scopeConfig->getValue(
            self::XML_INCREFF_AIL_API_KEY,
            ScopeInterface::SCOPE_STORE
        );
        $callUrl = $ailApiUrl . $endPoint;
        $authHeader = [
            'Content-Type: application/json',
            'Authorization:' . $ailApiKey
        ];

        try {

            $this->curl->setOption(CURLOPT_HTTPHEADER, $authHeader);
            $this->curl->setOption(CURLOPT_SSL_VERIFYHOST, false);
            $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);

            if ($method == 'GET') {

                $this->curl->get($callUrl);
            } else {

                $this->curl->post($callUrl, $data);
            }

            // Output of cURL request
            $result = $this->curl->getBody();

            $this->customLogger->info('Request Params: ' . $endPoint . ': ' . $data);
            $this->customLogger->info('Response: Code: ' . $this->curl->getStatus() . ', Data: ' . $result);
        } catch (\Exception $e) {

            $this->customLogger->info('Error: ' . $e->getMessage());
            $result = '';
        }

        return $result;
    }

    /**
     * Cancel an item in Increff
     */
    public function cancelOrderItemAil(
        $data,
        $comments = ''
    ) {
        $apiSource = $this->scopeConfig->getValue(
            self::XML_INCREFF_API_SOURCE,
            ScopeInterface::SCOPE_STORE
        );

        $postData = [
            'source' => 'API',
            'orderId' => $data['orderId'],
            'itemIds' => [
                $data['itemId']
            ],
            'status' => 'CANCELLED',
            'reason' => $comments,
            'createdAt' => time()
        ];

        return $this->makeCurlRequest('POST', $apiSource . '/order/status', json_encode($postData));
    }

    /**
     * cURL request to interact with the Vinculum
     */
    public function makeCurlRequestVin(
        $method,
        $endPoint,
        $data = [],
        $type = 'form-urlencoded'
    ) {

        $vinApiUrl = $this->scopeConfig->getValue(
            self::XML_VIN_API_URL,
            ScopeInterface::SCOPE_STORE
        );
        $vinApiKey = $this->scopeConfig->getValue(
            self::XML_VIN_API_KEY,
            ScopeInterface::SCOPE_STORE
        );
        $vinApiWoner = $this->scopeConfig->getValue(
            self::XML_VIN_API_OWNER,
            ScopeInterface::SCOPE_STORE
        );
        $callUrl = $vinApiUrl . $endPoint;

        if ($type == 'form-urlencoded') {

            $headers = [
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Authorization' => 'Basic ' . base64_encode($vinApiWoner . ':' . $vinApiKey)
            ];
            $payload = [
                'RequestBody' => json_encode($data)
            ];

            $this->curl->setHeaders($headers);
            $this->curl->post($callUrl, http_build_query($payload));
        } elseif ($type == 'application-json') {

            $headers = [
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic ' . base64_encode($vinApiWoner . ':' . $vinApiKey)
            ];
            $payload = json_encode($data);

            $this->curl->setHeaders($headers);
            $this->curl->post($callUrl, $payload);
        }

        try {

            // Output of cURL request
            $result = $this->curl->getBody();
            $this->customLogger->info('Request Params: ' . $endPoint . ': ' . json_encode($data));
            $this->customLogger->info('Response: Code: ' . $this->curl->getStatus() . ', Data: ' . $result);

            if ($this->curl->getStatus() != 200) {
                $this->customLogger->info('Exception Error ' . http_response_code());
            }
        } catch (\Exception $e) {

            $this->customLogger->info('Error: ' . $e->getMessage());
            $result = '';
        }

        return $result;
    }

    /**
     * Cancel an item in Vinculum
     */
    public function cancelOrderItemVinculum($data, $lineNo, $custComments = '')
    {

        $postData = [];
        $orderLocation = $this->scopeConfig->getValue(
            self::XML_VIN_ORDER_LOC,
            ScopeInterface::SCOPE_STORE
        );

        $postData['order'] = [
            'order_location' => $orderLocation ?? '',
            'uniqueKey' => '',
            'order_no' => $data['orderId'],
            'items' => [
                [
                    'lineno' => (string) $lineNo,
                    'ext_lineno' => '',
                    'cancelled_qty' => (string) $data['cancelqty'],
                    'sku' => $data['sku'],
                    'cancelation_reason' => 'Cancelled by customer',
                    'cancelation_remarks' => $custComments
                ]
            ]
        ];

        return $this->makeCurlRequestVin(
            'POST',
            'v1/order/cancelLineLevel',
            $postData
        );
    }

    /**
     * 
     * Validate cart delivery     
     */
    public function validateCartDelivery($currentQuote)
    {

        $currentStore = $this->_storeManagerInterface->getStore();
        $postCode = $currentQuote->getShippingAddress()->getPostcode();
        $vinSourceCode = $this->getStockCode('vin');

        if ($postCode && $currentStore->getCode() == 'in') {

            foreach ($currentQuote->getAllItems() as $item) {

                if ($item->getProductType() == 'simple') {

                    $vinInventoryStatus = false;
                    $sourceItemList = $this->sourceItemsBySku->execute($item->getSku());

                    if (is_array($sourceItemList) && count($sourceItemList)) {

                        foreach ($sourceItemList as $source) {

                            $sourceData = $source->getData();
                            if (
                                intval($sourceData['quantity']) &&
                                ($sourceData['source_code'] == $vinSourceCode)
                            ) {

                                $vinInventoryStatus = true;
                                break;
                            }
                        }
                    }

                    if ($vinInventoryStatus) {

                        $results = $this->pincodeManagement->create()
                            ->addFieldToFilter('pincode', $postCode);

                        if (count($results) > 0) {

                            foreach ($results as $result) {
                                $status = $result->getStatus() ?? false;
                            }

                            if (!$status) {

                                $this->logger->error(__("VIN 0: Postcode: $postCode - Delivery not serviceable! SKU: " . $item->getSku()));
                                throw new CouldNotShipException(__("Delivery not available for '" . $item->getName() . "'"));
                            }
                        } else {

                            $this->logger->error(__("VIN 1: Postcode: $postCode - Delivery not serviceable! SKU: " . $item->getSku()));
                            throw new CouldNotShipException(__("Delivery not available for '" . $item->getName() . "'"));
                        }
                    } else {

                        $jsonData = [
                            'location' => $postCode,
                            'storePickup' => '',
                            'warehouseId' => '',
                            'deliveryMode' => [],
                            'items' => [
                                [
                                    'skuId' => $item->getSku(),
                                    'eoisSkuID' => '',
                                    'quantity' => 1
                                ]
                            ]
                        ];

                        $jsonData = $this->jsonHelper->jsonEncode($jsonData);
                        $body =  $this->makeCurlRequest(
                            'post',
                            'order/checkServiceability',
                            $jsonData
                        );

                        if ($body) {

                            $json = $this->jsonHelper->jsonDecode($body);

                            if (isset($json['items'][0]['deliverymodes'])) {

                                if (count($json['items'][0]['deliverymodes']) <= 0) {

                                    $this->logger->error(
                                        _("AIL 0: Postcode: $postCode - Delivery not available! SKU: " . $item->getSku())
                                    );
                                    throw new CouldNotShipException(__("Delivery not available for '" . $item->getName() . "'"));
                                }
                            } else {

                                $this->logger->error(
                                    _("AIL 1: Postcode: $postCode - Delivery not available! SKU: " . $item->getSku())
                                );
                                throw new CouldNotShipException(__("Delivery not available for '" . $item->getName() . "'"));
                            }
                        } else {

                            $this->logger->error(__("AIL 2: Postcode: $postCode - Delivery not available! SKU: " . $item->getSku()));
                            throw new CouldNotShipException(__("Delivery not available for '" . $item->getName() . "'"));
                        }
                    }
                }
            }
        }

        return true;
    }

    /**
     * cURL New request to interact with the Increff
     */
    public function makeCurlRequest(
        $method,
        $endPoint,
        $data = []
    ) {
 
        $apiUrl = $this->scopeConfig->getValue(
            self::XML_INCREFF_AIL_API_URL,
            ScopeInterface::SCOPE_STORE
        );
        $apiUser = $this->scopeConfig->getValue(
            self::XML_INCREFF_AIL_API_USER,
            ScopeInterface::SCOPE_STORE
        );
        $apiPassword = $this->scopeConfig->getValue(
            self::XML_INCREFF_AIL_API_PASS,
            ScopeInterface::SCOPE_STORE
        );
        
        $callUrl = $apiUrl . $endPoint;

        try {
            
            $this->curl->addHeader("Content-Type", "application/json");
            $this->curl->addHeader("authUserName", "$apiUser");
            $this->curl->addHeader("authPassword", "$apiPassword");
            $this->curl->setOption(CURLOPT_SSL_VERIFYHOST, false);
            $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);
            $this->curl->setOption(CURLOPT_URL, $callUrl);

            if ($method == 'GET') {
                $this->curl->get($callUrl);
            } else {

                $this->curl->post($callUrl, $data);

            }

            // Output of cURL request
            $result = $this->curl->getBody();
            
            if (empty($result) && $this->curl->getStatus() == 200) {

                $result = $this->curl->getStatus();

            } else {

                $result = $this->curl->getBody();
            }
            $this->customLogger->info('Request Params: ' . $callUrl . ': ' . print_r($data,true));
            $this->customLogger->info('Response: Code: ' . $this->curl->getStatus() . ', Data: ' . $result);
        } catch (\Exception $e) {

            $this->customLogger->info('Error: ' . $e->getMessage());
            $result = '';
        }
        return $result;
    }

    /**
     * cURL New request to interact with the Increff
     */

    public function makeRmsCurlRequest(
        $method,
        $endPoint,
        $queryParams,
        $data = []
    ) {

        $apiUrl = $this->scopeConfig->getValue(
            self::XML_INCREFF_INVOICE_API_URL,
            ScopeInterface::SCOPE_STORE
        );
        $apiUser = $this->scopeConfig->getValue(
            self::XML_INCREFF_INVOICE_API_USER,
            ScopeInterface::SCOPE_STORE
        );
        $apiPassword = $this->scopeConfig->getValue(
            self::XML_INCREFF_INVOICE_API_PASS,
            ScopeInterface::SCOPE_STORE
        );
        $domainName = $this->scopeConfig->getValue(
            self::XML_INCREFF_INVOICE_DOMAIN_NAME,
            ScopeInterface::SCOPE_STORE
        );
        
        $callUrl = $apiUrl . $endPoint;
        
        if(!empty($queryParams)){
            $callUrl .='?' . http_build_query($queryParams);
        }
       
        try {
            
            $this->curl->addHeader("authDomainName", "$domainName");
            $this->curl->addHeader("authUserName", "$apiUser");
            $this->curl->addHeader("authPassword", "$apiPassword");
            $this->curl->setOption(CURLOPT_SSL_VERIFYHOST, false);
            $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);
            $this->curl->setOption(CURLOPT_URL, $callUrl);

            if ($method == 'GET') {
                $this->curl->get($callUrl);
            } else {
                $this->curl->post($callUrl, $data);
            }

            // Output of cURL request
            $result = $this->curl->getBody();
            $this->customLogger->info('Request Params: ' . $callUrl);
            $this->customLogger->info('Response: Code: ' . $this->curl->getStatus() . ', Data: ' . $result);
        } catch (\Exception $e) {

            $this->customLogger->info('Error: ' . $e->getMessage());
            $result = '';
        }
        return $result;
    }
}
