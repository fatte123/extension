<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Increff
 *
 */
namespace Eighteentech\Increff\Logger;

class Logger extends \Monolog\Logger
{
    /**
     * Logging level
     * @var int
     */
    protected $loggerType = Logger::INFO;
  
    
}
