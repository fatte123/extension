<?php
/**
 * @author 18th Digitech<info@18thdigitech.com>
 * @package Eighteentech_Increff
 */
declare(strict_types=1);

namespace Eighteentech\Increff\Block\Adminhtml\Rma\Edit\Tab\General;

/**
 * Comments History Block at RMA page
 *
 * @api
 * @since 100.0.2
 */
class Increffsyncstatus extends \Magento\Rma\Block\Adminhtml\Rma\Edit\Tab\General\AbstractGeneral
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $registry = null;

    /**
     * Rma Collection model
     *
     * @var \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory
     */
    protected $rmaFactory;

    /**
     * @var \Magento\Rma\Model\ResourceModel\Item\CollectionFactory
     */
    protected $rmaItemCollectionFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory $rmaFactory
     * @param \Magento\Rma\Model\ResourceModel\Item\CollectionFactory $rmaItemCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory $rmaFactory,
        \Magento\Rma\Model\ResourceModel\Item\CollectionFactory $rmaItemCollectionFactory,
        array $data = []
    ) {
        $this->rmaFactory = $rmaFactory;
        $this->rmaItemCollectionFactory = $rmaItemCollectionFactory;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return array
     */
    public function getRmaCollection()
    {
        $rma_entityid = $this->_coreRegistry->registry('current_rma')->getId();

        $RmaCollection = $this->rmaFactory->create()->addFieldToFilter(
            'entity_id',
            $rma_entityid
        )->getFirstItem();
        return $RmaCollection;
    }

    /**
     * @param $orderItemId
     * @return array
     */
    public function getRmaItemCollection($orderItemId)
    {
        return $this->rmaItemCollectionFactory->create()->addFieldToSelect(
            '*'
        )->addFieldToFilter(
            'order_item_id',
            $orderItemId
        );
    }

    /**
     * @return array
     */
    public function getRmaEntityItemsCollection()
    {
        $rma_entityid = $this->_coreRegistry->registry('current_rma')->getId();

        return $this->rmaItemCollectionFactory->create()->addFieldToSelect(
            '*'
        )->addFieldToFilter(
            'rma_entity_id',
            $rma_entityid
        );
    }
}
