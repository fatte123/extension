<?php

/**
 * @author 18th Digitech<info@18thdigitech.com>
 * @package Eighteentech_Increff
 */

declare(strict_types=1);

namespace Eighteentech\Increff\Block\Adminhtml\Rma;

/**
 * RMA Grid
 */
class Grid extends \Magento\Rma\Block\Adminhtml\Rma\Grid
{
    /**
     * Rma grid collection
     *
     * @var \Magento\Rma\Model\ResourceModel\Rma\Grid\CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * Rma model
     *
     * @var \Magento\Rma\Model\RmaFactory
     */
    protected $_rmaFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Rma\Model\ResourceModel\Rma\Grid\CollectionFactory $collectionFactory
     * @param \Magento\Rma\Model\RmaFactory $rmaFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Rma\Model\ResourceModel\Rma\Grid\CollectionFactory $collectionFactory,
        \Magento\Rma\Model\RmaFactory $rmaFactory,
        array $data = []
    ) {
        $this->_collectionFactory = $collectionFactory;
        $this->_rmaFactory = $rmaFactory;
        parent::__construct($context, $backendHelper, $collectionFactory, $rmaFactory, $data);
    }

    /**
     * Prepare grid columns
     *
     * @return \Magento\Rma\Block\Adminhtml\Rma\Grid
     */
    protected function _prepareColumns()
    {
        /** @var $rmaModel \Magento\Rma\Model\Rma */
        $rmaModel = $this->_rmaFactory->create();
        $this->addColumnAfter(
            'increff_status',
            [
                'header' => __('Increff sync'),
                'index' => 'increff_status',
                'type' => 'options',
                'options'   => [
                    0 => 'Pending',
                    1 => 'Synced',
                    2 => 'Failed',
                    3 => 'NA'
                ],
                'header_css_class' => 'col-status',
                'column_css_class' => 'col-status'
            ],
            'status'
        );

        return parent::_prepareColumns();
    }
}
