<?php

/**
 * @author 18th Digitech<info@18thdigitech.com>
 * @package Eighteentech_Increff
 */

declare(strict_types=1);

namespace Eighteentech\Increff\Cron;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Json\Helper\Data as JsonData;
use Magento\Eav\Api\AttributeOptionManagementInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Rma\Api\RmaAttributesManagementInterface;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\Order\ItemFactory;
use Eighteentech\Increff\Helper\Logger as LoggerHelper;
use Eighteentech\Increff\Model\LogsTblFactory as IncreffSyncLog;
use Eighteentech\Increff\Helper\Data as DataHelper;
use Magento\Rma\Model\RmaFactory;
use Eighteentech\Increff\Logger\Logger as CustomeLogger;

class RmaSync
{

    /**
     *
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $timezone;

    /**
     *
     * @var \Eighteentech\Increff\Logger\Logger
     */
    protected $customeLogger;
    
    /**
     *
     * @var \Magento\Rma\Model\RmaFactory
     */
    protected $rmaModelFactory;

    /**
     * Rma Collection model
     *
     * @var \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory
     */
    protected $rmaFactory;

    /**
     * @var AttributeOptionManagementInterface
     */
    private $attributeOptionManagement;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Mail transport builder
     *
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var JsonData
     */
    protected $jsonHelper;

    /**
     *
     * @var \Eighteentech\Increff\Helper\Logger
     */
    protected $loggerHelper;

    /**
     *
     * @var \Eighteentech\Increff\Model\LogsTbl
     */
    protected $IncreffSyncLog;

    /**
     *
     * @var \Eighteentech\Increff\Helper\Data
     */
    protected $dataHelper;

    /**
     * 
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * 
     * @var \Magento\Sales\Model\Order\ItemFactory
     */
    protected $orderItemFactory;

    /**
     * 
     * @param TimezoneInterface $timezone
     * @param \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory $rmaFactory
     * @param \Magento\Rma\Model\ResourceModel\Item\CollectionFactory $rmaItemCollectionFactory
     * @param AttributeOptionManagementInterface $attributeOptionManagement
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param TransportBuilder $transportBuilder
     * @param JsonData $jsonHelper
     * @param LoggerHelper $loggerHelper
     * @param IncreffSyncLog $increffSyncLog
     * @param DataHelper $dataHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Sales\Model\Order\ItemFactory $orderItemFactory
     * @param \Magento\Rma\Model\RmaFactory $rmaModelFactory
     * @param \Eighteentech\Increff\Logger\Logger $customeLogger
     */
    public function __construct(
        TimezoneInterface $timezone,
        \Magento\Rma\Model\ResourceModel\Rma\CollectionFactory $rmaFactory,
        \Magento\Rma\Model\ResourceModel\Item\CollectionFactory $rmaItemCollectionFactory,
        AttributeOptionManagementInterface $attributeOptionManagement,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        JsonData $jsonHelper,
        LoggerHelper $loggerHelper,
        IncreffSyncLog $increffSyncLog,
        DataHelper $dataHelper,
        OrderFactory $orderFactory,
        RmaFactory $rmaModelFactory,
        CustomeLogger $customeLogger,
        ItemFactory $orderItemFactory
    ) {

        $this->timezone = $timezone;
        $this->rmaFactory = $rmaFactory;
        $this->rmaItemCollectionFactory = $rmaItemCollectionFactory;
        $this->attributeOptionManagement = $attributeOptionManagement;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->_transportBuilder = $transportBuilder;
        $this->jsonHelper = $jsonHelper;
        $this->loggerHelper = $loggerHelper;
        $this->dataHelper = $dataHelper;
        $this->orderFactory = $orderFactory;
        $this->rmaItemFactory = $rmaModelFactory;
        $this->increffSyncLog = $increffSyncLog;
        $this->customeLogger = $customeLogger;
        $this->orderItemFactory = $orderItemFactory;
    }

    /**
     * Rma Sync
     */
    public function execute()
    {
        // ini_set('display_errors', '1');
        // error_reporting(E_ALL);

        if (!$this->dataHelper->isEnabled() || !$this->dataHelper->isRmaSyncEnabled()) {

            return false;
        }

        $this->customeLogger->info('Start Increff RMA sync');

        $rmaCollections = $this->getRmaCollection();
        
        
        $allowedStoreIds = explode(',', $this->dataHelper->getConfigValue(
            $this->dataHelper::XML_SYNC_RMA_ALL_STOR,
            null
        ));

        $locationCode = $this->dataHelper->getConfigValue(
            $this->dataHelper::XML_INCREFF_LOCATION_CODE,
            null
        );

        $increffSyncLog = $this->increffSyncLog->create();
        $reasonOptions = $this->getRmaAttributeOptions();
        $this->updateRmaStatus($rmaCollections);

        foreach ($rmaCollections as $rmaCollection) {
            
            // Get RMA item collection by Order Id
            $rmaItemsData = $this->getRmaEntityItemsCollection($rmaCollection->getEntityId());

            foreach ($rmaItemsData as $rmaItemData) {
                   
                    $rmaItemObj = $this->rmaItemFactory->create()->load($rmaItemData->getEntityId());
                    
                    if ($rmaItemObj->getIncreffStatus() || $rmaItemObj->getIncreffAttempt() >= 3) {
                        // break 2;
                        break;
                    }

                $reason =  isset($reasonOptions[$rmaItemData->getReason()])
                    ?  $reasonOptions[$rmaItemData->getReason()]
                    : '';

                if (empty($rmaItemData->getReason())) {

                    $reason = $rmaItemData->getReasonOther() ? $rmaItemData->getReasonOther() : '';
                }


                $orderItem = $this->orderItemFactory->create()->load($rmaItemData->getOrderItemId());

                //$canReturnQty = $orderItem->getQtyOrdered() - $orderItem->getQtyInvoiced();
                $canReturn = $rmaItemData->getQtyRequested() + $orderItem->getQtyReturned();                
                $returnorderdata = [];
                for ($i=0; $i < $canReturn ; $i++) { 
                    $orderItemData = [
                        'itemCode' => $rmaItemData->getId(),
                        'reason' => $reason,
                        'channelSkuCode' => $rmaItemData->getProductSku()
                    ];

                    $returnorderdata[] = $orderItemData;
                }
                
                if (in_array($rmaCollection->getStoreId(), $allowedStoreIds)) {
                    
                    // Push returns to Increff
                    $returnData = [
                        'forwardOrderCode' => $rmaCollection->getOrderId(),
                        'returnOrderCode' => $rmaCollection->getIncrementId(),
                        'locationCode' => $locationCode,
                        'returnOrderTime'=>$rmaCollection->getDateRequested(),
                        'orderType' => 'CUSTOMER_RETURN',
                        'awbNumber'=> '',
                        'transporter' => '',
                        'orderItems'=>$returnorderdata
                    ];

                    $jsonData = $this->jsonHelper->jsonEncode($returnData);
                    try {
                        
                        $curlResponse = $this->dataHelper->makeCurlRequest(
                            'POST',
                            '/return-orders',
                            $jsonData
                        );

                    } catch (\Exception $e) {

                        $increffSyncLog->setStatus('Faild');
                        $increffSyncLog->save();

                        $this->customeLogger->info(
                            'error : '.
                            'API Hit. Err: ' . $e->getMessage()
                        );
                            /*continue 3;*/
                    }
                    //$curlResponse = $this->jsonHelper->jsonDecode($curlResponse);

                    if (intval($curlResponse) == 200) {

                        $rmaItemObj->setData('increff_status', 1);
                        $rmaItemObj->setData('increff_attempt', $rmaItemObj->getIncreffAttempt() + 1);
                        $rmaItemObj->save();

                    } else {

                        $rmaItemObj->setData('increff_attempt', $rmaItemObj->getIncreffAttempt() + 1);
                        $rmaItemObj->save();
                    }
                    // End RMA item Qty iteration
                } else {

                    $rmaCollection->setIncreffStatus(3);
                    $rmaCollection->save();
                    //continue 2;
                }

                if ($rmaItemObj->getIncreffAttempt() >= 3) {

                    try {

                        $from = 'general';
                        $storeId = $this->storeManager->getStore()->getId();
                        $templateOptions = [
                            'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => $this->storeManager->getStore()->getId()
                        ];
                        $toGeneralEmail = $this->dataHelper->getConfigValue(
                            $this->dataHelper::XML_STORE_GENERAL_EMAIL,
                            $storeId
                        );
                        $to = [
                            $toGeneralEmail
                        ];
                        $templateId =  $this->dataHelper->getConfigValue(
                            $this->dataHelper::XML_SYNC_RMA_EMAIL_TPL,
                            $storeId
                        );
                        $templateVars = [
                            'store' => $this->storeManager->getStore()
                        ];

                        $transport = $this->_transportBuilder->setTemplateIdentifier(
                            $templateId,
                            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                        )->setTemplateOptions($templateOptions)
                            ->setTemplateVars($templateVars)
                            ->setFrom($from)
                            ->addTo($to)
                            ->getTransport();
                        $transport->sendMessage();
                        $this->customeLogger->info('RMA sync status email sent.');
                    } catch (\Exception $e) {

                        $this->customeLogger->info(
                            'error : '.
                            'RMA sync status email not sent. Err: ' . $e->getMessage()
                        );
                    }

                    continue 2;
                }
            } // End RMA item collection iteration

            $this->updateRmaStatus($rmaCollections);
        } // End RMA collection iteration

        $this->customeLogger->info('End increff RMA sync');

        $increffSyncLog->setStatus('complete');
        $increffSyncLog->setCompleteAt($this->timezone->date()->format('Y-m-d H:i:s'));
        $increffSyncLog->save();
    }

    /**
     * @return void
     */
    public function updateRmaStatus($rmaCollections)
    {
        // $rmaCollections = $this->getRmaCollection();
        $count = $increffStatus = 0;

        foreach ($rmaCollections as $rmaCollection) {

            // 2.get rma item collection by orderId
            $rmaItemsCollections = $this->getRmaEntityItemsCollection($rmaCollection->getEntityId());
            //$count = count($rmaItemsCollections->getData());
            $count = count($rmaItemsCollections);

            foreach ($rmaItemsCollections as $rmaItemsCollection) {

                $increffStatus += (int)$rmaItemsCollection->getIncreffStatus();
            }

            if ($count == $increffStatus) {

                $rmaCollection->getIncreffStatus(1);
                $rmaCollection->save();
            }
        }
    }

    /**
     * @return array
     */
    public function getRmaCollection()
    {

        $syncStartDate = $this->dataHelper->getConfigValue(
            $this->dataHelper::XML_SYNC_RMA_START_DATE,
            null
        );

        $rmaCollection = $this->rmaFactory->create()->addFieldToSelect('*');

        if ($syncStartDate) {

            $rmaCollection->addFieldToFilter('date_requested', [
                'gteq' => date('Y-m-d 00:00:00', strtotime(trim($syncStartDate)))
            ]);
        } else {

            $rmaCollection->addFieldToFilter('date_requested', [
                'gteq' => $this->timezone->date()->format('Y-m-d 00:00:00')
            ]);
        }

        //->addFieldToFilter('store_id', ['in' => $allowedStoreIds])
        $rmaCollection->addFieldToFilter('increff_status', ['eq' => 0]);

        return $rmaCollection;
    }

    /**
     * @param $rmaEntityId
     * @return array
     */
    public function getRmaEntityItemsCollection($rmaEntityId)
    {
        return $this->rmaItemCollectionFactory->create()
            ->addFieldToSelect('*')
            ->addFieldToFilter('rma_entity_id', $rmaEntityId);
    }

    /**
     * Get all attribute options by attribute code RMA.
     * @return string[]
     */
    public function getRmaAttributeOptions(): array
    {
        $attributeCode = 'reason';
        $options = $this->attributeOptionManagement->getItems(
            RmaAttributesManagementInterface::ENTITY_TYPE,
            $attributeCode
        );

        $rmaOptions = [];

        foreach ($options as $option) {

            $rmaOptions[$option->getValue()] = strtolower($option->getLabel());
        }

        return $rmaOptions;
    }
}
