<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Crocs
 * @package  Crocs_Storelocator
 *
 */

namespace Crocs\Storelocator\Model\Resolver;
 
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\App\Action\Context;
use Amasty\Base\Model\Serializer; 
use Amasty\Storelocator\Model\Location as locationModel;
/*
  GraphQl class for API Call
*/

class StoreLocationDetail implements ResolverInterface
{

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Amasty\Storelocator\Model\LocationFactory $locationFactory,
        \Amasty\Storelocator\Model\ReviewFactory $reviewFactory,
        \Amasty\Storelocator\Model\GalleryFactory $galleryFactory,
        locationModel $locationModel,
        Serializer $serializer
    ) {
        $this->_storeManager=$storeManager;
        $this->locationFactory = $locationFactory;
        $this->reviewFactory = $reviewFactory;
        $this->galleryFactory = $galleryFactory;
        $this->locationModel = $locationModel;
        $this->serializer = $serializer;
    }
   
    /**
     * @param Field $field
     * @param \Magento\Framework\GraphQl\Query\Resolver\ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array|\Magento\Framework\GraphQl\Query\Resolver\Value|mixed
     * @throws GraphQlInputException
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $this->validateArgs($args);
        $output = [];
         $location = $this->locationFactory->create();
         $location = $location->getCollection();
        if ($args['id']) {
            $location = $location->addFieldToFilter('id', ['eq' => $args['id']]);
        }
            
        $x = [];
        
        foreach ($location as $item) {
            $this->locationModel->load($args['id']);  
			$schedule  = $this->locationModel->getData('schedule_string');
			$infoData = [];
			if(isset($schedule) && $schedule!=''){
				$schedule = $this->serializer->unserialize($schedule);
				if(isset($schedule) && count($schedule) >1){
					foreach($schedule as $index=>$info){
						$data['day'] = $index;				
						$data['info'] = $info;
						$data['info']['status'] = $info[$index.'_status'];
						$infoData[] = $data;
					}
				}
			}
            $x['id'] =  $item->getData('id');
            $x['name'] =  $item->getData('name');
            $x['country'] =  $item->getData('country');
            $x['city'] =  $item->getData('city');
            $x['state'] =  $item->getData('state');
            $x['address'] =  $item->getData('address');
            $x['lng'] =  $item->getData('lng');
            $x['lat'] =  $item->getData('lat');
            $x['zip'] =  $item->getData('zip');
            $x['stores'] =  $item->getData('stores');
            $x['schedule'] =  $infoData;
            $x['url_key'] =  "amlocator/".$item->getData('url_key');
            
              $j = 0;
              $m = 0;
              $y = [];
              $z = [];
              $review = $this->reviewFactory->create();
              $review = $review->getCollection();
              $review = $review->addFieldToFilter('location_id', ['eq' => $item->getData('id')]);
              
              $gallery = $this->galleryFactory->create();
              $gallery = $gallery->getCollection();
              $gallery = $gallery->addFieldToFilter('location_id', ['eq' => $item->getData('id')]);
            
            foreach ($review as $rev) {
                $y[$j]['location_id'] = $rev->getData('id');
                $y[$j]['review_text'] = $rev->getData('review_text');
                $y[$j]['customer_id'] = $rev->getData('customer_id');
                $y[$j]['rating'] = $rev->getData('rating');
                $y[$j]['placed_at'] = $rev->getData('placed_at');
                $y[$j]['published_at'] = $rev->getData('published_at');
                $y[$j]['status'] = $rev->getData('status');
                $j++;
            }

            foreach ($gallery as $gal) {
                $z[$m]['image_name'] = $gal->getData('image_name');
                $z[$m]['is_base'] = $gal->getData('is_base');
                $z[$m]['image_path'] = $this->getImgPath($gal->getData('image_name'), $gal->getData('location_id'));
                $m++;
            }
             $x['images'] =  $z;
             $x['reviews'] =  $y;
        
        }
        $output = $x;
        return $output ;
    }
    public function getImgPath($image_name, $location_id)
    {

        $media_url=$this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        return $media_url."amasty/amlocator/gallery/".$location_id."/".$image_name;
    }
    /**
     * @param array $args
     *
     * @throws GraphQlInputException
     */
    private function validateArgs(array $args): void
    {
        if (!isset($args['id'])) {
            throw new GraphQlInputException(__('Store location id value must be greater than 0.'));
        }
    }
}
