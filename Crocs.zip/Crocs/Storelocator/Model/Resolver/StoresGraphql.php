<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Crocs
 * @package  Crocs_Storelocator
 *
 */

namespace Crocs\Storelocator\Model\Resolver;
 
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Amasty\Storelocator\Model\ResourceModel\Attribute\Collection as AttributeCollection;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\ResponseInterface;
use Amasty\Storelocator\Model\ResourceModel\Location\CollectionFactory;
use Amasty\Base\Model\Serializer;
use Magento\Directory\Model\RegionFactory;

/*
  GraphQl class for API Call
*/

class StoresGraphql implements ResolverInterface
{

    /**
     * @var array
     */
    private $stateNameByCode = [];

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    /**
     * @var AttributeCollection
     */
    private $attributeCollection;

    /**
     * @var RegionFactory
     */
    private $regionFactory;

    /**
     * @var CollectionFactory
     */
    private $locationCollectionFactory;

    /**
     * @var Serializer
     */
    protected $serializer;
        
    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Amasty\Storelocator\Model\LocationFactory $locationFactory,
        \Amasty\Storelocator\Model\ReviewFactory $reviewFactory,
        \Amasty\Storelocator\Model\GalleryFactory $galleryFactory,
        Serializer $serializer,
        CollectionFactory $locationCollectionFactory,
        AttributeCollection $attributeCollection,
        RegionFactory $regionFactory,
        ResourceConnection $resourceConnection
    ) {

        $this->request = $request;
        $this->_storeManager=$storeManager;
        $this->locationFactory = $locationFactory;
        $this->reviewFactory = $reviewFactory;
        $this->galleryFactory = $galleryFactory;
        $this->serializer = $serializer;
        $this->regionFactory = $regionFactory;
        $this->locationCollectionFactory = $locationCollectionFactory;
        $this->attributeCollection = $attributeCollection;
        $this->resourceConnection = $resourceConnection;
    }
   
    /**
     * @param Field $field
     * @param \Magento\Framework\GraphQl\Query\Resolver\ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array|\Magento\Framework\GraphQl\Query\Resolver\Value|mixed
     * @throws GraphQlInputException
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {

        if (isset($args['lat']) && ($args['lat']!='')) {
             $this->request->setPostValue('lat', $args['lat']);
        }
        if (isset($args['lng']) && ($args['lng']!='')) {
            $this->request->setPostValue('lng', $args['lng']);
        }
        if (isset($args['radius']) && ($args['radius']!='')) {
            $this->request->setPostValue('radius', $args['radius']);
        }
         $postValue = $this->request->getPostValue();
         $location = $this->locationFactory->create();
         $locationCollection = $this->locationCollectionFactory->create();
         $locationCollection->applyDefaultFilters();
         $locationCollection->joinScheduleTable();
         $locationCollection->joinMainImage();
        if (isset($args['currentPage']) && ($args['currentPage']!='')) {
            $this->request->setPostValue('currentPage', $args['currentPage']);
        }
        $count = $locationCollection->getSize();
        $pageNumber = $args['currentPage'] ?? '1';
        $pageSize = $args['pageSize'] ?? '10';
        $locationCollection->setCurPage($pageNumber);
        $locationCollection->setPageSize($pageSize);
        $i = 0;
        $x = [];
        
        foreach ($locationCollection as $item) {
			$schedule  = $item->getData('schedule_string');
			$infoData = [];
			if(isset($schedule) && $schedule!=''){
				$schedule = $this->serializer->unserialize($schedule);
				if(isset($schedule) && count($schedule) >1){
					foreach($schedule as $index=>$info){
						$data['day'] = $index;				
						$data['info'] = $info;
						$data['info']['status'] = $info[$index.'_status'];
						$infoData[] = $data;
					}
				}
			}
            $x[$i]['id'] =  $item->getData('id');
            $x[$i]['name'] =  $item->getData('name');
            $x[$i]['country'] =  $item->getData('country');
            $x[$i]['city'] =  $item->getData('city');
            $x[$i]['state'] =  $this->getStateName($item->getData('state'));
            $x[$i]['address'] =  $item->getData('address');
            $x[$i]['lng'] =  $item->getData('lng');
            $x[$i]['lat'] =  $item->getData('lat');
            $x[$i]['zip'] =  $item->getData('zip');
            $x[$i]['stores'] =  $item->getData('stores');
            $x[$i]['phone_number'] =  $item->getData('phone');
            $x[$i]['email'] =  $item->getData('email');
            $x[$i]['state_id'] =  $item->getData('state');
            $x[$i]['store_code'] =  $this->getStoreCode($item->getData('id'));
            $x[$i]['schedule'] =  $infoData;
            $x[$i]['url_key'] =  "amlocator/".$item->getData('url_key');
            
              $j = 0;
              $m = 0;
              $y = [];
              $z = [];
              $review = $this->reviewFactory->create();
              $review = $review->getCollection();
              $review = $review->addFieldToFilter('location_id', ['eq' => $item->getData('id')]);
              
              $gallery = $this->galleryFactory->create();
              $gallery = $gallery->getCollection();
              $gallery = $gallery->addFieldToFilter('location_id', ['eq' => $item->getData('id')]);
            
            foreach ($review as $rev) {
                $y[$j]['location_id'] = $rev->getData('id');
                $y[$j]['review_text'] = $rev->getData('review_text');
                $y[$j]['customer_id'] = $rev->getData('customer_id');
                $y[$j]['rating'] = $rev->getData('rating');
                $y[$j]['placed_at'] = $rev->getData('placed_at');
                $y[$j]['published_at'] = $rev->getData('published_at');
                $y[$j]['status'] = $rev->getData('status');

                $j++;
            }
            foreach ($gallery as $gal) {
                $z[$m]['image_name'] = $gal->getData('image_name');
                $z[$m]['is_base'] = $gal->getData('is_base');
                $z[$m]['image_path'] = $this->getImgPath($gal->getData('image_name'), $gal->getData('location_id'));
                $m++;
            }
             $x[$i]['images'] =  $z;
             $x[$i]['reviews'] =  $y;
             $i++;
        
        }
        $output['totalRecords'] = $count;
        $output['pageSize'] = $args['pageSize'];
        $output['currentPage'] = $args['currentPage'];
        $output['stores'] = $x;
        return $output ;
    }

    public function getImgPath($image_name, $location_id)
    {

        $media_url=$this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        return $media_url."amasty/amlocator/gallery/".$location_id."/".$image_name;
    }
    
    /**
     * Get state name
     *
     * @return string
     */

    private function getStateName($stateCode)
    {
        if (!isset($this->stateNameByCode[$stateCode])) {
            $stateName = $this->regionFactory->create()->load($stateCode)->getName();
            $this->stateNameByCode[$stateCode] = $stateName ?: $stateCode;
        }
        return $this->stateNameByCode[$stateCode];
    }
    
    /**
     * Get Store Code 
     *
     * @return string
     */

    private function getStoreCode($storeId){

       $tableName = $this->resourceConnection->getTableName('amasty_amlocator_store_attribute');
       $connection = $this->resourceConnection->getConnection();
       $select = $connection->select()
            ->from(
                ['attr' => $tableName],
                ['value','store_id']
            )
            ->where(
                "attr.store_id = :store_id"
            );
        $row = ['store_id'=>$storeId];

        $fetchData  = $connection->fetchRow($select, $row);
        $store_code = array_column($fetchData, 'store_id');
        
        if($fetchData['value'] != "" && $fetchData['value'] != null) {
            
            return $fetchData['value'];
        }

        return "";
    }
}
