# Nalli_Categoryattribute

This module contain Custom category attributes 
international_store,
international_storecode,
is_international,
is_sneakpeak,
pagebuilder_image,
category_footer


## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Categoryattribute
php bin/magento setup:upgrade
php bin/magento setup:di:compile
php bin/magento setup:static-content:deploy -f
php bin/magento cache:clean
php bin/magento cache:flush 
```

## Usage

goto category admin form to get all these attribute on (International Store)
