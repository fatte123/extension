<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Categoryattribute
 */
 
namespace Nalli\Categoryattribute\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;

class InstallData implements InstallDataInterface
{
    /*
     *@var  EavSetupFactory $eavSetupFactory
     */
    private $eavSetupFactory;
    
    /*
     *@var  \Magento\Catalog\Setup\CategorySetupFactory $categorySetupFactory
     */
    protected $categorySetupFactory;

    /*
     *@param EavSetupFactory $eavSetupFactory,
     *@param \Magento\Catalog\Setup\CategorySetupFactory $categorySetupFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        \Magento\Catalog\Setup\CategorySetupFactory $categorySetupFactory
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->categorySetupFactory = $categorySetupFactory;
    }

    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $setup = $this->categorySetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY,
            'international_storecode',
            [
                'type'         => 'varchar',
                'label'        => 'International Storecode',
                'input'        => 'text',
                'sort_order'   => 100,
                'source'       => '',
                'global'       => 1,
                'visible'      => true,
                'required'     => false,
                'user_defined' => false,
                'default'      => null,
                'group'        => 'International Store Attributes',
                'backend'      => ''
            ]
        );
        $setup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY,
            'pagebuilder_image',
            [
                'type' => 'varchar',
                'label' => 'Pagebuilder Image',
                'input' => 'image',
                'backend' => \Magento\Catalog\Model\Category\Attribute\Backend\Image::class,
                'required' => false,
                'sort_order' => 9,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                'group' => 'International Store Attributes',
            ]
        );
    }
}
