<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Categoryattribute
 */
 
namespace Nalli\Categoryattribute\Model\Category;
 
class DataProvider extends \Magento\Catalog\Model\Category\DataProvider
{
 
    protected function getFieldsMap()
    {
        $fields = parent::getFieldsMap();
        $fields['content'][] = 'pagebuilder_image'; // custom image field
        return $fields;
    }
}
