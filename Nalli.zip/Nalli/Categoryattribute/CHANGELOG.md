# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## [1.0.2] - 2021-12-09
### Added
- This module contain Custom category attributes 
international_store,
international_storecode,
is_international,
is_sneakpeak,
pagebuilder_image,
category_footer
