# Nalli_Core

This module contain common js file ,admin menu and system Configuration file.

## INSTALLATION
In magento root directory, execute:


```bash
php bin/magento module:enable Nalli_Core
php bin/magento setup:upgrade
php bin/magento setup:di:compile
php bin/magento setup:static-content:deploy -f
php bin/magento cache:clean
php bin/magento cache:flush 
```

## Usage

goto admin=>Nalli admin menu (all custom extension link are there),

goto store=>Configuration=>Nalli  admin system Configuration (all custom system Configuration setting's are there)