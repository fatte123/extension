/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Core
 */
var config = {
    map: {
        '*': {
            'Nalli_Core/js/slick': 'Nalli_Core/js/slick',
            'Nalli_Core/js/niceselect': 'Nalli_Core/js/niceselect'
        }
    },
    paths: {
        'Nalli_Core/js/slick': 'Nalli_Core/js/slick',
        'Nalli_Core/js/niceselect': 'Nalli_Core/js/niceselect'
    },
    shim: {
      	'Nalli_Core/js/slick': {
            deps: ['jquery', 'jquery/ui']
        },
        'Nalli_Core/js/niceselect': {
            deps: ['jquery', 'jquery/ui']
        }
    }
};
