<?php

namespace Nalli\Core\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
	protected $_registry;
	
    /* 
	 *@var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
	
	public function __construct(
        \Magento\Framework\Registry $registry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\UrlInterface $urlInterface
    )
    {        
        $this->_registry = $registry;
		$this->_storeManager = $storeManager;
		$this->_urlInterface = $urlInterface;
    }
	
	public function getCurrentProduct()
    {        
        return $this->_registry->registry('current_product');
    }  
	
	public function getMediaUrl(){
	   return  $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
    
	public function getUrlInterfaceData()
    {
        return $this->_urlInterface;
   }  
}