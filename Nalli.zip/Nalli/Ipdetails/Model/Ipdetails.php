<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Model;

class Ipdetails extends \Magento\Framework\Model\AbstractModel implements
    \Magento\Framework\DataObject\IdentityInterface
{
    /**
     * @var CACHE_TAG
     */
    const CACHE_TAG = 'nalli_ipdetails_ipdetails';

    /**
     * @var _cacheTag
     */
    protected $_cacheTag = 'nalli_ipdetails_ipdetails';

    /**
     * @var _eventPrefix
     */
    protected $_eventPrefix = 'nalli_ipdetails_ipdetails';

    /**
     * Defined Constructor
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Nalli\Ipdetails\Model\ResourceModel\Ipdetails::class);
    }

    /**
     * @return int
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return array
     */
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
