<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Model\ResourceModel;

class Ipdetails extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('ipdetails', 'ipdetails_id');
    }
}
