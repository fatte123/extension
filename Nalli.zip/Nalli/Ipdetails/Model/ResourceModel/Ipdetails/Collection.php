<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Model\ResourceModel\Ipdetails;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var _idFieldName
     */
    protected $_idFieldName = 'ipdetails_id';

    /**
     * @var _eventPrefix
     */
    protected $_eventPrefix = 'nalli_ipdetails_ipdetails_collection';

    /**
     * @var _eventObject
     */
    protected $_eventObject = 'ipdetails_collection';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Nalli\Ipdetails\Model\Ipdetails::class, \Nalli\Ipdetails\Model\ResourceModel\Ipdetails::class);
    }
}
