<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Ipdetails
 */
 
namespace Nalli\Ipdetails\Cron;

class Ipdetailsupdate
{
	/*
	 *@var \Magento\Sales\Model\Order $order
	 */
	public $order;
	
	/*
	 *@var \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
	 */
	 public $ipdetailsFactory;
    
    /*
     *@param \Magento\Sales\Model\Order $order
     *@param \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
     */
    
    public function __construct(
       \Magento\Sales\Model\Order $order,
	   \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory,
	   \Nalli\Ipdetails\Model\ResourceModel\Ipdetails\CollectionFactory $IpdetailsCollectionFactory,
	   \Magento\Framework\Serialize\Serializer\Serialize $searializenew,
	   \Magento\Framework\Filesystem\Driver\File $fileSystem,
	   \Nalli\Ipdetails\Logger\Logger $logger
    ) {
        $this->order = $order;
        $this->ipdetailsFactory = $ipdetailsFactory;
		$this->ipdetailsCollectionFactory =$IpdetailsCollectionFactory;
		$this->searializenew = $searializenew;
		 $this->_fileSystem = $fileSystem;
		$this->logger = $logger;
    }
    
    public function execute()
    {
		$collection = $this->ipdetailsCollectionFactory->create();
		$collection->addFieldToFilter('increment_id',array('null' => true));
		$collection->setPageSize(50);
		$collection->setCurPage(1);
		$collection->setOrder('ipdetails_id','DESC');
		foreach ($collection as $data) { 
			$order = $this->getorder($data->getOrderId());
			if($order){
				$ip = $order->getRemoteIp();
				$query = $this->searializenew->unserialize(
                        $this->_fileSystem->fileGetContents('http://pro.ip-api.com/php/'.$ip.'?key=7guBP1wLZmbAoTr')
                    );
				if ($query && $query['status'] == 'success') {
					$model  = $this->ipdetailsFactory->create();
					$result = $model->load($data->getIpdetailsId());
					$model->setIncrementId($order->getIncrementId());
					$model->setIpAddress($ip);
					$model->setCountry($query['country']);
					$model->setState($query['regionName']);
					$model->setCity($query['city']);
					$model->setCountryId($query['countryCode']); 
					$model->save();	
				}
			}
		}
	
	}
    
    /*
     *return product details
     */
    public function getorder($id)
    {
        $order=null;
        try {
            $order = $this->order->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($id.' --dont exits-- ');
            return false;
        }
        return $order;
    }
}
