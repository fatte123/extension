<?php
namespace Nalli\Ipdetails\Setup;

use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('ipdetails');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'ipdetails_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'order_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'increment_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'ip_address',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'country',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'state',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'city',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'country_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'user_agent',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'device',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'os',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'browser',
                                Table::TYPE_TEXT,
                                255
                            )
                             ->addColumn(
                                 'created_time',
                                 Table::TYPE_DATETIME
                             )
                             ->addColumn(
                                 'update_time',
                                 Table::TYPE_DATETIME
                             )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }

        $setup->endSetup();
    }
}
