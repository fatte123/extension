## Nalli_Ipdetails
-------------
This module contain sync orders data by Ip.


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Ipdetails
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
Orders Sync Dashboard, you can review those data from admin gid.


## Copyright
---------
Copyright (c) 2022. 18th DigiTech Team. All rights reserved.