<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Block\Adminhtml\Ipdetails\Custom;

use Magento\Backend\Block\Widget\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Button implements ButtonProviderInterface
{
    /**
     * @var Context
     */
    protected $context;

    /**
     * @param Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     * @param \Magento\Framework\UrlInterface $urlInterface
     */
    public function __construct(
        Context $context,
        \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
        \Magento\Framework\UrlInterface $urlInterface
    ) {
        $this->context = $context;
        $this->StoreManagerInterface = $StoreManagerInterface;
        $this->urlInterface = $urlInterface;
    }
/**
 * @return array
 */
    public function getButtonData()
    {
        $storeManager = $this->StoreManagerInterface;
        $backendUrl = $this->urlInterface;
        $base_url = $storeManager->getStore()->getBaseUrl();
        $callback_url = $backendUrl->getUrl('ipdetails/ipdetails/bulk/is_sync/1');
        $data = [];
            $data = [
                'id' => 'add',
                'name' => 'add',
                'label' => __('Sync Order Data'),
                'class' => 'primary',
                'url' => $callback_url
            ];
            return $data;
    }

    /**
     * @return int
     */
    public function getStoreId()
    {
        return $this->context->getRequest()->getParam('store_id');
    }

    /**
     * @return string
     */
    public function getOption()
    {
        return $this->context->getRequest()->getParam('option');
    }
}
