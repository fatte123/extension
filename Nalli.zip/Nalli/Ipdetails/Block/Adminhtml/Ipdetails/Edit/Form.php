<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Block\Adminhtml\Ipdetails\Edit;

/**
 * Adminhtml Add New Row Form.
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Nalli\Ipdetails\Block\Adminhtml\Ipdetails\Custom\Button $customButton
     */

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Nalli\Ipdetails\Block\Adminhtml\Ipdetails\Custom\Button $customButton,
        array $data = []
    ) {
        $this->customButton = $customButton;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $blockObj = $this->customButton;
        $option = $blockObj->getOption();
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );
        $form->setHtmlIdPrefix('ipdetails');
        if ($model->getIpdetailsId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Item'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('ipdetails_id', 'hidden', ['name' => 'ipdetails_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Item'), 'class' => 'fieldset-wide']
            );
        }
        if ($option == '2') {
            $fieldset->addField(
                'store_id',
                'text',
                [
                'name' => 'store_id',
                'label' => __('Store Id'),
                'id' => 'store_id',
                'title' => __('Store Id'),
                ]
            );
            $fieldset->addField(
                'bulk_file',
                'file',
                [
                    'name' => 'bulk_file',
                    'label' => __('File'),
                    'id' => 'bulk_file',
                    'title' => __('File'),
                ]
            );
        }

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
