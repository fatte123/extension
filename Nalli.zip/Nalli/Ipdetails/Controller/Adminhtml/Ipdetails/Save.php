<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Controller\Adminhtml\Ipdetails;

use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\HTTP\PhpEnvironment\Request;

class Save extends \Magento\Backend\App\Action
{
    protected $_ipdetailsFactory;
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;

    /**
     * @var Request
     */
    protected $request;

    /**
     * Save constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\Http $request
     * @param \UploaderFactory $uploaderFactory
     * @param \dapterFactory $adapterFactory
     * @param \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
     * @param \Magento\Framework\Filesystem\Driver\File $fileSystem
     * @param Request $fileRequest
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
        \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory,
        \Magento\Framework\Filesystem\Driver\File $fileSystem,
        Request $fileRequest
    ) {
        $this->request = $request;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->_ipdetailsFactory = $ipdetailsFactory;
        $this->_fileSystem = $fileSystem;
        $this->fileRequest = $fileRequest;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('ipdetails/ipdetails/add/');
            return;
        }
        $files = $this->fileRequest->getFiles()->toArray(); // same as $_FIELS
        if (isset($files['bulk_file']['name']) && $files['bulk_file']['name'] != '') {
            $this->_bulkUpload($data['store_id']);
        } else {
            try {
                if (array_key_exists('ipdetails_id', $data)) {
                    $rowData =  $this->_ipdetailsFactory->create()->load($data['ipdetails_id']);
                    date_default_timezone_set("Asia/Calcutta");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData->setData($data);
                    $rowData->save();
                } else {
                    date_default_timezone_set("Asia/Calcutta");
                    $data['created_time'] = date("Y-m-d h:i:sa");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData1 =  $this->_ipdetailsFactory->create();
                    $rowData1->setData($data);
                    $rowData1->save();
                }
                    $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
            }
        }
        $this->_redirect('ipdetails/ipdetails/index/');
    }

    protected function _bulkUpload($store_id)
    {
        date_default_timezone_set("Asia/Calcutta");
        try {
            $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'bulk_file']);
            $uploaderFactory->setAllowedExtensions(['CSV', 'csv']);
            $fileAdapter = $this->adapterFactory->create();
            $uploaderFactory->setAllowRenameFiles(true);
            $destinationPath = $this->filesystem->getDirectoryRead(
                \Magento\Framework\App\Filesystem\DirectoryList::MEDIA
            )->getAbsolutePath('ipdetails');
            $result = $uploaderFactory->save($destinationPath);
            if (!$result) {
                throw new LocalizedException(
                    __('File cannot be saved to path: $1', $destinationPath)
                );
            }
            $fileHandler = $this->_fileSystem->fileOpen($destinationPath."/".$result['file'], 'r');
            $i = 0;
            if ($fileHandler) {
                $colNames = $this->_fileSystem->fileGetCsv($fileHandler);
                foreach ($colNames as &$colName) {
                    $colName = trim($colName);
                }
                $requiredColumns = ['order_id', 'increment_id', 'ip_address', 'country', 'state', 'city', 'country_id'];
                $requiredColumnsPositions = [];

                foreach ($requiredColumns as $columnName) {
                    $found = array_search($columnName, $colNames);
                    if (false !== $found) {
                        $requiredColumnsPositions[] = $found;
                    } else {
                        $this->messageManager->addError('Corrupt file');
                        $this->_redirect('ipdetails/ipdetails/add/option/2/');
                        return;
                    }
                }
                while (($currentRow = $this->_fileSystem->fileGetCsv($fileHandler)) !== false) {
                    foreach ($requiredColumnsPositions as $index) {
                        if (isset($currentRow[$index])) {
                            $csvDataRow[$colNames[$index]] = trim($currentRow[$index]);
                        }
                    }
                    if (isset($csvDataRow['order_id']) && $csvDataRow['order_id'] !== '') {
                        $csvData[] = $csvDataRow;
                    }
                }
                
                $added = 0;
                $present = 0;
                $error = "";

                foreach ($csvData as $productdata) {
                        $model = $this->_ipdetailsFactory->create();
                        $model->setOrderId($productdata['order_id']);
                        $model->setIncrementId($productdata['increment_id']);
                        $model->setIpAddress($productdata['ip_address']);
                        $model->setCountry($productdata['country']);
                        $model->setState($productdata['state']);
                        $model->setCity($productdata['city']);
                        $model->setCountryId($productdata['country_id']);
                        $model->setCreatedTime(date("Y-m-d h:i:sa"));
                        $model->setUpdateTime(date("Y-m-d h:i:sa"));
                        $model->save();
                        $added++;
                }
                $this->_fileSystem->fileGetCsv->fileClose($fileHandler);
                $succmsg = $added ." items added";
                $this->messageManager->addSuccess(__($succmsg));
                if ($error) {
                    $errmsg = "Items already present: " .$error;
                    $this->messageManager->addError(__($errmsg));
                }
                $this->_redirect('ipdetails/ipdetails/add/option/2/');
                return;
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            return;
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Ipdetails::save');
    }
}
