<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Controller\Adminhtml\Ipdetails;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\SerializerInterface;

class Bulk extends \Magento\Backend\App\Action
{
    /**
     * @var _ipdetailsFactory
     */
    protected $_ipdetailsFactory;

    /**
     * @var SerializerInterface
     */
    private $serializer;
    /**
     * Businessoverview constructor.
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\Sales\Model\Order $order
     * @param SerializerInterface $serializer
     * @param \Magento\Framework\Filesystem\Driver\File $fileSystem
     */

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Sales\Model\Order $order,
        SerializerInterface $serializer = null,
        \Magento\Framework\Serialize\Serializer\Serialize $searializenew,
        \Magento\Framework\Filesystem\Driver\File $fileSystem,
        \Nalli\Ipdetails\Logger\Logger $logger
    ) {
        $this->request = $request;
        $this->_ipdetailsFactory = $ipdetailsFactory;
        $this->_messageManager = $messageManager;
        $this->_order = $order;
        $this->searializenew = $searializenew;
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(SerializerInterface::class);
        $this->_fileSystem = $fileSystem;
        $this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Set Sync order data.
     * @return string
     */
    public function execute()
    {
        if ($this->request->getParam('is_sync') == 1) {
            try {
                $orders = $this->_order->getCollection();
                $orders->addAttributeToSelect('entity_id');
                $orders->addAttributeToSelect('increment_id');
                $orders->addAttributeToSelect('remote_ip');
                $orders->getSelect()->group('entity_id');
                $orders->getSelect()->joinLeft(
                    'ipdetails',
                    'main_table.entity_id = ipdetails.order_id',
                    ['ip_address']
                );
                $orders->addAttributeToFilter('ipdetails.ip_address', ['null' => true]);

                $added = 0;
                $error = "";

                foreach ($orders as $order) {
                    $ip = $order->getRemoteIp();
                    $query = $this->searializenew->unserialize(
                        $this->_fileSystem->fileGetContents('http://pro.ip-api.com/php/'.$ip.'?key=7guBP1wLZmbAoTr')
                    );
                    if ($query && $query['status'] == 'success') {

                        $model = $this->_ipdetailsFactory->create();
                        $model->setOrderId($order->getId());
                        $model->setIncrementId($order->getIncrementId());
                        $model->setIpAddress($ip);
                        $model->setCountry($query['country']);
                        $model->setState($query['regionName']);
                        $model->setCity($query['city']);
                        $model->setCountryId($query['countryCode']);
                        $model->save();

                        $added++;

                    } else {
                        //echo $order->getId();die;
                        $model = $this->_ipdetailsFactory->create();
                        $model->setOrderId($order->getId());
                        $model->setIncrementId($order->getIncrementId());
                        $model->setIpAddress($ip);
                        $model->save();
                        $error .= $order->getId() ." - " .$ip .", ";
                        $this->logger->info($error.' -- Synchronize  error-- ');
                    }
                }

                $succmsg = $added ." items added";
                 $this->_messageManager->addSuccessMessage($succmsg);
                if ($error) {
                    $errmsg = "Items have error: " .$error;
                    $this->_messageManager->addErrorMessage($errmsg);
                }
                $this->_redirect('ipdetails/ipdetails/index');
                return;
            } catch (Exception $e) {
                $this->_messageManager->addErrorMessage($e->getMessage());
            }
                $this->_redirect('ipdetails/ipdetails/index');
        }
    }
}
