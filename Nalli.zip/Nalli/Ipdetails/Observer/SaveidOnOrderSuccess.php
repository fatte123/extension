<?php
 /**
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Ipdetails
  */
namespace Nalli\Ipdetails\Observer;

use Magento\Framework\Event\ObserverInterface;

class SaveidOnOrderSuccess implements ObserverInterface
{
    /**
     * @var \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
     */
    protected $ipdetailsFactory;
  
    /*
     *@parma \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
     */
    public function __construct(
        \Nalli\Ipdetails\Model\IpdetailsFactory $ipdetailsFactory
    ) {
        $this->_ipdetailsFactory = $ipdetailsFactory;
    }
    
    /*save order id to ipdetails table*/
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getEvent()->getOrderIds();
        if (count($orderIds)) {
            $orderId = $orderIds[0];
            $model = $this->_ipdetailsFactory->create();
            $model->setOrderId($orderId);
            $model->save();
        }
    }
}
