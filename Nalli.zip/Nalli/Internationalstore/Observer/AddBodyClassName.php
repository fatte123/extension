<?php
/**
 * Internationalstore Observer
 *
 * This Observer class use to add body class name
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class AddBodyClassName
 * frontend area, layout_render_before event
 */
class AddBodyClassName implements ObserverInterface
{
    /**
     * Request
     *
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var \Magento\Framework\View\Page\Config
     */
    private $pageConfig;

    /**
     * @var \Magento\Framework\View\DesignInterface
     */
    private $design;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**     
     *
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Config $pageConfig
     * @param \Magento\Framework\View\DesignInterface $design
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Config $pageConfig,
        \Magento\Framework\View\DesignInterface $design,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->request = $request;
        $this->pageConfig = $pageConfig;
        $this->design = $design;
        $this->logger = $logger;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {  

       if ($this->request->getFullActionName() == 'catalog_product_view') {      
         try {
            
             if ($this->pageConfig->getElementAttribute(
                   \Magento\Framework\View\Page\Config::ELEMENT_TYPE_BODY,
                   \Magento\Framework\View\Page\Config::BODY_ATTRIBUTE_CLASS
                ) && $this->pageConfig->getPageLayout() == 'product-international') {
                   $this->pageConfig->addBodyClass('product-international');
                   $this->pageConfig->addBodyClass('page-layout-1column');
                }

            } catch (\Exception $exception) {
                $this->logger->critical($exception);
            } 
         }          
    }
}
