<?php
/**
 * Nalli
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the nalli.com license that is
 * available through the world-wide-web at this URL:
 * https://www.nalli.com/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Nalli
 * @package     Nalli_Internationalstore
 * @copyright   Copyright (c) Nalli (https://www.nalli.com/)
 * @license     https://www.nalli.com/
 */
namespace Nalli\Internationalstore\Setup;

use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('internationalstore');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'internationalstore_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'store_name',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'store_code',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'store_currency',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'currency_attribute',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'store_contact',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'store_mobile',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'viewpage_text',
                                Table::TYPE_TEXT
                            )
                            ->addColumn(
                                'listpage_text',
                                Table::TYPE_TEXT
                            )
                            ->addColumn(
                                'sneak_title',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'sneak_content',
                                Table::TYPE_TEXT
                            )
                            ->addColumn(
                                'sneak_label',
                                Table::TYPE_TEXT,
                                255
                            )
                             ->addColumn(
                                 'sneak_countrycode',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'sneak_footer_text',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'sneak_footer_link',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'sneak_error',
                                 Table::TYPE_TEXT
                             )
                             ->addColumn(
                                 'session_name',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'session_auth',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'cookie_name',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'email_required',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'sneak_priceverify',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'reg_priceverify',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'memberprice_attribute',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'session_priceauth',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'session_timeout',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'static_content',
                                 Table::TYPE_TEXT
                             )
                             ->addColumn(
                                 'sneak_email_label',
                                 Table::TYPE_TEXT,
                                 255
                             )
                             ->addColumn(
                                 'created_time',
                                 Table::TYPE_DATETIME
                             )
                             ->addColumn(
                                 'update_time',
                                 Table::TYPE_DATETIME
                             )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }
        $setup->endSetup();
    }
}
