<?php
/**
 * Internationstore block edit form
 *
 * This class renders form data
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Block\Adminhtml\Internationalstore\Edit;

/**
 * Adminhtml Add New Row Form.
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Nalli\Internationalstore\Model\Source\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context       $context
     * @param \Magento\Framework\Registry                   $registry
     * @param \Magento\Framework\Data\FormFactory           $formFactory
     * @param \Nalli\Internationalstore\Model\Source\Status $status
     * @param array                                         $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Nalli\Internationalstore\Model\Source\Status $status,
        array $data = []
    ) {
        $this->_status = $status;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('internationalstore_');
        if ($model->getInternationalstoreId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Row Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('internationalstore_id', 'hidden', ['name' => 'internationalstore_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Row Data'), 'class' => 'fieldset-wide']
            );
        }
        $fieldset->addField(
            'store_name',
            'text',
            [
                'name' => 'store_name',
                'label' => __('Store Name'),
                'id' => 'store_name',
                'title' => __('Store Name'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'store_code',
            'text',
            [
                'name' => 'store_code',
                'label' => __('Store Code'),
                'id' => 'store_code',
                'title' => __('Store Code'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'store_currency',
            'text',
            [
                'name' => 'store_currency',
                'label' => __('Store Currency Code'),
                'id' => 'store_currency',
                'title' => __('Store Currency Code'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'currency_attribute',
            'text',
            [
                'name' => 'currency_attribute',
                'label' => __('Currency Attribute'),
                'id' => 'currency_attribute',
                'title' => __('Currency Attribute'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'memberprice_attribute',
            'text',
            [
                'name' => 'memberprice_attribute',
                'label' => __('Member Price Attribute'),
                'id' => 'memberprice_attribute',
                'title' => __('Member Price Attribute'),
            ]
        );
        $fieldset->addField(
            'store_contact',
            'text',
            [
                'name' => 'store_contact',
                'label' => __('Store Contact'),
                'id' => 'store_contact',
                'title' => __('Store Contact'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'store_mobile',
            'text',
            [
                'name' => 'store_mobile',
                'label' => __('Store Mobile'),
                'id' => 'store_mobile',
                'title' => __('Store Mobile'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'email_required',
            'select',
            [
                'name' => 'email_required',
                'required'  => true,
                'label' => __('Verify email in Sneak Preview?'),
                'id' => 'email_required',
                'title' => __('Verify email in Sneak Preview?'),
                'class' => 'required-entry email_required',
                'values'    => [
                  [
                      'value'     => 1,
                      'label'     => 'Yes',
                  ],[
                      'value'     => 2,
                      'label'     => 'No',
                  ],
                ],
            ]
        );
        $fieldset->addField(
            'sneak_priceverify',
            'select',
            [
                'name' => 'sneak_priceverify',
                'required'  => true,
                'label' => __('Sneak Preview: Price on Request'),
                'id' => 'sneak_priceverify',
                'title' => __('Sneak Preview: Price on Request'),
                'class' => 'required-entry sneak_priceverify',
                'values'    => [
                  [
                      'value'     => 1,
                      'label'     => 'Yes',
                  ],[
                      'value'     => 2,
                      'label'     => 'No',
                  ],
                ],
            ]
        );
         $fieldset->addField(
             'reg_priceverify',
             'select',
             [
                'name' => 'reg_priceverify',
                'required'  => true,
                'label' => __('Regular Collection: Price on Request'),
                'id' => 'reg_priceverify',
                'title' => __('Regular Collection: Price on Request'),
                'class' => 'required-entry reg_priceverify',
                'values'    => [
                  [
                      'value'     => 1,
                      'label'     => 'Yes',
                  ],[
                      'value'     => 2,
                      'label'     => 'No',
                  ],
                ],
             ]
         );
        $fieldset->addField(
            'viewpage_text',
            'textarea',
            [
                'name' => 'viewpage_text',
                'label' => __('Store View Page Text'),
                'id' => 'viewpage_text',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Store View Page Text'),
            ]
        );
        $fieldset->addField(
            'listpage_text',
            'textarea',
            [
                'name' => 'listpage_text',
                'label' => __('Store Liew Page Text'),
                'id' => 'listpage_text',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Store Liew Page Text'),
            ]
        );
        $fieldset->addField(
            'sneak_title',
            'text',
            [
                'name' => 'sneak_title',
                'label' => __('Sneak Preview Title'),
                'id' => 'sneak_title',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Sneak Preview Title'),
            ]
        );
        $fieldset->addField(
            'sneak_content',
            'textarea',
            [
                'name' => 'sneak_content',
                'label' => __('Sneak Preview Content'),
                'id' => 'sneak_content',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Sneak Preview Content'),
            ]
        );
        $fieldset->addField(
            'sneak_label',
            'text',
            [
                'name' => 'sneak_label',
                'label' => __('Sneak Preview Mobile Label'),
                'id' => 'sneak_label',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Sneak Preview Mobile Label'),
            ]
        );
        $fieldset->addField(
            'sneak_email_label',
            'text',
            [
                'name' => 'sneak_email_label',
                'label' => __('Sneak Preview Email Label'),
                'id' => 'sneak_email_label',
                'title' => __('Sneak Preview Email Label'),
            ]
        );
        $fieldset->addField(
            'sneak_countrycode',
            'text',
            [
                'name' => 'sneak_countrycode',
                'label' => __('Sneak Preview Countrycode'),
                'id' => 'sneak_countrycode',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Sneak Preview Countrycode'),
            ]
        );
        $fieldset->addField(
            'sneak_footer_text',
            'text',
            [
                'name' => 'sneak_footer_text',
                'label' => __('Sneak Preview Footer Text'),
                'id' => 'sneak_footer_text',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Sneak Preview Footer Text'),
            ]
        );
        $fieldset->addField(
            'sneak_footer_link',
            'text',
            [
                'name' => 'sneak_footer_link',
                'label' => __('Sneak Preview Footer Link'),
                'id' => 'sneak_footer_link',
                'class'     => 'required-entry',
                'required'  => true,
                'title' => __('Sneak Preview Footer Link'),
            ]
        );
        $fieldset->addField(
            'sneak_error',
            'textarea',
            [
                'name' => 'sneak_error',
                'label' => __('Sneak Preview Error Message'),
                'id' => 'sneak_error',
                'class'     => 'required-entry',
                'required'  => true,
                'title' => __('Sneak Preview Error Message'),
            ]
        );
        $fieldset->addField(
            'session_name',
            'text',
            [
                'name' => 'session_name',
                'label' => __('Session Name'),
                'id' => 'session_name',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Session Name'),
            ]
        );
        $fieldset->addField(
            'session_auth',
            'text',
            [
                'name' => 'session_auth',
                'label' => __('Session Auth'),
                'id' => 'session_auth',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Session Auth'),
            ]
        );
        $fieldset->addField(
            'cookie_name',
            'text',
            [
                'name' => 'cookie_name',
                'label' => __('Cookie Name'),
                'id' => 'cookie_name',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Cookie Name'),
            ]
        );
        $fieldset->addField(
            'session_priceauth',
            'text',
            [
                'name' => 'session_priceauth',
                'label' => __('Session Price Auth'),
                'id' => 'session_priceauth',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Session Price Auth'),
            ]
        );
        $fieldset->addField(
            'session_timeout',
            'text',
            [
                'name' => 'session_timeout',
                'label' => __('Session Timeout'),
                'id' => 'session_timeout',
                'class' => 'required-entry',
                'required' => true,
                'title' => __('Session Timeout'),
            ]
        );
        $fieldset->addField(
            'static_content',
            'textarea',
            [
                'name' => 'static_content',
                'label' => __('Static JS/CSS'),
                'id' => 'static_content',
                'title' => __('Static JS/CSS'),
            ]
        );
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
