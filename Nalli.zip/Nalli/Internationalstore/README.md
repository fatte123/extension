This module contain the functionality to add customer emails to display private categories.

# Nalli_Internationalstore

This module contain functionality to add custom stores & code with its attributes.

## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Internationalstore
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage

goto nalli backend to check the functionality to check and add/upload custom store and other details.
