<?php
/**
 * module registration file
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Nalli_Internationalstore',
    __DIR__
);
