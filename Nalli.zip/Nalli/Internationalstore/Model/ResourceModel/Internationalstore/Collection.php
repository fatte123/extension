<?php
/**
 * Internationalstore Collection
 *
 * This class returns table collection data
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Model\ResourceModel\Internationalstore;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'internationalstore_id';
    protected $_eventPrefix = 'nalli_internationalstore_internationalstore_collection';
    protected $_eventObject = 'internationalstore_collection';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Nalli\Internationalstore\Model\Internationalstore::class,
            \Nalli\Internationalstore\Model\ResourceModel\Internationalstore::class
        );
    }
}
