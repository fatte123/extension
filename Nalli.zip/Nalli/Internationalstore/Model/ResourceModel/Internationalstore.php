<?php
/**
 * Internationalstore Resource Model
 *
 * This class connects db table
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Model\ResourceModel;

class Internationalstore extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('internationalstore', 'internationalstore_id');
    }
}
