<?php
/**
 * Internationalstore Model
 *
 * This class acts as an interface for db operations
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Model;

use \Magento\Framework\Model\AbstractModel;
use \Magento\Framework\DataObject\IdentityInterface;

class Internationalstore extends AbstractModel implements IdentityInterface
{
    const CACHE_TAG = 'nalli_internationalstore_internationalstore';

    protected $_cacheTag = 'nalli_internationalstore_internationalstore';

    protected $_eventPrefix = 'nalli_internationalstore_internationalstore';

    protected function _construct()
    {
        $this->_init(\Nalli\Internationalstore\Model\ResourceModel\Internationalstore::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
