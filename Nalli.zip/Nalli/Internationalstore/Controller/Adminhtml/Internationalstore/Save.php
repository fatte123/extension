<?php
/**
 * Internationalstore admin controller
 *
 * This controller saves the items
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Internationalstore
 */

namespace Nalli\Internationalstore\Controller\Adminhtml\Internationalstore;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Nalli\Internationalstore\Model\InternationalstoreFactory
     */
    protected $_internationalstoreFactory;

    /**
     * @param \Nalli\Internationalstore\Model\InternationalstoreFactory $internationalstoreFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Internationalstore\Model\InternationalstoreFactory $internationalstoreFactory
    ) {
        $this->request = $request;
        $this->_internationalstoreFactory = $internationalstoreFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('internationalstore/internationalstore/add/');
            return;
        }
        try {
            date_default_timezone_set("Asia/Calcutta");
            if (array_key_exists('internationalstore_id', $data)) {
                $rowData =  $this->_internationalstoreFactory->create()->load($data['internationalstore_id']);
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData->setData($data);
                $rowData->save();
            } else {
                $data['created_time'] = date("Y-m-d h:i:sa");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData1 =  $this->_internationalstoreFactory->create();
                $rowData1->setData($data);
                $rowData1->save();
            }
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('internationalstore/internationalstore/index/');
    }

    /**
     * Check permission for passed action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Internationalstore::save');
    }
}
