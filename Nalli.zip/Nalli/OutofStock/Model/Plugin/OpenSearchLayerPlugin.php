<?php

namespace Nalli\OutofStock\Model\Plugin;

use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Registry;
use Magento\Store\Model\ScopeInterface;
use Nalli\OutofStock\Helper\Data;

class OpenSearchLayerPlugin
{
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\Collection
     */
    protected $productCollection;
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;
    /**
     * @var \Nalli\OutofStock\Helper\Data
     */
    protected $helper;

    /**
     * Constructor for Layper Plugin
     *
     * @param Registry $registry
     * @param ScopeConfigInterface $scopeConfig
     * @param Collection $productCollection
     * @param Data $helper
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ResourceModel\Product\Collection $productCollection,
        \Nalli\OutofStock\Helper\Data $helper
    ) {
        $this->productCollection = $productCollection;
        $this->scopeConfig = $scopeConfig;
        $this->registry = $registry;
        $this->helper = $helper;
    }

    /**
     * Plugin for before query
     *
     * @param \Magento\OpenSearch\Model\SearchClient $subject
     * @param array $query
     * @return array[]
     */
    public function beforeQuery(
        \Magento\OpenSearch\Model\SearchClient $subject,
        $query
    ) {
        if ($this->helper->isNotifyStockEnabled()) {

            $productIds = $this->filterCollectionIds();
            if (!empty($productIds)) {

                $query['body']['query']['bool']['filter'] = [
                    'ids' => ['values' => $productIds]
                ];
            }
        }

        return [$query];
    }

    /**
     * Function to get Filtered product Ids
     *
     * @return array
     */
    public function filterCollectionIds()
    {
        $categoryId = 0;
        if(null !== $this->registry->registry('current_category')){
			$categoryId = $this->registry->registry('current_category')->getId();
		}
        $allowedCategories = $this->scopeConfig->getValue(
            'outofstock/selection_page/categories',
            ScopeInterface::SCOPE_STORE
        );
        $categories = explode(",", $allowedCategories);

        $filterIds = [];
        if (!in_array($categoryId, $categories)) {
            $collection = $this->productCollection;
            $collection->addFieldToSelect('*')
                ->setFlag('has_stock_status_filter', true)
                ->joinField(
                    'stock_item',
                    'cataloginventory_stock_item',
                    'is_in_stock',
                    'product_id=entity_id',
                    'is_in_stock=1'
                );
            if($categoryId > 0 ){   
				$collection->addCategoriesFilter(['eq' => $categoryId]);
			}
            foreach ($collection as $product) {
                $productId = $product->getId();
                $filterIds[] = $productId;
            }

        }
        return $filterIds;
    }
}
