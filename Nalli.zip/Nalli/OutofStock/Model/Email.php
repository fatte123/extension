<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Nalli\OutofStock\Model;

use Magento\Framework\App\Area;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\ProductAlert\Block\Email\AbstractEmail;
use Magento\ProductAlert\Block\Email\Price;
use Magento\ProductAlert\Block\Email\Stock;
use Magento\Store\Model\ScopeInterface;

class Email extends \Magento\ProductAlert\Model\Email
{
    public const EMAIL_CC = 'outofstock/email/address_cc';
    public const ENABLED = 'outofstock/general/enabled';
    /**
     * Send customer email
     *
     * @return bool
     * @throws MailException
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function send()
    {
        $status = (bool)$this->_scopeConfig->getValue(
            self::ENABLED,
            ScopeInterface::SCOPE_STORE
        );
        if ($status) {

            if ($this->_website === null || $this->_customer === null || !$this->isExistDefaultStore()) {
                return false;
            }

            $products = $this->getProducts();
            $templateConfigPath = $this->getTemplateConfigPath();
            if (!in_array($this->_type, ['price', 'stock']) || count($products) === 0 || !$templateConfigPath) {
                return false;
            }

            $storeId = (int)$this->getStoreId() ?: (int)$this->_customer->getStoreId();
            $store = $this->getStore($storeId);

            $this->_appEmulation->startEnvironmentEmulation($storeId);

            $block = $this->getBlock();
            $block->setStore($store)->reset();

            // Add products to the block
            foreach ($products as $product) {
                $product->setCustomerGroupId($this->_customer->getGroupId());
                $block->addProduct($product);
            }

            $templateId = $this->_scopeConfig->getValue(
                $templateConfigPath,
                ScopeInterface::SCOPE_STORE,
                $storeId
            );

            $alertGrid = $this->_appState->emulateAreaCode(
                Area::AREA_FRONTEND,
                [$block, 'toHtml']
            );
            $this->_appEmulation->stopEnvironmentEmulation();

            $ccReceiver = $this->_scopeConfig->getValue(
                self::EMAIL_CC,
                ScopeInterface::SCOPE_STORE,
                $storeId
            );

            $customerName = $this->_customerHelper->getCustomerName($this->_customer);
            $this->_transportBuilder->setTemplateIdentifier(
                $templateId
            )->setTemplateOptions(
                ['area' => Area::AREA_FRONTEND, 'store' => $storeId]
            )->setTemplateVars(
                [
                    'customerName' => $customerName,
                    'alertGrid' => $alertGrid,
                ]
            )->setFromByScope(
                $this->_scopeConfig->getValue(
                    self::XML_PATH_EMAIL_IDENTITY,
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                ),
                $storeId
            )->addTo(
                $this->_customer->getEmail(),
                $customerName
            );
            $notifyReceier = explode(',', $ccReceiver);
            foreach ($notifyReceier as $receiver) {
                $this->_transportBuilder->addCc($receiver);
            }

            $this->_transportBuilder->getTransport()->sendMessage();

        } else {
            parent::send();
        }
        return true;
    }
    /**
     * Check if exists default store.
     *
     * @return bool
     */
    private function isExistDefaultStore(): bool
    {
        if (!$this->_website->getDefaultGroup() || !$this->_website->getDefaultGroup()->getDefaultStore()) {
            return false;
        }
        return true;
    }
    /**
     * Retrieve the products for the email based on type
     *
     * @return array
     */
    private function getProducts(): array
    {
        return $this->_type === 'price'
            ? $this->_priceProducts
            : $this->_stockProducts;
    }
    /**
     * Retrieve template config path based on type
     *
     * @return string
     */
    private function getTemplateConfigPath(): string
    {
        return $this->_type === 'price'
            ? self::XML_PATH_EMAIL_PRICE_TEMPLATE
            : self::XML_PATH_EMAIL_STOCK_TEMPLATE;
    }
    /**
     * Retrieve the block for the email based on type
     *
     * @return Price|Stock
     * @throws LocalizedException
     */
    private function getBlock(): AbstractEmail
    {
        return $this->_type === 'price'
            ? $this->_getPriceBlock()
            : $this->_getStockBlock();
    }
}
