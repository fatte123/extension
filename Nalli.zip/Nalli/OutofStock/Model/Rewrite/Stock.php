<?php

namespace Nalli\OutofStock\Model\Rewrite;

use Magento\Framework\Exception\MailException;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\Customer;
use Magento\Catalog\Model\Product;
use Nalli\OutofStock\Helper\Data;

class Stock extends \Magento\ProductAlert\Model\ResourceModel\Stock
{
    public const XML_PATH_EMAIL_TEMPLATE = 'outofstock/email/template';
    public const XML_PATH_EMAIL_IDENTITY = 'outofstock/email/identity';
    public const EMAIL_CC = 'outofstock/email/address_cc';
    /**
     * @var StateInterface
     */
    protected $inlineTranslation;
    /**
     * @var TransportBuilder
     */
    protected $transportBuilder;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var Customer
     */
    protected $customer;
    /**
     * @var Product
     */
    protected $product;
    /**
     * @var Data
     */
    protected $helper;

    /**
     * Constructor Outofstock
     *
     * @param Context $context
     * @param DateTimeFactory $dateFactory
     * @param StateInterface $inlineTranslation
     * @param TransportBuilder $transportBuilder
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param Customer $customer
     * @param Product $product
     * @param Data $helper
     * @param string|null $connectionName
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
        StateInterface $inlineTranslation,
        TransportBuilder $transportBuilder,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        Customer $customer,
        Product $product,
        Data $helper,
        $connectionName = null
    ) {
        parent::__construct($context, $dateFactory, $connectionName);

        $this->inlineTranslation = $inlineTranslation;
        $this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->customer = $customer;
        $this->product = $product;
        $this->helper = $helper;
    }

    /**
     * Send an Email after Save
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return Stock|void
     */
    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {

        $connection = $this->getConnection();

        $select = $connection->select()->from(
            'product_alert_stock',
            ['customer_id','product_id','store_id']
        )->order('alert_stock_id desc')
            ->limit(1);
        $lastDate = $connection->fetchAssoc($select);
        $result = [];
        if ($this->helper->isNotifyStockEnabled()) {
            if (!empty($lastDate)) {
                foreach ($lastDate as $record) {
                    $result['customer_id'] = $record['customer_id'];
                    $result['product_id'] = $record['product_id'];
                    $result['store_id'] = $record['store_id'];
                }
                $this->sendPreNotifyEmail($result);
            }
        }
    }

    /**
     * Process Email
     *
     * @param array $result
     * @return void
     * @throws \Zend_Log_Exception
     */
    private function sendPreNotifyEmail($result)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/alert_entry.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $customer = $this->customer->load($result['customer_id']);
        $product = $this->product->load($result['product_id']);

        $this->inlineTranslation->suspend();
        try {
            $transport = $this->transportBuilder
                ->setTemplateIdentifier($this->getTemplateIdentifier())
                ->setTemplateOptions(
                    [
                        'area' => 'frontend',
                        'store' => $this->storeManager->getStore()->getId()
                    ]
                )
                ->setTemplateVars(
                    [
                        'name' => $customer->getFirstname(),
                        'email' => $customer->getEmail(),
                        'mobile' => $customer->getMobile(),
                        'sku' => $product->getSku()
                    ]
                )
                ->setFromByScope(
                    $this->getEmailIdentity(),
                    $this->storeManager->getStore()->getId()
                );
            $ccReceiver = $this->scopeConfig->getValue(
                self::EMAIL_CC,
                ScopeInterface::SCOPE_STORE
            );
            $notifyReceier = explode(',', $ccReceiver);
            foreach ($notifyReceier as $receiver) {
                $this->transportBuilder->addTo($receiver);
            }
            $transport
                ->getTransport()
                ->sendMessage();

            $this->inlineTranslation->resume();
        } catch (MailException $exception) {
            $logger->debug("Mail Exception ". $exception->getMessage());
        }
    }

    /**
     * Get Email Identity
     *
     * @return mixed
     */
    private function getEmailIdentity()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_EMAIL_IDENTITY,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get Template Identifier
     *
     * @return mixed
     */
    private function getTemplateIdentifier()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_EMAIL_TEMPLATE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
