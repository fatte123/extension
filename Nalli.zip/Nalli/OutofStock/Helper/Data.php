<?php

namespace Nalli\OutofStock\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Registry;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    public const ENABLED = 'outofstock/general/enabled';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
        $this->scopeConfig = $context->getScopeConfig();
    }

    /**
     * Check if module is enabled or not
     *
     * @return bool
     */
    public function isNotifyStockEnabled()
    {
        $status = (bool)$this->scopeConfig->getValue(
            self::ENABLED,
            ScopeInterface::SCOPE_STORE
        );
        return $status;
    }
}
