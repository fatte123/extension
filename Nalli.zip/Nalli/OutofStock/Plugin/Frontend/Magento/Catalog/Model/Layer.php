<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\OutofStock\Plugin\Frontend\Magento\Catalog\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Nalli\OutofStock\Helper\Data;

class Layer
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param Data $helper
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Data $helper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->helper = $helper;
    }

    /**
     * Prepare product collection
     *
     * @param \Magento\Catalog\Model\Layer $subject
     * @param \Closure $proceed
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $collection
     * @return mixed
     */
    public function aroundPrepareProductCollection(
        \Magento\Catalog\Model\Layer $subject,
        \Closure $proceed,
        $collection
    ) {
        if ($this->helper->isNotifyStockEnabled()) {

            // Getting current category Id
            $categoryId = $subject->getCurrentCategory()->getId();
            // Getting specified category whom we wann show OOS products
            $allowedCategories = (string) $this->scopeConfig->getValue(
                'outofstock/selection_page/categories',
                ScopeInterface::SCOPE_STORE
            );
            $categories = explode(",", $allowedCategories);
            if (!empty($categories)) {
                if (!in_array($categoryId, $categories)) {
                    $collection->addFieldToSelect('*')
                    ->setFlag('has_stock_status_filter', true)
                    ->removeFieldFromSelect('is_in_stock')
                    ->joinField(
                        'stock_item',
                        'cataloginventory_stock_item',
                        'is_in_stock',
                        'product_id=entity_id',
                        'is_in_stock=1'
                    );
                    //Apply to the collection
                    $collection->addCategoriesFilter(['eq' => $categoryId]);

                    $result = $proceed($collection);
                    return $result;
                }
            }
        }
        return $proceed($collection);
    }
}
