<?php

namespace Nalli\OutofStock\Block\Plugin;

class ProductsList
{

    /**
     * After Collection
     *
     * @param \Magento\CatalogWidget\Block\Product\ProductsList $subject
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $collection
     */
    public function afterCreateCollection(
        \Magento\CatalogWidget\Block\Product\ProductsList $subject,
        $collection
    ) {
        $collection->getSelect()->joinLeft(
            'cataloginventory_stock_item',
            'e.entity_id = cataloginventory_stock_item.product_id',
            'cataloginventory_stock_item.is_in_stock'
        )->where('cataloginventory_stock_item.is_in_stock', ['eq' => 1]);

        return $collection;
    }
}
