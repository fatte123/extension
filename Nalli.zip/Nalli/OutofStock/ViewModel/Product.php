<?php

namespace Nalli\OutofStock\ViewModel;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\View\Element\Block\ArgumentInterface;
use Magento\Store\Model\ScopeInterface;

class Product implements ArgumentInterface
{
    /**
     * @var \Nalli\OutofStock\Helper\Data
     */
    protected $helper;
    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;
    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $product;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor
     *
     * @param \Nalli\OutofStock\Helper\Data $helper
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Catalog\Model\Product $product
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Nalli\OutofStock\Helper\Data $helper,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Model\Product $product,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->helper = $helper;
        $this->registry = $registry;
        $this->product = $product;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Product is Applicable for Notify
     *
     * @return bool
     */
    public function isApplicable()
    {
        if ($this->helper->isNotifyStockEnabled()) {
            $allowedCategories = $this->scopeConfig->getValue(
                'outofstock/selection_page/categories',
                ScopeInterface::SCOPE_STORE
            );
            $categories = explode(",", $allowedCategories);
            $currentProductId = $this->registry->registry('current_product')->getId();
            $_product = $this->product->load($currentProductId);
            $catIds = $_product->getCategoryIds();
            $result = [];
            if (!empty($categories) && !empty($catIds)) {
                $result = array_intersect($categories, $catIds);
            }
            $result = array_intersect($categories, $catIds);
            if (!empty($result)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}
