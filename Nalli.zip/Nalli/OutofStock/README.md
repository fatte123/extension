
# Module Nalli OutofStock

    ``nalli/module-outofstock``

- [Main Functionalities](#markdown-header-main-functionalities)
- [Configuration](#markdown-header-configuration)
- [Specifications](#markdown-header-specifications)
- [Attributes](#markdown-header-attributes)


## Main Functionalities
Listing Out of stock products on specific category selected from Admin Panel.

## Requirements to make this functionality works

- Enable Out of Stock products visible on front-end `Stores >> Configuration >> Catalog >> Inventory >> Display Out of Stock Products`
- Enable Product Alert feature `Stores >> Configuration >> Catalog >> Product Alerts >> Allow Alert When Product Comes Back in Stock`
- Enable the module functionality from backend `Stores >> Configuration >> Nalli >> Out of Stock >> General Configuration`
- Categories selection on which need to show outofstock products `Stores >> Configuration >> Nalli >> Out of Stock >> Categories Selection`
- Email Address Configuration to keep in CC in product alert `Stores >> Configuration >> Nalli >> Out of Stock >> Email Address Configuration`

### Zip file

- Unzip the zip file in `app/code/Nalli`
- Enable the module by running `php bin/magento module:enable Nalli_OutofStock`
- Apply database updates by running `php bin/magento setup:upgrade`
- Flush the cache by running `php bin/magento cache:flush`


## Configuration

- categories (outofstock/selection_page/categories)

- enabled (outofstock/general/enabled)

- Email CC (outofstock/email/address_cc)


## Specifications

- Plugin
    - aroundPrepareProductCollection - Magento\Catalog\Model\Layer > Nalli\OutofStock\Plugin\Frontend\Magento\Catalog\Model\Layer
    - beforeQuery - Magento\Elasticsearch7\Model\Client\Elasticsearch > Nalli\OutofStock\Model\Plugin\ElasticLayerPlugin
- Preference
    - send - Magento\ProductAlert\Model\Email > Nalli\OutofStock\Model\Email
 


