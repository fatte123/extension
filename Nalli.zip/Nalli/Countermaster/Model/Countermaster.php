<?php
/**
 * Countermaster Model
 *
 * This class acts as an interface for db operations
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Model;

class Countermaster extends \Magento\Framework\Model\AbstractModel implements
    \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'nalli_countermaster_countermaster';

    protected $_cacheTag = 'nalli_countermaster_countermaster';

    protected $_eventPrefix = 'nalli_countermaster_countermaster';

    protected function _construct()
    {
        $this->_init(\Nalli\Countermaster\Model\ResourceModel\Countermaster::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];
        return $values;
    }
}
