<?php
/**
 * Countermaster Resource Model
 *
 * This class connects db table
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Model\ResourceModel;

class Countermaster extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('countermaster', 'countermaster_id');
    }
}
