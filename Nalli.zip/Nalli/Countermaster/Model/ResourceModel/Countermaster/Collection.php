<?php
/**
 * Countermaster Collection
 *
 * This class returns table collection data
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Countermaster
 */
 
namespace Nalli\Countermaster\Model\ResourceModel\Countermaster;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'countermaster_id';
    protected $_eventPrefix = 'nalli_countermaster_countermaster_collection';
    protected $_eventObject = 'countermaster_collection';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Nalli\Countermaster\Model\Countermaster::class,
            \Nalli\Countermaster\Model\ResourceModel\Countermaster::class
        );
    }
}
