<?php
/**
 * Countermaster cron
 *
 * This class populates hourly counter
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Cron;

use Magento\Framework\Controller\ResultFactory;
use \Psr\Log\LoggerInterface;

class Test
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Nalli\Countermaster\Helper\Data
     */
    private $countermasterHelper;

    /**
     * [__construct]
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory,
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Nalli\Countermaster\Helper\Data $countermasterHelper
     */
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Nalli\Countermaster\Helper\Data $countermasterHelper
    ) {
        $this->_pageFactory = $pageFactory;
        $this->coreRegistry = $coreRegistry;
        $this->countermasterHelper = $countermasterHelper;
    }

    public function execute()
    {
        $this->countermasterHelper->populatehourlycounters();
    }
}
