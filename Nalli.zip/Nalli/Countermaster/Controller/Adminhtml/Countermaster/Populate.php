<?php
/**
 * Countermaster populate controller
 *
 * This class populates the counter
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Adminhtml\Countermaster;

use \Magento\Framework\Controller\ResultFactory;

class Populate extends \Magento\Backend\App\Action
{

    /**
     * @var \Magento\Backend\App\Action\Context
     */
    protected $context;

    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $result;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Nalli\Countermaster\Helper\Data
     */
    protected $helper;
    
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Controller\ResultFactory $result
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Nalli\Countermaster\Helper\Data $helper
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Controller\ResultFactory $result,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Nalli\Countermaster\Helper\Data $helper
    ) {
        $this->resultRedirect = $result;
        $this->_messageManager = $messageManager;
        $this->helper = $helper;
        parent::__construct($context);
    }

    /**
     * Return Populate Counters Hourly
     * @return bool|ResponseInterface|Forward|ResultInterface|ResultPage
     */
    public function execute()
    {
        //populate counters hourly
        $this->helper->populatehourlycounters();
        $this->_messageManager->addSuccess(__('Success'));
        $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setPath('*/*/');
        return $resultRedirect;
    }
    
    /**
     * Check permission for corresponding action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Countermaster::save');
    }
}
