<?php
/**
 * Countermaster add controller
 *
 * This class contains logic to add countermaster item
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Adminhtml\Countermaster;

use Magento\Framework\Controller\ResultFactory;

class Add extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_countermasterFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Nalli\Countermaster\Model\CountermasterFactory $countermasterFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Nalli\Countermaster\Model\CountermasterFactory $countermasterFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->_countermasterFactory = $countermasterFactory;
    }

    /**
     * Mapped Grid List page.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $rowId = (int) $this->getRequest()->getParam('id');
        $rowData = $this->_countermasterFactory->create();
        if ($rowId) {
            $rowData = $this->_countermasterFactory->create()->load($rowId);
            if (!$rowData->getId()) {
                $this->messageManager->addError(__('Item no longer exist.'));
                $this->_redirect('countermaster/countermaster');
                return;
            }
        }
        $this->coreRegistry->register('row_data', $rowData);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = $rowId ? __('Edit Item ') : __('Add Item');
        $resultPage->getConfig()->getTitle()->prepend($title);
        return $resultPage;
    }

    /**
     * Check permission for corresponding action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Countermaster::add');
    }
}
