<?php
/**
 * Countermaster save controller
 *
 * This class save the counter
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Adminhtml\Countermaster;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Nalli\Countermaster\Model\CountermasterFactory
     */
    protected $_countermasterFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Nalli\Countermaster\Model\CountermasterFactory $countermasterFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Countermaster\Model\CountermasterFactory $countermasterFactory
    ) {
        $this->request = $request;
        $this->_countermasterFactory = $countermasterFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('countermaster/countermaster/add/');
            return;
        }
        try {
            if (array_key_exists('countermaster_id', $data)) {
                $rowData =  $this->_countermasterFactory->create()->load($data['countermaster_id']);
                date_default_timezone_set("Asia/Calcutta");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData->setData($data);
                $rowData->save();
            } else {
                date_default_timezone_set("Asia/Calcutta");
                $data['created_time'] = date("Y-m-d h:i:sa");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData1 =  $this->_countermasterFactory->create();
                $rowData1->setData($data);
                $rowData1->save();
            }
            $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('countermaster/countermaster/index/');
    }

    /**
     * Check permission for corresponding action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Countermaster::save');
    }
}
