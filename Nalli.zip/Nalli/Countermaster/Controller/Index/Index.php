<?php
/**
 * Countermaster Index controller
 *
 * This class renders Counter master items
 * /
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{

    protected $_pageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory
    ) {
        $this->_pageFactory = $pageFactory;
        return parent::__construct($context);
    }

     /**
      * Counter master items
      * @return bool|ResponseInterface|Forward|ResultInterface|ResultPage
      */
    public function execute()
    {
        $resultPage = $this->_pageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__(' heading '));

        $block = $resultPage->getLayout()
                ->createBlock(\Nalli\Countermaster\Block\Countermaster::class)
                ->setTemplate('Nalli_Countermaster::countermaster-items.phtml')
                ->toHtml();
        return $this->getResponse()->setBody($block);
    }
}
