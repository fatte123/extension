<?php
/**
 * Countermaster controller
 *
 * This class returns price counter data
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */
 
namespace Nalli\Countermaster\Controller\Countermaster;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\Json\Helper\Data as jsonHelper;
use Nalli\Countermaster\Helper\Data as counterHelper;
use Nalli\Weeklyreport\Helper\Data as reportHelper;
 
class Pricebucket extends Action
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;
    
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var \Nalli\Countermaster\Helper\Data
     */
    protected $counterHelper;

    /**
     * @var \Nalli\Weeklyreport\Helper\Data
     */
    protected $reportHelper;

    /**
     * [__construct]
     * @param Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        jsonHelper $jsonHelper,
        counterHelper $counterHelper,
        reportHelper $reportHelper
    ) {
        $this->customerSession = $customerSession;
        $this->jsonHelper = $jsonHelper;
        $this->counterHelper = $counterHelper;
        $this->reportHelper = $reportHelper;
        parent::__construct(
            $context
        );
    }
 
    /**
     * Return Counter price
     * @return bool|ResponseInterface|Forward|ResultInterface|ResultPage
     */
    public function execute()
    {
        if ($this->customerSession->isLoggedIn()) {
            $customeremail = $this->customerSession->getCustomer()->getEmail();
            $allowed_user = $this->reportHelper->getConfig('weeklyreport/general/officscreen_allowed_users');
            $screenusers = array_map('trim', explode(',', $allowed_user));
            if (in_array($customeremail, $screenusers)) {
                $postParams = $this->getRequest()->getPostValue();
                $counterId = 16;
                if (isset($counterId) && !empty($counterId)) {
                    $counterProductsRes = $this->counterHelper->getCounterPriceBuckets($counterId);
                    $resp = $this->jsonHelper->jsonEncode($counterProductsRes);
                    return $this->getResponse()->setBody($resp);
                }
            } else {
                $this->_redirect('eventuser/noroute');
            }
        } else {
            $this->_redirect('customer/account/login');
        }
    }
}
