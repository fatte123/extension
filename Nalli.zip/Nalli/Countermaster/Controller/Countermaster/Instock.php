<?php
/**
 * Countermaster controller
 *
 * This class renders instockadvanced cms
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Countermaster;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Instock extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Nalli\Weeklyreport\Helper\Data
     */
    protected $weeklyreportHelper;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;
 
    /**
     * [__construct]
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Customer\Model\Session $customerSession,
        \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->weeklyreportHelper = $weeklyreportHelper;
        $this->jsonHelper = $jsonHelper;
        parent::__construct(
            $context
        );
    }
 
     /**
      * Return Instock data
      * @return bool|ResponseInterface|Forward|ResultInterface|ResultPage
      */
    public function execute()
    {
        if ($this->customerSession->isLoggedIn()) {
            $customerEmail = $this->customerSession->getCustomer()->getEmail();
            $allowedUser = $this->weeklyreportHelper->getConfig('weeklyreport/general/instock_allowed_users');
            $screenUsers = array_map('trim', explode(',', $allowedUser));
            if (in_array($customerEmail, $screenUsers)) {
                $block = $this->_resultPageFactory->create()->getLayout()
                ->createBlock(\Nalli\Countermaster\Block\Countermaster::class)
                ->setTemplate("Nalli_Countermaster::instockadvanced/instock-data.phtml")->toHtml();
                return $this->getResponse()->setBody($block);
                // return $this->jsonHelper->jsonEncode(['result' => 1,
                //     'block' => $block
                //     ], true);
            } else {
                $this->_redirect('eventuser/noroute');
            }
        } else {
            $this->_redirect('customer/account/login');
        }
    }
}
