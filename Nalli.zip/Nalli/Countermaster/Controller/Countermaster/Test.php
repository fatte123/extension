<?php
/**
 * Countermaster controller
 *
 * This class renders officescreen cms
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Countermaster;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
 
class Test extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Nalli\Weeklyreport\Helper\Data
     */
    protected $weeklyreportHelper;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;
    
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $timeZone;

    /**
     * [__construct]
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timeZone
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->weeklyreportHelper = $weeklyreportHelper;
        $this->jsonHelper = $jsonHelper;
        $this->timeZone = $timeZone;
        parent::__construct(
            $context
        );
    }
 
    /**
     * loads custom layout
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if ($this->customerSession->create()->isLoggedIn()) {
            $customerEmail = $this->customerSession->create()->getCustomer()->getEmail();
            $allowedUser = $this->weeklyreportHelper->getConfig('weeklyreport/general/officscreen_allowed_users');
            $screenUsers = array_map('trim', explode(',', $allowedUser));
            if (in_array($customerEmail, $screenUsers)) {
                $block = $this->_resultPageFactory->create()
                ->getLayout()->createBlock("Magento\Framework\View\Element\Template")
                ->setTemplate("Magento_Cms::officescreen/officescreen-items.phtml")->toHtml();
                $this->jsonHelper->jsonEncode(['result' => 1,
                    'block' => $block,
                    'time' => $this->timeZone->formatDate(date("Y-m-d H:i:s"), \IntlDateFormatter::MEDIUM, true)
                    ]);
            } else {
                $this->_redirect('eventuser/noroute');
            }
        } else {
            $this->_redirect('customer/account/login');
        }
    }
}
