<?php
/**
 * Countermaster controller
 *
 * This class renders salesdashboard cms
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Controller\Countermaster;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Nalli\Weeklyreport\Helper\Data
     */
    protected $weeklyreportHelper;
    
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * [__construct]
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Nalli\Weeklyreport\Helper\Data $weeklyreportHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->weeklyreportHelper = $weeklyreportHelper;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }
 
    /**
     * loads custom layout
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if ($this->chechLogin()) {
            $customerEmail = $this->getCustomerEmail();
            $allowedUser = $this->weeklyreportHelper->getConfig('weeklyreport/general/salesdashboard_allowed_users');
            $screenUsers = array_map('trim', explode(',', $allowedUser));
            if (in_array($customerEmail, $screenUsers)) {
                $block = $this->_resultPageFactory->create()->getLayout()
                ->createBlock(\Nalli\Countermaster\Block\Salesdashboard::class)
                ->setTemplate("Nalli_Countermaster::salesdashboard/salesdashboard-items.phtml")->toHtml();
                 $this->getResponse()->setBody($block);
                 echo json_encode(['result' => 1,  
                             'block' => $block]);
                die;
            } else {
                $this->_redirect('eventuser/noroute');
            }
        } else {
            $this->_redirect('customer/account/login');
        }
    }
	
	/*
     *return customer login or not
     */
    public function chechLogin()
    {
        return $this->customerSession->create()->isLoggedIn();
    }
	
	/*
	 *@return get login customer email 
	 */
	public function getCustomerEmail()
    {
        return $this->customerSession->create()->getCustomer()->getEmail();
    }
}
