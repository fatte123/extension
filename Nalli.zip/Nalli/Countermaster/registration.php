<?php
/**
 * Nalli
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the nalli.com license that is
 * available through the world-wide-web at this URL:
 * https://www.nalli.com/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category  Nalli
 * @package   Nalli_Countermaster
 * @copyright Copyright (c) Nalli (https://www.nalli.com/)
 * @license   https://www.nalli.com/
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Nalli_Countermaster',
    __DIR__
);
