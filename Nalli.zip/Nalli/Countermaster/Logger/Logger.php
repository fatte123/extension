<?php
namespace Nalli\Countermaster\Logger;

class Logger extends \Monolog\Logger
{
}
