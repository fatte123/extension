<?php
/**
 * Countermaster Helper
 *
 * This class contains functions to help data rendering
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /**
     * @var \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory
     */
    protected $countermasterCollectionFactory;

    /**
     * @var \Nalli\Countermaster\Model\CountermasterFactory
     */
    protected $countermaster;
    
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var \Magento\CatalogInventory\Helper\Stock
     */
    protected $stockHelper;
    
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $product;
    
    /**
     * @var \Nalli\Counteritems\Model\Counteritems
     */
    protected $counteritems;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    protected $directoryList;

    /**
     * @var \Magento\Eav\Model\Attribute
     */
    protected $eavAttribute;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;
    
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Eav\Attribute
     */
    protected $eavAttributeResource;

    /**
     * @var \Magento\Catalog\Model\Product\Attribute\Repository
     */
    protected $productAttributeRepo;

    /**
     * [__construct]
     * @param \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory $countermaster,
     * @param \Nalli\Countermaster\Model\CountermasterFactory $countermaster,
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
     * @param \Magento\CatalogInventory\Helper\Stock $stockHelper,
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
     * @param \Magento\Catalog\Model\Product $product,
     * @param \Nalli\Counteritems\Model\Counteritems $counteritems,
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection,
     * @param \Magento\Framework\Filesystem\DirectoryList $directoryList,
     * @param \Magento\Eav\Model\Attribute $eavAttribute,
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper,
     * @param \Magento\Catalog\Model\ResourceModel\Eav\Attribute $eavAttributeResource,
     * @param \Magento\Catalog\Model\Product\Attribute\Repository $productAttributeRepo
     */
     
    public function __construct(
        \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory $countermasterCollectionFactory,
        \Nalli\Countermaster\Model\CountermasterFactory $countermaster,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\CatalogInventory\Helper\Stock $stockHelper,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Catalog\Model\ProductFactory $product,
        \Nalli\Counteritems\Model\CounteritemsFactory $counteritems,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\Filesystem\DirectoryList $directoryList,
        \Magento\Eav\Model\Attribute $eavAttribute,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Catalog\Model\ResourceModel\Eav\Attribute $eavAttributeResource,
        \Magento\Catalog\Model\Product\Attribute\Repository $productAttributeRepo,
        \Nalli\Countermaster\Logger\Logger $logger
    ) {
        $this->countermasterCollectionFactory = $countermasterCollectionFactory;
        $this->countermaster = $countermaster;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->stockHelper = $stockHelper;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->product = $product;
        $this->counteritems = $counteritems;
        $this->resourceConnection = $resourceConnection;
        $this->directoryList = $directoryList;
        $this->eavAttribute = $eavAttribute;
        $this->jsonHelper = $jsonHelper;
        $this->eavAttributeResource = $eavAttributeResource;
        $this->productAttributeRepo = $productAttributeRepo;
        $this->logger = $logger;
    }

    /**
     * Get Config value
     * @return string
     */
    public function getConfig($config_path)
    {
          return $this->scopeConfig->getValue($config_path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     *
     * @return array
     */
    public function counternames()
    {
        $counternames = [];
        $counternames['KJH'] = "Kanchipuram Jacquard - Half Fine/Without Zari";
        $counternames['KBBH'] = "Kanchipuram BB - Half Fine/Without Zari";
        $counternames['KPKHH'] = "Kanchipuram PB, KK, HH - Half Fine/Without Zari";
        $counternames['KJBP'] = "Kanchipuram JBB - Pure Zari";
        $counternames['KPKHP'] = "Kanchipuram PB, KK, HH - Pure Zari";
        $counternames['KWB'] = "Kanchipuram Without Border";
        $counternames['COT'] = "Cotton";
        $counternames['BANSO'] = "Banarasi Silk cotton & others";
        $counternames['CRE'] = "Crepe";
        $counternames['CHI'] = "Chiffon";
        $counternames['GEO'] = "Georgette";
        $counternames['BAN'] = "Bangalore Silk";
        $counternames['TUS'] = "Tussar Silk";
        $counternames['SOF'] = "Soft Silk";
        $counternames['SCO'] = "Silk cotton";
        $counternames['LKO'] = "Linen";
        $counternames['RAW'] = "Raw Silk";
        $counternames['PPO'] = "Ikats";
        $counternames['BAL'] = "Balchuri";
        $counternames['JUT'] = "Jute";
        $counternames['ARTSLK'] = "Art Silk";
        $counternames['AJRK'] = "Ajrakh";
        $counternames['CHD'] = "Chanderi";
        $counternames['MHESH'] = "Maheshwari";
        $counternames['KOT'] = "Kota";
        $counternames['KOR'] = "KORA";
        $counternames['ORG'] = "Organza";
        $counternames['GDW'] = "Gadwal";
        $counternames['UPD'] = "Uppada";
        $counternames['PAT'] = "Paithani";
        $counternames['DHT'] = "Dhoti";
        $counternames['DMAT'] = "Dress Material";
        $counternames['KAZBR'] = "Kanchipuram Zari Border";
        $counternames['BLANK'] = "Blank (Not mapped to any Counter)";
        $this->logger->info('counternames working');
        return $counternames;
    }
    
    /**
     * @param  array $category_ids
     * @param  string $pattern
     * @param  string $material
     * @param  string $zaritype
     * @param  string $border
     * @return string
     */
    public function mapcounters($category_ids, $pattern, $material, $zaritype, $border)
    {
        $countername = '';
        $cat_kanchipuram = ['5','6','7','8','826'];
        $cat_banaras = ['9','10','11','12','13','14','15','16','17','18','801'];
        $cat_cotton = ['19','20','21','22','23','24','25','26','27','28','29','30'];
        $cat_crepe = ['52','53','54'];
        $cat_chiffon = '51';
        $cat_cmk = ['45','46','65'];
        $cat_georgette = '50';
        $cat_bangalore = ['58','59'];
        $cat_tussar = ['31','32','33','34','35','36'];
        $cat_coimbatore = '60';
        /**$cat_silkcotton = array('143','23','147','27','146','287','381','470');*/
        $cat_silkcotton = ['24','47','48','49'];
        $cat_lko = ['55','56','57'];
        $cat_raw = '62';
        $cat_ikats = ['37','38','39','40'];
        $cat_jute = '116';
        $artslk=['419'];
        $ajrk=['420'];
        $chanderi = ['45'];
        $maheshwari = ['46'];
        $kota = ['65'];
        $kor=['64'];
        $org=['63'];
        $dht=['455','456'];
        
        $baluchari = ['43'];
        $gadwal = ['44'];
        $uppada = ['41'];
        $paithani = ['42'];
        $dmat = ['2773'];
        
        $pattern_j = ["Jacquard","Jacquard With Zari Butta"];
        $pattern_bb = ["Butta", "Thread Butta", "Zari and Thread Butta", "Zari Butta", "Brocade", "Thread Brocade", "Zari Brocade","Bandhani Print","Jacquard With Zari Butta"];
        $pattern_pcsh = ["Plain Body", "Checks", "Stripes", "Half and Half", "Veldhari"];
        $pattern_jbb = ["Jacquard", "Butta", "Thread Butta", "Zari and Thread Butta", "Zari Butta", "Brocade", "Thread Brocade", "Zari Brocade", "Ikat","Bandhani Print","Jacquard With Zari Butta"];

        if (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && in_array($pattern, $pattern_j) && $material != "Cotton" && ($zaritype == "Half-Fine Zari" || $zaritype == '') && $border != "Without Border") {
            $countername = "KJH";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && in_array($pattern, $pattern_bb) && $material != "Cotton" && ($zaritype == "Half-Fine Zari" || $zaritype == '' || $zaritype =="Without Zari") && $border != "Without Border") {
            $countername = "KBBH";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && in_array($pattern, $pattern_pcsh) && $material != "Cotton" && ($zaritype == "Half-Fine Zari" || $zaritype == '' || $zaritype == "Without Zari") && $border != "Without Border") {
            $countername = "KPKHH";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && in_array($pattern, $pattern_jbb) && $material != "Cotton" && $zaritype == "Pure Zari" && $border != "Without Border") {
            $countername = "KJBP";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && in_array($pattern, $pattern_pcsh) && $material != "Cotton" && $zaritype == "Pure Zari" && $border != "Without Border") {
            $countername = "KPKHP";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && $material != "Cotton" && $border == "Without Border") {
            $countername = "KWB";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && ($material == "Silk") && ($zaritype == "Half-Fine Zari" || $zaritype == "Without Zari")) {
            $countername = "KPKHH";
        } elseif (count(array_intersect($cat_kanchipuram, $category_ids)) > 0 && ($border == "Zari Border") && ($zaritype == "Pure Zari")) {
            $countername = "KAZBR";
        } elseif (count(array_intersect($cat_cotton, $category_ids)) > 0 || $material == "Cotton Silk") {
            $countername = "COT";
        } elseif (count(array_intersect($cat_banaras, $category_ids)) > 0 && ($material != "Linen" || $material != "Silk Cotton")) {
            $countername = "BANSO";
        } elseif (count(array_intersect($cat_crepe, $category_ids)) > 0) {
            $countername = "CRE";
        } elseif (in_array($cat_chiffon, $category_ids) && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "CHI";
        } elseif (in_array($cat_georgette, $category_ids) && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "GEO";
        } elseif (count(array_intersect($cat_bangalore, $category_ids)) > 0 && ($material == "Blended Silk" || $material == "Silk")) {
            $countername = "BAN";
        } elseif (count(array_intersect($cat_tussar, $category_ids)) > 0 && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "TUS";
        } elseif (in_array($cat_coimbatore, $category_ids) && ($material == "Silk" || $material == "Tissue Silk")) {
            $countername = "SOF";
        } elseif (count(array_intersect($cat_silkcotton, $category_ids)) > 0 && $material == "Silk Cotton") {
            $countername = "SCO";
        } elseif (count(array_intersect($cat_lko, $category_ids)) > 0 && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "LKO";
        } elseif (in_array($cat_raw, $category_ids) && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "RAW";
        } elseif (count(array_intersect($cat_ikats, $category_ids)) > 0) {
            $countername = "PPO";
        } elseif (in_array($cat_jute, $category_ids) && $material != "Cotton" && count(array_intersect($cat_banaras, $category_ids)) == 0) {
            $countername = "JUT";
        } elseif (count(array_intersect($artslk, $category_ids)) > 0) {
            $countername = "ARTSLK";
        } elseif (count(array_intersect($ajrk, $category_ids)) > 0) {
            $countername = "AJRK";
        } elseif (count(array_intersect($chanderi, $category_ids)) > 0) {
            $countername = "CHD";
        } elseif (count(array_intersect($maheshwari, $category_ids)) > 0) {
            $countername = "MHESH";
        } elseif (count(array_intersect($kota, $category_ids)) > 0) {
            $countername = "KOT";
        } elseif (count(array_intersect($kor, $category_ids)) > 0) {
            $countername = "KOR";
        } elseif (count(array_intersect($baluchari, $category_ids)) > 0) {
            $countername = "BAL";
        } elseif (count(array_intersect($gadwal, $category_ids)) > 0) {
            $countername = "GDW";
        } elseif (count(array_intersect($uppada, $category_ids)) > 0) {
            $countername = "UPD";
        } elseif (count(array_intersect($paithani, $category_ids)) > 0) {
            $countername = "PAT";
        } elseif (count(array_intersect($org, $category_ids)) > 0) {
            $countername = "ORG";
        } elseif (count(array_intersect($dht, $category_ids)) > 0) {
            $countername = "DHT";
        } elseif (count(array_intersect($dmat, $category_ids)) > 0) {
            $countername = "DMAT";
        } else {
            $countername = "BLANK";
        }

        return $countername;
    }

    /**
     * Get Product object
     * @param $id
     * @return array
     */
    public function getProduct($id)
    {
        $product=null;
        try {
            $product = $this->product->create()->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($e->getMessage().'id not exits'. $id);
        }
        return $product;
    }
    
    /**
     * Hourly counter
     * @return void
     */
    public function populatehourlycounters()
    {
        $this->logger->info('----process started-- Function populatehourlycounters');
        $allcounters = ['KJH', 'KBBH', 'KPKHH', 'KJBP', 'KPKHP', 'KWB', 'COT', 'BNR', 'CRE', 'CHI', 'CHA', 'GEO', 'BAN', 'TUS', 'SOF', 'SCO', 'LKO', 'RAW', 'PPO', 'BGUP', 'JUT','ARTSLK', 'BAL','BLANK','CHD','AJRK','MHESH','KOT','KOR','ORG','GDW','UPD','PAT','DHT','BANSO','DMAT','KAZBR'];
        $soscounters = [];
        $soldcounters = [];
        $uploadcounters =[];
        foreach ($allcounters as $allc) {
            $soscounters[$allc] = 0;
            $soldcounters[$allc] = 0;
            $uploadcounters[$allc]=0;
        }
        $start = date('Y-m-d H:i:s', (strtotime('-7 days', strtotime(date("Y-m-d H:i:s")))));
        $end = date("Y-m-d H:i:s");
        $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
        $to =   date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
        $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));

        $lwcountermaster = $this->countermasterCollectionFactory->create();
        $lwcountermaster->addFieldToFilter('status', 1);
        $lwcountermaster->addFieldToFilter('created_time', ['lt'=>$from]);
        $this->logger->info("from date".$from);
        if (count($lwcountermaster)) {
            $lwcounterid = $lwcountermaster->getLastItem()->getId();
        } else {
            $lwcounterid = 'base';
        }
        $countermaster = $this->countermaster->create();
        $countermaster->setLastweekid($lwcounterid);
        if ($lwcounterid != 'base') {
            $countermaster->setLwsos($lwcountermaster->getLastItem()->getSos());
        }
        $this->logger->info("lwcounterid : ".$lwcounterid);
        $countermaster->setCreatedTime(date("Y-m-d H:i:s"));
        $countermaster->save();

        $productCollection = $this->productCollectionFactory->create();
        $productCollection->addAttributeToSelect('*');
        $productCollection->addAttributeToFilter('status', 1);
        $productCollection->addAttributeToFilter('visibility', ['4']);
        // $this->stockHelper->addInStockFilterToCollection($productCollection);
        $sku = 'GV';
        $productCollection->addAttributeToFilter('sku', [
                    ['nlike' => '%'.$sku.'%'], //spaces on each side
        ]);
        
        // $productCollection->getSelect()->joinLeft(
        //     [ 'stocktable' => 'cataloginventory_stock_status' ],
        //     'e.entity_id = stocktable.product_id',
        //     []
        // );

        // $subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM inventory_reservation GROUP BY sku)');
        // $joinConditions = 'e.sku = reservetable.sku';
        // $productCollection->getSelect()->joinLeft(
        //     [ 'reservetable' => $subquery ],
        //     $joinConditions,
        //     []
        // )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")
        //              ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");
        $productCollection->setFlag('has_stock_status_filter', true)
        ->joinField(
            'stock_item',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            'is_in_stock=1'
        );
        $soscount = count($productCollection);
        foreach ($productCollection as $product) {
            if (!empty($product)) {
                     $soscountername = $this->mapcounters(
                         $product->getCategoryIds(),
                         $product->getAttributeText('pattern'),
                         $product->getAttributeText('material'),
                         $product->getAttributeText('zari_type'),
                         $product->getAttributeText('border')
                     );
            //$this->logger->info("soscountername".$soscountername);
                     $soscounters[$soscountername] += 1;
            }
        }
        
        $orders = $this->orderCollectionFactory->create();
        $orders->getSelect()->joinLeft('ipdetails', 'main_table.entity_id = ipdetails.order_id', ['country_id', 'state', 'country', 'city']);
        $orders->addAttributeToFilter('created_at', ['from'=>$from, 'to'=>$to_end]);
        $orders->addAttributeToFilter('status', ['processing', 'shipped', 'complete']);
        $orders->getSelect()->group('entity_id');
        $soldcount = 0;
        $this->logger->info("from".$from." to".$to_end);
        foreach ($orders as $order) {
            $items = $order->getAllVisibleItems();
            foreach ($items as $item) {
                if (!empty($item->getProductId())) {
                    $product = $this->getProduct($item->getProductId());
                    //$product = $this->product->create()->load($item->getProductId());
                    if ($product) {
                        $soldcountername = $this->mapcounters(
                            $product->getCategoryIds(),
                            $product->getAttributeText('pattern'),
                            $product->getAttributeText('material'),
                            $product->getAttributeText('zari_type'),
                            $product->getAttributeText('border')
                        );
                        $soldcounters[$soldcountername] += 1;
                        $soldcount++;
                    }
                }
            }
        }
        
        $uploadcountersnew = $this->uploadproducts($from, $to_end, $uploadcounters);
        $counternames = $this->counternames();

        foreach ($counternames as $counterkey => $countervalue) {
            $countersos = $soscounters[$counterkey] ? $soscounters[$counterkey] : 0;
            $countersold = $soldcounters[$counterkey] ? $soldcounters[$counterkey] : 0;
            $counterupload=$uploadcountersnew[$counterkey] ? $uploadcountersnew[$counterkey] : 0;
            $lwcounteritem = $this->counteritems->create()->getCollection();
            $lwcounteritem->addFieldToFilter('parent_id', $lwcounterid);
            $lwcounteritem->addFieldToFilter('counter_id', $counterkey);
            $lwcounteritemsos = $lwcounteritem->getLastItem()->getSos();
            $divid=(($countersos + $lwcounteritemsos) / 2);
            $counterstr=0;
            if ($divid!=0) {
                $counterstr = $countersold / $divid;
            }
            $counteritems = $this->counteritems->create();
            $counteritems->setParentId($countermaster->getId());
            $counteritems->setCounterId($counterkey);
            $counteritems->setCounterName($countervalue);
            $counteritems->setSos($countersos);
            $counteritems->setLwsos($lwcounteritemsos);
            $counteritems->setSold($countersold);
            $counteritems->setStr($counterstr);
            $counteritems->setLwstr($lwcounteritem->getLastItem()->getStr());
            $counteritems->setCreatedTime(date("Y-m-d H:i:s"));
            $counteritems->setUpldprd($counterupload);
            $counteritems->save();
        }
        $countermaster->setSos($soscount);
        $countermaster->setSold($soldcount);
        $countermaster->setStatus(1);
        $countermaster->setUpdateTime(date("Y-m-d H:i:s"));
        $this->logger->info("save".$soscount);
        $countermaster->save();
    }

    /**
     * Hourly counter
     * @param $duration
     * @return array
     */
    public function fetchorderby($duration)
    {
        date_default_timezone_set('Asia/Kolkata');
        switch ($duration) {
            case 'today':
                $start = date('Y-m-d', strtotime('now'));
                $end = date('Y-m-d', strtotime('now'));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'day':
                $start = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));
                $end = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(now())));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to_end = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                break;

            case 'week':
                $start = date("Y-m-d H:i:s", strtotime('Monday this week'));
                $end = date('Y-m-d', strtotime('now'));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'month':
                $start = date('Y-m-d H:i:s', strtotime(date('Y-m-01')));
                $end = date('Y-m-d', strtotime('now'));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'lastmonth':
                $lastmonth = date("m", strtotime(now())) - 1;
                $start = date('Y-m-d H:i:s', strtotime(date('Y-'.$lastmonth.'-01')));
                $end = date('Y-'.$lastmonth.'-d, H:i:s', strtotime('now'));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to_end = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                break;
                
            case 'pastmonth':
                $lastmonth = date('m', strtotime('-1 month'));
                $lastyear = date('Y', strtotime('-1 month'));
                $pastmonth = date('m', strtotime('-3 month'));
                $pastyear = date('Y', strtotime('-3 month'));
                $daysoflastmonth = cal_days_in_month(CAL_GREGORIAN, $lastmonth, $lastyear);
                $start = date($pastyear.'-'.$pastmonth.'-01 00:00:00');
                $end = date($lastyear.'-'.$lastmonth.'-'.$daysoflastmonth.' 23:59:59');

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to_end = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                break;

            default:
                $start = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));
                $end = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;
        }
        // Establish DB connection
        $resource = $this->resourceConnection;
        $connection = $resource->getConnection();

        // Order Sum and Count
        $ordersql = "SELECT sum(base_grand_total) as totalsales, COUNT(increment_id) as ordercount FROM `sales_order` WHERE `status` IN ('processing','shipped','complete') AND `created_at` BETWEEN '".$from."' AND '".$to_end ."'";
        $orderlist = $connection->fetchAll($ordersql);

        return $orderlist;
    }

    /**
     * Fetch sold products
     * @param $duration
     * @return array
     */
    public function fetchsoldproductsby($duration)
    {
        date_default_timezone_set('Asia/Kolkata');
        switch ($duration) {
            case 'today':
                $start = date('Y-m-d', strtotime('now'));
                $end = date('Y-m-d', strtotime('now'));
                
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'day':
                $start = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));
                $end = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(now())));

                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to_end = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                break;

            case 'week':
                $start = date("Y-m-d H:i:s", strtotime('Monday this week'));
                $end = date('Y-m-d', strtotime('now'));
                
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'month':
                $start = date('Y-m-d H:i:s', strtotime(date('Y-m-01')));
                $end = date('Y-m-d', strtotime('now'));
                
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            case 'pastmonth':
                $lastmonth = date('m', strtotime('-1 month'));
                $lastyear = date('Y', strtotime('-1 month'));
                $pastmonth = date('m', strtotime('-3 month'));
                $pastyear = date('Y', strtotime('-3 month'));
                $daysoflastmonth = cal_days_in_month(CAL_GREGORIAN, $lastmonth, $lastyear);
                $start = date($pastyear.'-'.$pastmonth.'-01 00:00:00');
                $end = date($lastyear.'-'.$lastmonth.'-'.$daysoflastmonth.' 23:59:59');
                
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;

            default:
                $start = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));
                $end = date('Y-m-d H:i:s', strtotime('-1 days', strtotime(date('Y-m-d'))));
                
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                break;
        }

        // Establish DB connection
        $resource = $this->resourceConnection;
        $connection = $resource->getConnection();

        // Products ES, ET, etc
        $productsql = "SELECT LEFT(sku,2) as CAT, sum(qty_ordered) as qty, sum(base_price * qty_ordered) as pricetotal FROM sales_order_item LEFT JOIN sales_order on sales_order_item.order_id = sales_order.entity_id where sales_order.status in ('processing','shipped','complete') and sales_order_item.parent_item_id is NULL AND sales_order_item.created_at BETWEEN '".$from."' AND '".$to_end ."' group by CAT";
        $productlist = $connection->fetchAll($productsql);

        $productcount = [];
        $producttotal = [];
        $productcount['custom'] = $producttotal['custom'] = $productcount['total'] = $producttotal['total'] = $productcount['ES'] = $productcount['ET'] = $productcount['GV'] = $producttotal['ES'] = $producttotal['ET'] = $producttotal['GV'] = 0;
        $productcount['dress_materials'] = $producttotal['dress_materials'] = 0;
        $noncustom = ['ES', 'ET', 'GV'];
        $dress_materials = ['SC', 'ND'];
        foreach ($productlist as $fields) {
            $cat = $fields['CAT'];
            if (in_array($cat, $noncustom)) {
                $productcount[$cat] = $fields['qty'];
                $producttotal[$cat] = $fields['pricetotal'];
            } else {
				 if (in_array($cat, $noncustom)) {
					$productcount['dress_materials'] += $fields['qty'];
					$producttotal['dress_materials'] += $fields['pricetotal'];					 
				
				}
                $productcount['custom'] += $fields['qty'];
                $producttotal['custom'] += $fields['pricetotal'];
            }
            
        }

        return $productcount;
    }

    /**
     * Money from india
     * @param $num
     * @return array
     */
    public function moneyFormatIndia($num)
    {
        $explrestunits = "" ;
        if (strlen($num)>3) {
            $lastthree = substr($num, strlen($num)-3, strlen($num));
            $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
            $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
            $expunit = str_split($restunits, 2);
            for ($i=0; $i<sizeof($expunit); $i++) {
                // creates each of the 2's group and adds a comma to the end
                if ($i==0) {
                    $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
                } else {
                    $explrestunits .= $expunit[$i].",";
                }
            }
            $thecash = $explrestunits.$lastthree;
        } else {
            $thecash = $num;
        }
        return $thecash; // writes the final format where $currency is the currency symbol.
    }

    /**
     * Stock
     * @return array
     */
    public function notuploadedstock()
    {
        require_once $this->directoryList->getPath('lib_internal').'/Google/helloanalytics.php';

        $KEY_FILE_LOCATION = $this->directoryList->getPath('lib_internal').'/Google/service-account-credentials.json';

        /*
         * We need to get a Google_Client object first to handle auth and api calls, etc.
         */
        $client = new \Google_Client();
        $client->setApplicationName('My PHP App');
        $client->setAuthConfig($KEY_FILE_LOCATION);
        $client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
        $client->setAccessType('offline');

        /*
         * The JSON auth file can be provided to the Google Client in two ways, one is as a string which is assumed to be the
         * path to the json file. This is a nice way to keep the creds out of the environment.
         *
         * The second option is as an array. For this example I'll pull the JSON from an environment variable, decode it, and
         * pass along.
         */
        $jsonAuth = getenv('JSON_AUTH');
        $client->setAuthConfig(json_decode($jsonAuth, true));

        /*
         * With the Google_Client we can get a Google_Service_Sheets service object to interact with sheets
         */
        $sheets = new \Google_Service_Sheets($client);

        /*
         * To read data from a sheet we need the spreadsheet ID and the range of data we want to retrieve.
         * Range is defined using A1 notation, see https://developers.google.com/sheets/api/guides/concepts#a1_notation
         */
        $data = '';

        // The range of A2:H will get columns A through H and all rows starting from row 2
        $spreadsheetId = '10Uivf327Fzm1vgHmjV3mRwTCxbZJTeFpYfI-KE6jSbU';

        $range = 'B7';
        $rows = $sheets->spreadsheets_values->get($spreadsheetId, $range, ['majorDimension' => 'ROWS']);

        if (isset($rows['values'])) {
            $data = $rows['values']['0']['0'];
        }
        
        return $data;
    }
    
    /**
     * Get attribute values
     * @param $attributecode
     * @return array
     */
    public function attributevalues($attributecode)
    {
        $attributeInfo = $this->eavAttribute
                                       ->getCollection()
                                       ->addFieldToFilter('attribute_code', $attributecode)
                                       ->getFirstItem();
        $attributeId = $attributeInfo->getAttributeId();
        $eavModel = $this->eavAttributeResource;
        $attribute = $eavModel->load($attributeId);
        $attributeOptions = $attribute->getSource()->getAllOptions(false);

        $atr = [];
        foreach ($attributeOptions as $option) {
            $value = $option['value'];
            $atr[$value] = $option['label'];
        }
        return $atr;
    }

    /**
     * Upload products
     * @param $from
     * @param $to_end
     * @param $uploadcounters
     * @return array
     */
    public function uploadproducts($from, $to_end, $uploadcounters)
    {
        $this->logger->info("uploadproducts ".$from." to_end".$to_end);
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addFieldToFilter(
            'sku',
            [
                ['like' => '%ES%'],
                ['like' => 'ES%'],
                ['like' => '%ES']
            ]
        );
        $collection->addAttributeToFilter('created_at', ['gteq' => $from]);
        $collection->addAttributeToFilter('created_at', ['lteq' => $to_end]);
        
        /*$resource = $this->resourceConnection;
        $connection = $resource->getConnection();
        $productsql = "SELECT `e`.* FROM `catalog_product_entity` AS `e` WHERE (`e`.`created_at` >= '".$from."' AND `e`.`created_at` <= '".$to_end."') AND (((`e`.`sku` LIKE '%ES%') OR (`e`.`sku` LIKE '%ES') OR (`e`.`sku` LIKE 'ES%')))";
        $productlist = $connection->fetchAll($productsql);*/
        $productlist = $collection;
        if (count($productlist)) {
            foreach ($productlist as $product) {
               // $product = $this->product->create()->load($item['entity_id']);
                //if ($product) {
                    $productCounter= $this->mapcounters(
                        $product->getCategoryIds(),
                        $product->getAttributeText('pattern'),
                        $product->getAttributeText('material'),
                        $product->getAttributeText('zari_type'),
                        $product->getAttributeText('border')
                    );
                    $uploadcounters[$productCounter] += 1;
                //}
            }
        }
        //$this->logger->info("uploadproducts : Function".$uploadcounters);
        return $uploadcounters;
    }

    /**
     * Function to get the counter categories list
     * @param $counter_id
     * @return array
     */
    public function getCounterCategories($counter_id)
    {
        $response = [
            'success' => true
        ];
        switch ($counter_id) {
            case 'KJH':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'KBBH':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'KPKHH':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'KJBP':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'KPKHP':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'KWB':
                $response['cat'] = ['5','6','7','8'];
                break;
            case 'COT':
                $response['cat'] = ['19','20','21','22','23','24','25','26','27','28','29','30'];
                break;
            case 'BNR':
                $response['cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'CRE':
                $response['cat'] = ['52','53','54'];
                break;
            case 'CHI':
                $response['cat'] = ['51'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'GEO':
                $response['cat'] = ['50'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'BAN':
                $response['cat'] = ['58','59'];
                break;
            case 'TUS':
                $response['cat'] = ['31','32','33','34','35','36'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'SOF':
                $response['cat'] = ['60'];
                break;
            case 'SCO':
                $response['cat'] = ['24','47','48','49'];
                break;
            case 'LKO':
                $response['cat'] = ['55','56','57'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'RAW':
                $response['cat'] = ['62'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'PPO':
                $response['cat'] = ['38','39','40'];
                break;
            case 'BAL':
                $response['cat'] = ['43'];
                break;
            case 'JUT':
                $response['cat'] = ['116'];
                $response['no_cat'] = ['9','10','11','12','13','14','15','16','17','18'];
                break;
            case 'ARTSLK':
                $response['cat'] = ['419'];
                break;
            case 'AJRK':
                $response['cat'] = ['420'];
                break;
            case 'CHD':
                $response['cat'] = ['45'];
                break;
            case 'MHESH':
                $response['cat'] = ['46'];
                break;
            case 'KOT':
                $response['cat'] = ['65'];
                break;
            case 'KOR':
                $response['cat'] = ['64'];
                break;
            case 'ORG':
                $response['cat'] = ['63'];
                break;
            case 'GDW':
                $response['cat'] = ['44'];
                break;
            case 'UPD':
                $response['cat'] = ['41'];
                break;
            case 'PAT':
                $response['cat'] = ['42'];
                break;
            case 'DHT':
                $response['cat'] = ['455','456'];
                break;
            case 'BLANK':
                $response['cat'] = ['5','6','7','8','19','20','21','22','23','24','25','26','27','28','29','30','9','10','11','12','13','14','15','16','17','18','52','53','54','51','50','58','59','31','32','33','34','35','36','60','47','48','49','55','56','57','62','38','39','40','43','116','419','420','45','46','65','64','63','44','41','42'];
                break;
            default:
                $response['success'] = false;
                $response['message'] = "Invalid Counter Id";
                break;
        }
        return $response;
    }

    /**
     * get the product attribute value based on attribute text
     * Function to get the counter categories list
     * @param $attr_code
     * @param $optionText
     * @return array
     */
    public function getOptionIdbyAttributeCodeandLabel($attr_code, $optionText)
    {
        $attributeRepository = $this->productAttributeRepo->create();
        if (is_array($optionText)) {
            $optionId = [];
            foreach ($optionText as $key => $value) {
                $attribute = $attributeRepository->get($attr_code);
                   $optionId[] = $attribute->getSource()->getOptionId($value);
            }
        } else {
            $attribute = $attributeRepository->get($attr_code);
               $optionId = $attribute->getSource()->getOptionId($optionText);
        }
           return $optionId;
    }

    /**
     * get the available price ranges
     * @return array
     */
    protected function getPriceRanges()
    {
        return $price_ranges = [
            'p1' => "0 - 2000",
            'p2' => "2000 - 4000",
            'p3' => "4000 - 6000",
            'p4' => "6000 - 8000",
            'p5' => "8000 - 10000",
            'p6' => "10000 - 12500",
            'p7' => "12500 - 15000",
            'p8' => "15000 - 20000",
            'p9' => "20000 - 30000",
            'p10' => "30000 - 50000",
            'p11' => "50000+"
        ];
    }

    /**
     * check and return matched price range
     * @param $price
     * @return string
     */
    protected function getMatchedPriceRange($price)
    {
        $price_range = '';
        if ($price >= 0 && $price <= 2000) {
            $price_range = 'p1';
        } elseif ($price > 2000 && $price <= 4000) {
            $price_range = 'p2';
        } elseif ($price > 4000 && $price <= 6000) {
            $price_range = 'p3';
        } elseif ($price > 6000 && $price <= 8000) {
            $price_range = 'p4';
        } elseif ($price > 8000 && $price <= 10000) {
            $price_range = 'p5';
        } elseif ($price > 10000 && $price <= 12500) {
            $price_range = 'p6';
        } elseif ($price > 12500 && $price <= 15000) {
            $price_range = 'p7';
        } elseif ($price > 15000 && $price <= 20000) {
            $price_range = 'p8';
        } elseif ($price > 20000 && $price <= 30000) {
            $price_range = 'p9';
        } elseif ($price > 30000 && $price <= 50000) {
            $price_range = 'p10';
        } else {
            $price_range = 'p11';
        }
        return $price_range;
    }

    /**
     * get the products price bucket for counters
     * @param $counter_id
     * @return array
     */
    public function getCounterPriceBuckets($counter_id = '')
    {
        $response = [
            'success' => true
        ];
        $result = [
            'success' => false
        ];
        if ($counter_id) {
            $cat_response = $this->getCounterCategories($counter_id);
            if ($cat_response['success'] == true) {
                $cat = $cat_response['cat'];
                $pattern_j = "Jacquard";
                $pattern_bb = ["Butta", "Thread Butta", "Zari and Thread Butta", "Zari Butta", "Brocade", "Thread Brocade", "Zari Brocade"];
                $pattern_pcsh = ["Plain Body", "Checks", "Stripes", "Half and Half", "Veldhari"];
                $pattern_jbb = ["Jacquard", "Butta", "Thread Butta", "Zari and Thread Butta", "Zari Butta", "Brocade", "Thread Brocade", "Zari Brocade", "Ikat"];

                $allcounters = $this->counternames();
                $allPriceRanges = $this->getPriceRanges();
                $countersArr = [];
                $countersArr[$counter_id] = [];
                $countersArr[$counter_id]['name'] = $allcounters[$counter_id];
                $countersArr[$counter_id]['sos'] = 0;
                $countersArr[$counter_id]['sold'] = 0;
                $countersArr[$counter_id]['upload'] = 0;
                $countersArr[$counter_id]['str'] = 0;
                foreach ($allPriceRanges as $pallk => $pallv) {
                    $countersArr[$counter_id]['pb'][$pallk]['name'] = $pallv;
                    $countersArr[$counter_id]['pb'][$pallk]['sos'] = 0;
                    $countersArr[$counter_id]['pb'][$pallk]['sold'] = 0;
                    $countersArr[$counter_id]['pb'][$pallk]['upload'] = 0;
                    $countersArr[$counter_id]['pb'][$pallk]['str'] = 0;
                }

                $start = date('Y-m-d H:i:s', (strtotime('-7 days', strtotime(date("Y-m-d H:i:s")))));
                $end = date("Y-m-d H:i:s");
                $from = date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($start))));
                $to =   date('Y-m-d H:i:s', strtotime('-30 minute', strtotime('-5 hour', strtotime($end))));
                $to_end = date('Y-m-d H:i:s', (strtotime('+1 days', strtotime($to) - 1)));
                $lwcountermaster = $this->countermasterCollectionFactory->create();
                if (count($lwcountermaster) > 0) {
                    $lwcounterid = $lwcountermaster->getLastItem()->getId();
                } else {
                    $lwcounterid = 'base';
                }
                $sku = 'GV';
                $productlist = $this->productCollectionFactory->create();
                $productlist->addAttributeToSelect('*');
                $productlist->addAttributeToFilter('sku', [
                            ['nlike' => '%'.$sku.'%'], //spaces on each side
                ]);

                $productCollection = $productCollectionFactory->create();
                $productCollection->addAttributeToSelect('*');
                $productCollection->addAttributeToFilter('status', 1);
                $productCollection->addAttributeToFilter('visibility', ['4']);
                // $this->stockHelper->create()->addInStockFilterToCollection($productCollection);
                $productCollection->addAttributeToFilter('sku', [
                            ['nlike' => '%'.$sku.'%'], //spaces on each side
                ]);
                
                // $productCollection->getSelect()->joinLeft(
                //     [ 'stocktable' => 'cataloginventory_stock_status' ],
                //     'e.entity_id = stocktable.product_id',
                //     []
                // );

                // $subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM inventory_reservation GROUP BY sku)');
                // $joinConditions = 'e.sku = reservetable.sku';
                // $productCollection->getSelect()->joinLeft(
                //     [ 'reservetable' => $subquery ],
                //     $joinConditions,
                //     []
                // )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")
                //              ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");
                $productCollection->setFlag('has_stock_status_filter', true)
                ->joinField(
                    'stock_item',
                    'cataloginventory_stock_item',
                    'is_in_stock',
                    'product_id=entity_id',
                    'is_in_stock=1'
                );
                if ($response['success'] == true) {
                    foreach ($productCollection as $key => $product) {
                        $soscountername = $this->mapcounters($product->getCategoryIds(), $product->getAttributeText('pattern'), $product->getAttributeText('material'), $product->getAttributeText('zari_type'), $product->getAttributeText('border'));
                        if ($soscountername == $counter_id) {
                            $pricename = $this->getMatchedPriceRange($product->getPrice());
                            $countersArr[$soscountername]['sos'] += 1;
                            $countersArr[$soscountername]['pb'][$pricename]['sos'] += 1;
                        }
                    }
                    $orders = $this->orderCollectionFactory->create();
                    $orders->getSelect()->joinLeft('ipdetails', 'main_table.entity_id = ipdetails.order_id', ['country_id', 'state', 'country', 'city']);
                    $orders->addAttributeToFilter('created_at', ['from'=>$from, 'to'=>$to_end]);
                    $orders->addAttributeToFilter('status', ['processing', 'shipped', 'complete']);
                    $orders->getSelect()->group('entity_id');

                    foreach ($orders as $order) {
                        $items = $order->getAllVisibleItems();
                        foreach ($items as $item) {
                            if (!empty($item->getProductId())) {
                                $product = $this->getProduct($item->getProductId());
                                //$product = $this->product->create()->load($item->getProductId());
                                if ($product) {
                                    $soldcountername = $this->mapcounters(
                                        $product->getCategoryIds(),
                                        $product->getAttributeText('pattern'),
                                        $product->getAttributeText('material'),
                                        $product->getAttributeText('zari_type'),
                                        $product->getAttributeText('border')
                                    );
                                    if ($soldcountername == $counter_id) {
                                        $pricename = $this->getMatchedPriceRange($product->getPrice());
                                        $countersArr[$soldcountername]['sold'] += 1;
                                        $countersArr[$soldcountername]['pb'][$pricename]['sold'] += 1;
                                    }
                                }
                            }
                            
                        }
                    }
                    $productlist->addAttributeToFilter('created_at', ['gteq' => $from]);
                    $productlist->addAttributeToFilter('created_at', ['lteq' => $to_end]);
                    if (count($productlist)) {
                        foreach ($productlist as $product) {
                            $productCounter= $this->mapcounters(
                                $product->getCategoryIds(),
                                $product->getAttributeText('pattern'),
                                $product->getAttributeText('material'),
                                $product->getAttributeText('zari_type'),
                                $product->getAttributeText('border')
                            );
                            if ($productCounter == $counter_id) {
                                $pricename = $this->getMatchedPriceRange($product->getPrice());
                                $countersArr[$productCounter]['upload'] += 1;
                                $countersArr[$productCounter]['pb'][$pricename]['upload'] += 1;
                            }
                        }
                    }

                       $countersos = $countersArr[$counter_id]['sos'] ? $countersArr[$counter_id]['sos'] : 0;
                       $countersold = $countersArr[$counter_id]['sold'] ? $countersArr[$counter_id]['sold'] : 0;
                       $lwcounteritem = $this->counteritems->create()->getCollection();
                       $lwcounteritem->addFieldToFilter('parent_id', $lwcounterid);
                       $lwcounteritem->addFieldToFilter('counter_id', $counter_id);
                       $lwcounteritemsos = $lwcounteritem->getLastItem()->getSos();
                       $divid = (($countersos + $lwcounteritemsos) / 2);
                       $counterstr = 0;
                    if ($divid != 0) {
                        $counterstr = round(($countersold / $divid) * 100);
                    }
                    $countersArr[$counter_id]['str'] = $counterstr;
                    foreach ($countersArr[$counter_id]['pb'] as $pbkey => $pbvalue) {
                        if ($divid != 0) {
                            $counterstr = round(($pbvalue['sold'] / $divid) * 100);
                        }
                        $countersArr[$counter_id]['pb'][$pbkey]['str'] = $counterstr;
                    }

                    $result['products'] = [];
                    if (count($countersArr) > 0) {
                        $result['products'] = $countersArr;
                    }
                    $result['success'] = true;
                }
            }
        }
        return $result;
    }
}
