<?php
/**
 * Countermaster block file
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */
namespace Nalli\Countermaster\Block;

class Salesdashboard extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Framework\View\Element\Template\Context $context
     */
    public $context;
    
    /*
     *@var \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
     */
     public $TimezoneInterface;
     
    /*
     *@var \Magento\Framework\App\ResourceConnection $ResourceConnection
     */
     public $ResourceConnection;
	 
	 /*
     *@var \Magento\Framework\Url\Helper\Data
     */
     public $urlHelper;
    
    /*
     *@param \Magento\Framework\View\Element\Template\Context $context
     *@param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
     *@param \Magento\Framework\App\ResourceConnection $ResourceConnection
	 *@param \Magento\Framework\Url\Helper\Data
	 *@param \Magento\Customer\Model\SessionFactory
	 *@param 
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface,
        \Magento\Framework\App\ResourceConnection $ResourceConnection,
		\Magento\Framework\Url\Helper\Data $urlHelper,
		\Magento\Customer\Model\SessionFactory  $Session,
		\Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper,
		\Magento\Framework\App\Response\Http $Http,
        \Magento\Framework\App\Http\Context $httpContext,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory 
		
		 
    ) {
        $this->timezoneInterface = $TimezoneInterface;
        $this->resourceConnection = $ResourceConnection;
		$this->urlHelper = $urlHelper;
		$this->Session = $Session;
		$this->WeeklyreportHelper = $WeeklyreportHelper;
		$this->httpresponse = $Http;
		$this->httpContext = $httpContext;
		$this->productCollectionFactory = $productCollectionFactory;
		
        parent::__construct($context);
    }
	
	/*
     *return customer login or not
     */
    public function chechLogin()
    {
        return $this->Session->create()->isLoggedIn();
    }
	
	/*
	 *@return get login customer email 
	 */
	public function getCustomerEmail()
    {
        return $this->Session->create()->getCustomer()->getEmail();
    }
	
	/*
	 *@return redirect url
	 */
	public function setRedirect($path)
    {
        return $this->httpresponse->setRedirect($path);
    }
	
	/*
     *return \Nalli\Weeklyreport\Helper\Data  class functions
     */
    public function getWeeklyreportHelper()
    {
        return $this->WeeklyreportHelper;
    }
	
    public function getProductCollections()
    {
        return $this->productCollectionFactory;
    }
    
    public function getTimeZone()
    {
        return $this->timezoneInterface;
    }
	
	public function getresourceConnection(){
	 return $this->resourceConnection->getConnection();
	}
}
