<?php
/**
 * Countermaster block file
 *
 * This class prepares Layout
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Countermaster
 */

namespace Nalli\Countermaster\Block;

use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\CatalogInventory\Helper\Stock;
use Magento\Customer\Model\Session;
use Magento\Directory\Model\Country;
use Magento\Eav\Model\Config;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Locale\CurrencyInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Model\ResourceModel\Order\Item\Collection;
use Magento\Store\Model\StoreManagerInterface;
use Nalli\Countermaster\Helper\Data;
use Nalli\InStockAdvance\Model\InstockAdvacneFactory;
use Nalli\InStockAdvance\Api\InstockAdvacneRepositoryInterface;
use Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne\Collection as CustomQueryTable;
use Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne\CollectionFactory as InstockFactoryCol;
use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\Collection as SoldProductCol;
use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\CollectionFactory as SoldProductColFactory;
use Magento\Catalog\Model\ProductFactory;

class Countermaster extends Template
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $_orderCollectionFactory;

    /**
     * @var \Nalli\Countermaster\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\Locale\CurrencyInterface
     */
    protected $currency;

    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $pricingHelper;

    /**
     * @var \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory
     */
    protected $CountermasterFactory;

    /**
     * @var \Nalli\Countermaster\Model\ResourceModel\Counteritems\CollectionFactory
     */
    protected $CounteritemsFactory;
    /**
     * @var InstockAdvacneFactory
     */
    protected $instockAdvacneModel;
    /**
     * @var InstockAdvacneRepositoryInterface
     */
    protected $instockAdvacneRepository;
    /**
     * @var CustomQueryTable
     */
    protected $queryColTable;
    /**
     * @var InstockFactoryCol
     */
    /**
     * @var InstockFactoryCol
     */
    /**
     * @var InstockFactoryCol
     */
    protected $instockColFactory;
    /**
     * @var SoldProductCol
     */
    protected $soldProCollection;
    /**
     * @var SoldProductColFactory
     */
    protected $soldProColFactory;
    /**
     * @var ProductFactory
     */
    protected $productModelFactory;

    /**
     * @param Context $context ,
     * @param StoreManagerInterface $storeManager ,
     * @param CollectionFactory $productCollectionFactory ,
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory ,
     * @param Data $helper ,
     * @param CurrencyInterface $currency ,
     * @param \Magento\Framework\Pricing\Helper\Data $pricingHelper ,
     * @param \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory $CountermasterFactory ,
     * @param \Nalli\Counteritems\Model\ResourceModel\Counteritems\CollectionFactory $CounteritemsFactory
     * @param TimezoneInterface $timezone
     * @param ResourceConnection $resource
     * @param Stock $stockInventory
     * @param Collection $orderItemsCollection
     * @param Config $eavConfig
     * @param Image $imageHelper
     * @param Country $country
     * @param \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper
     * @param Session $Session
     * @param Http $Http
     * @param InstockAdvacneFactory $instockAdvacneModel
     * @param InstockAdvacneRepositoryInterface $instockAdvacneRepository
     * @param CustomQueryTable $queryColTable
     * @param InstockFactoryCol $instockColFactory
     * @param SoldProductCol $soldProCollection
     * @param SoldProductColFactory $soldProColFactory
     * @param ProductFactory $productModelFactory
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Nalli\Countermaster\Helper\Data $helper,
        \Magento\Framework\Locale\CurrencyInterface $currency,
        \Magento\Framework\Pricing\Helper\Data $pricingHelper,
        \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory $CountermasterFactory,
        \Nalli\Counteritems\Model\ResourceModel\Counteritems\CollectionFactory $CounteritemsFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\CatalogInventory\Helper\Stock $stockInventory,
        \Magento\Sales\Model\ResourceModel\Order\Item\Collection $orderItemsCollection,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Directory\Model\Country $country,
        \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper,
        \Magento\Customer\Model\Session $Session,
        \Magento\Framework\App\Response\Http $Http,
        InstockAdvacneFactory $instockAdvacneModel,
        InstockAdvacneRepositoryInterface $instockAdvacneRepository,
        CustomQueryTable $queryColTable,
        InstockFactoryCol $instockColFactory,
        SoldProductCol $soldProCollection,
        SoldProductColFactory $soldProColFactory,
        ProductFactory $productModelFactory,
        array $data = []
    ) {

        $this->storeManager = $storeManager;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->helper = $helper;
        $this->currency = $currency;
        $this->pricingHelper = $pricingHelper;
        $this->CountermasterFactory = $CountermasterFactory;
        $this->counteritemsFactory = $CounteritemsFactory;
        $this->timezone = $timezone;
        $this->_resource = $resource;
        $this->stockInventory = $stockInventory;
        $this->orderItemsCollection = $orderItemsCollection;
        $this->eavConfig = $eavConfig;
        $this->imageHelper = $imageHelper;
        $this->country = $country;
        $this->WeeklyreportHelper = $WeeklyreportHelper;
        $this->Session = $Session;
        $this->httpresponse = $Http;
        parent::__construct(
            $context,
            $data
        );
        $this->instockAdvacneModel = $instockAdvacneModel;
        $this->instockAdvacneRepository = $instockAdvacneRepository;
        $this->queryColTable = $queryColTable;
        $this->instockColFactory = $instockColFactory;
        $this->soldProCollection = $soldProCollection;
        $this->soldProColFactory = $soldProColFactory;
        $this->productModelFactory = $productModelFactory;
    }

    /**
     * Function returns parent template layout
     */
    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * Function returns media url for the current store
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Function returns count of product collection based on specified parameters
     */
    public function getProductCollectionCount()
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addFieldToFilter('status', 1);
        $collection->addFieldToFilter('visibility', ['4']);
        $collection->joinField(
            'qty',
            'cataloginventory_stock_item',
            'qty',
            'product_id=entity_id',
            '{{table}}.stock_id=1',
            'left'
        );
        $sku = 'ES';
        $collection->addFieldToFilter('sku', [
            ['like' => '%'.$sku.'%'], //spaces on each side
            ['like' => '%'.$sku], //space before and ends with $needle
            ['like' => $sku.'%'] // starts with needle and space after
        ]);

        return $collection->count();
    }

    /**
     * Function returns count of order collection based on specified parameters
     */
    public function getOrderCollectionCount()
    {
        $collection = $this->_orderCollectionFactory->create()
            ->addAttributeToFilter('status', 'processing');

        return $collection->count();
    }

    /**
     * Function returns sales order for a duration
     */
    public function fetchorderby($duration)
    {
        return $this->helper->fetchorderby($duration);
    }

    /**
     * Function returns sales products for a duration
     */
    public function fetchsoldproductsby($duration)
    {
        return $this->helper->fetchsoldproductsby($duration);
    }

    /**
     * Function returns store currency symbol
     */
    public function getCurrencySymbol($code)
    {
        return $this->currency->getCurrency($code)->getSymbol();
    }

    /**
     * Function returns store currency symbol
     */
    public function formatCurrency($price)
    {
        return $this->pricingHelper->currency($price);
    }

    /**
     * Function returns store currency symbol
     */
    public function getNotuploadedstock()
    {
        return $this->helper->notuploadedstock();
    }

    /**
     * Function returns store currency symbol
     */
    public function getColorcorrectionstock()
    {
        return $this->helper->colorcorrectionstock();
    }

    /**
     * Function returns active counter items
     */
    public function getActiveCounterItems()
    {

        $counteritems = [];
        $countermaster = $this->CountermasterFactory->create()->addFieldToFilter('status', 1);
        if (count($countermaster)>0):

            $counteritems = $this->counteritemsFactory->create()
                ->addFieldToFilter('parent_id', $countermaster->getLastItem()->getId());
        endif;
        return $counteritems;
    }

    /**
     * Function returns timezone
     */
    public function getTimezoneDate()
    {
        return $this->timezone;
    }

    /**
     * Function returns Db connection
     */
    public function getDbConnection()
    {
        return $this->_resource;
    }

    /**
     * Function returns Products collections
     */
    public function getProductCollection()
    {
        $productCollection = $this->productCollectionFactory->create();
        $productCollection->addAttributeToSelect('*');
        $productCollection->addAttributeToFilter('status', 1);
        $productCollection->addAttributeToFilter('visibility', ['4']);

        // $this->getStockInventory()->addInStockFilterToCollection($productCollection);
        $sku = 'ES';
        $productCollection->addAttributeToFilter('sku', [
            ['like' => '%'.$sku.'%'], //spaces on each side
            ['like' => '%'.$sku], //space before and ends with $needle
            ['like' => $sku.'%'] // starts with needle and space after
        ]);
        // $productCollection->getSelect()->joinLeft(
        //     [ 'stocktable' => 'cataloginventory_stock_status' ],
        //     'e.entity_id = stocktable.product_id',
        //     []
        // );
        // $subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM inventory_reservation GROUP BY sku)');
        // $joinConditions = 'e.sku = reservetable.sku';
        // $productCollection->getSelect()->joinLeft(
        //     [ 'reservetable' => $subquery ],
        //     $joinConditions,
        //     []
        // )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")
        //              ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");
        $productCollection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );
        return $productCollection;
    }

    /**
     * Function returns stock inventory
     */
    public function getStockInventory()
    {
        return $this->stockInventory;
    }

    /**
     * Function returns Products collections
     */
    public function getOrderItemCollections()
    {

        $collection = $this->orderItemsCollection;
        $collection->addAttributeToSelect('sku');
        $collection->addAttributeToSelect('product_id');
        $collection->addAttributeToSelect('name');
        $collection->addAttributeToSelect('base_price');
        $collection->getSelect()->joinLeft('sales_order', 'main_table.order_id = sales_order.entity_id', ['increment_id', 'status', 'order_date' => 'created_at', 'billing_address_id', 'shipping_address_id']);

        $collection->getSelect()

            ->joinLeft('sales_order_address as billaddr', 'sales_order.billing_address_id = billaddr.entity_id', ['billing_country' => 'country_id', 'billing_city' => 'city', 'billing_region' => 'region'])

            ->joinLeft('sales_order_address as shipaddr', 'sales_order.shipping_address_id = shipaddr.entity_id', ['shipping_country' => 'country_id', 'shipping_city' => 'city', 'shipping_region' => 'region']);

        $collection->getSelect()->joinLeft('catalog_product_entity', 'main_table.product_id = catalog_product_entity.entity_id', ['product_created_at' => 'created_at', 'product_sku' => 'sku']);

        $attributes = ['atc_count', 'article_type', 'border', 'border_type', 'blouse', 'color', 'counter', 'fabric_purity', 'magentoone_upload', 'magentoone_views', 'magentoone_totalimpressions', 'magentoone_atc', 'material', 'no_of_views', 'occasion', 'ornamentation_type', 'pattern', 'price', 'small_image', 'store_code', 'style_of_work', 'supplier_code', 'technique', 'total_impressions', 'url_key','image', 'zari_type'];

        foreach ($attributes as $attribute) {
            $eav = $this->eavConfig->getAttribute('catalog_product', $attribute);
            $collection->getSelect()

                ->joinLeft(
                    [$attribute => $eav->getBackendTable()],
                    //To resolved filter error chnages made entity_id to value_id
                    "main_table.product_id = {$attribute}.row_id AND

                    {$attribute}.attribute_id = {$eav->getAttributeId()}",
                    [$attribute => 'value']
                );

        }
        $collection->getSelect()->columns("IF( IFNULL(`magentoone_upload`.`value`, 0) = 0, DATEDIFF(`sales_order`.`created_at`, `catalog_product_entity`.`created_at`), DATEDIFF(`sales_order`.`created_at`, `magentoone_upload`.`value`) ) as age");

        $collection->getSelect()->columns("(((IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0)) / (IFNULL(`total_impressions`.`value`,0) + IFNULL(`magentoone_totalimpressions`.`value`,0))) * 1000) as views_impressions");

        $collection->getSelect()->columns("(((IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) / (IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0))) * 100) as atc_views");

        $collection->getSelect()->columns("(IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) as atc");

        $sku = 'ES00';
        $collection->addFieldToFilter('main_table.sku', [
            ['like' => '%'.$sku.'%'], //spaces on each side
            ['like' => '%'.$sku], //space before and ends with $needle
            ['like' => $sku.'%'] // starts with needle and space after
        ]);
        return $collection;
    }

    /**
     * Item collections
     * @param $from
     * @param $to
     * @param $data
     * @return array
     */
    public function getOrderItemCollectionsCmsPage($from, $to, $data)
    {

        $now = date("Y-m-d h:i:s");
        $collection = $this->soldProColFactory->create();

        $soldProductDb = clone $collection;

        $addProdCol = $this->soldProCollection;

        $soldProductDb->addFieldToFilter('status', ['in' => ['pending','processing', 'shipped', 'complete']]);

        $soldProductDb->addFieldToFilter('order_date', ['from' => $from, 'to' => $to]);

        $resource = $this->_resource;

        $connection = $resource->getConnection();

        $productfiltertitles = ['counter' => 'Counter', 'article_type' => 'Category', 'border' => 'Border', 'border_type' => 'Border Type', 'zari_type' => 'Zari Type', 'blouse' => 'Blouse', 'fabric_purity' => 'Fabric Purity', 'ornamentation_type' => 'Ornamentation Type', 'occasion' => 'Occasion', 'color' => 'Color', 'material' => 'Material', 'pattern' => 'Pattern', 'style_of_work' => 'Style of Work', 'technique' => 'Technique' , 'store_code' => 'Store Code'];

        $productfilterarray = [];

        foreach ($productfiltertitles as $productfilterkey => $productfiltervalue) {

            $soldProductDb->getSelect()->reset(\Magento\Framework\DB\Select::COLUMNS);

            $soldProductDb->getSelect()->columns($productfilterkey);

            $productfilterarray[$productfilterkey] = array_values(array_unique($connection->fetchCol($soldProductDb->getSelect())));

        }

        $orderfiltertitles_actual = ['shipping_country' => 'Shipping Country', 'shipping_region' => 'Shipping State', 'shipping_city' => 'Shipping City', 'billing_country' => 'Billing Country', 'billing_region' => 'Billing State', 'billing_city' => 'Billing City'];

        $orderfiltertitles = ['billing_country' => 'billing_country' , 'billing_region' => 'billing_region','billing_city' =>  'billing_city','shipping_country' =>  'shipping_country', 'shipping_region' => 'shipping_region', 'shipping_city' => 'shipping_city'];

        $orderfilterarray = [];

        foreach ($orderfiltertitles as $orderfilterkey => $orderfiltervalue) {

            $soldProductDb->getSelect()->reset(\Magento\Framework\DB\Select::COLUMNS);

            $soldProductDb->getSelect()->columns($orderfiltervalue);

            $orderfilterarray[$orderfilterkey] = array_values(
                array_unique(
                    $connection->fetchCol(
                        $soldProductDb->getSelect()
                    )
                )
            );
        }

        // Default values

        $defaultsort = 'order_date';

        $defaultdir = 'DESC';

        $pagesize = '20';

        $curpage = '1';

        $pricefrom = '';

        $priceto = '';

        $agefrom = '';

        $ageto = '';

        $atcfrom = '';

        $atcto = '';

        $views_impressionsfrom = '';

        $views_impressionsto = '';

        $atc_viewsfrom  = '';

        $atc_viewsto = '';

        $viewsfrom = '';

        $viewsto = '';

        $impressionsfrom = '';

        $impressionsto = '';

        $skufilter = '';

        $supplierfilter = '';

        $flag = 0;

        // Check for Filters
        $appliedfilters = [];

        foreach ($data as $datakey => $datavalue) {

            if ($datakey == 'sort') {

                $defaultsort = $datavalue;

            } elseif ($datakey == 'dir') {

                $defaultdir = $datavalue;

            } elseif ($datakey == 'fromdate') {
                $flag = 1;
            } elseif ($datakey == 'todate') {
                $flag = 2;
            } elseif ($datakey == 'pagesize') {

                $pagesize = $datavalue;

            } elseif ($datakey == 'curpage') {

                $curpage = $datavalue;

            } elseif ($datakey == 'pricefrom') {

                if ($datavalue != '') {

                    $collection->addFieldToFilter('main_table.price', ['gteq' => trim($datavalue)]);

                    $pricefrom = trim($datavalue);

                }

            } elseif ($datakey == 'priceto') {

                if ($datavalue != '') {

                    $collection->addFieldToFilter('main_table.price', ['lteq' => trim($datavalue)]);

                    $priceto = trim($datavalue);

                }

            } elseif ($datakey == 'agefrom') {

                if ($datavalue != '') {

                    //$collection->getSelect()->where("IF( IFNULL(`magentoone_upload`, 0) = 0, DATEDIFF('".$now."', `product_created_at`), DATEDIFF('".$now."', `magentoone_upload`) ) >= '".trim($datavalue)."'");

                    $agefrom = trim($datavalue);
                    $collection->addFieldToFilter('age', ['gteq' => $agefrom]);

                }

            } elseif ($datakey == 'ageto') {

                if ($datavalue != '') {

                   // $collection->getSelect()->where("IF( IFNULL(`magentoone_upload`, 0) = 0, DATEDIFF('".$now."', `product_created_at`), DATEDIFF('".$now."', `magentoone_upload`) ) <= '".trim($datavalue)."'");

                    $ageto = trim($datavalue);
                    $collection->addFieldToFilter('age', ['lteq' => $ageto]);

                }

            } elseif ($datakey == 'atcfrom') {

                if ($datavalue != '') {

                    // $collection->addAttributeToFilter('atc_count', array('gteq' => trim($datavalue)));

                    $collection->getSelect()->where("(IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) >= '".trim($datavalue)."'");

                    $atcfrom = trim($datavalue);

                }

            } elseif ($datakey == 'atcto') {

                if ($datavalue != '') {

                    // $collection->addAttributeToFilter('atc_count', array('lteq' => trim($datavalue)));

                    $collection->getSelect()->where("(IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) <= '".trim($datavalue)."'");

                    $atcto = trim($datavalue);

                }

            } elseif ($datakey == 'viewsfrom') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) >= '".trim($datavalue)."'");

                    $viewsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'viewsto') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) <= '".trim($datavalue)."'");

                    $viewsto = trim($datavalue);

                }

            } elseif ($datakey == 'impressionsfrom') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0)) >= '".trim($datavalue)."'");

                    $impressionsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'impressionsto') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0)) <= '".trim($datavalue)."'");

                    $impressionsto = trim($datavalue);

                }

            } elseif ($datakey == 'views_impressionsfrom') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(((IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) / (IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0))) * 1000) >= '".trim($datavalue) ."'");

                    $views_impressionsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'views_impressionsto') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(((IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) / (IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0))) * 1000) <= '".trim($datavalue) ."'");

                    $views_impressionsto = trim($datavalue);

                }

            } elseif ($datakey == 'atc_viewsfrom') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(((IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) / (IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0))) * 100) >= '".trim($datavalue) ."'");

                    $atc_viewsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'atc_viewsto') {

                if ($datavalue != '') {

                    $collection->getSelect()->where("(((IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) / (IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0))) * 100) <= '".trim($datavalue) ."'");

                    $atc_viewsto = trim($datavalue);

                }

            } elseif ($datakey == 'sku') {

                if ($datavalue != '') {

                    $skuarray = explode(',', str_replace(' ', '', $datavalue));

                    $collection->addFieldToFilter('main_table.sku', ['in' => $skuarray]);

                    $skufilter = $datavalue;

                }

            } elseif ($datakey == 'supplier_code') {

                if ($datavalue != '') {

                    $supplierarray = explode(',', str_replace(' ', '', $datavalue));

                    $collection->addFieldToFilter('supplier_code', ['in' => $supplierarray]);

                    $supplierfilter = $datavalue;

                }

            } else {

                if (array_key_exists($datakey, $orderfiltertitles)) {

                    if (in_array("blank", $datavalue)) {

                        $collection->addFieldToFilter($orderfiltertitles[$datakey], [

                            ['in' => $datavalue],

                            ['eq' => ''],

                            ['null' => true]

                        ]);

                    } else {

                        $collection->addFieldToFilter($orderfiltertitles[$datakey], ['in' => $datavalue]);

                    }

                    $appliedfilters[$datakey] = $datavalue;

                } else {

                    if (in_array("blank", $datavalue)) {

                        $collection->addFieldToFilter($datakey, [

                            ['in' => $datavalue],

                            ['eq' => ''],

                            ['null' => true]

                        ]);

                    } else {

                        $collection->addFieldToFilter($datakey, ['in' => $datavalue]);
                    }

                    $appliedfilters[$datakey] = $datavalue;

                }

            }

        }
        $filter_idsSelect = clone $collection->getSelect();

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::ORDER);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_COUNT);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_OFFSET);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::COLUMNS);

        $totalcount = $connection->fetchCol($filter_idsSelect->columns('COUNT(*)'));

        $collection->addFieldToFilter('status', ['in' => ['pending','processing', 'shipped', 'complete']]);

        $collection->addFieldToFilter('order_date', ['from' => $from, 'to' => $to]);
        $collection->addFieldToFilter('price', ['neq' => 'NULL']);
        $collection->getSelect()->order("{$defaultsort}  {$defaultdir}");

        $collection->setPageSize($pagesize);

        $collection->setCurPage($curpage);

        $sortdir = $defaultsort."|".$defaultdir;

        $datas['totalcount'] = $totalcount;
        $datas['totalcount'][0] = $collection->getSize();
        $datas['sortdir'] = $sortdir;
        $datas['pagesize'] = $pagesize;
        $datas['productfilterarray'] = $productfilterarray;
        $datas['productfiltertitles'] = $productfiltertitles;
        $datas['pricefrom'] = $pricefrom;
        $datas['priceto'] = $priceto;
        $datas['agefrom'] = $agefrom;
        $datas['ageto'] = $ageto;
        $datas['atcfrom'] = $atcfrom;
        $datas['atcto'] = $atcto;
        $datas['views_impressionsfrom'] = $views_impressionsfrom;
        $datas['views_impressionsto'] = $views_impressionsto;
        $datas['atc_viewsfrom'] = $atc_viewsfrom;
        $datas['atc_viewsto'] = $atc_viewsto;
        $datas['viewsfrom'] = $viewsfrom;
        $datas['viewsto'] = $viewsto;
        $datas['impressionsfrom'] = $impressionsfrom;
        $datas['impressionsto'] = $impressionsto;
        $datas['skufilter'] = $skufilter;
        $datas['supplierfilter'] = $supplierfilter;
        $datas['defaultsort'] = $defaultsort;
        $datas['defaultdir'] = $defaultdir;
        $datas['curpage'] = $curpage;
        $datas['appliedfilters'] = $appliedfilters;
        $datas['collection'] = $collection;
        $datas['orderfilterarray'] = $orderfilterarray;
        $datas['orderfiltertitles_actual'] = $orderfiltertitles_actual;
        $datas['orderfiltertitles'] = $orderfiltertitles;
        return $datas;
    }
    /**
     * @return string
     */
    public function getImage()
    {
        return $this->imageHelper;
    }

    /**
     * Get Product
     *
     * @param int $id
     * @return \Magento\Catalog\Model\Product
     */
    public function getProduct($id)
    {
        $productFactory = $this->productModelFactory->create();
        $product = $productFactory->load($id);
        return $product;
    }

    /**
     * Initialize Block to work with Image
     *
     * @param \Magento\Catalog\Model\Product $product
     * @param string $imageId
     * @param array $attributes
     * @return $this
     */
    public function init($product, $imageId, $attributes = [])
    {


        return $this->imageHelper->init($product, $imageId);
    }

    /**
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * @return array
     */
    public function getInstockProductCollection()
    {
        $now = date("Y-m-d h:i:s");
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('sku');
        $collection->addAttributeToSelect('name');
        $collection->addAttributeToSelect('entity_id');
        $collection->addAttributeToSelect('created_at');
        $attributes = ['atc_count', 'article_type', 'border', 'border_type', 'blouse', 'color', 'counter', 'fabric_purity', 'magentoone_upload', 'magentoone_views', 'magentoone_totalimpressions', 'magentoone_atc', 'material', 'no_of_views', 'occasion', 'ornamentation_type', 'pattern', 'price', 'small_image', 'store_code', 'style_of_work', 'supplier_code', 'technique', 'total_impressions', 'url_key','image', 'zari_type'];

        foreach ($attributes as $attribute) {
            $eav = $this->eavConfig->getAttribute('catalog_product', $attribute);

            $collection->getSelect()
                ->joinLeft(
                    [$attribute => $eav->getBackendTable()],
                    //To resolved filter error chnages made entity_id to value_id
                    "e.entity_id = {$attribute}.row_id AND
        {$attribute}.attribute_id = {$eav->getAttributeId()}",
                    [$attribute => 'value']
                );
        }

        $collection->getSelect()->columns("IF( IFNULL(`magentoone_upload`.`value`, 0) = 0, DATEDIFF('".$now."', `created_at`), DATEDIFF('".$now."', `magentoone_upload`.`value`) ) as age");

        $collection->getSelect()->columns("(((IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0)) / (IFNULL(`total_impressions`.`value`,0) + IFNULL(`magentoone_totalimpressions`.`value`,0))) * 1000) as views_impressions");

        $collection->getSelect()->columns("(((IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) / (IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0))) * 100) as atc_views");

        $collection->getSelect()->columns("(IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) as atc");
        // Remove reserved products

        // $collection->getSelect()->joinLeft(
        //     [ 'stocktable' => 'cataloginventory_stock_status' ],
        //     'e.entity_id = stocktable.product_id',
        //     []
        // );

        // $subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM inventory_reservation GROUP BY sku)');

        // $joinConditions = 'e.sku = reservetable.sku';

        // $collection->getSelect()->joinLeft(
        //     [ 'reservetable' => $subquery ],
        //     $joinConditions,
        //     []
        // )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")

        //  ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");
        $collection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );
        $collection->addAttributeToFilter('status', 1);

        $collection->addAttributeToFilter('visibility', 4);

        $collection->getSelect()->group("e.entity_id");
        // $this->stockInventory->addInStockFilterToCollection($collection);

        $sku = 'ES';
        $collection->addAttributeToFilter('sku', [
            ['like' => '%'.$sku.'%'], //spaces on each side
            ['like' => '%'.$sku], //space before and ends with $needle
            ['like' => $sku.'%'] // starts with needle and space after
        ]);

        return $collection;
    }

    public function getInstockProductCollectionCmsPage($now, $data)
    {
        $colFactory = $this->instockColFactory->create();

        $resource = $this->_resource;

        $connection = $resource->getConnection();
        $stockDB = $this->queryColTable;

        $existingData = $this->queryColTable;

        $productfiltertitles = ['counter' => 'Counter', 'article_type' => 'Category', 'border' => 'Border', 'border_type' => 'Border Type', 'zari_type' => 'Zari Type', 'blouse' => 'Blouse', 'fabric_purity' => 'Fabric Purity', 'ornamentation_type' => 'Ornamentation Type', 'occasion' => 'Occasion', 'color' => 'Color', 'material' => 'Material', 'pattern' => 'Pattern', 'style_of_work' => 'Style of Work', 'technique' => 'Technique' , 'store_code' => 'Store Code', 'supplier_code' => 'Supplier Code'];

        $productfilterarray = [];

        foreach ($productfiltertitles as $productfilterkey => $productfiltervalue) {
            $stockDB->getSelect()->reset(\Magento\Framework\DB\Select::COLUMNS);
            $stockDB->getSelect()->columns($productfilterkey);
            $productfilterarray[$productfilterkey] = array_values(array_unique($connection->fetchCol($stockDB->getSelect())));
        }
        // Default values

        $defaultsort = 'age';

        $defaultdir = 'ASC';

        $pagesize = '20';

        $curpage = '1';

        $pricefrom = '';

        $priceto = '';

        $agefrom = '';

        $ageto = '';

        $atcfrom = '';

        $atcto = '';

        $views_impressionsfrom = '';

        $views_impressionsto = '';

        $atc_viewsfrom  = '';

        $atc_viewsto = '';

        $skufilter = '';

        // Check for Filters

        // print_r($data);

        $appliedfilters = [];

        foreach ($data as $datakey => $datavalue) {

            if ($datakey == 'sort') {

                $defaultsort = $datavalue;

            } elseif ($datakey == 'dir') {

                $defaultdir = $datavalue;

            } elseif ($datakey == 'pagesize') {

                $pagesize = $datavalue;

            } elseif ($datakey == 'curpage') {

                $curpage = $datavalue;

            } elseif ($datakey == 'pricefrom') {

                if ($datavalue != '') {

                    $colFactory->addFieldToFilter('price', ['gteq' => trim($datavalue)]);

                    $pricefrom = trim($datavalue);

                }

            } elseif ($datakey == 'priceto') {

                if ($datavalue != '') {

                    $colFactory->addFieldToFilter('price', ['lteq' => trim($datavalue)]);

                    $priceto = trim($datavalue);

                }

            } elseif ($datakey == 'agefrom') {

                if ($datavalue != '') {

                    $colFactory->addFieldToFilter('age', ['gteq' => trim($datavalue)]);
                    $agefrom = trim($datavalue);

                }

            } elseif ($datakey == 'ageto') {

                if ($datavalue != '') {

                    $ageto = trim($datavalue);
                    $colFactory->addFieldToFilter('age', ['lteq' => trim($ageto)]);
                }

            } elseif ($datakey == 'atcfrom') {

                if ($datavalue != '') {

                    $atcfrom = trim($datavalue);
                    $colFactory->addFieldToFilter('atc_count', ['gteq' => $atcfrom]);

                }

            } elseif ($datakey == 'atcto') {

                if ($datavalue != '') {

                    $atcto = trim($datavalue);
                    $colFactory->addFieldToFilter('atc_count', ['lteq' => $atcto]);

                }

            } elseif ($datakey == 'views_impressionsfrom') {

                if ($datavalue != '') {

                    $colFactory->getSelect()->where("(((IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) / (IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0))) * 1000) >= '".trim($datavalue) ."'");

                    $views_impressionsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'views_impressionsto') {

                if ($datavalue != '') {

                    $colFactory->getSelect()->where("(((IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0)) / (IFNULL(`total_impressions`,0) + IFNULL(`magentoone_totalimpressions`,0))) * 1000) <= '".trim($datavalue) ."'");

                    $views_impressionsto = trim($datavalue);

                }

            } elseif ($datakey == 'atc_viewsfrom') {

                if ($datavalue != '') {

                    $colFactory->getSelect()->where("(((IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) / (IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0))) * 100) >= '".trim($datavalue) ."'");

                    $atc_viewsfrom = trim($datavalue);

                }

            } elseif ($datakey == 'atc_viewsto') {

                if ($datavalue != '') {

                    $colFactory->getSelect()->where("(((IFNULL(`atc_count`,0) + IFNULL(`magentoone_atc`,0)) / (IFNULL(`no_of_views`,0) + IFNULL(`magentoone_views`,0))) * 100) <= '".trim($datavalue) ."'");

                    $atc_viewsto = trim($datavalue);

                }

            } elseif ($datakey == 'sku') {

                if ($datavalue != '') {

                    $skuarray = explode(',', str_replace(' ', '', $datavalue));

                    $colFactory->addFieldToFilter($datakey, ['in' => $skuarray]);

                    $skufilter = $datavalue;

                }

            } else {

                if (in_array("blank", $datavalue)) {

                    $colFactory->addFieldToFilter($datakey, [

                        ['in' => $datavalue],

                        ['eq' => ''],

                        ['null' => true]

                    ]);

                } else {

                    $colFactory->addFieldToFilter($datakey, ['in' => $datavalue]);
                }

                // }

                $appliedfilters[$datakey] = $datavalue;

            }

        }
        $filter_idsSelect = $existingData->getSelect();

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::ORDER);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_COUNT);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_OFFSET);

        $filter_idsSelect->reset(\Magento\Framework\DB\Select::COLUMNS);

        $totalcount = $connection->fetchCol($filter_idsSelect->columns('COUNT(*)'));

        $colFactory->getSelect()->order("{$defaultsort}  {$defaultdir}");

        $colFactory->setPageSize($pagesize);

        $colFactory->setCurPage($curpage);

        $sortdir = $defaultsort."|".$defaultdir;

        $datas['totalcount'] = $totalcount;
        $datas['totalcount'][0] = $colFactory->getSize();
        $datas['sortdir'] = $sortdir;
        $datas['pagesize'] = $pagesize;
        $datas['productfilterarray'] = $productfilterarray;
        $datas['productfiltertitles'] = $productfiltertitles;
        $datas['pricefrom'] = $pricefrom;
        $datas['priceto'] = $priceto;
        $datas['agefrom'] = $agefrom;
        $datas['ageto'] = $ageto;
        $datas['atcfrom'] = $atcfrom;
        $datas['atcto'] = $atcto;
        $datas['views_impressionsfrom'] = $views_impressionsfrom;
        $datas['views_impressionsto'] = $views_impressionsto;
        $datas['atc_viewsfrom'] = $atc_viewsfrom;
        $datas['atc_viewsto'] = $atc_viewsto;
        $datas['skufilter'] = $skufilter;
        $datas['defaultsort'] = $defaultsort;
        $datas['defaultdir'] = $defaultdir;
        $datas['curpage'] = $curpage;
        $datas['appliedfilters'] = $appliedfilters;
        $datas['collection'] = $colFactory;
        return $datas;
    }
    /*
     *return \Nalli\Weeklyreport\Helper\Data  class functions
     */
    public function getWeeklyreportHelper()
    {
        return $this->WeeklyreportHelper;
    }

    /*
    *return customer login or not
    */
    public function getCustomerEmail()
    {
        return $this->Session->getCustomer()->getEmail();
    }

    /*
     *return customer login or not
     */
    public function chechLogin()
    {
        return $this->Session->isLoggedIn();
    }

    public function setRedirect($path)
    {
        return $this->httpresponse->setRedirect($path);
    }
}
