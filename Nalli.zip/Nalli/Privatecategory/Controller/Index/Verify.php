<?php
/**
 * Privatecategory admin controller
 *
 * This controller verifies the items
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Controller\Index;

use Magento\Framework\Controller\ResultFactory;
use \Magento\Framework\Session\SessionManagerInterface as CoreSession;

class Verify extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Nalli\Privatecategory\Model\Privatecategory
     */
    protected $_privatecategoryFactory;

    /**
     * @var \Nalli\Internationalstore\Model\Internationalstore
     */
    protected $_internationalstore;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_coreSession;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface CookieManagerInterface
     */
    private $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Nalli\Privatecategory\Model\Privatecategory $_privatecategoryFactory,
     * @param \Nalli\Internationalstore\Model\Internationalstore $_internationalstore,
     * @param \Magento\Framework\Session\SessionManagerInterface $_coreSession,
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\CatalogInventory\Helper\Stock $stockFilter,
        \Nalli\Privatecategory\Model\Privatecategory $privatecategoryFactory,
        \Nalli\Internationalstore\Model\Internationalstore $internationalstore,
        CoreSession $coreSession,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->_stockFilter = $stockFilter;
        $this->_privatecategoryFactory = $privatecategoryFactory;
        $this->_internationalstore = $internationalstore;
        $this->_coreSession = $coreSession;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->_resultJsonFactory = $resultJsonFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */

    public function execute()
    {
        $returnData = $this->_resultJsonFactory->create();
        if ($data = $this->getRequest()->getPost()) {
            $intstore = $this->_internationalstore->load($data['store_id']);
            $collection = $this->_privatecategoryFactory->getCollection();
            $collection->addFieldToFilter('store_id', $data['store_id']);
            $collection->addFieldToFilter('mobile', $data['private-mobile']);
            if ($intstore->getEmailRequired() && $data['private-email']) {
                $collection->addFieldToFilter('email', $data['private-email']);
            }
            $result = 0;
            if (count($collection) && $intstore->getId()) {
                $result = 1;

                if ($intstore->getEmailRequired() && $data['private-email']) {
                    if ($intstore->getSneakPriceverify() == 1 || $intstore->getRegPriceverify() == 1) {
                        $session_auth = $intstore->getSessionPriceauth();
                    } else {
                        $session_auth = $intstore->getSessionAuth();
                    }
                } else {
                    $session_auth = $intstore->getSessionAuth();
                }

                $this->_coreSession->setData($intstore->getSessionName(), $session_auth);
                $msg = "session set";

                $timeout = $intstore->getSessionTimeout() ? $intstore->getSessionTimeout() : '1800';
                $this->setCustomCookie($intstore->getCookieName(), "1", time() + $timeout);
                $returnData->setData(['result' => $result, "msg" => $msg]);
                return $returnData;
            }
        }
        $returnData->setData(['result' => '0']);
        return $returnData;
    }

    /**
     * Set Custom Cookie
     *
     */
    public function setCustomCookie($name, $value, $duration)
    {
        $publicCookieMetadata = $this->cookieMetadataFactory->createPublicCookieMetadata();
        $publicCookieMetadata->setDuration($duration);
        $publicCookieMetadata->setPath('/');
        $publicCookieMetadata->setHttpOnly(false);

        return $this->cookieManager->setPublicCookie(
            $name,
            $value,
            $publicCookieMetadata
        );
    }

    /**
     * Get Custom Cookie
     *
     */
    public function getCustomCookie($name)
    {
        return $this->cookieManager->getCookie(
            $name
        );
    }
}
