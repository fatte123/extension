<?php
/**
 * Privatecategory admin controller
 *
 * This controller saves the items
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Controller\Adminhtml\Privatecategory;

use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\HTTP\PhpEnvironment\Request;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @var \Nalli\Privatecategory\Model\PrivatecategoryFactory
     */
    protected $_privatecategoryFactory;
    
    /**
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $uploaderFactory;
    
    /**
     * @var \Magento\Framework\Image\AdapterFactory
     */
    protected $adapterFactory;
    
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $filesystem;

    /**
     * @var Request
     */
    protected $request;

    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $_fileSystem;
    /**
     * @param \Nalli\Privatecategory\Model\PrivatecategoryFactory $_privatecategoryFactory
     * @param \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
     * @param \Magento\Framework\Image\AdapterFactory $adapterFactory,
     * @param \Magento\Framework\Filesystem $filesystem,
     * @param Request $request,
     * @param \Magento\Framework\Filesystem\Driver\File $fileSystem
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
        \Nalli\Privatecategory\Model\PrivatecategoryFactory $privatecategoryFactory,
        Request $request,
        \Magento\Framework\Filesystem\Driver\File $fileSystem
    ) {
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->_privatecategoryFactory = $privatecategoryFactory;
        $this->request = $request;
        $this->_fileSystem = $fileSystem;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('privatecategory/privatecategory/add/');
            return;
        }
        // get files from request obj
        $files = $this->request->getFiles()->toArray();
        if (isset($files['bulk_file']['name']) && $files['bulk_file']['name'] != '') {
            $this->_bulkUpload($data['store_id']);
        } else {
            try {
                if (array_key_exists('privatecategory_id', $data)) {
                    $rowData =  $this->_privatecategoryFactory->create()->load($data['privatecategory_id']);
                    date_default_timezone_set("Asia/Calcutta");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData->setData($data);
                    $rowData->save();
                } else {
                    date_default_timezone_set("Asia/Calcutta");
                    $data['created_time'] = date("Y-m-d h:i:sa");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData1 =  $this->_privatecategoryFactory->create();
                    $rowData1->setData($data);
                    $rowData1->save();
                }
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
            }
            $this->_redirect('privatecategory/privatecategory/index/');
        }
    }

    protected function _bulkUpload($store_id)
    {
        date_default_timezone_set("Asia/Calcutta");
        try {
            $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'bulk_file']);
            $uploaderFactory->setAllowedExtensions(['CSV', 'csv']);
            $fileAdapter = $this->adapterFactory->create();
            $uploaderFactory->setAllowRenameFiles(true);
            $destinationPath = $this->filesystem
                               ->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                               ->getAbsolutePath('privatecategory');
            $result = $uploaderFactory->save($destinationPath);
            if (!$result) {
                throw new LocalizedException(
                    __('File cannot be saved to path: $1', $destinationPath)
                );
            }
            $fileHandler = $this->_fileSystem->fileOpen($destinationPath."/".$result['file'], 'r');
            $i = 0;
            if ($fileHandler) {
                $colNames = $this->_fileSystem->fileGetCsv($fileHandler);
                foreach ($colNames as &$colName) {
                    $colName = trim($colName);
                }
                $requiredColumns = ['email', 'countrycode', 'mobile'];
                $requiredColumnsPositions = [];

                foreach ($requiredColumns as $columnName) {
                    $found = array_search($columnName, $colNames);
                    if (false !== $found) {
                        $requiredColumnsPositions[] = $found;
                    } else {
                        $this->messageManager->addError('Corrupt file');
                        $this->_redirect('privatecategory/privatecategory/add/option/2/');
                        return;
                    }
                }
                while (($currentRow = $this->_fileSystem->fileGetCsv($fileHandler)) !== false) {
                    foreach ($requiredColumnsPositions as $index) {
                        if (isset($currentRow[$index])) {
                            $csvDataRow[$colNames[$index]] = trim($currentRow[$index]);
                        }
                    }
                    if (isset($csvDataRow['mobile']) && $csvDataRow['mobile'] !== '') {
                        $csvData[] = $csvDataRow;
                    }
                }
                $this->_fileSystem->fileClose($fileHandler);
                $added = 0;
                $present = 0;
                $error = "";

                foreach ($csvData as $productdata) {
                    $collection = $this->_privatecategoryFactory->create()->getCollection();
                    $collection->addFieldToFilter('mobile', trim($productdata['mobile']));
                    $collection->addFieldToFilter('store_id', trim($store_id));
                    if (count($collection) > 0) {
                        $error .= $productdata['mobile'] .", ";
                    } else {
                        $model = $this->_privatecategoryFactory->create();
                        $model->setEmail($productdata['email']);
                        $model->setCountrycode($productdata['countrycode']);
                        $model->setMobile(trim($productdata['mobile']));
                        $model->setStoreId(trim($store_id));
                        if (empty($productdata['email'])) {
                            $model->setEmailMissing(1);
                        }
                        $model->setCreatedTime(date("Y-m-d h:i:sa"));
                        $model->setUpdateTime(date("Y-m-d h:i:sa"));
                        $model->save();
                        $added++;
                    }
                }
                $succmsg = $added ." items added";
                $this->messageManager->addSuccess(__($succmsg));
                if ($error) {
                    $errmsg = "Items already present: " .$error;
                    $this->messageManager->addError(__($errmsg));
                }
                $this->_redirect('privatecategory/privatecategory/add/option/2/');
                return;
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            return;
        }
    }

    /**
     * Check permission for passed action.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Privatecategory::save');
    }
}
