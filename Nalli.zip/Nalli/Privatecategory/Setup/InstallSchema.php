<?php
/**
 * Privatecategory db installer
 *
 * This class creates tables in the database
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Setup;

use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('privatecategory');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'privatecategory_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'email',
                                Table::TYPE_TEXT,
                                255,
                                ['nullable'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'countrycode',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'mobile',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'customer_id',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'store_id',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'email_missing',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'is_confirmed',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'otp',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'welcome_otp',
                                Table::TYPE_TEXT,
                                255,
                                ['nullbale'=>false,'default'=>'']
                            )
                            ->addColumn(
                                'otp_created',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'welcome_otp_created',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'created_time',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'update_time',
                                Table::TYPE_DATETIME
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }
        $setup->endSetup();
    }
}
