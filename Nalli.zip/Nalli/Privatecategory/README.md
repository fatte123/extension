This module contain the functionality to add customer emails to display private categories.

# Nalli_Storelocator

This module contain diffrent store address with google map.

## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Storelocator
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage

goto nalli backend to check the functionality to check and add/upload custom emails and other details.
