<?php
/**
 * Privatecategory Helper
 *
 * This class returns custom data
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\Session\SessionManagerInterface as CoreSession;
use Nalli\Internationalstore\Model\InternationalstoreFactory;
use Magento\Directory\Model\CurrencyFactory;
use Magento\Framework\Registry;

class Data extends AbstractHelper
{
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_coreSession;
    
    /**
     * @var InternationalstoreFactory
     */
    protected $internationalstoreFactory;
     
    /**
     * @var CurrencyFactory
     */
    protected $currencyFactory;
    
    /**
     * @var Registry
     */
    protected $categoryRegistry;
    
    /**
     * @param \Magento\Framework\Session\SessionManagerInterface $coreSession
     */
    public function __construct(
        CoreSession $coreSession,
        InternationalstoreFactory $internationalstoreFactory,
        CurrencyFactory $currencyFactory,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        Registry $categoryRegistry
    ) {
        $this->_coreSession = $coreSession;
        $this->internationalstoreFactory = $internationalstoreFactory;
        $this->currencyFactory = $currencyFactory;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->categoryRegistry = $categoryRegistry;
    }
    
    /**
     * Get Session
     *
     * @return object
     */
    public function getcoresession()
    {
        return $this->_coreSession;
    }
    
    /**
     * Get international store
     *
     * @param int $store_code
     * @return object
     */
    public function getInternationaStoreByCode($store_code)
    {
        $intstore = $this->internationalstoreFactory->create();
        return $intstore->load($store_code, 'store_code');
    }
    
    /**
     * Get currency
     *
     * @param int $store
     * @return object
     */
    public function getCurrency($store)
    {
        return $this->currencyFactory->create()->load($store);
    }
    
    /**
     * Get international store by category
     *
     * @return object
     */
    public function getStoreByCategory()
    {
        $category = $this->getCurrentCategory();
        return $this->getInternationaStoreByCode($category->getInternationalStorecode());
    }
    
    /**
     * Get current category
     *
     * @return object
     */
    public function getCurrentCategory()
    {
        return $this->categoryRegistry->registry('current_category');
    }

    public function getCurrentProduct()
    {
        return $this->categoryRegistry->registry('current_product');
    }

    public function getCustomCookie($cookie_name)
    {
        return $this->cookieManager->getCookie($cookie_name);
    }
}
