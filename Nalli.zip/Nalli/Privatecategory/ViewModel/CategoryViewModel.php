<?php
/**
 * @copyright Copyright (c) Magebuild (https://www.magebuild.com)
 */
namespace Nalli\Privatecategory\ViewModel;

class CategoryViewModel implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    /**
     * @var helper
     */
    private $helper;

    /**
     * Constructor
     *
     * @param Data $helper
     */
    public function __construct(
        \Nalli\Privatecategory\Helper\Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * Get helper
     *
     * @return object
     */
    public function getHelper()
    {
        return $this->helper;
    }
}
