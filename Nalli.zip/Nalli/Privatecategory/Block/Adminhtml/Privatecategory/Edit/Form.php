<?php
/**
 * Privatecategory Block
 *
 * This class builds edit form
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Edit;

use Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom\Button;

/**
 * Adminhtml Add New Row Form.
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom\Button
     */
    protected $_customButton;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry           $registry
     * @param Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom\Button $_customButton
     * @param array                                 $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        Button $button,
        array $data = []
    ) {
        $this->_customButton = $button;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $option = $this->_customButton->getOption();
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );
        $form->setHtmlIdPrefix('privatecategory');
        if ($model->getPrivatecategoryId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Item'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('privatecategory_id', 'hidden', ['name' => 'privatecategory_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Item'), 'class' => 'fieldset-wide']
            );
        }
        if ($option == '2') {
            $fieldset->addField(
                'store_id',
                'text',
                [
                'name' => 'store_id',
                'label' => __('Store Id'),
                'id' => 'store_id',
                'title' => __('Store Id'),
                ]
            );
            $fieldset->addField(
                'bulk_file',
                'file',
                [
                    'name' => 'bulk_file',
                    'label' => __('File'),
                    'id' => 'bulk_file',
                    'title' => __('File'),
                ]
            );
        } elseif (($option == "") || ($option == null)) {

            $fieldset->addField(
                'email',
                'text',
                [
                'name' => 'email',
                'label' => __('Email Id'),
                'id' => 'email',
                'title' => __('Email Id'),
                'class' => 'required-entry',
                'required' => true,
                ]
            );
            $fieldset->addField(
                'countrycode',
                'text',
                [
                    'name' => 'countrycode',
                    'label' => __('Country code'),
                    'id' => 'countrycode',
                    'title' => __('Country code'),
                ]
            );
            $fieldset->addField(
                'mobile',
                'text',
                [
                    'name' => 'mobile',
                    'label' => __('Mobile No'),
                    'id' => 'mobile',
                    'title' => __('Mobile No'),
                ]
            );
            $fieldset->addField(
                'store_id',
                'text',
                [
                'name' => 'store_id',
                'label' => __('Store Id'),
                'id' => 'store_id',
                'title' => __('Store Id'),
                ]
            );
        }

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
