<?php
/**
 * Privatecategory Block
 *
 * This class builds button text & URL
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom;

use Magento\Backend\Block\Widget\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Button implements ButtonProviderInterface
{
  /**
   * @var Context
   */
   
    protected $context;
   /**
    * @param Context $context
    */
    protected $_backendUrl;
   
   /**
    * @var \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
    */
    protected $StoreManagerInterface;
   
   /*
    *@param Context $context,
    *@param \Magento\Backend\Model\UrlInterface $backendUrl,
    *@param \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
    */
    public function __construct(
        Context $context,
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
    ) {
        $this->context = $context;
        $this->_backendUrl = $backendUrl;
        $this->storeManagerInterface = $StoreManagerInterface;
    }
    /**
     * Returns button data
     *
     * @return array
     */
    public function getButtonData()
    {
        $storeManager = $this->storeManagerInterface;
        $base_url = $storeManager->getStore()->getBaseUrl();
        $storeId = $this->context->getRequest()->getParam('store_id');
        $callback_url =$this->_backendUrl->getUrl('privatecategory/privatecategory/add/store_id/'.$storeId);
        $data = [];
        if ($this->getStoreId()) {
            $data = [
                'id' => 'add',
                'name' => 'add',
                'label' => __('Add Item'),
                'class' => 'primary',
                'url' => $callback_url
            ];
        } else {
            $data = [
               'id' => 'add',
               'name' => 'add',
               'label' => __('Add Item'),
               'class' => 'primary',
               'url' => $callback_url
            ];
        }
        return $data;
    }

    /**
     * @return int
     */
    public function getStoreId()
    {
        return $this->context->getRequest()->getParam('store_id');
    }

    public function getOption()
    {
        return $this->context->getRequest()->getParam('option');
    }
}
