<?php
/**
 * Privatecategory Block
 *
 * This class builds bulk add form
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Block\Adminhtml\Privatecategory;

class Bulk extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry.
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
    
    /**
     * @var \Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom\Button $Button
     */
    protected $Button;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry           $registry
     * @param array                                 $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Nalli\Privatecategory\Block\Adminhtml\Privatecategory\Custom\Button $Button,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->button = $Button;
        parent::__construct($context, $data);
    }

    /**
     * Initialize Imagegallery Images Edit Block.
     */
    protected function _construct()
    {
        $store_id = $this->button->getStoreId();
        $this->_objectId = 'privatecategory_id';
        $this->_blockGroup = 'Nalli_Privatecategory';
        $this->_controller = 'adminhtml_privatecategory';
        parent::_construct();
        if ($this->_isAllowedAction('Nalli_Privatecategory::bulk')) {
            $this->buttonList->update('save', 'label', __('Save'));
        } else {
            $this->buttonList->remove('save');
        }
        $this->buttonList->remove('reset');
        $url = $this->getUrl('privatecategory/privatecategory/index/store_id/'.$store_id);
        $this->buttonList->update('back', 'onclick', 'setLocation(\''. $url . '\')');
    }

    /**
     * Retrieve text for header element depending on loaded image.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        return __('Bulk Upload');
    }

    /**
     * Check permission for passed action.
     *
     * @param string $resourceId
     *
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * Get form action URL.
     *
     * @return string
     */
    public function getFormActionUrl()
    {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }

        return $this->getUrl('*/*/bulksave');
    }
}
