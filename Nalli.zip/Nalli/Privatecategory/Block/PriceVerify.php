<?php

namespace Nalli\Privatecategory\Block;

use Magento\Framework\View\Element\Template\Context;
use Nalli\Privatecategory\Helper\Data;
use \Magento\Customer\Model\Session;

class PriceVerify extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Helper
     */
    protected $helper;
    
    /**
     * @var Session
     */
    protected $session;
    
    /**
     * Constructor
     * @param Context $context
     * @param Data $helper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Data $helper,
        Session $session,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper = $helper;
        $this->session = $session;
    }

    /**
     * Get store by category
     *
     * @return object
     */
    public function getStoreByCategory()
    {
        return $this->helper->getStoreByCategory();
    }
    
    /**
     * Get customer
     *
     * @return object
     */
    public function getCustomer()
    {
        return $this->session->getCustomer();
    }
    
    /**
     * Check if logged in
     *
     * @return boolean
     */
    public function isCustomerLoggedIn()
    {
        return $this->session->isLoggedIn();
    }

    public function getCurrentProduct()
    {
        return $this->helper->getCurrentProduct();
    }

    public function getHelper()
    {
        return $this->helper;
    }
}
