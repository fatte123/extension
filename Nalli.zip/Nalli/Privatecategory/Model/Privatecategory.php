<?php
/**
 * Privatecategory Model
 *
 * This class acts as an interface for db operations
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Model;

use \Magento\Framework\Model\AbstractModel;
use \Magento\Framework\DataObject\IdentityInterface;

class Privatecategory extends AbstractModel implements IdentityInterface
{
    const CACHE_TAG = 'nalli_privatecategory_privatecategory';

    protected $_cacheTag = 'nalli_privatecategory_privatecategory';

    protected $_eventPrefix = 'nalli_privatecategory_privatecategory';

    protected function _construct()
    {
        $this->_init(\Nalli\Privatecategory\Model\ResourceModel\Privatecategory::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
