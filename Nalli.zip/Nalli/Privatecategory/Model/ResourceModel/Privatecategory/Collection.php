<?php
/**
 * Privatecategory Collection
 *
 * This class returns table collection data
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Model\ResourceModel\Privatecategory;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Nalli\Privatecategory\Model\Privatecategory::class,
            \Nalli\Privatecategory\Model\ResourceModel\Privatecategory::class
        );
    }
}
