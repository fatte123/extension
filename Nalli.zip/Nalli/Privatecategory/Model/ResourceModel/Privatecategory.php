<?php
/**
 * Privatecategory Resource Model
 *
 * This class connects db table
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */

namespace Nalli\Privatecategory\Model\ResourceModel;

class Privatecategory extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('privatecategory', 'privatecategory_id');
    }
}
