<?php
/**
 * module registration file
 *
 * @author  18th Digitech <mailto:info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */
 
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Nalli_Privatecategory',
    __DIR__
);
