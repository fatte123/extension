var config = {
    "map": {
        "*": {
            "priceVerify": "Nalli_Privatecategory/js/priceVerify"
        } 
    }
};