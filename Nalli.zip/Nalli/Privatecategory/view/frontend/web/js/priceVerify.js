/**
 * Price verify JS
 *
 * @author 18th Digitech <info@18thdigitech.com>
 * @package Nalli_Privatecategory
 */
 
define([
    'jquery', 'mage/url', 'mage/validation'
], function($, urlBuilder){
   "use strict";
      $.widget('mage.priceVerify', {
        options: {
            privateform:'',

        },
        
        /**
         * Creates widget
         * @private
         */
        _create: function () {
            var self = this;
            $('body').addClass('sneakpeek');

            var maxLen = 15;
            var minLen = 7;

            $('#privateform').submit(function() {
                var url = urlBuilder.build('privatecategory/index/verify');   
                    $.ajax({
                        type:"POST",
                      url: url,
                      data: $("#privateform").serialize(),
                      dataType: "JSON",
                      beforeSend:function()
                      {
                          $('.private-auth').show();
                          $('.private-fail').hide();
                          $('.private-success').hide();
                      },
                      success: function(response) {
                        $('.private-auth').hide();
                        if(response.result == '1' || response.result == '2') {
                            $('.private-success').show();
                            window.location.reload();
                        } else {
                            $('.private-fail').show();
                        }
                    }
                });


                    $.ajax({
                        type:"POST",
                      url: url,
                      data: $("#privateform").serialize(),
                      dataType: "JSON",
                      beforeSend:function()
                      {
                          $('.int-auth').show();
                          $('.int-fail').hide();
                          $('.int-success').hide();
                      },
                      success: function(response) {
                        $('.private-auth').hide();
                        if(response.result == '1') {
                            $('.int-success').show();
                            window.location.reload();
                        } else {
                            $('.int-fail').show();
                        }
                    }
                });
            })

            $('#private-mobile').keypress(function(event){
                var Length = $("#private-mobile").val().length;

                if(event.which == 13 && Length >= minLen) {
                    $('#privateform').submit();
                }

                if(Length == 0 && event.which == 48) { 
                    return false;
                }
                if (event.which != 8 && event.which != 0 && (event.which < 48 || event.which > 57)) {
                 return false;
             }

             if(Length >= maxLen){
                if (event.which != 8 && event.which != 0) {
                    return false;
                }
            }
        });

            $('#privateform').on('focus', 'input[type=number]', function (e) {
                $(this).on('wheel.disableScroll', function (e) {
                    e.preventDefault()
                });
            });
            $('#privateform').on('blur', 'input[type=number]', function (e) {
                $(this).off('wheel.disableScroll');
            });


            $('.international-pricereq').on('click', function() {
                $('.internationalprice-sneakform').css('display','');
            });

            $('.international-form-hide').on('click', function() {
                $('.internationalprice-sneakform').css('display','none');
            });

            var i = 0;
            setInterval(function() {
                i = ++i % 4;
                $(".private-auth").html("Verifying"+Array(i+1).join("."));
            }, 500);
        },
        
        /**
         * Initialize configuration.
         * @private
         */
        _initializeWidget: function () {
            var options = this.options;
        },
    });
    return $.mage.priceVerify;
});