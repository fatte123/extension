## Nalli_Erpsync
-------------
This module is used to get order data by order increment id


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_CustomorderApi
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x 
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
CustomorderApi module is used to get order data in form of api by order increment id


## Copyright
---------
Copyright (c) 2021. 18th DigiTech Team. All rights reserved.