<?php
/**
 * CustomorderApi
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_CustomorderApi
 */

namespace Nalli\CustomorderApi\Model\Api;

use Exception;
use Magento\Framework\App\Helper\AbstractHelper;

class Custom extends AbstractHelper
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var RegionFactory
     */
    protected $regionFactory;

    /**
     * @var OrderInterfaceFactory
     */
    protected $orderFactory;

    /**
     * @var ProductFactory
     */
    protected $productFactory;

    /**
     * @var TransactionSearchResultInterfaceFactory
     */
    protected $transactions;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /*
     *@param \Magento\Sales\Api\Data\OrderInterfaceFactory $orderFactory
     *@param \Magento\Catalog\Model\ProductFactory $productFactory,
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Directory\Model\RegionFactory $regionFactory,
        \Magento\Sales\Api\Data\OrderInterfaceFactory $orderFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory $transactions,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->logger = $logger;
        $this->regionFactory = $regionFactory;
        $this->orderFactory = $orderFactory;
        $this->productFactory = $productFactory;
        $this->productRepository = $productRepository;
        $this->transactions = $transactions;
        $this->resourceConnection = $resourceConnection;
        $this->jsonHelper = $jsonHelper;
    }

    /**
     * Get Order data by Order Increment Id
     *
     * @param $incrementId
     * @return \Magento\Sales\Api\Data\OrderInterface[]|null
     */
     
    public function getOrder($incrementId)
    {
        $order = $this->getorderdata($incrementId);
        $orderid = $order->getId();
        if ($orderid) {
           
            $this->logger->info('Order increment Id is '.$incrementId);
            $shipping_address = $order->getShippingAddress()->getData();
            $regionId = $order->getShippingAddress()->getData('region_id');
            $billing_address = $order->getBillingAddress()->getData();
        
            $region = $this->regionFactory->create()->load($regionId);
            $regioncode = $region->getCode();
        
            $eshopitems=[];
			$fall_pico_charges =0;
			$totalQty = 0;
            foreach ($order->getAllVisibleItems() as $item) {

                $product = $this->getproductdata($item->getSku());
                if ($product) {
					$categoryName = strtolower($product->getCategoryName());
					$isQtyDecimal = $product->getExtensionAttributes()->getStockItem()->getIsQtyDecimal();
					$matType = '';
					$productSize = '';
					$matQty = 0;
					$perMtrCost = 0;
					$price_diff = 0;
					$productprice = 0.0000;
					$qty = number_format($item->getQtyOrdered(),1);
					$price_diff = $item->getBasePrice()-$item->getBaseOriginalPrice();
                    //$productprice = $item->getBaseOriginalPrice()-$price_diff;
                    $productprice = $item->getBaseOriginalPrice();
					$productprice = number_format( (float) $productprice, 4, '.', '');
					if(($isQtyDecimal) == 1 && ($categoryName == "fabric")) { 
						$matType = 'RM';
						$matQty = number_format($item->getQtyOrdered(),1);
						$perMtrCost= $item->getBaseOriginalPrice();
						$productprice= $item->getBaseRowTotalInclTax();
						$productprice = number_format( (float) $productprice, 4, '.', '');
						$qty = 1;
					}
                    if('configurable'==$item->getProductType()){
						$productSize = $product->getAttributeText('size');
						$matType = 'R';
					}
                   

					$fall_pico_charges = $fall_pico_charges+$price_diff;
					$options = $item->getProductOptions();
                    if (isset($options['options']) && !empty($options['options'])) {
                        foreach ($options['options'] as $option) {
                            $item_options[] = [
                            'ID'    => $option['option_id'],
                            'Value' => $option['option_value']
                            ];
                        }
                    }
                    $eshopitems[] = [
                    'ITEMCODE'      => $product->getData('be_code'),
                    'ESCODE'        => $item->getSku(),
                    'PRODUCTPRICE'  => $productprice,
                    'QTY'           => (int)$qty,
                    'PRODUCTDESC'   => $product->getData('article_type'),
                    "COLOR"         => $product->getAttributeText('color'),
                    "BRANCH_CODE"   => $product->getData('physical_store_code'),
                    "PRODUCTSIZE"   => $productSize,
                    "FALL_PICO" => $price_diff,
                    "ITM_PACKINGCOST" => "0.0000",
                    "ITM_SHIPPINGCOST" => "0.0000",
                    "MAT_TYPE"=> $matType,
					"MTR"=> $matQty,
					"PER_MTR_COST"=> $perMtrCost
                    ];
                    $totalQty = $totalQty + $qty;
                }
            }
            $order_transaction = $this->getTransactionRecord($order->getId());
            $orderpaymentid = '';
            if (isset($order_transaction['txn_id']) && $order_transaction['txn_id']!='' ) {
                $orderpaymentid = $order_transaction['txn_id'];
            }
            $paymentTranData = $order->getPayment()->getData();
            if(isset($paymentTranData['last_trans_id']) && $paymentTranData['last_trans_id']!=''){
				$orderpaymentid = $paymentTranData['last_trans_id'];
			}
			$paymentMode = $order->getPayment()->getMethodInstance()->getCode();
			if($orderpaymentid =='' && $paymentMode == 'adminrazorpay'){
				$orderComment = '';
				foreach ($order->getStatusHistoryCollection(true) as $_item){
					$orderComment = $_item->getComment();
					
				}
				$orderpaymentid = $orderComment;
			
			}			
            $eshopitems[0]["ITM_PACKINGCOST"] = $order->getData("base_fee");
            $eshopitems[0]["ITM_SHIPPINGCOST"] = $order->getData("base_shipping_incl_tax");
        
            if ($shipping_address['country_id'] == "IN") {
                if (trim(strtolower($shipping_address['region'])) == "karnataka") {
                    $ordertype = "LOCAL";
                } else {
                    $ordertype = "INTERSTATE";
                }
            } else {
                $ordertype = "EXPORT";
            }
			
			$roundOffGrandTotal = round($order->getData("base_grand_total"));
			$roundOffValue = ($roundOffGrandTotal) - ($order->getData("base_grand_total"));
			$order_currency_code = $order->getData("order_currency_code");
			if('INR'!=$order_currency_code){
				$roundOffValue = 0;
			}
            $data[] = [
            "ORDERID" => $order->getIncrementId(),
            "ORDERDATE" => $order->getData("created_at"),
            "SUBTOTAL" => $order->getData("base_subtotal")-$fall_pico_charges,
            "PACKINGCHARGES" => $order->getData("base_fee"),
            "SHIPPINGCHARDES" => $order->getData("base_shipping_incl_tax"),
            "GRANDTOTAL" => (int) $roundOffGrandTotal,
            "ROUNDOFF" => $roundOffValue,
            "TOTALQTY" => (int)$totalQty,
            "PAYMENTMODE" => $order->getPayment()->getMethodInstance()->getCode(),
            "BANKTRANID" => $orderpaymentid,
        // check this
            "ORDERTYPE" => $ordertype,
            "SHIPPINGNAME" => $shipping_address['firstname']." " .$shipping_address['lastname'],
            "SHIPPINGADD1" => $shipping_address['street'],
            "SHIPPINGADD2" => "",
            "SHIPPINGCITY" => $shipping_address['city'],
            "SHIPPINGSTATE" => $shipping_address['region'],
            "SHIPPINGPINCODE" => $shipping_address['postcode'],
            "SHIPPINGMOBILENO" => $shipping_address['telephone'],
            "SHIPPINGCOUNTRY" => $shipping_address['country_id'],
            "ORDERMAILID" => $order->getData('customer_email'),
            "BILLINGNAME" => $billing_address['firstname'].$billing_address['lastname'],
            "BILLINGADD1" => $billing_address['street'],
            "BILLINGADD2" => "",
            "BILLINGCITY" => $billing_address['city'],
            "BILLINGSTATE" => $billing_address['region'],
            "BILLINGPINCODE" => $billing_address['postcode'],
            "BILLINGMOBILENO" => $billing_address['telephone'],
            "BILLINGCOUNTRY" => $billing_address['country_id'],
            "PRODUCTDETAILS" => $eshopitems
            ];
            $row = $this->jsonHelper->jsonEncode($data);
        
            $this->logger->info('Json data is '.$row);
            return $data;
        
        } else {
            $result[]=['message' => "The Order Id that was requested doesn't exist. Verify the Order Id and try again."];
            return $result;
        }
    }
    
    public function getorderdata($orderid)
    {
        $order=null;
        try {
             $order = $this->orderFactory->create()->loadByIncrementId($orderid);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($orderid.' --order id dont exits-- ');
        }
        return $order;
    }
    
    public function getproductdata($sku)
    {
        $product=null;
        try {
            $product = $this->productRepository->get($sku);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($sku.' --product sku dont exits-- ');
        }
        return $product;
    }
    
	public function getTransactionRecord($orderId)
    {
        $tableName = $this->resourceConnection->getTableName('sales_payment_transaction');
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(
                ['c' => $tableName],
                ['order_id','txn_id']
            )->where("order_id = ?",$orderId);

        $records = $connection->fetchRow($select);
        return $records;
    }    
    
} 
