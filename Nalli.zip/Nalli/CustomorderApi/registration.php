<?php
/**
 * Module registration file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_CustomorderApi
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Nalli_CustomorderApi',
    __DIR__
);
