<?php
/**
 * Delete Controller
 *
 * This controller returns deleted item info
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Controller\Adminhtml\Locator;

use Nalli\Storelocator\Controller\Adminhtml\Locator;

/**
 * Delete Controller
 */
class Delete extends Locator
{
    /**
     * @return void
     */
    public function execute()
    {
        $locatorId = (int) $this->getRequest()->getParam('id');

        if ($locatorId) {
           /** @var $locatorModel \Nalli\Storelocator\Model\Locator */
            $locatorModel = $this->_locatorFactory->create();
            $locatorModel->load($locatorId);

           // Check this item exists or not
            if (!$locatorModel->getId()) {
                $this->messageManager->addError(__('This item no longer exists.'));
            } else {
                try {
                   // Delete item
                    $locatorModel->delete();
                    $this->messageManager->addSuccess(__('The item has been deleted.'));

                   // Redirect to grid page
                    $this->_redirect('*/*/');
                    return;
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->_redirect('*/*/edit', ['id' => $locatorModel->getId()]);
                }
            }
        }
    }
}
