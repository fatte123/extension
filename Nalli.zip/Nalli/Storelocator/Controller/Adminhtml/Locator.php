<?php
/**
 * Locator Controller
 *
 * This controller returns resultPage
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;

/**
 * Locator Controller
 */
class Locator extends Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Locator model factory
     *
     * @var \Nalli\Storelocator\Model\LocatorFactory
     */
    protected $_locatorFactory;

    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param LocatorFactory $locatorFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        \Nalli\Storelocator\Model\LocatorFactory $locatorFactory
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_locatorFactory = $locatorFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultPage = $this->_resultPageFactory->create();
        return $resultPage;
    }

    /**
     * Locator access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Storelocator::manage_locator');
    }
}
