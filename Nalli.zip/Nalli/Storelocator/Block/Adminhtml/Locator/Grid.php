<?php
/**
 * Grid Block
 *
 * This block shows Admin Grid
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Block\Adminhtml\Locator;

use Magento\Backend\Block\Widget\Grid as WidgetGrid;

/**
 * Grid block
 */
class Grid extends WidgetGrid
{
   
}
