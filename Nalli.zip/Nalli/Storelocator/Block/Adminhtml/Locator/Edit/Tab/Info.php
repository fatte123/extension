<?php
/**
 * Info Block
 *
 * This block shows Admin Grid
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Block\Adminhtml\Locator\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Cms\Model\Wysiwyg\Config;
use Nalli\Storelocator\Model\Source\Status;
use Nalli\Storelocator\Model\Source\Country;
use Nalli\Storelocator\Model\Source\City;

/**
 * Info block
 */
class Info extends Generic implements TabInterface
{
    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;

    /**
     * @var \Nalli\Storelocator\Model\Source\Status
     */
    protected $_locatorStatus;

    /**
     * @var \Nalli\Storelocator\Model\Source\Country
     */
    protected $_locatorCountry;

    /**
     * @var \Nalli\Storelocator\Model\Source\City
     */
    protected $_locatorCity;

   /**
    * @param Context $context
    * @param Registry $registry
    * @param FormFactory $formFactory
    * @param Config $wysiwygConfig
    * @param Status $locatorStatus
    * @param Status $locatorCountry
    * @param Status $locatorCity
    * @param array $data
    */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Config $wysiwygConfig,
        Status $locatorStatus,
        Country $locatorCountry,
        City $locatorCity,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_locatorStatus = $locatorStatus;
        $this->_locatorCountry = $locatorCountry;
        $this->_locatorCity    = $locatorCity;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
       /** @var $model \Nalli\Storelocator\Model\Locator */
        $model = $this->_coreRegistry->registry('storelocator_locator');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('locator_');
        $form->setFieldNameSuffix('locator');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('General')]
        );

        if ($model->getId()) {
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
        $fieldset->addField(
            'store_name',
            'text',
            [
                'name'        => 'store_name',
                'label'    => __('Store Name'),
                'required'     => true,
                'renderer' => '\Nalli\Storelocator\Block\Adminhtml\Locator\Renderer\Grid\Image'
            ]
        );
        $fieldset->addField(
            'store_address',
            'textarea',
            [
                'name'      => 'store_address',
                'label'     => __('Store Address'),
                'required'  => true,
                'style'     => 'height: 15em; width: 30em;'
            ]
        );
        $fieldset->addField(
            'city',
            'select',
            [
                'name'      => 'city',
                'label'     => __('City'),
                'options'   => $this->_locatorCity->toOptionArray()
            ]
        );
        $fieldset->addField(
            'country',
            'select',
            [
                'name'      => 'country',
                'label'     => __('Country'),
                'options'   => $this->_locatorCountry->toOptionArray()
            ]
        );
        $fieldset->addField(
            'email',
            'text',
            [
                'name'        => 'email',
                'label'    => __('Email'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'phone',
            'text',
            [
                'name'        => 'phone',
                'label'    => __('Phone'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'store_timing',
            'text',
            [
                'name'        => 'store_timing',
                'label'    => __('Store Timing'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'latitude',
            'text',
            [
                'name'        => 'latitude',
                'label'    => __('Latitude'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'longitude',
            'text',
            [
                'name'        => 'longitude',
                'label'    => __('Longitude'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'map_link',
            'text',
            [
                'name'        => 'map_link',
                'label'    => __('Map Link'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'store_image',
            'image',
            [
                'name'        => 'store_image',
                'label'    => __('Store Image'),
                'required'     => false
            ]
        );
        $fieldset->addField(
            'url',
            'text',
            [
                'name'        => 'url',
                'label'    => __('Store Collection'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'video-link',
            'text',
            [
                'name'        => 'video-link',
                'label'    => __('Video Share'),
                'required'     => false
            ]
        );
        $fieldset->addField(
            'phone_number',
            'text',
            [
                'name'        => 'phone_number',
                'label'    => __('Calling phone Number'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'sort',
            'text',
            [
                'name'        => 'sort',
                'label'    => __('Sort'),
                'required'     => true
            ]
        );
        $fieldset->addField(
            'status',
            'select',
            [
                'name'      => 'status',
                'label'     => __('Status'),
                'options'   => $this->_locatorStatus->toOptionArray()
            ]
        );

        $data = $model->getData();
        $form->setValues($data);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Locations Info');
    }
 
    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Locations Info');
    }
 
    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
}
