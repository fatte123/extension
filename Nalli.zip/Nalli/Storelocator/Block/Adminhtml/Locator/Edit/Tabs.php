<?php
/**
 * Storelocator Block
 *
 * This block shows Admin Grid
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Block\Adminhtml\Locator\Edit;

use Magento\Backend\Block\Widget\Tabs as WidgetTabs;

/**
 * Tabs block
 */
class Tabs extends WidgetTabs
{
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('locator_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Store Locator Information'));
    }

    /**
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'locator_info',
            [
                'label' => __('General'),
                'title' => __('General'),
                'content' => $this->getLayout()->createBlock(
                    \Nalli\Storelocator\Block\Adminhtml\Locator\Edit\Tab\Info::class
                )->toHtml(),
                'active' => true
            ]
        );

        return parent::_beforeToHtml();
    }
}
