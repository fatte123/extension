<?php
/**
 * Storelocator Block
 *
 * This block shows Admin Grid Label's
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */

namespace Nalli\Storelocator\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;

/**
 * Locator block
 */
class Locator extends Container
{
   /**
    * Constructor
    *
    * @return void
    */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_locator';
        $this->_blockGroup = 'Nalli_Storelocator';
        $this->_headerText = __('Manage Items');
        $this->_addButtonLabel = __('Add Items');
        parent::_construct();
    }
}
