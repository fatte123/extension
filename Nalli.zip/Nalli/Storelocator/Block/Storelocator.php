<?php
/**
 * Storelocator Block
 *
 * This block shows Store location details
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Storelocator
 */
 
namespace Nalli\Storelocator\Block;

/**
 * Storelocator block
 */
class Storelocator extends \Magento\Framework\View\Element\Template
{
    /**
     * @var $_storeManager
     */
    protected $_storeManager;

    /**
     * @var \Nalli\Storelocator\Model\Locator $Locator
     */
    protected $Locator;
     
    /**
     * @var \Nalli\Storelocator\Helper\Data $helper
     */
    protected $helper;
    
    /**
     * Storelocator constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context $context,
     * @param \Nalli\Storelocator\Model\Locator $Locator,
     * @param \Nalli\Storelocator\Helper\Data $helper
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Nalli\Storelocator\Model\Locator $Locator,
        \Nalli\Storelocator\Helper\Data $helper,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->locator = $Locator;
        $this->helper = $helper;
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }
    
    /**
     * Get current requested product
     *
     * @return \Nalli\Storelocator\Model\Locator City Collection
     */
    public function getcityCollection($city)
    {
        $storecity = $this->locator->getCollection();
        $storecity->addFieldToFilter('city', $city);
        $storecity->addFieldToFilter('status', 1);
        $storecity->setOrder('sort', 'ASC');
        return $storecity;
    }
    
    /**
     * Get current requested product
     *
     * @return \Nalli\Storelocator\Helper\Data functions
     */
    public function getHelper()
    {
        return $this->helper;
    }

     /**
      * Get media path
      *
      * @return string
      */
    public function getMediaUrl()
    {
        return $mediaDirectory = $this->_storeManager->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
        );
    }
}
