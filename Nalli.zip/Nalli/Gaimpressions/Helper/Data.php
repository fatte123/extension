<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */
 
namespace Nalli\Gaimpressions\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /*
     *@var \Magento\Framework\Filesystem\Driver\File $fileDriver
     */
    protected $fileDriver;
     
    /*
     *@var \Magento\Framework\Filesystem\DirectoryList $DirectoryList
     */
    protected $DirectoryList;
    
    /*
     *@param \Magento\Framework\Filesystem\Driver\File $fileDriver
     *@param \Magento\Framework\Filesystem\DirectoryList $DirectoryList
     */
    public function __construct(
        \Magento\Framework\Filesystem\Driver\File $fileDriver,
        \Magento\Framework\Filesystem\DirectoryList $DirectoryList
    ) {
        $this->fileDriver = $fileDriver;
        $this->directoryList = $DirectoryList;
    }

    /**
     * Print results
     * @param $reports
     * @return array
     */
    public function printResults($reports)
    {
        $prodviews = [];
        $count = count($reports);
        for ($reportIndex = 0; $reportIndex < $count; $reportIndex++) {
            $report = $reports[ $reportIndex ];
            $header = $report->getColumnHeader();
            $dimensionHeaders = $header->getDimensions();
            $metricHeaders = $header->getMetricHeader()->getMetricHeaderEntries();
            $rows = $report->getData()->getRows();
            $rowcount = count($rows);
            for ($rowIndex = 0; $rowIndex < $rowcount; $rowIndex++) {
                $indview = [];
                $row = $rows[ $rowIndex ];
                $dimensions = $row->getDimensions();
                $metrics = $row->getMetrics();
                $countdimensionHeaders = count($dimensionHeaders);
                $countdimensions = count($dimensions);
                for ($i = 0; $i < $countdimensionHeaders && $i < $countdimensions; $i++) {
                    $indview['product_id'] = $dimensions[$i];
                }
                $countmetrics = count($metrics);
                for ($j = 0; $j < $countmetrics; $j++) {
                    $values = $metrics[$j]->getValues();
                    $countvalues = count($values);
                    for ($k = 0; $k < $countvalues; $k++) {
                        $entry = $metricHeaders[$k];
                        $indview['impressions'] = $values[$k];
                    }
                }
                $prodviews[] = $indview;
            }
        }
        return $prodviews;
    }

    /**
     * Weekly Data
     * @param $rawdata
     * @param $type
     * @return array
     */
    public function weeklyData($rawdata, $type)
    {

        $directory = $this->directoryList;
        if ($this->fileDriver->isExists($directory->getPath('lib_internal').'/Google/helloanalytics.php')) {
            include_once $directory->getPath('lib_internal').'/Google/helloanalytics.php';
        } else {
            return 'File doesnt exist.';
        }

        $analytics = initializeAnalytics();
          /**Create the DateRange object.*/
        $dateRange = daterange();
        if ($type == 'gaimpressions') {
            $dateRange->setStartDate("today");
        } else {
            $dateRange->setStartDate("2020-01-11");
        }
      
        $dateRange->setEndDate("today");
      
        if ($type == 'views') {
            /**Create the Metrics object.*/
            $sessions = metric();
            $sessions->setExpression("ga:productListClicks");
            $sessions->setAlias("productListClicks");
        } else {
            /**Create the Metrics object.*/
            $sessions = metric();
            $sessions->setExpression("ga:productListViews");
            $sessions->setAlias("productListViews");
        }
        $dimensions = dimension();
        $dimensions->setName("ga:productSku");
      
         /**Create Filters*/
        $dimensionfilterclause = dimensionfilterclause();
        $dimensionfilterclause->setOperator("AND");

        $dimensionfilter = dimensionfilter();
        $dimensionfilter->setDimensionName("ga:productSku");
        $dimensionfilter->setNot(false);
        $dimensionfilter->getOperator("REGEXP");
        $dimensionfilter->setExpressions([$rawdata]);
        $dimensionfilter->setCaseSensitive(false);

        $dimensionfilterclause->setFilters([$dimensionfilter]);

        $VIEW_ID = "115854344";
      
        $request = reportRequest();
        $request->setViewId($VIEW_ID);
        $request->setDateRanges($dateRange);
        $request->setMetrics([$sessions]);
        $request->setDimensions([$dimensions]);
        $request->setDimensionFilterClauses([$dimensionfilterclause]);
        $request->setPageSize(10000);
        $body = getReportsRequest();
        $body->setReportRequests([ $request]);
        $dat = $analytics->reports->batchGet($body);
        return $this->printResults($dat);
    }
    
    /**
     * Total impressions, views and atc
     * @param $rawdata
     * @return array
     */
    public function totalimpressionsdata($rawdata)
    {
            $directory = $this->directoryList;
        if ($this->fileDriver->isExists($directory->getPath('lib_internal').'/Google/helloanalytics.php')) {
            include_once $directory->getPath('lib_internal').'/Google/helloanalytics.php';
        } else {
            return 'File doesnt exist.';
        }
    
           $analytics = initializeAnalytics();
              /**Create the DateRange object.*/
           $dateRange = daterange();
           $dateRange->setStartDate("2020-01-11");
      
           $dateRange->setEndDate("today");
              /**Create the Metrics object.*/
            $impressions = metric();
            $impressions->setExpression("ga:productListViews");
            $impressions->setAlias("productListViews");
          
            $views = metric();
            $views->setExpression("ga:productListClicks");
            $views->setAlias("productListClicks");
          
            $atc = metric();
            $atc->setExpression("ga:productAddsToCart");
            $atc->setAlias("productAddsToCart");
            $dimensions = dimension();
            $dimensions->setName("ga:productSku");
          
          // Create Filters
            $dimensionfilterclause = dimensionfilterclause();
            $dimensionfilterclause->setOperator("AND");
    
            $dimensionfilter = dimensionfilter();
            $dimensionfilter->setDimensionName("ga:productSku");
            $dimensionfilter->setNot(false);
            $dimensionfilter->setOperator("IN_LIST");
            $dimensionfilter->setExpressions(explode("|", $rawdata));
            $dimensionfilter->setCaseSensitive(false);
            $dimensionfilterclause->setFilters([$dimensionfilter]);
            $VIEW_ID = '115854344';
      
            $request = reportRequest();
            $request->setViewId($VIEW_ID);
            $request->setDateRanges($dateRange);
            $request->setMetrics([$impressions, $views, $atc]);
            $request->setDimensions([$dimensions]);
            $request->setDimensionFilterClauses([$dimensionfilterclause]);
            $request->setPageSize(100000);
            $body = getReportsRequest();
            $body->setReportRequests([ $request]);
            $dat = $analytics->reports->batchGet($body);
            return $this->printTotalimpressionResults($dat);
    }

    /**
     * Total impressions results
     * @param $reports
     * @return array
     */
    protected function printTotalimpressionResults($reports)
    {
        $reportdata = [];
        $countreports = count($reports);
        for ($reportIndex = 0; $reportIndex < $countreports; $reportIndex++) {
            $report = $reports[ $reportIndex ];
            $header = $report->getColumnHeader();
            $dimensionHeaders = $header->getDimensions();
            $metricHeaders = $header->getMetricHeader()->getMetricHeaderEntries();
            $rows = $report->getData()->getRows();
            $countrows = count($rows);
            for ($rowIndex = 0; $rowIndex < $countrows; $rowIndex++) {
                $reportitem = [];
                $row = $rows[ $rowIndex ];
                $dimensions = $row->getDimensions();
                $metrics = $row->getMetrics();
                $countdimensionHeaders = count($dimensionHeaders);
                $countdimensions = count($dimensions);
                for ($i = 0; $i < $countdimensionHeaders && $i < $countdimensions; $i++) {
                    $dheader = $dimensionHeaders[$i];
                    $reportitem[$dheader] = $dimensions[$i];
                }
                $countmetrics = count($metrics);
                for ($j = 0; $j < $countmetrics; $j++) {
                    $values = $metrics[$j]->getValues();
                    $countvalues = count($values);
                    for ($k = 0; $k < $countvalues; $k++) {
                        $entry = $metricHeaders[$k];
                        $reportitem[$entry->getName()] = $values[$k];
                    }
                }
                $reportdata[] = $reportitem;
            }
        }
        return $reportdata;
    }
}
