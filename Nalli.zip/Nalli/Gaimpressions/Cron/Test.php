<?php
namespace Nalli\Gaimpressions\Cron;

use Magento\Framework\Controller\ResultFactory;
use \Psr\Log\LoggerInterface;

class Test
{

    /*
     *@var \Psr\Log\LoggerInterface $logger
     */
    protected $logger;
    
    /*
     *@var \Magento\CatalogInventory\Helper\Stock $stockFilter
     */
    protected $stockFilter;
    
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     */
    protected $ProductCollectionFactory;
    
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\Collection $ProductCollection
     */
    protected $ProductCollection;
    
    /*
     *@var \Magento\Framework\Filesystem\DirectoryList $dir
     */
    protected $dir;
    
    /*
     *@param \Psr\Log\LoggerInterface $logger
     *@param \Magento\CatalogInventory\Helper\Stock $stockFilter
     *@param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     *@param \Magento\Catalog\Model\ResourceModel\Product\Collection $ProductCollection
     *@param \Magento\Framework\Filesystem\DirectoryList $dir
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\CatalogInventory\Helper\Stock $stockFilter,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Product\Collection $ProductCollection,
        \Magento\Framework\Filesystem\DirectoryList $dir
    ) {
        $this->logger = $logger;
        $this->_stockFilter = $stockFilter;
        $this->productCollectionFactory = $ProductCollectionFactory;
        $this->productCollection = $ProductCollection;
        $this->_dir = $dir;
    }

    public function execute()
    {
        require_once $this->_dir->getPath('lib_internal').'/Google/helloanalytics.php';
        try {
              $collection = $this->productCollectionFactory->create();
              $collection->addAttributeToFilter('status', 1);
              $collection->addAttributeToFilter('visibility', ['2', '4']);
              // $this->_stockFilter->addInStockFilterToCollection($collection);
              $collection->setFlag('has_stock_status_filter', true)->joinField('stock_item', 'cataloginventory_stock_item', 'is_in_stock', 'product_id=entity_id', 'is_in_stock=1');
              $allids = $collection->getAllIds();
              $rawdata = implode('|', $allids);
              $analytics = initializeAnalytics();
              $response = getReport($analytics, $rawdata);
              $result = printResults($response);
        } catch (Exception $e) {
            $this->logger->info($e->getMessage());
        }
        $i = 0;
        foreach ($allids as $id) {
            try {
                $key = array_search($id, array_column($result, 'product_id'));
                if ($key) {
                    $products = $this->productCollection;
                    foreach ($products as $p) {
                        if ($p->getId() == $result[$key]['product_id']) {
                            $p->setData('gaimpressions', str_pad($result[$key]['impressions'], 10, '0', STR_PAD_LEFT));
                            $p->getResource()->saveAttribute($p, 'gaimpressions');
                        }
                    }
                    $logmsg = $result[$key]['product_id'] ." - " .$result[$key]['impressions'];
                    $i++;
                }
            } catch (Exception $e) {
                $this->logger->info($e->getMessage());
            }
        }
        $succmsg = $i ." products updated";
        $this->logger->info($succmsg);
    }
}
