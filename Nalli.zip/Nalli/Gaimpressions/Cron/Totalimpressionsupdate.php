<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */
 
namespace Nalli\Gaimpressions\Cron;

class Totalimpressionsupdate
{
     /*
     *@var \Magento\CatalogInventory\Helper\Stock $Stock
     */
    protected $Stock;
    
    /*
     *@var  \Nalli\Gaimpressions\Helper\Data $Helper
     */
    protected $Helper;
    
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     */
    protected $ProductCollectionFactory;
    
    /*
     *@var \Magento\Catalog\Model\Product $Product
     */
    protected $Product;
    
    /*
     *@param \Magento\CatalogInventory\Helper\Stock $Stock
     *@param \Nalli\Gaimpressions\Helper\Data $Helper
     *@param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     *@param \Magento\Catalog\Model\Product $Product
     */
    
    public function __construct(
        \Magento\CatalogInventory\Helper\Stock $Stock,
        \Nalli\Gaimpressions\Helper\Data $Helper,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory,
        \Magento\Catalog\Model\Product $Product,
        \Nalli\Gaimpressions\Logger\Logger $logger,
        \Nalli\Gaimpressions\Logger\Loggerimpression $loggerimpression
    ) {
        $this->stock = $Stock;
        $this->helper = $Helper;
        $this->productCollectionFactory = $ProductCollectionFactory;
        $this->_product = $Product;
        $this->_logger = $logger;
        $this->logger = $loggerimpression;
    }

    /**
     * Update attributes
     * @return bool
     */
    public function execute()
    {
        try {
            $this->logger->info("----- Totalimpressioncron Cron Start -----");
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->addAttributeToFilter('status', 1);
            $collection->addAttributeToFilter('visibility', ['2', '4']);

            $collection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );

            $allids = $collection->getAllIds();
            $rawdata = implode('|', $allids);
            // $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/impressioncron.log');
            // $newlogger = new \Zend\Log\Logger();
            // $newlogger->addWriter($writer);
            $this->logger->info($rawdata);
            $result = $this->helper->totalimpressionsdata($rawdata);
            $this->logger->info(true , $result);
            $i = 0;
            foreach ($allids as $id) {
                $key = array_search($id, array_column($result, 'ga:productSku'));
                if ($key) {
                    if ($id == $result[$key]['ga:productSku']) {
                        $product =$this->getProductByid($id);
                        if ($product) {
                            $product->setData(
                                'total_impressions',
                                str_pad($result[$key]['productListViews'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'total_impressions');
                            
                            $product->setData(
                                'no_of_views',
                                str_pad($result[$key]['productListClicks'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'no_of_views');
                            
                            $product->setData(
                                'atc_count',
                                str_pad($result[$key]['productAddsToCart'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'atc_count');
                            
                            $logmsg = $product->getSku() ." - Impressions: " .
                            str_pad($result[$key]['productListViews'], 10, '0', STR_PAD_LEFT) .";
							Views: " .str_pad($result[$key]['productListClicks'], 10, '0', STR_PAD_LEFT) .";
							ATC: " .str_pad($result[$key]['productAddsToCart'], 10, '0', STR_PAD_LEFT);
                            $this->logger->info($logmsg);
                            $i++;
                        }
                    }
                }
            }
            $succmsg = $i ." products updated";
            $this->logger->info($succmsg);
            $this->logger->info("----- Totalimpressioncron Cron End -----");
        } catch (Exception $e) {
            $this->logger->info($e->getMessage(), true);
        }
    }
    
    /**
     * Return product object
     * @param $id
     * @return array
     */
    public function getProductByid($id)
    {
        $product=null;
        try {
            $product = $this->_product->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($id.' --dont exits-- ');
            return false;
        }
        return $product;
    }
}
