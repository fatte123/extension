<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */
 
namespace Nalli\Gaimpressions\Controller\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Model\Order;

class Cancel extends \Magento\Framework\App\Action\Action
{
    /*
     *@var \Magento\Framework\App\Action\Context $context
     */
    protected $context;
    
    /*
     *@var  \Magento\Sales\Model\Order $order
     */
    protected $order;
     
    /*
     *@var \Magento\Framework\View\Result\PageFactory $pageFactory
     */
    protected $_pageFactory;
    
    /*
     *@var \Magento\Sales\Api\OrderManagementInterface $orderManagement
     */
    protected $orderManagement;
    
    /*
     *@var \Magento\Framework\App\Request\Http $request
     */
    protected $redirect;
    
    /*
     *@var \Magento\Framework\App\Request\Http $request
     */
    protected $request;
    
    /*
     *@param \Magento\Framework\App\Action\Context $context
     *@param \Magento\Sales\Model\Order $order
     *@param \Magento\Framework\View\Result\PageFactory $pageFactory
     *@param \Magento\Framework\App\Response\RedirectInterface $redirect
     *@param \Magento\Sales\Api\OrderManagementInterface $orderManagement
     *@param \Magento\Framework\App\Request\Http $request
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\Order $order,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        \Magento\Sales\Api\OrderManagementInterface $orderManagement,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->_pageFactory = $pageFactory;
        $this->orderManagement = $orderManagement;
        $this->order = $order;
        $this->_redirect = $redirect;
        $this->request = $request;
        parent::__construct($context);
    }

    public function execute()
    {
        $orderId = $this->request->getParam('order_id');
        $order = $this->order->load($orderId);
        $order->setState(\Magento\Sales\Model\Order::STATE_CANCELED, true);
        $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
        $order->save();
        $this->orderManagement->cancel($orderId);
        $this->messageManager->addSuccess(__('Order Cancelled successfully'));
        $this->_redirect('checkout/cart');
        return true;
    }
}
