<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */
 
namespace Nalli\Gaimpressions\Controller\Index;

class Reorder extends \Magento\Framework\App\Action\Action
{
    /*
     *@var \Magento\Framework\App\Action\Context $context
     */
    protected $context;
    /*
     *@var \Magento\Sales\Model\Order $order
     */
    protected $order;
    /*
     *@var \Magento\Framework\App\Request\Http $request
     */
    protected $request;
    /*
     *@var \Magento\Framework\Controller\ResultFactory $result
     */
    protected $result;
    /*
     *@var \Magento\Framework\Message\ManagerInterface $messageManager
     */
    protected $messageManager;
    
    /*
     *@var \Magento\Checkout\Model\Cart $Cart
     */
    protected $Cart;
    
    /*
     *@var \Magento\Checkout\Model\Session $Session
     */
    protected $Session;
    
    /*
     *@param \Magento\Framework\App\Action\Context $context
     *@param \Magento\Sales\Model\Order $order
     *@param \Magento\Framework\App\Request\Http $request
     *@param \Magento\Framework\Controller\ResultFactory $result
     *@param \Magento\Framework\Message\ManagerInterface $messageManager
     *@param \Magento\Checkout\Model\Cart $Cart
     *@param \Magento\Checkout\Model\Session $Session
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\Order $order,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Controller\ResultFactory $result,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Checkout\Model\Cart $Cart,
        \Magento\Checkout\Model\Session $Session
    ) {
        $this->order = $order;
        $this->request = $request;
        $this->resultRedirect = $result;
        $this->messageManager = $messageManager;
        $this->cart = $Cart;
        $this->session = $Session;
        parent::__construct($context);
    }

    public function execute()
    {
        $orderId = $this->request->getParam('order_id');
        $order = $this->order->load($orderId);
        if ($order->getStatus() == 'pending' || $order->getStatus() == 'pending_payment') {
            $order->cancel();
            $history = $order->addStatusHistoryComment('Reorder - cancel old order', false);
            $history->setIsCustomerNotified(false);
            $order->save();
        }
        
        $resultRedirect = $this->resultRedirectFactory->create();
        $cart = $this->cart;
        $items = $order->getItemsCollection();
        foreach ($items as $item) {
            try {
                $cart->addOrderItem($item);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->session->getUseNotice(true)) {
                    $this->messageManager->addNotice($e->getMessage());
                } else {
                    $this->messageManager->addError($e->getMessage());
                }
                return $resultRedirect->setPath('/*/*/history');
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
                return $resultRedirect->setPath('checkout/cart');
            }
        }
        $cart->save();
        return $resultRedirect->setPath('checkout');
    }
}
