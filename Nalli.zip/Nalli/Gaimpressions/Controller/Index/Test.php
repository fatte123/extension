<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */
 
namespace Nalli\Gaimpressions\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Test extends \Magento\Framework\App\Action\Action
{
    /*
     *@var \Magento\Framework\View\Result\PageFactory $pageFactory
     */
    protected $_pageFactory;
    
    /*
     *@var \Psr\Log\LoggerInterface $logger
     */
    protected $logger;
    
    /*
     *@var \Magento\CatalogInventory\Helper\Stock $stockFilter
     */
    protected $stockFilter;
    
    /*
     *@var \Magento\Framework\Filesystem\DirectoryList $dir
     */
    protected $dir;
    
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     */
    protected $ProductCollectionFactory;
    
    /*
     *@var \Nalli\Gaimpressions\Helper\Data $Helper
     */
    protected $Helper;
    
    /*
     *@var \Magento\Catalog\Model\Product $Product
     */
    protected $Product;
    
    /*
     *@parma \Magento\Framework\App\Action\Context $context
     *@parma \Magento\Framework\View\Result\PageFactory $pageFactory
     *@parma \Psr\Log\LoggerInterface $logger
     *@parma \Magento\CatalogInventory\Helper\Stock $stockFilter
     *@parma \Magento\Framework\Filesystem\DirectoryList $dir
     *@parma \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     *@parma \Nalli\Gaimpressions\Helper\Data $Helper
     *@parma \Magento\Catalog\Model\Product $Product
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\CatalogInventory\Helper\Stock $stockFilter,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory,
        \Nalli\Gaimpressions\Helper\Data $Helper,
        \Magento\Catalog\Model\Product $Product
    ) {
        $this->_pageFactory = $pageFactory;
        $this->logger = $logger;
        $this->_stockFilter = $stockFilter;
        $this->_dir = $dir;
        $this->productCollectionFactory = $ProductCollectionFactory;
        $this->helper = $Helper;
        $this->_product = $Product;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->addAttributeToFilter('status', 1);
            $collection->addAttributeToFilter('visibility', ['2', '4']);
            $collection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );
            $allids = $collection->getAllIds();
            $rawdata = implode('|', $allids);
            $result = $this->helper->weeklyData($rawdata, 'gaimpressions');
            // $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/gaimpressioncronupdate.log');
            // $newlogger = new \Zend_Log();
            // $newlogger->addWriter($writer);
            $this->logger->info($result, true);
            $i = 0;
            foreach ($allids as $id) {
                $key = array_search($id, array_column($result, 'product_id'));
                if ($key !== false) {
                    if ($id == $result[$key]['product_id']) {
                        $product = $this->getProductByid($id);
                        if ($product) {
                            $product->setData('gaimpressions', str_pad(
                                $result[$key]['impressions'],
                                10,
                                '0',
                                STR_PAD_LEFT
                            ));
                            $product->getResource()->saveAttribute($product, 'gaimpressions');
                            $logmsg = $result[$key]['product_id'] ." - " .$result[$key]['impressions'];
                            $newlogger->info($logmsg);
                            $i++;
                        }
                    }
                }
            }
            $succmsg = $i ." products updated";
            $newlogger->info($succmsg);
        } catch (Exception $e) {
            return($e->getMessage());
        }
    }
    
    /*
     *return product details
     */
    public function getProductByid($id)
    {
        $product=null;
        try {
            $product = $this->_product->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($id.' --dont exits-- ');
            return false;
        }
        return $product;
    }
}
