<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_ProductSync
 *
 */
namespace Nalli\Gaimpressions\Logger;

class Loggerimpression extends \Monolog\Logger
{
    
}
