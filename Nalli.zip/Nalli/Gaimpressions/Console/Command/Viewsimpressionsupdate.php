<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Gaimpressions
 */

namespace Nalli\Gaimpressions\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Viewsimpressionsupdate extends Command
{

    const NAME_ARGUMENT = "name";
    const NAME_OPTION = "option";
    
    /*
     *@var \Psr\Log\LoggerInterface $loggerInterface
     */
    protected $logger;
    
    /*
     *@var \Magento\Framework\App\ResourceConnection $resource
     */
    protected $_resource;
    
    /*
     *@var \Magento\Framework\App\State
     **/
    private $state;
    
    /*
     *@var \Magento\CatalogInventory\Helper\Stock $Stock
     */
    protected $Stock;
    
    /*
     *@var \Nalli\Gaimpressions\Helper\Data $Helper
     */
    protected $Helper;
    
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     */
    protected $ProductCollectionFactory;
    
    /*
     *@var \Magento\Catalog\Model\Product $Product
     */
    protected $Product;

    /*
     *@var \Nalli\Gaimpressions\Logger\Loggerimpression $loggerimpression
     */
    protected $loggerimpression;
     
    /*
     *@parma \Psr\Log\LoggerInterface $loggerInterface
     *@parma \Magento\Framework\App\ResourceConnection $resource
     *@parma \Magento\Framework\App\State $state
     *@parma \Magento\CatalogInventory\Helper\Stock $Stock
     *@param \Nalli\Gaimpressions\Helper\Data $Helper
     *@param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory
     *@param \Magento\Catalog\Model\Product $Product
     */
    public function __construct(
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\App\State $state,
        \Magento\CatalogInventory\Helper\Stock $Stock,
        \Nalli\Gaimpressions\Helper\Data $Helper,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $ProductCollectionFactory,
        \Magento\Catalog\Model\Product $Product,
        \Nalli\Gaimpressions\Logger\Loggerimpression $loggerimpression
    ) {
        $this->logger = $loggerInterface;
        $this->_resource = $resource;
        $this->state = $state;
        $this->stock = $Stock;
        $this->helper = $Helper;
        $this->_product = $Product;
        $this->productCollectionFactory = $ProductCollectionFactory;
        $this->loggerimpression = $loggerimpression;
        parent::__construct();
    }
    /**
     * {@inheritdoc}
     */
    protected function execute(
        InputInterface $input,
        OutputInterface $output
    ) {
        $this->state->setAreaCode(\Magento\Framework\App\Area::AREA_FRONTEND);
        try {
            $this->loggerimpression->info("----- Totalimpressioncron Command execute -----");
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->addAttributeToFilter('status', 1);
            $collection->addAttributeToFilter('visibility', ['2', '4']);
            $collection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );
            $allids = $collection->getAllIds();
            $rawdata = implode('|', $allids);
            $this->loggerimpression->info($rawdata);
            // $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/impressiontest4.log');
            // $newlogger = new \Zend_Log();
            // $newlogger->addWriter($writer);
            // $newlogger->info($rawdata);
            $result = $this->helper->totalimpressionsdata($rawdata);
            // $newlogger->info($result, true);
            $this->loggerimpression->info(true , $result);
            
            $i = 0;
            foreach ($allids as $id) {
                $key = array_search($id, array_column($result, 'ga:productSku'));
                if ($key) {
                    if ($id == $result[$key]['ga:productSku']) {
                        $product =$this->getProductByid($id);
                        if ($product) {
                            $product->setData(
                                'total_impressions',
                                str_pad($result[$key]['productListViews'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'total_impressions');
                            
                            $product->setData(
                                'no_of_views',
                                str_pad($result[$key]['productListClicks'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'no_of_views');
                            
                            $product->setData(
                                'atc_count',
                                str_pad($result[$key]['productAddsToCart'], 10, '0', STR_PAD_LEFT)
                            );
                            $product->getResource()->saveAttribute($product, 'atc_count');
                            
                            $views_impressions = (
                                $result[$key]['productListClicks'] / $result[$key]['productListViews']
                            ) * 1000;
                            $product->setData('views_impressions', $views_impressions);
                            $product->getResource()->saveAttribute($product, 'views_impressions');
                            
                            // $logmsg = $result[$key]['product_id'] ." - " .$result[$key]['impressions'];
                            $logmsg = $product->getId() ." - " .$product->getSku() .
                            " - Impressions: " .str_pad($result[$key]['productListViews'], 10, '0', STR_PAD_LEFT) ."; 
							Views: " .str_pad($result[$key]['productListClicks'], 10, '0', STR_PAD_LEFT) .";
							ATC: " .str_pad($result[$key]['productAddsToCart'], 10, '0', STR_PAD_LEFT) .";
							MCTR: " .$views_impressions ." - " .str_pad($views_impressions, 10, '0', STR_PAD_LEFT);
                            $this->loggerimpression->info($logmsg);
                            $i++;
                        }
                    }
                }
            }
            $succmsg = $i ." products updated";
            $output->writeln($succmsg);
            $this->loggerimpression->info("----- Totalimpressioncron Command end -----");
        } catch (Exception $e) {
            $output->writeln($e);
        }
    }
    
    /**
     * Return product object
     * @param $id
     * @return array
     */
    public function getProductByid($id)
    {
        $product=null;
        try {
            $product = $this->_product->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($id.' --dont exits-- ');
            $this->loggerimpression->info($id.' --dont exits-- ');
            return false;
        }
        return $product;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName("nalli_gaimpressions:viewsimpressionsupdate");
        $this->setDescription("");
        $this->setDefinition([
            new InputArgument(self::NAME_ARGUMENT, InputArgument::OPTIONAL, "Name"),
            new InputOption(self::NAME_OPTION, "-a", InputOption::VALUE_NONE, "Option functionality")
        ]);
        parent::configure();
    }
}
