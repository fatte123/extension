/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Payment
 */
var config = {
    map: {
        '*': {
          'Razorpay_Magento/template/payment/razorpay-form.html':'Nalli_Payment/template/payment/razorpay-form.html',
		  'Razorpay_Magento/js/view/payment/method-renderer/razorpay-method':'Nalli_Payment/js/view/payment/method-renderer/razorpay-method',
          'Juspay_Payment/template/payment/juspay.html':'Nalli_Payment/template/payment/juspay.html',
		  'Juspay_Payment/js/view/payment/method-renderer/juspay':'Nalli_Payment/js/view/payment/method-renderer/juspay'
        },
		
  }
};
