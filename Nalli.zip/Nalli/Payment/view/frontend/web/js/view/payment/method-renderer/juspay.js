define(
    [
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/model/quote',
        'jquery',
        'ko',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Magento_Checkout/js/action/set-payment-information',
        'mage/url',
        'Magento_Customer/js/model/customer',
        'Magento_Checkout/js/action/place-order',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Ui/js/model/messageList',
        'Magento_Checkout/js/model/shipping-save-processor',
        'Magento_Ui/js/modal/modal'
    ],
    function (Component, quote, $, ko, additionalValidators, setPaymentInformationAction, url, customer, placeOrderAction, fullScreenLoader, messageList, shippingSaveProcessor, modal) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Juspay_Payment/payment/juspay',
                juspayServiceLoaded: false,
                juspay_response : []
            },

            getClientId: function() {
                return window.checkoutConfig.payment.juspay.client_id;
            },

            getBetaAssets: function() {
                return window.checkoutConfig.payment.juspay.beta_assets;
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'juspay';
            },

            isActive: function() {
                return true;
            },

            initObservable: function() {

                var self = this._super();   //Resolves UI Error on Checkout

                if(!self.juspayServiceLoaded) {
                    $.getScript("https://public.releases.juspay.in/hyper-sdk-web/HyperServices.js", function() {
                        self.juspayServiceLoaded = true;
                        window.hyperServices = new window.HyperServices();

                        this.client_id = self.getClientId();
                        this.beta_assets = self.getBetaAssets();

                        var beta_assets = false;
                        if(this.beta_assets === 1){
                            beta_assets = true;
                        }
        
                        const payload = {
                            "service" : "in.juspay.hyperpay",
                            "betaAssets" : beta_assets,
                            "payload" : {
                                "clientId" : this.client_id
                            }
                        }
                        window.HyperServices.preFetch(payload);
       
                    });
                    console.log("juspay hyper service loaded");
                }

                return self;
            },

            preparePayment: function (context, event) {
                console.log('triggering juspay payment - prepare payment');

                if(!additionalValidators.validate()) {   //Resolve checkout aggreement accept error
                    return false;
                }

                var self = this,
                    billing_address,
                    jp_order_id;

                fullScreenLoader.startLoader();
                this.messageContainer.clear();

                this.amount = quote.totals()['base_grand_total'] * 100;
                billing_address = quote.billingAddress();

                this.user = {
                    name: billing_address.firstname + ' ' + billing_address.lastname,
                    contact: billing_address.telephone,
                };

                if (!customer.isLoggedIn()) {
                    this.user.email = quote.guestEmail;
                }
                else
                {
                    this.user.email = customer.customerData.email;
                }

                this.isPaymentProcessing = $.Deferred();

                $.when(this.isPaymentProcessing).done(
                    function () {
                        // self.placeOrder();
                    }
                ).fail(
                    function (result) {
                        self.handleError(result);
                    }
                );

                // self.preFetchJuspayService();
                self.getJpOrderId();

                return;
            },


            getJpOrderId: function () {
                var self = this;

                //update shipping and billing before order into quotes
                if(!quote.isVirtual()) {
                    shippingSaveProcessor.saveShippingInformation().success(
                        function (response) {
                            self.createJpOrder();
                        }
                    ).fail(
                        function (response) {
                            fullScreenLoader.stopLoader();
                            self.isPaymentProcessing.reject(response.message);
                        }
                    );
                } else {
                    self.createJpOrder();
                }

            },

            createJpOrder: function(){
                var self = this;

                $.ajax({
                    type: 'POST',
                    url: url.build('juspay_payment/standard/order?' + Math.random().toString(36).substring(10)),
                    data: {
                        email: this.user.email,
                        billing_address: JSON.stringify(quote.billingAddress())
                    },

                    /**
                     * Success callback
                     * @param {Object} response
                     */
                    success: function (response) {
                        fullScreenLoader.stopLoader();
                        if (response.success) {
                            self.juspay_response = response;
                            /*
                            if (self.juspay_response.is_hosted) {
                                console.log("triggering is_hosted");
                                self.placeOrder();
                            }else{
                                console.log("triggering iframe mode");
                                self.renderIframe(self.juspay_response);
                                self.placeOrder();
                            }
                            */

                            console.log("triggering after createJuspayOrder");

                            self.placeOrder();

                        } else {
                            self.isPaymentProcessing.reject(response.message);
                        }
                    },


                    /**
                     * Error callback
                     * @param {*} response
                     */
                    error: function (response) {
                        fullScreenLoader.stopLoader();
                        self.isPaymentProcessing.reject(response.message);
                    }
                });
            },

            placeOrder: function (data, event) {

                if (event) {
                    event.preventDefault();
                }
                var self = this,
                    placeOrder,
                    emailValidationResult = customer.isLoggedIn(),
                    loginFormSelector = 'form[data-role=email-with-possible-login]';
                if (!customer.isLoggedIn()) {
                    $(loginFormSelector).validation();
                    emailValidationResult = Boolean($(loginFormSelector + ' input[name=username]').valid());
                }
                if (emailValidationResult && this.validate() && additionalValidators.validate()) {
                    this.isPlaceOrderActionAllowed(false);
                    placeOrder = placeOrderAction(this.getData(), false, this.messageContainer);

                    $.when(placeOrder).fail(function () {
                        self.isPlaceOrderActionAllowed(true);
                    }).done(this.afterPlaceOrder.bind(this));
                    return true;
                }
                return false;
            },

            afterPlaceOrder: function () {
                console.log("triggering after place order");
                var self = this;
                if (self.juspay_response.is_hosted) {
                    self.renderHosted(self.juspay_response);
                }else{
                    self.renderIframe(self.juspay_response);
                    self.handleBackpressEvent();
                }
            },

            renderHosted: function(data) {
                var self = this;
                window.juspay_data = data;

                console.log("triggering hosted payment page");

                var beta_assets = false;
                if(self.beta_assets === 1){
                    beta_assets = true;
                }


                const initiatePayload = {
                    action: "initiate",
                    clientId: data.client_id,
                    merchantId: data.merchant_id,
                    merchantKeyId: data.merchant_key_id,
                    signaturePayload: data.signature_payload,
                    signature : data.signature,
                    environment: data.environment,
                    integrationType: "redirection"
                };
                const sdkPayload1 = {
                    service: "in.juspay.hyperpay",
                    requestId: data.request_id,
                    payload: initiatePayload,
                    betaAssets: beta_assets,
                };
                window.hyperServices.initiate(sdkPayload1);  

                const processPayload = {
                    "action": "paymentPage",
                    "merchantId": data.merchant_id,
                    "clientId": data.client_id,
                    "merchantKeyId": data.merchant_key_id,
                    "amount": data.amount,
                    "customerId": data.customer_id,
                    "customerMobile": data.customer_phone,
                    "description": JSON.parse(data.description),
                    "endUrl": data.end_url,
                    "orderId": data.order_id,
                    "orderDetails": data.signature_payload,
                    "signature" : data.signature,
                }
                const sdkPayload2 = {
                  "service": "in.juspay.hyperpay",
                  "requestId": data.request_id,
                  "payload": processPayload
                };

                // console.log(sdkPayload2);

                window.hyperServices.process(sdkPayload2);                                
            },

           renderIframe: function(data) {
                console.log("triggering iframe payment page");
                window.juspay_data = data;
                // console.log(data);
                // jQuery( "<div id='juspayView'></div>").insertAfter( ".page-wrapper" );

                var iframe_type = data.iframe_type;

                var custom_styles = '<style>' + data.custom_css + '</style>';

                jQuery('body').append(custom_styles);

                if(iframe_type == 'embed'){
                    jQuery('#checkoutSteps').after("<div id='juspayContainer' class='juspay-view-embed'><div class='juspayClose'><span>&times;</span></div><div id='juspayView' class='juspayView'></div></div>");
                }else if(data.iframe_type == 'popup'){
                    jQuery('body').append("<div id='juspayContainer' class='juspay-view-popup'><div class='juspayClose'><span>&times;</span></div><div id='juspayView' class='juspayView'></div></div>");
                }else{
                    jQuery('body').append("<div id='juspayContainer' class='juspay-view-fullscreen'><div class='juspayClose'><span>&times;</span></div><div id='juspayView' class='juspayView'></div></div>");
                }

                // jQuery("#juspayView").css({"height":"100vh","width":"100%"});

                var self = this;

                var cancel_payment_url = url.build('juspay_payment/standard/cancel?action=close');

                $('.juspayClose span').click(function() {
                    window.location = cancel_payment_url;
                });

                var beta_assets = false;
                if(data.beta_assets === 1){
                    beta_assets = true;
                }

                const initiatePayload = {
                    action: "initiate",
                    clientId: data.client_id,
                    merchantId: data.merchant_id,
                    merchantKeyId: data.merchant_key_id,
                    signaturePayload: data.signature_payload,
                    signature : data.signature,
                    environment: data.environment,
                    integrationType: "iframe",
                    entryPointId: "juspayView" // Div ID to be used for rendering
                };
                const sdkPayload1 = {
                    service: "in.juspay.hyperpay",
                    requestId: data.request_id,
                    payload: initiatePayload,
                    betaAssets: beta_assets,
                };
                window.hyperServices.initiate(sdkPayload1, this.hyperPaymentsCallback);  


                if(iframe_type == 'embed'){
                    jQuery('#checkoutSteps').hide();
                }else if(iframe_type == 'fullscreen'){
                    console.log("hiding page wrapper for fullscreen iframe");
                    jQuery(".page-wrapper").hide();
                }
               
                jQuery("#juspayContainer").show();
                jQuery("body").loader('hide');


                const processPayload = {
                    "action": "paymentPage",
                    "merchantId": data.merchant_id,
                    "clientId": data.client_id,
                    "merchantKeyId": data.merchant_key_id,
                    "amount": data.amount,
                    "customerId": data.customer_id,
                    "customerMobile": data.customer_phone,
                    "description": JSON.parse(data.description),
                    "endUrl": data.end_url,
                    "orderId": data.order_id,
                    "orderDetails": data.signature_payload,
                    "signature" : data.signature,
                    "environment": data.environment,
                }
                const sdkPayload2 = {
                  "service": "in.juspay.hyperpay",
                  "requestId": data.request_id,
                  "payload": processPayload
                };

                // console.log(sdkPayload2);

                window.hyperServices.process(sdkPayload2,this.hyperPaymentsCallback);
                
            },

            handleBackpressEvent: function(){

                document.onmouseover = function() {
                    //User's mouse is inside the page.
                    window.innerDocClick = true;
                }

                document.onmouseleave = function() {
                    //User's mouse has left the page.
                    window.innerDocClick = false;
                }

                window.onhashchange = function() {

                    var cancel_payment_url = url.build('juspay_payment/standard/cancel?action=backpress');

                    if (window.innerDocClick) {
                        console.log("Your own in-page mechanism triggered the hash change");
                        location.href = cancel_payment_url;
                    } else {
                        console.log("Browser back button was clicked");
                        location.href = cancel_payment_url;
                    }
                }
            },

            hyperPaymentsCallback: function(eventData){

                var cancel_payment_url = url.build('juspay_payment/standard/cancel?action=backpress');
                // console.log(eventData);
                try {
                    if (eventData){
                        const eventJSON  = eventData;
                        const event = eventJSON.event
                        // Check for event key
                        if (event == "initiate_result") {
                           // console.log("initiate_result ");
                        // Handle initiate result here
                        } else if (event == "process_result") {
                            // console.log("process_result");
                            // console.log(eventJSON);
                            // console.log(eventJSON.payload.status);
                            if(eventJSON.payload.status == "backpressed"){
                                // console.log("now go backwards");
                                location.href = cancel_payment_url;
                            }
                        } else {
                            console.log("Unhandled event",event, " Event data", eventData);  
                            console.log(eventJSON);         
                        }
                    } else {
                        console.log("No data received in event",eventData);
                        // console.log(eventJSON);
                    }
                } catch (error) {
                    console.log("Error in hyperSDK response",error);
                }
            }


        });
    }
);
