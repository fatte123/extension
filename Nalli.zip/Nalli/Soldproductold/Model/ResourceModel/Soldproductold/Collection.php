<?php
/**
 * Collection file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package RetailInsights_PlaceOrder
 */
 
namespace Nalli\Soldproductold\Model\ResourceModel\Soldproductold;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'soldproductold_id';
    protected $_eventPrefix = 'nalli_soldproductold_soldproductold_collection';
    protected $_eventObject = 'soldproductold_collection';

    /**
     * Define resource model
     * @return void
     */
   
    protected function _construct()
    {
        $this->_init(
            \Nalli\Soldproductold\Model\Soldproductold::class,
            \Nalli\Soldproductold\Model\ResourceModel\Soldproductold::class
        );
    }
}
