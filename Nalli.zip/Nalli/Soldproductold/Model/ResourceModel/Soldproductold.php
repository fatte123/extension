<?php
/**
 * Model file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package RetailInsights_PlaceOrder
 */
 
namespace Nalli\Soldproductold\Model\ResourceModel;

class Soldproductold extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('soldproductold', 'soldproductold_id');
    }
}
