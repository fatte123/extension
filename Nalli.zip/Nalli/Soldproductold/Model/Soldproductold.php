<?php
/**
 * Model file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package RetailInsights_PlaceOrder
 */
 
namespace Nalli\Soldproductold\Model;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\DataObject\IdentityInterface;

class Soldproductold extends AbstractModel implements IdentityInterface
{
    const CACHE_TAG = 'nalli_soldproductold_soldproductold';

    protected $_cacheTag = 'nalli_soldproductold_soldproductold';

    protected $_eventPrefix = 'nalli_soldproductold_soldproductold';

    protected function _construct()
    {
        $this->_init(\Nalli\Soldproductold\Model\ResourceModel\Soldproductold::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
