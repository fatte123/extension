<?php
/**
 * Block file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Block;

class Soldproductold extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Framework\View\Element\Template\Context $context
     */
    public $context;
    
    /*
     *@var \Magento\Framework\Url\Helper\Data $helper
     */
    public $helper;
    
    /*
     *@var \Magento\Customer\Model\Session $Session
     */
    public $Session;
    
    /*
     *@var \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper
     */
    public $WeeklyreportHelper;
    
    /*
     *@var \Magento\Framework\App\Response\Http $Http
     */
    public $Http;
    
    /*
     *@parma \Magento\Framework\View\Element\Template\Context $context
     *@parma \Magento\Framework\Url\Helper\Data $helper
     *@param \Magento\Customer\Model\Session $Session
     *@param \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Url\Helper\Data $helper,
        \Magento\Customer\Model\Session $Session,
        \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper,
        \Magento\Framework\App\Response\Http $Http
    ) {
        $this->context = $context;
        $this->helper = $helper;
        $this->Session = $Session;
        $this->WeeklyreportHelper = $WeeklyreportHelper;
        $this->httpresponse = $Http;
        parent::__construct($context);
    }
    /*
     *return \Nalli\Weeklyreport\Helper\Data  class functions
     */
    public function getWeeklyreportHelper()
    {
        return $this->WeeklyreportHelper;
    }
    
    /*
     *return \Magento\Framework\Url\Helper\Data class function
     */
    public function getUrlHelper()
    {
        return $this->helper;
    }
    
    /*
     *return customer login or not
     */
    public function chechLogin()
    {
        return $this->Session->isLoggedIn();
    }
    
    /*
     *return customer login or not
     */
    public function getCustomerEmail()
    {
        return $this->Session->getCustomer()->getEmail();
    }
    
    public function setRedirect($path)
    {
        return $this->httpresponse->setRedirect($path);
    }
}
