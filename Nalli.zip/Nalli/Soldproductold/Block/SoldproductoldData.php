<?php
/**
 * Block file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Block;

class SoldproductoldData extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Framework\View\Element\Template\Context $context
     */
    public $context;
    
    /*
     *@var \Nalli\Soldproductold\Model\Soldproductold $Soldproductold
     */
    public $Soldproductold;
    
    /*
     *@var \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     */
    public $StoreManagerInterface;
    
    /*
     *@var \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
     */
    public $TimezoneInterface;
    
    /*
     *@var  \Magento\Framework\App\RequestInterface $request;
     */
     protected $request;
     
     /*
     *@var  \Magento\Framework\App\ResourceConnection $resource
     */
     protected $resource;
    
    /*
     *@parma \Magento\Framework\View\Element\Template\Context $context
     *@parma Nalli\Soldproductold\Model\Soldproductold $Soldproductold
     *@param \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     *@param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
     *@parma \Magento\Framework\App\Request\Http $request
     *@parma \Magento\Framework\App\ResourceConnection $resource
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Nalli\Soldproductold\Model\Soldproductold $Soldproductold,
        \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        $this->soldproductold = $Soldproductold;
        $this->storeManagerInterface = $StoreManagerInterface;
        $this->timezoneInterface = $TimezoneInterface;
        $this->request = $request;
        $this->resource = $resource;
        parent::__construct($context);
    }
     /*
     *return data on phtml
     */
    public function getCustomCollection($from, $to, $data)
    {
		if($from != '' && $to != '') {
        $collection =  $this->soldproductold->getCollection();
        $sku = 'ES00';
        $collection->addFieldToFilter('main_table.sku', [
                   ['like' => '%'.$sku.'%'], //spaces on each side
                   ['like' => '%'.$sku], //space before and ends with $needle
                   ['like' => $sku.'%'] // starts with needle and space after
        ]);

        $collection->addFieldToFilter('status', ['in' => ['processing', 'shipped', 'complete']]);
        $collection->addFieldToFilter('order_date', ['from' => $from, 'to' => $to]);
        $resource = $this->resource;
        $connection = $resource->getConnection();
    
        $idsSelect = clone $collection->getSelect();
        $idsSelect->reset(\Magento\Framework\DB\Select::ORDER);
        // $idsSelect->reset(Zend_Db_Select::WHERE);
        $idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_COUNT);
        $idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_OFFSET);
        $idsSelect->reset(\Magento\Framework\DB\Select::COLUMNS);

        $productfiltertitles = [
               'shipping_country' => 'Shipping Country',
               'shipping_state' => 'Shipping State',
               'shipping_city' => 'Shipping City',
               'billing_country' => 'Billing Country',
               'billing_state' => 'Billing State',
               'billing_city' => 'Billing City',
               'counter' => 'Counter',
               'article_type' => 'Category',
               'border' => 'Border',
               'border_type' => 'Border Type',
               'zari_type' => 'Zari Type',
               'blouse' => 'Blouse',
               'fabric_purity' => 'Fabric Purity',
               'ornamentation_type' => 'Ornamentation Type',
               'occasion' => 'Occasion',
               'color' => 'Color',
               'material' => 'Material',
               'pattern' => 'Pattern',
               'style_of_work' => 'Style of Work',
               'technique' => 'Technique' ,
               'store_code' => 'Store Code'
               ];

        $productfilterarray = array();
        foreach ($productfiltertitles as $productfilterkey => $productfiltervalue) {
            $idsSelect->reset(\Magento\Framework\DB\Select::COLUMNS);
            $idsSelect->columns($productfilterkey);
            $productfilterarray[$productfilterkey] = array_values(array_unique($connection->fetchCol($idsSelect)));
        }

        // Default values
        $defaultsort = 'order_date';
        $defaultdir = 'DESC';
    
        $pagesize = '20';
        $curpage = '1';
    
        $pricefrom = '';
        $priceto = '';
        $agefrom = '';
        $ageto = '';
        $atcfrom = '';
        $atcto = '';
        $views_impressionsfrom = '';
        $views_impressionsto = '';
        $atc_viewsfrom  = '';
        $atc_viewsto = '';
        $viewsfrom = '';
        $viewsto = '';
        $impressionsfrom = '';
        $impressionsto = '';
        $skufilter = '';
        $supplierfilter = '';

        // Check for Filters
        $appliedfilters = array();
    
        foreach ($data as $datakey => $datavalue) {
            if ($datakey == 'sort') {
                $defaultsort = $datavalue;
            } elseif ($datakey == 'dir') {
                $defaultdir = $datavalue;
            } elseif ($datakey == 'fromdate') {
            } elseif ($datakey == 'todate') {
            } elseif ($datakey == 'pagesize') {
                $pagesize = $datavalue;
            } elseif ($datakey == 'curpage') {
                $curpage = $datavalue;
            } elseif ($datakey == 'pricefrom') {
                if ($datavalue != '') {
                    $collection->getSelect()->where("CAST(IFNULL(`base_price`,0) AS SIGNED) >= '".trim($datavalue)."'");
                    $pricefrom = trim($datavalue);
                }
            } elseif ($datakey == 'priceto') {
                if ($datavalue != '') {
                    $collection->getSelect()->where("CAST(IFNULL(`base_price`,0) AS SIGNED) <= '".trim($datavalue)."'");
                    $priceto = trim($datavalue);
                }
            } elseif ($datakey == 'agefrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('sold_age', ['gteq' => trim($datavalue)]);
                    $agefrom = trim($datavalue);
                }
            } elseif ($datakey == 'ageto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('sold_age', ['lteq' => trim($datavalue)]);
                    $ageto = trim($datavalue);
                }
            } elseif ($datakey == 'atcfrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('atc_count', ['gteq' => trim($datavalue)]);
                    $atcfrom = trim($datavalue);
                    
                }
            } elseif ($datakey == 'atcto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('atc_count', ['lteq' => trim($datavalue)]);
                    $atcto = trim($datavalue);
                }
            } elseif ($datakey == 'viewsfrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('views', ['gteq' => trim($datavalue)]);
                    $viewsfrom = trim($datavalue);
                }
            } elseif ($datakey == 'viewsto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('views', ['lteq' => trim($datavalue)]);
                    $viewsto = trim($datavalue);
                }
            } elseif ($datakey == 'impressionsfrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('impressions', ['gteq' => trim($datavalue)]);
                    $impressionsfrom = trim($datavalue);
                }
            } elseif ($datakey == 'impressionsto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('impressions', ['lteq' => trim($datavalue)]);
                    $impressionsto = trim($datavalue);
                }
            } elseif ($datakey == 'views_impressionsfrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('mctr', ['gteq' => trim($datavalue)]);
                    $views_impressionsfrom = trim($datavalue);
                }
            } elseif ($datakey == 'views_impressionsto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('mctr', ['lteq' => trim($datavalue)]);
                    $views_impressionsto = trim($datavalue);
                }
            } elseif ($datakey == 'atc_viewsfrom') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('atc_percent', ['gteq' => trim($datavalue)]);
                    $atc_viewsfrom = trim($datavalue);
                }
            } elseif ($datakey == 'atc_viewsto') {
                if ($datavalue != '') {
                    $collection->addFieldToFilter('atc_percent', ['lteq' => trim($datavalue)]);
                    $atc_viewsto = trim($datavalue);
                }
            } elseif ($datakey == 'sku') {
                if ($datavalue != '') {
                    $skuarray = explode(',', str_replace(' ', '', $datavalue));
                    $collection->addFieldToFilter('sku', ['in' => $skuarray]);
                    $skufilter = $datavalue;
                }
            } elseif ($datakey == 'supplier_code') {
                if ($datavalue != '') {
                    $supplierarray = explode(',', str_replace(' ', '', $datavalue));
                    $collection->addFieldToFilter('supplier_code', ['in' => $supplierarray]);
                    $supplierfilter = $datavalue;
                }
            } else {
				//print_r($datavalue);die;   
				//if (is_array($datavalue)) {
                if (in_array("blank", $datavalue,true)) {
                    $collection->addFieldToFilter($datakey, [
                                ['in' => $datavalue],
                                ['eq' => ''],
                                ['null' => true]
                    ]);
                //} 
				}else {
                    $collection->addFieldToFilter($datakey, ['in' => $datavalue]);
                }
                $appliedfilters[$datakey] = $datavalue;
            }
        }

        $filter_idsSelect = clone $collection->getSelect();
        $filter_idsSelect->reset(\Magento\Framework\DB\Select::ORDER);
        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_COUNT);
        $filter_idsSelect->reset(\Magento\Framework\DB\Select::LIMIT_OFFSET);
        $filter_idsSelect->reset(\Magento\Framework\DB\Select::COLUMNS);
    
        $totalcount = $connection->fetchCol($filter_idsSelect->columns('COUNT(*)'));
    
        if ($defaultsort == 'order_date') {
            $collection->getSelect()->order("{$defaultsort}  {$defaultdir}");
        } else {
            $collection->getSelect()->order("CAST({$defaultsort} AS SIGNED) {$defaultdir}");
        }
        
        $collection->setPageSize($pagesize);
        $collection->setCurPage($curpage);
        
        $sortdir = $defaultsort."|".$defaultdir;
        
        $datas['totalcount'] = $totalcount;
        $datas['sortdir'] = $sortdir;
        $datas['pagesize'] = $pagesize;
        $datas['productfilterarray'] = $productfilterarray;
        $datas['productfiltertitles'] = $productfiltertitles;
        $datas['pricefrom'] = $pricefrom;
        $datas['priceto'] = $priceto;
        $datas['agefrom'] = $agefrom;
        $datas['ageto'] = $ageto;
        $datas['atcfrom'] = $atcfrom;
        $datas['atcto'] = $atcto;
        $datas['views_impressionsfrom'] = $views_impressionsfrom;
        $datas['views_impressionsto'] = $views_impressionsto;
        $datas['atc_viewsfrom'] = $atc_viewsfrom;
        $datas['atc_viewsto'] = $atc_viewsto;
        $datas['viewsfrom'] = $viewsfrom;
        $datas['viewsto'] = $viewsto;
        $datas['impressionsfrom'] = $impressionsfrom;
        $datas['impressionsto'] = $impressionsto;
        $datas['skufilter'] = $skufilter;
        $datas['supplierfilter'] = $supplierfilter;
        $datas['defaultsort'] = $defaultsort;
        $datas['defaultdir'] = $defaultdir;
        $datas['curpage'] = $curpage;
        $datas['appliedfilters'] = $appliedfilters;
        $datas['collection'] = $collection;
        return $datas;
		} else {
		 return false;
		}
    }
    
    /*
     *return string
     */
    public function compareByName($a, $b)
    {
        return strcmp($a["label"], $b["label"]);
    }
    
    public function getStoreDetails()
    {
        return $this->storeManagerInterface;
    }
    
    public function getDateFormate()
    {
        return $this->timezoneInterface;
    }
}
