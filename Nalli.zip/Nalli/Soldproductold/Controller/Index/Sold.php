<?php
/**
 * Controller file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Controller\Index;
 
class Sold extends \Magento\Framework\App\Action\Action
{
    /*
     *@var \Magento\Framework\App\Action\Context $context
     */
    protected $context;
     
    /*
     *@var \Magento\Framework\View\Result\PageFactory $pageFactory
     */
    protected $_pageFactory;
    
    /*
     *@var \Magento\Customer\Model\Session $Session
     */
    protected $Session;
    
    /*
     *@var \Nalli\Weeklyreport\Helper\Data $helper
     */
    protected $helper;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $Session,
        \Nalli\Weeklyreport\Helper\Data $helper
    ) {
        $this->_pageFactory = $pageFactory;
        $this->session = $Session;
        $this->helper = $helper;
        return parent::__construct($context);
    }
    
    public function execute()
    {
        $resultPage = $this->_pageFactory->create();
        
        $customerSession = $this->session;
        if ($customerSession->isLoggedIn()) {
            $customeremail = $customerSession->getCustomer()->getEmail();
            $allowed_user = $this->helper->getConfig('weeklyreport/general/sold_allowed_users');
            $screenusers = array_map('trim', explode(',', $allowed_user));

            if (in_array($customeremail, $screenusers)) {
                
                $block = $resultPage->getLayout()
                ->createBlock(\Nalli\Soldproductold\Block\SoldproductoldData::class)
                ->setTemplate('Nalli_Soldproductold::soldproductold-data.phtml')
                ->toHtml();
                 return $this->getResponse()->setBody($block);
            } else {
                $this->_redirect('eventuser/noroute');
            }
        } else {
            $this->_redirect('customer/account/login');
        }
    }
}
