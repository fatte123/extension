<?php
/**
 * Controller file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Controller\Adminhtml\Soldproductold;

use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;

class Save extends \Magento\Backend\App\Action
{
    /*
     *@var \Magento\Backend\App\Action\Context $context
     */
    public $context;
    
    /*
     *@var \Magento\Framework\App\Request\Http $request
     */
    public $request;
    
    /*
     *@var UploaderFactory $uploaderFactory
     */
    public $uploaderFactory;
    
    /*
     *@var AdapterFactory $adapterFactory
     */
    public $adapterFactory;
    
    /*
     *@var Filesystem $filesystem
     */
    public $filesystem;
    
    /*
     *@var \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
     */
    protected $soldproductoldFactory;
    
    /*
     *@param \Magento\Backend\App\Action\Context $context
     *@param \Magento\Framework\App\Request\Http $request
     *@param UploaderFactory $uploaderFactory
     *@param AdapterFactory $adapterFactory
     *@param Filesystem $filesystem
     *@param \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
     */
     
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
        \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
    ) {
        $this->request = $request;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->_soldproductoldFactory = $soldproductoldFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('soldproductold/soldproductold/add/');
            return;
        }
        if (isset($_FILES['bulk_file_upload']['name']) && $_FILES['bulk_file_upload']['name'] != '') {
            try {
                $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'bulk_file_upload']);
                $uploaderFactory->setAllowedExtensions(['CSV', 'csv']);
                $fileAdapter = $this->adapterFactory->create();
                $uploaderFactory->setAllowRenameFiles(true);
                $destinationPath = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('soldproductold');
                $result = $uploaderFactory->save($destinationPath);
                if (!$result) {
                    throw new LocalizedException(
                        __('File cannot be saved to path: $1', $destinationPath)
                    );
                }
                $fileHandler = fopen($destinationPath."/".$result['file'], 'r');
                $i = 0;
                if ($fileHandler) {
                    $colNames = fgetcsv($fileHandler);
                    foreach ($colNames as &$colName) {
                        $colName = trim($colName);
                    }
                    $requiredColumns = ['item_id','order_id','increment_id','status','order_date','customer_id','customer_email','billing_country','billing_state','billing_city','billing_country_id','shipping_country','shipping_state','shipping_city','shipping_country_id','remote_ip','ip_country','ip_state','ip_city','ip_country_id','product_id','sku','be_code','qty_ordered','base_price','sold_age','name','article_type','counter','product_created_at','product_url','border','border_type','zari_type','blouse','fabric_purity','occasion','ornamentation_type','color','multicolor','material','pattern','style_of_work','technique','atc_count','views','impressions','mctr','atc_percent','supplier_code','consignment_id','store_code','base_image','small_image'];
                    $requiredColumnsPositions = [];

                    foreach ($requiredColumns as $columnName) {
                        $found = array_search($columnName, $colNames);
                        if (false !== $found) {
                            $requiredColumnsPositions[] = $found;
                        } else {
                            $this->messageManager->addError('Corrupt file');
                            $this->_redirect('soldproductold/soldproductold/add');
                            return;
                        }
                    }
                    while (($currentRow = fgetcsv($fileHandler)) !== false) {
                        foreach ($requiredColumnsPositions as $index) {
                            if (isset($currentRow[$index])) {
                                $csvDataRow[$colNames[$index]] = trim($currentRow[$index]);
                            }
                        }
                        if (isset($csvDataRow['item_id']) && $csvDataRow['item_id'] !== '') {
                            $csvData[] = $csvDataRow;
                        }
                    }
                    fclose($fileHandler);
                    $added = 0;
                    $present = 0;

                    foreach ($csvData as $productdata) {

                        $rowData = $this->_soldproductoldFactory->create()->getCollection()->addFieldToFilter('item_id', ['eq'=>$productdata['item_id']]);

                        if (count($rowData)) {
                            $model = $this->_soldproductoldFactory->create()->load($rowData->getFirstItem()->getId());
                            $present++;
                        } else {
                            $model = $this->_soldproductoldFactory->create();
                            $added++;
                        }
                        
                        $model->setData('item_id', $productdata['item_id']);
                        $model->setData('order_id', $productdata['order_id']);
                        $model->setData('increment_id', $productdata['increment_id']);
                        $model->setData('status', $productdata['status']);
                        $model->setData('order_date', $productdata['order_date']);
                        $model->setData('customer_id', $productdata['customer_id']);
                        $model->setData('customer_email', $productdata['customer_email']);
                        $model->setData('billing_country', $productdata['billing_country']);
                        $model->setData('billing_state', $productdata['billing_state']);
                        $model->setData('billing_city', $productdata['billing_city']);
                        $model->setData('billing_country_id', $productdata['billing_country_id']);
                        $model->setData('shipping_country', $productdata['shipping_country']);
                        $model->setData('shipping_state', $productdata['shipping_state']);
                        $model->setData('shipping_city', $productdata['shipping_city']);
                        $model->setData('shipping_country_id', $productdata['shipping_country_id']);
                        $model->setData('remote_ip', $productdata['remote_ip']);
                        $model->setData('ip_country', $productdata['ip_country']);
                        $model->setData('ip_state', $productdata['ip_state']);
                        $model->setData('ip_city', $productdata['ip_city']);
                        $model->setData('ip_country_id', $productdata['ip_country_id']);
                        $model->setData('product_id', $productdata['product_id']);
                        $model->setData('sku', $productdata['sku']);
                        $model->setData('be_code', $productdata['be_code']);
                        $model->setData('qty_ordered', $productdata['qty_ordered']);
                        $model->setData('base_price', $productdata['base_price']);
                        $model->setData('sold_age', $productdata['sold_age']);
                        $model->setData('name', $productdata['name']);
                        $model->setData('article_type', $productdata['article_type']);
                        $model->setData('counter', $productdata['counter']);
                        $model->setData('product_created_at', $productdata['product_created_at']);
                        $model->setData('product_url', $productdata['product_url']);
                        $model->setData('border', $productdata['border']);
                        $model->setData('border_type', $productdata['border_type']);
                        $model->setData('zari_type', $productdata['zari_type']);
                        $model->setData('blouse', $productdata['blouse']);
                        $model->setData('fabric_purity', $productdata['fabric_purity']);
                        $model->setData('occasion', $productdata['occasion']);
                        $model->setData('ornamentation_type', $productdata['ornamentation_type']);
                        $model->setData('color', $productdata['color']);
                        $model->setData('multicolor', $productdata['multicolor']);
                        $model->setData('material', $productdata['material']);
                        $model->setData('pattern', $productdata['pattern']);
                        $model->setData('style_of_work', $productdata['style_of_work']);
                        $model->setData('technique', $productdata['technique']);
                        $model->setData('atc_count', $productdata['atc_count']);
                        $model->setData('views', $productdata['views']);
                        $model->setData('impressions', $productdata['impressions']);
                        $model->setData('mctr', $productdata['mctr']);
                        $model->setData('atc_percent', $productdata['atc_percent']);
                        $model->setData('supplier_code', $productdata['supplier_code']);
                        $model->setData('consignment_id', $productdata['consignment_id']);
                        $model->setData('store_code', $productdata['store_code']);
                        $model->setData('base_image', $productdata['base_image']);
                        $model->setData('small_image', $productdata['small_image']);

                        $model->save();
                        
                    }

                    $succmsg = $added ." items added; " .$present ." items updated";
                    $this->messageManager->addSuccess(__($succmsg));
                    
                    $this->_redirect('soldproductold/soldproductold/index');
                    return;
                }
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
                $this->_redirect('soldproductold/soldproductold/add');
            }
        } else {
            $this->messageManager->addError('File not found');
            $this->_redirect('soldproductold/soldproductold/add');
            return;
        }
        $this->_redirect('soldproductold/soldproductold/add');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Soldproductold::save');
    }
}
