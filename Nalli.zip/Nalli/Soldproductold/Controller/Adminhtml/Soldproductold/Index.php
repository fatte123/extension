<?php
/**
 * Controller file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Controller\Adminhtml\Soldproductold;

class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory = false;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Nalli_Soldproductold::soldproductold_manage');
        $resultPage->getConfig()->getTitle()->prepend((__('Items')));
        return $resultPage;
    }
}
