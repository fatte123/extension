<?php
/**
 * Controller file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Soldproductold
 */
 
namespace Nalli\Soldproductold\Controller\Adminhtml\Soldproductold;

use Magento\Framework\Controller\ResultFactory;

class Add extends \Magento\Backend\App\Action
{
    /*
     *$var \Magento\Backend\App\Action\Context $context
     */
    protected $context;
    
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;
    
    /**
     * @var \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
     */
    protected $_soldproductoldFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @parma \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Nalli\Soldproductold\Model\SoldproductoldFactory $soldproductoldFactory
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->_soldproductoldFactory = $soldproductoldFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $rowId = (int) $this->getRequest()->getParam('id');
        $rowData = $this->_soldproductoldFactory->create();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        if ($rowId) {
            $rowData = $this->_soldproductoldFactory->create()->load($rowId);

            if (!$rowData->getId()) {
                $this->messageManager->addError(__('Item no longer exist.'));
                $this->_redirect('soldproductold/soldproductold');
                return;
            }
        }

        $this->coreRegistry->register('row_data', $rowData);
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title = $rowId ? __('Edit Item ') : __('Add Item');
        $resultPage->getConfig()->getTitle()->prepend($title);
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Soldproductold::add');
    }
}
