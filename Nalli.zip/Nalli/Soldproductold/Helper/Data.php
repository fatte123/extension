<?php
/**
 * Helper file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package RetailInsights_PlaceOrder
 */
 
namespace Nalli\Soldproductold\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /*
     *@var \Nalli\Soldproductold\Model\Soldproductold $Soldproductold
     */
    public $Soldproductold;
    
    /*
     *@var \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     */
    public $StoreManagerInterface;
    
    /*
     *@var \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     */
    public $TimezoneInterface;
    
    /*
     *@param \Nalli\Soldproductold\Model\Soldproductold $Soldproductold
     *@param \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     *@param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
     */

    public function __construct(
        \Nalli\Soldproductold\Model\Soldproductold $Soldproductold,
        \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $TimezoneInterface
    ) {
        $this->soldproductold = $Soldproductold;
        $this->storeManagerInterface = $StoreManagerInterface;
        $this->timezoneInterface = $TimezoneInterface;
    }
}
