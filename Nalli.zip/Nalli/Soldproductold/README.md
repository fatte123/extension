## Nalli_Soldproductold
-------------
This module contain Soldout product details with some order information .


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Soldproductold
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
This module contain Soldout product details with some order information .
_________
In forntend there is {base_url}/soldproductold some filter options ans well as pagination option 


## Copyright
---------
Copyright (c) 2021. 18th DigiTech Team. All rights reserved.