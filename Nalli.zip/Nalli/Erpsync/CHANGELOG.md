# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2022-01-03
### Added
- This module contain custom Shipping method.
- Fixed some minor occurrences of deprecated code
- code sniffer changes
- use Magento scope config
- code clean up
- Magento code formatting and commenting issues.
