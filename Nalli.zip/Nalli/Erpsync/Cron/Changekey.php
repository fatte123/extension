<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Cron;

use Magento\Framework\Controller\ResultFactory;

class Changekey
{

    /**
     * @var helper
     */
    protected $helper;

    /**
     * @var logger
     */
    protected $logger;

    /**
     * Data constructor.
     * @param \Nalli\Weeklyreport\Helper\Data $helper
     * @param \Psr\Log\LoggerInterface $logger
     */

    public function __construct(
        \Nalli\Erpsync\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_helper = $helper;
        $this->logger = $logger;
    }
    /**
     * @return string
     */
    public function execute()
    {
        $changecall = $this->_helper->changeEncryptionkey();
        $this->logger->info("changeEncryptionkey function run");
    }
}
