<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Adminhtml\Erporder;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var $context
     */
    protected $context;

    /**
     * @var $context
     */
    protected $request;
    
    /**
     * @var $context
     */
    protected $erporderFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Nalli\Erpsync\Model\ErporderFactory $erporderFactory
     */
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Erpsync\Model\ErporderFactory $erporderFactory
    ) {
        $this->request = $request;
        $this->_erporderFactory = $erporderFactory;
        parent::__construct($context);
    }

    /**
     * Save Data
     * @return string
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('erpsync/erporder/add/');
            return;
        }
        try {
            if (array_key_exists('erporder_id', $data)) {
                $rowData =  $this->_erporderFactory->create()->load($data['erporder_id']);
                date_default_timezone_set("Asia/Calcutta");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData->setData($data);
                $rowData->save();
            } else {
                date_default_timezone_set("Asia/Calcutta");
                $data['created_time'] = date("Y-m-d h:i:sa");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData1 =  $this->_erporderFactory->create();
                $rowData1->setData($data);
                $rowData1->save();
            }
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('erpsync/erporder/index/');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Erpsync::save');
    }
}
