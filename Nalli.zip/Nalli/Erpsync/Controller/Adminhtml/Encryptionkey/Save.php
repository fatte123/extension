<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Adminhtml\Encryptionkey;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var $context
     */
    protected $context;

    /**
     * @var $request
     */
    protected $request;
    
    /**
     * @var $encryptionkeyFactory
     */
    protected $encryptionkeyFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Nalli\Erpsync\Model\ErpdispatchFactory $encryptionkeyFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Erpsync\Model\EncryptionkeyFactory $encryptionkeyFactory
    ) {
        $this->request = $request;
        $this->_encryptionkeyFactory = $encryptionkeyFactory;
        parent::__construct($context);
    }
    /**
     * Save data return page
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('erpsync/encryptionkey/add/');
            return;
        }
        try {
            if (array_key_exists('encryptionkey_id', $data)) {
                $rowData =  $this->_encryptionkeyFactory->create()->load($data['encryptionkey_id']);
                date_default_timezone_set("Asia/Calcutta");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData->setData($data);
                $rowData->save();
            } else {
                date_default_timezone_set("Asia/Calcutta");
                $data['created_time'] = date("Y-m-d h:i:sa");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData1 =  $this->_encryptionkeyFactory->create();
                $rowData1->setData($data);
                $rowData1->save();
            }
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('erpsync/encryptionkey/index/');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Erpsync::save');
    }
}
