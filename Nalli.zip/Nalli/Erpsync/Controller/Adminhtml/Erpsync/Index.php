<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Adminhtml\Erpsync;

class Index extends \Magento\Backend\App\Action
{
    /**
     * @var $context
     */
    protected $context = false;
    
    /**
     * @var $resultPageFactory
     */
    protected $resultPageFactory = false;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Get title
     *
     * @return $resultPage
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Nalli_Erpsync::erpsync_manage');
        $resultPage->getConfig()->getTitle()->prepend((__('Items')));
        return $resultPage;
    }
}
