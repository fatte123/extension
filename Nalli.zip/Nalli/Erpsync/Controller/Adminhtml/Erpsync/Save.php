<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Adminhtml\Erpsync;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var $context
     */
    protected $context;

    /**
     * @var $request
     */
    protected $request;
    
    /**
     * @var $erpsyncFactory
     */
    protected $erpsyncFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Nalli\Erpsync\Model\ErpsyncFactory $erpsyncFactory
    ) {
        $this->request = $request;
        $this->_erpsyncFactory = $erpsyncFactory;
        parent::__construct($context);
    }

    /**
     * Set Data
     * @return Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('erpsync/erpsync/add/');
            return;
        }
        try {
            if (array_key_exists('erpsync_id', $data)) {
                $rowData =  $this->_erpsyncFactory->create()->load($data['erpsync_id']);
                date_default_timezone_set("Asia/Calcutta");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData->setData($data);
                $rowData->save();
            } else {
                date_default_timezone_set("Asia/Calcutta");
                $data['created_time'] = date("Y-m-d h:i:sa");
                $data['update_time'] = date("Y-m-d h:i:sa");
                $rowData1 =  $this->_erpsyncFactory->create();
                $rowData1->setData($data);
                $rowData1->save();
            }
                $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('erpsync/erpsync/index/');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Erpsync::save');
    }
}
