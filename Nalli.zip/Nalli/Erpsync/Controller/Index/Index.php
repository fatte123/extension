<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Nalli\Erpsync\Helper\Data $helper
	)
	{
		$this->_pageFactory = $pageFactory;
		$this->_helper = $helper;
		return parent::__construct($context);
	}

	public function execute()
	{
		$changecall = $this->_helper->changeEncryptionkey();
		return $this->_pageFactory->create();
	}
}