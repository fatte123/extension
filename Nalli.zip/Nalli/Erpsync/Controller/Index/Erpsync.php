<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Erpsync extends \Magento\Framework\App\Action\Action
{

    /**
     * @var $logger
     */
    private $logger;

     /**
      * @var $scopeConfig
      */
    private $scopeConfig;

     /**
      * @var $erporderFactory
      */
    private $erporderFactory;

     /**
      * @var $orderFactory
      */
    private $orderFactory;

     /**
      * @var $erpsyncFactory
      */
    private $erpsyncFactory;

     /**
      * @var $helper
      */
    private $helper;

    /**
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Nalli\Erpsync\Model\Erporder $erporderFactory
     * @param \Magento\Sales\Model\Order $orderFactory
     * @param \Nalli\Erpsync\Model\Erpsync $erpsyncFactory
     * @param \Nalli\Erpsync\Helper\Data $helper
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Nalli\Erpsync\Model\Erporder $erporderFactory,
        \Magento\Sales\Model\Order $orderFactory,
        \Nalli\Erpsync\Model\Erpsync $erpsyncFactory,
        \Nalli\Erpsync\Helper\Data $helper
    ) {
        $this->logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->erporderFactory = $erporderFactory;
        $this->orderFactory = $orderFactory;
        $this->erpsyncFactory = $erpsyncFactory;
        $this->_helper = $helper;
    }

    /**
     * save data
     */
    public function execute()
    {

        $this->logger->debug('ran cron succesfully');
        $erpsync_select = $this->_scopeConfig->getValue('erpsync/general/erpsync_select');

        if ($erpsync_select == 1) {

            $grand_total = $this->_scopeConfig->getValue('erpsync/general/grand_total');
            $item_skus = [];
            $collection = $this->erporderFactory->getCollection()->addFieldToFilter('sync_status', 'no');
            foreach ($collection->getData() as $data) {

                $order = $this->orderFactory->loadByIncrementId($data['order_id']);
                $order_state = $order->getStatus();
                $order_total = $order->getData("base_grand_total");
            
                $this->logger->debug('Order status of order id '.$data['order_id'].' is '.$order_state);

                if (($order_state == 'processing') && ($order_total <= $grand_total)) {

                    foreach ($order->getAllItems() as $item) {
                        if (substr($item->getSku(), 0, 2) != "GV") {
                            continue;
                        } else {
                            array_push($item_skus, $item->getSku());
                            $this->logger->debug('Order has GV product');
                        }
                    }
                    if (empty($item_skus)) {
                        $status = $id = "";
                        $order_id = $order->getIncrementId();
                        $syncollection = $this->erpsyncFactory
                                        ->getCollection()
                                        ->addFieldToFilter('order_id', $order_id)->getLastItem();
                        if ($syncollection->getData()) {
                            // $id = $syncollection['id'];
                            $id = $syncollection['erpsync_id'];
                            $status = $syncollection['flag'];
                            $model = $syncollection->load($id);
                            if (($status == 0) || ($status == null)) {
                                $callapi = $this->_helper->callerp($order_id);
                                if ($callapi['response_data']) {
                                    try {
                                        $model->setRequestData($callapi['request_data'])->save();
                                        $model->setResponseData($callapi['response_data'])->save();
                                        $model->setInvoiceId($callapi['invoice_id'])->save();
                                        $model->setFlag(1)->save();
                                    } catch (Exception $e) {
                                        $this->logger->debug('sql error is'.$e->getMessage());
                                    }
                                      $decode_data = json_decode($callapi['response_data']);
                                      $response_code = $decode_data->code;
                                      $erpordermodel = $this->erporderFactory->load($data['erporder_id']);
                                    if ($response_code == 200) {
                                        $erpordermodel->setResponseStatus('success');
                                    } else {
                                        $erpordermodel->setResponseStatus('failure');
                                    }
                                      $erpordermodel->setSyncStatus('yes');
                                      $erpordermodel->setSyncDate(date("Y-m-d H:i:s"));
                                      $erpordermodel->setUpdatedDate(date("Y-m-d H:i:s"));
                                      $erpordermodel->setInvoiceId($callapi['invoice_id']);
                                      $erpordermodel->save();
                                }
                            }
                        } else {
                            $this->logger->debug('Erp function is calling with order id');
                            $callapi = $this->_helper->callerp($order_id);
                            if (isset($callapi['response_data'])) {
                                $model = $this->erpsyncFactory;
                                $decode_respo = json_decode($callapi['response_data'], true);
                                if ($decode_respo['code'] == 422) {
                                    $this->logger->debug('Erp error- Data already exists');
                                } else {
                                    if (isset($callapi['invoice_id'])) {
                                        $invoice_id = $callapi['invoice_id'];
                                    } else {
                                        $invoice_id = "";
                                    }
                                    $dataset = [
                                      'order_id' => $order_id,
                                      'invoice_id' =>$invoice_id,
                                      'flag' => 1,
                                      "request_data" => $callapi['request_data'],
                                      "response_data" => $callapi['response_data'],
                                    ];
                                    try {
                                        $model->setData($dataset)->save();
                                    } catch (Exception $e) {
                                        $this->logger->debug('sql error is'.$e->getMessage());
                                    }
                                }
                                $decode_data = json_decode($callapi['response_data']);
                                $response_code = $decode_data->code;
                                $this->logger->debug('response code is'.$response_code);
                                $erpordermodel = $this->erporderFactory->load($data['erporder_id']);
                                if ($response_code == 200) {
                                    $erpordermodel->setResponseStatus('success');
                                } else {
                                    $erpordermodel->setResponseStatus('failure');
                                }
                                $erpordermodel->setSyncStatus('yes');
                                $erpordermodel->setSyncDate(date("Y-m-d H:i:s"));
                                $erpordermodel->setUpdatedDate(date("Y-m-d H:i:s"));
                                if (isset($callapi['invoice_id']) && $callapi['invoice_id']!="") {
                                    $erpordermodel->setInvoiceId($callapi['invoice_id']);
                                }
                                
                                $erpordermodel->save();
                            } else {
                                $model = $this->erpsyncFactory;
                                
                                $eshop_respo = $callapi[0]['Eshop_response'];
                                $store_respo = $callapi[0]['store_response'];
                                
                                $eshop_decode_respo = json_decode($eshop_respo['response_data'], true);
                                $store_decode_respo = json_decode($store_respo['response_data'], true);
                                
                                if ($eshop_decode_respo['code'] == 422 && $store_decode_respo['code'] == 422) {
                                    $this->logger->debug('Erp error- Data already exists');
                                } else {
                                    if (isset($eshop_decode_respo['invoice_id'])) {
                                        $eshop_invoice_id = $eshop_decode_respo['invoice_id'];
                                    } else {
                                        $eshop_invoice_id = "";
                                    }
                                    if (isset($store_decode_respo['invoice_id'])) {
                                        $store_invoice_id = $store_decode_respo['invoice_id'];
                                    } else {
                                        $store_invoice_id = "";
                                    }
                                    $eshop_dataset = [
                                    'order_id' => $order_id,
                                    'invoice_id' =>$eshop_invoice_id,
                                    'flag' => 1,
                                    "request_data" => $eshop_respo['request_data'],
                                    "response_data" => $eshop_respo['response_data'],
                                    ];
                                    try {
                                        $model->setData($eshop_dataset)->save();
                                    } catch (Exception $e) {
                                        $this->logger->debug('sql error is'.$e->getMessage());
                                    }
                                    $store_dataset = [
                                    'order_id' => $order_id,
                                    'invoice_id' =>$store_invoice_id,
                                    'flag' => 1,
                                    "request_data" => $store_respo['request_data'],
                                    "response_data" => $store_respo['response_data'],
                                    ];
                                    try {
                                        $model->setData($store_dataset)->save();
                                    } catch (Exception $e) {
                                        $this->logger->debug('sql error is'.$e->getMessage());
                                    }
                                }
                                
                                $eshop_decode_data = json_decode($eshop_respo['response_data']);
                                $store_decode_data = json_decode($store_respo['response_data']);
                                $eshop_response_code = $eshop_decode_data->code;
                                $store_response_code = $store_decode_data->code;
                                $this->logger->debug(
                                    'Eshop response code is'.$eshop_response_code.
                                        'Store response code is'.$store_response_code
                                );
                                $erpordermodel = $this->erporderFactory->load($data['erporder_id']);
                                if ($eshop_response_code == 200 && $store_response_code == 200) {
                                    $erpordermodel->setResponseStatus('success');
                                } elseif ($eshop_response_code == 200 && $store_response_code != 200) {
                                    $erpordermodel->setResponseStatus('Eshop - success, Store - failure');
                                } elseif ($eshop_response_code != 200 && $store_response_code == 200) {
                                    $erpordermodel->setResponseStatus('Eshop - failure, Store - success');
                                } else {
                                    $erpordermodel->setResponseStatus('failure');
                                }
                                
                                $erpordermodel->setSyncStatus('yes');
                                $erpordermodel->setSyncDate(date("Y-m-d H:i:s"));
                                $erpordermodel->setUpdatedDate(date("Y-m-d H:i:s"));
                                if (isset($eshop_respo['invoice_id']) && isset($store_respo['invoice_id'])) {
                                    $full_invoice_id = 'Eshop - '.$eshop_respo['invoice_id'].', 
                                    Store - '.$eshop_respo['invoice_id'];
                                    $erpordermodel->setInvoiceId($full_invoice_id);
                                }
                                
                                $erpordermodel->save();
                            }
                        }
                    } else {
                        $this->logger->debug('GV product order sending');
                        $status = $id = "";
                        $order_id = $order->getIncrementId();
                        $syncollection = $this->erpsyncFactory
                                      ->getCollection()
                                      ->addFieldToFilter('order_id', $order_id)->getLastItem();
                        if ($syncollection->getData()) {
                            $this->logger->debug('GV product order syncollection data received');
                            $id = $syncollection['id'];
                            $status = $syncollection['flag'];
                            $model = $this->erpsyncFactory->load($id);
                            if (($status == 0) || ($status == null)) {
                                $callapi = $this->_helper->callErpNF($order_id);
                               
                                try {
                                    $model->setRequestData($callapi['request_data'])->save();
                                    $model->setResponseData($callapi['response_data'])->save();
                                    $model->setInvoiceId($callapi['invoice_id'])->save();
                                    $model->setFlag(1)->save();
                                } catch (Exception $e) {
                                    $this->logger->debug('sql error is'.$e->getMessage());
                                }
                                        $decode_data = json_decode($callapi['response_data']);
                                        $response_code = $decode_data->code;
                                        $erpordermodel = $this->erporderFactory->load($data['erporder_id']);
                                if ($response_code == 200) {
                                    $erpordermodel->setResponseStatus('success');
                                } else {
                                    $erpordermodel->setResponseStatus('failure');
                                }
                                        $erpordermodel->setSyncStatus('yes');
                                        $erpordermodel->setSyncDate(date("Y-m-d H:i:s"));
                                        $erpordermodel->setUpdatedDate(date("Y-m-d H:i:s"));
                                        $erpordermodel->setInvoiceId($callapi['invoice_id']);
                                        $erpordermodel->save();
                                    
                            }
                        } else {
                            $this->logger->debug('Erp function is calling with order id');
                            $callapi = $this->_helper->callErpNF($order_id);
                            if ($callapi['response_data']) {
                                $model = $this->erpsyncFactory;
                                $decode_respo = json_decode($callapi['response_data'], true);
                                if ($decode_respo['code'] == 422) {
                                    $this->logger->debug('Erp error- Data already exists');
                                } else {
                                    if (isset($callapi['invoice_id'])) {
                                        $invoice_id = $callapi['invoice_id'];
                                    } else {
                                        $invoice_id = "";
                                    }
                                    $dataset = [
                                      'order_id' => $order_id,
                                      'invoice_id' =>$invoice_id,
                                      'flag' => 1,
                                      "request_data" => $callapi['request_data'],
                                      "response_data" => $callapi['response_data'],
                                    ];
                                    try {
                                        $model->setData($dataset)->save();
                                    } catch (Exception $e) {
                                        $this->logger->debug('sql error is'.$e->getMessage());
                                    }
                                }
                                $decode_data = json_decode($callapi['response_data']);
                                $response_code = $decode_data->code;
                                $this->logger->debug('response code is'.$response_code);
                                $erpordermodel = $this->erporderFactory->load($data['erporder_id']);
                                if ($response_code == 200) {
                                    $erpordermodel->setResponseStatus('success');
                                } else {
                                    $erpordermodel->setResponseStatus('failure');
                                }
                                $erpordermodel->setSyncStatus('yes');
                                $erpordermodel->setSyncDate(date("Y-m-d H:i:s"));
                                $erpordermodel->setUpdatedDate(date("Y-m-d H:i:s"));
                                if (isset($callapi['invoice_id']) && $callapi['invoice_id']!="") {
                                    $erpordermodel->setInvoiceId($callapi['invoice_id']);
                                }
                                
                                $erpordermodel->save();
                            }
                        }
                    }
                }
            }
        }
    }
}
