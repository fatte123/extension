<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Testerp extends \Magento\Framework\App\Action\Action
{

      protected $helper;
      

    public function __construct(
		\Magento\Framework\App\Action\Context $context,
        \Nalli\Erpsync\Helper\Datam $helper
    ) {
        $this->_helper = $helper;
        return parent::__construct($context);
    }

    public function execute()
    {
			//echo 'fggdgfd'; exit;
				$param = $this->getRequest()->getParams();
				//print_r($param['order_id']); exit;             
				$order_id = $param['order_id'];            
				$callapi = $this->_helper->callerp($order_id);

    }
}
