<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Directory\Model\RegionFactory;

class Data extends AbstractHelper
{
    /**
     * @var $regionFactory
     */
    protected $regionFactory;

    /**
     * @var $logger
     */
    protected $logger;
    /**
     * @var $orderFactory
     */
    protected $orderFactory;
    /**
     * @var $scopeConfig
     */
    protected $scopeConfig;
    /**
     * @var $productloader
     */
    protected $productloader;
    /**
     * @var $encryptionkeyFactory
     */
    protected $encryptionkeyFactory;
    /**
     * @var $transactionsFactory
     */
    protected $transactionsFactory;
    
    /**
     * Data constructor.
     * @param RegionFactory $regionFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Sales\Model\Order $orderFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\Product $productloader
     * @param \Nalli\Erpsync\Model\Encryptionkey $encryptionkeyFactory
     * @param \Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory $transactionsFactory
     */

    public function __construct(
        RegionFactory $regionFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Sales\Model\Order $orderFactory,
        \Magento\Catalog\Model\Product $productloader,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Nalli\Erpsync\Model\Encryptionkey $encryptionkeyFactory,
        \Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory $transactionsFactory,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Nalli\Erpsync\Logger\Logger $loggerErp
    ) {
        $this->regionFactory = $regionFactory;
        $this->logger = $logger;
        $this->orderFactory = $orderFactory;
        $this->productloader = $productloader;
        $this->_scopeConfig = $scopeConfig;
        $this->encryptionkeyFactory = $encryptionkeyFactory;
        $this->transactionsFactory = $transactionsFactory;
        $this->resourceConnection = $resourceConnection;
        $this->loggerErp = $loggerErp;
    }

    /**
     * Retrieve config data
     *
     * @param $config_path
     * @return string
     */

    public function getConfig($config_path)
    {
          return $this->scopeConfig->getValue(
              $config_path,
              \Magento\Store\Model\ScopeInterface::SCOPE_STORE
          );
    }

    /**
     * Retrieve config data
     *
     * @param $OrderNumber
     * @return array
     */
    public function callErp($OrderNumber)
    {
        $this->logger->debug('ERP called with order number '.$OrderNumber);
        $order = $this->orderFactory->loadByIncrementId($OrderNumber);
        $shipping_address = $order->getShippingAddress()->getData();
        $regionId = $order->getShippingAddress()->getData('region_id');
        
        $this->logger->debug("debuglog", $shipping_address);
        
        $billing_address = $order->getBillingAddress()->getData();
        
        $this->logger->debug('SHIPPING sate code is'.$order->getShippingAddress()->getData('region_id'));
        
        $region = $this->regionFactory->create()->load($regionId);
        $regioncode = $region->getCode();
        $this->logger->debug("region code: ".$region->getCode());

        $eshopitems=[];
        $storeitems=[];
        $fall_pico_charges =0;
        $juspay_txn_id = '';
		$totalQty = 0;		
        foreach ($order->getAllVisibleItems() as $item) {
			$price_diff = 0;
			$productprice = 0.0000;
            $product = $this->productloader;
            $productId = $product->getIdBySku($item->getSku());
            $price_diff = $item->getBasePrice()-$item->getBaseOriginalPrice();
            $productprice = $item->getBaseOriginalPrice();
            $productprice = number_format( (float) $productprice, 4, '.', '');
            $fall_pico_charges = $fall_pico_charges+($price_diff*$item->getQtyOrdered());
            $options = $item->getProductOptions();
            
            if (substr($item->getSku(), 0, 2) === "ES") {
                if ($productId) {
                    $product->load($productId);
					$categoryName = strtolower($product->getCategoryName());
					$isQtyDecimal = 0;
					if ($product->getExtensionAttributes()->getStockItem()) {
						$isQtyDecimal = $product->getExtensionAttributes()->getStockItem()->getIsQtyDecimal();
					}					
					$matType = '';
					$matQty = 0;
					$perMtrCost = 0;
					$productSize = '';
					$qty = number_format($item->getQtyOrdered(),1);
					if(($isQtyDecimal) == 1 && ($categoryName == "fabric")) { 
						$matType = 'RM';
						$matQty = number_format($item->getQtyOrdered(),1);
						$perMtrCost= $item->getBaseOriginalPrice();
						$productprice = $item->getBaseRowTotalInclTax()-$price_diff;
						$productprice = number_format( (float) $productprice, 4, '.', '');
						$qty = 1;
					}                    
					if('configurable'==$item->getProductType()){
						$productSize = $product->getAttributeText('size');
						$matType = 'R';
					}
                    $eshopitems[] = [
                        'ESCODE'        => $item->getSku(),
						'PRODUCTPRICE'  => $productprice,
						'QTY'           => (int)$qty,
						'PRODUCTDESC'   => $product->getData('article_type'),
						"COLOR"         => $product->getAttributeText('color'),
						"PRODUCTSIZE"   => $productSize,
						"FALL_PICO"     => $price_diff,
						"ITM_PACKINGCOST" => "0.0000",
						"ITM_SHIPPINGCOST" => "0.0000",
						"MAT_TYPE"=> $matType,
						"MTR"=> $matQty,
						"PER_MTR_COST"=> $perMtrCost
                    ];
                    $totalQty = $totalQty + $qty;
                }
                $this->logger->debug('Eshop items added');
            } else {
                if ($productId) {
                    $product->load($productId);
					$categoryName = strtolower($product->getCategoryName());
					$isQtyDecimal = $product->getExtensionAttributes()->getStockItem()->getIsQtyDecimal();
					$matType = '';
					$matQty = 0;
					$perMtrCost = 0;
					$productSize = '';
					$qty = number_format($item->getQtyOrdered(),1);
					if(($isQtyDecimal) == 1 && ($categoryName == "fabric")) { 
						$matType = 'RM';
						$matQty = number_format($item->getQtyOrdered(),1);
						$perMtrCost= $item->getBaseOriginalPrice();
						$productprice = $item->getBaseRowTotalInclTax()-$price_diff;
						$productprice = number_format( (float) $productprice, 4, '.', '');
						$qty = 1;
					}
					if('configurable'==$item->getProductType()){
						$productSize = $product->getAttributeText('size');
						$matType = 'R';
					}                    
                    $price_diff = $item->getBasePrice()-$item->getBaseOriginalPrice();
                    $fall_pico_charges = $fall_pico_charges+($price_diff*$item->getQtyOrdered());
                    $options = $item->getProductOptions();
                    $storeitems[] = [
                       'ESCODE'        => $item->getSku(),
						'PRODUCTPRICE'  => $productprice,
						'QTY'           => (int)$qty,
						'PRODUCTDESC'   => $product->getData('article_type'),
						"COLOR"         => $product->getAttributeText('color'),
						"BRANCH_CODE"   => $product->getData('physical_store_code'),
						"PRODUCTSIZE"   => $productSize,
						"FALL_PICO"     => $price_diff,
						"ITM_PACKINGCOST" => "0.0000",
						"ITM_SHIPPINGCOST" => "0.0000",
						"MAT_TYPE"=> $matType,
						"MTR"=> $matQty,
						"PER_MTR_COST"=> $perMtrCost   
                    ];
                    $totalQty = $totalQty + $qty;
                }
            }
        }
		$order_transaction = $this->getTransactionRecord($order->getId());
		$orderpaymentid = '';
		if (isset($order_transaction['txn_id']) && $order_transaction['txn_id']!='' ) {
			$orderpaymentid = $order_transaction['txn_id'];
		}
		$paymentTranData = $order->getPayment()->getData();
		if(isset($paymentTranData['last_trans_id']) && $paymentTranData['last_trans_id']!=''){
			$orderpaymentid = $paymentTranData['last_trans_id'];
		}
		$paymentMode = $order->getPayment()->getMethodInstance()->getCode();
		if($orderpaymentid == '' && $paymentMode=='adminrazorpay'){
			$orderComment = '';
			foreach ($order->getStatusHistoryCollection(true) as $_item){
				$orderComment = $_item->getComment();
				
			}
			$orderpaymentid = $orderComment;
		
		}
        if($paymentMode =='juspay'){
			$orderComment = '';
             $juspay_txn_id = $orderpaymentid;
			foreach ($order->getStatusHistoryCollection(true) as $_item){
                if (str_contains($_item->getComment(), 'epg_txn_id') && str_contains($_item->getComment(), 'Gateway Response')) {
                    $jsonString = trim(str_replace("Gateway Response :",'',$_item->getComment()),": ");
                    $jsonString = str_replace("{",'',$jsonString);
                    $jsonString = str_replace("}",'',$jsonString);
                    $jsonString = str_replace('":"',':',$jsonString);
                    $commentArray = explode('"', $jsonString);
                    foreach($commentArray as $value){
                        if(str_contains($value, 'epg_txn_id')){
                             $orderpaymentid =  substr($value, strpos($value, ":") + 1);
                        }
                    }    
                }		
			}
		
		}   
        if (!empty($eshopitems)) {
            $eshopitems[0]["ITM_PACKINGCOST"] = $order->getData("base_fee");
            $eshopitems[0]["ITM_SHIPPINGCOST"] = $order->getData("base_shipping_incl_tax");
        } else {
            $storeitems[0]["ITM_PACKINGCOST"] = $order->getData("base_fee");
            $storeitems[0]["ITM_SHIPPINGCOST"] = $order->getData("base_shipping_incl_tax");
        }

        if ($shipping_address['country_id'] == "IN") {
            if (trim(strtolower($shipping_address['region'])) == "karnataka") {
                $ordertype = "LOCAL";
            } else {
                $ordertype = "INTERSTATE";
            }
        } else {
            $ordertype = "EXPORT";
        }
        
        if (!empty($eshopitems)) {
            $data = [];
			$roundOffGrandTotal = floor($order->getData("base_grand_total"));
			$roundOffValue = ($order->getData("base_original_grand_total"))-($roundOffGrandTotal);
			$roundOffValue = $roundOffValue>0?$roundOffValue:0;            
            $data["ORDERID"] = $order->getIncrementId();
			$data["ORDERDATE"] = $order->getData("created_at");
			$data["SUBTOTAL"] = $order->getData("base_subtotal")-$fall_pico_charges;
			$data["PACKINGCHARGES"] = $order->getData("base_fee");
			$data["SHIPPINGCHARDES"] = $order->getData("base_shipping_incl_tax");
			$data["GRANDTOTAL"] = (int)$roundOffGrandTotal;
			$data["TOTALQTY"] = (int)$totalQty;
			$order_currency_code = $order->getData("order_currency_code");
			if('INR'!=$order_currency_code){
				$roundOffValue = 0;
			}
			$data["ROUNDOFF"] = $roundOffValue;
			$data["PAYMENTMODE"] = $order->getPayment()->getMethodInstance()->getCode();
			$data["BANKTRANID"] = $orderpaymentid;
            $data["JUSPAYTXNID"] = $juspay_txn_id;
			// check this
			$data["ORDERTYPE"] = $ordertype;
			$data["SHIPPINGNAME"] = $shipping_address['firstname']." " .$shipping_address['lastname'];
			$data["SHIPPINGADD1"] = $shipping_address['street'];
			$data["SHIPPINGADD2"] = "";
			$data["SHIPPINGCITY"] = $shipping_address['city'];
			$data["SHIPPINGSTATE"] = $shipping_address['region'];
			$data["SHIPPINGPINCODE"] = $shipping_address['postcode'];
			$data["SHIPPINGMOBILENO"] = $shipping_address['telephone'];
			$data["SHIPPINGCOUNTRY"] = $shipping_address['country_id'];
			$data["ORDERMAILID"] = $order->getData('customer_email');
			$data["BILLINGNAME"] = $billing_address['firstname'].$billing_address['lastname'];
			$data["BILLINGADD1"] = $billing_address['street'];
			$data["BILLINGADD2"] = "";
			$data["BILLINGCITY"] = $billing_address['city'];
			$data["BILLINGSTATE"] = $billing_address['region'];
			$data["BILLINGPINCODE"] = $billing_address['postcode'];
			$data["BILLINGMOBILENO"] = $billing_address['telephone'];
			$data["BILLINGCOUNTRY"] = $billing_address['country_id'];
			$data["PRODUCTDETAILS"] = $eshopitems;
            $row = json_encode($data); //exit;
			$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
			$logger = new \Zend_Log();
			$logger->addWriter($writer);		
			$logger->info('UpdateMemberProfile'.$row);	
			
			//echo 'done00'; exit;        
            $this->logger->debug($row);

            /* Encrypting the data */
            $model = $this->encryptionkeyFactory;
            $data = $model->getCollection()->getLastItem()->getData();

            $encryption_key = $data['enc_key'];
            $encryption_iv = $data['enc_iv'];

            $key_pwd = substr(hash('sha256', $encryption_key, true), 0, 32);
            $cipher_method = 'aes-256-cbc';
            $crypted_token = base64_encode(openssl_encrypt(
                "[".$row."]",
                $cipher_method,
                $key_pwd,
                OPENSSL_RAW_DATA,
                $encryption_iv
            ));
            
            $this->logger->debug($crypted_token);
			$logger->info('crypted_token'.$crypted_token);				;
			
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, '"'.$crypted_token.'"');

            $storeConfig = $this->_scopeConfig;
            $url = $storeConfig->getValue('erpsync/general/sync_api_url');

            $server_key = $storeConfig->getValue('erpsync/general/server_key');

            curl_setopt($curl, CURLOPT_URL, $url);
               curl_setopt($curl, CURLOPT_HTTPHEADER, [
                  'apikey:' . $server_key,
                  'Content-Type: application/json',
               ]);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            
            $this->logger->debug('Eshop Encrypted data generated');
            
            $response = curl_exec($curl);
            
            $this->logger->debug('Eshop curl excuted');
            
            $respo = "[".$response."]";
            $resp = json_decode($respo);
            $this->logger->debug("resp:", $resp);
            if ($resp[0]->code == "200") {
                $resp1 = explode(",", $resp[0]->description);
                if (isset($resp1[1]) && strpos($resp1[1], ":") !== false) {
                    $resp2 = explode(":", $resp1[1]);
                    $resp_arr['invoice_id'] = trim($resp2[1], '"');
                } else {
                    $resp_arr['invoice_id'] = "";
                }
            }
            $err = curl_error($curl);
            curl_close($curl);
            $resp_arr['request_data'] = $row;
            $resp_arr['response_data'] = $response;
            $resp_arr['error_data'] = $err;
            
            $this->logger->debug("response:", $resp_arr);

            if (!empty($storeitems)) {
                $eshopresp_arr = $resp_arr;
            } else {
                return $resp_arr;
            }
        }
            
        if (!empty($storeitems)) {
            $storedata = [];
			$roundOffGrandTotal = floor($order->getData("base_grand_total"));
			$roundOffValue = ($order->getData("base_original_grand_total"))-($roundOffGrandTotal);
			$roundOffValue = $roundOffValue>0?$roundOffValue:0;            
            $storedata["ORDERID"] = $order->getIncrementId();
			$storedata["ORDERDATE"] = $order->getData("created_at");
			$storedata["SUBTOTAL"] = $order->getData("base_subtotal")-$fall_pico_charges;
			$storedata["PACKINGCHARGES"] = $order->getData("base_fee");
			$storedata["SHIPPINGCHARDES"] = $order->getData("base_shipping_incl_tax");
			$storedata["GRANDTOTAL"] = (int)$roundOffGrandTotal;
			$storedata["TOTALQTY"] = (int)$totalQty;
			$order_currency_code = $order->getData("order_currency_code");
			if('INR'!=$order_currency_code){
				$roundOffValue = 0;
			}
			$storedata["ROUNDOFF"] = $roundOffValue;
			$storedata["PAYMENTMODE"] = $order->getPayment()->getMethodInstance()->getCode();
			$storedata["BANKTRANID"] = $orderpaymentid;
            $storedata["JUSPAYTXNID"] = $juspay_txn_id;
			// check this
			$storedata["ORDERTYPE"] = $ordertype;
			$storedata["SHIPPINGNAME"] = $shipping_address['firstname']." " .$shipping_address['lastname'];
			$storedata["SHIPPINGADD1"] = $shipping_address['street'];
			$storedata["SHIPPINGADD2"] = "";
			$storedata["SHIPPINGCITY"] = $shipping_address['city'];
			$storedata["SHIPPINGSTATE"] = $shipping_address['region'];
			$storedata["DL_STATECODE"] = $regioncode;
			$storedata["SHIPPINGPINCODE"] = $shipping_address['postcode'];
			$storedata["SHIPPINGMOBILENO"] = $shipping_address['telephone'];
			$storedata["SHIPPINGCOUNTRY"] = $shipping_address['country_id'];
			$storedata["ORDERMAILID"] = $order->getData('customer_email');
			$storedata["BILLINGNAME"] = $billing_address['firstname'].$billing_address['lastname'];
			$storedata["BILLINGADD1"] = $billing_address['street'];
			$storedata["BILLINGADD2"] = "";
			$storedata["BILLINGCITY"] = $billing_address['city'];
			$storedata["BILLINGSTATE"] = $billing_address['region'];
			$storedata["BILLINGPINCODE"] = $billing_address['postcode'];
			$storedata["BILLINGMOBILENO"] = $billing_address['telephone'];
			$storedata["BILLINGCOUNTRY"] = $billing_address['country_id'];
			$storedata["PRODUCTDETAILS"] = $storeitems;
            $storerow = json_encode($storedata);
			$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
			$logger = new \Zend_Log();
			$logger->addWriter($writer);		
			$logger->info('UpdateMemberProfile->'.$storerow);	

			        
            $this->logger->debug($storerow);

             /* Encrypting the data */
            $model = $this->encryptionkeyFactory;
            $storedata = $model->getCollection()->getLastItem()->getData();

            $encryption_key = $storedata['enc_key'];
            $encryption_iv = $storedata['enc_iv'];

            $key_pwd = substr(hash('sha256', $encryption_key, true), 0, 32);
            $cipher_method = 'aes-256-cbc';
            $crypted_token = base64_encode(openssl_encrypt(
                "[".$storerow."]",
                $cipher_method,
                $key_pwd,
                OPENSSL_RAW_DATA,
                $encryption_iv
            ));
            $logger->info('UpdateMemberProfile->'.$crypted_token);
            $this->logger->debug($crypted_token);

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, '"'.$crypted_token.'"');

            $storeConfig = $this->_scopeConfig;
            $storeurl = $storeConfig->getValue('erpsync/physical/store_sync_api_url');
            
            $this->logger->debug('Store API url '.$storeurl);

            $storeserver_key = $storeConfig->getValue('erpsync/physical/store_server_key');
            $this->logger->debug('Store API server_key :'.$storeserver_key);

            curl_setopt($curl, CURLOPT_URL, $storeurl);
               curl_setopt($curl, CURLOPT_HTTPHEADER, [
                  'apikey:' . $storeserver_key,
                  'Content-Type: application/json',
               ]);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            
            $this->logger->debug('Store Encrypted data generated');

            $storeresponse = curl_exec($curl);
            
            $this->logger->debug('Store curl generated');
            
            $storerespo = "[".$storeresponse."]";
            $this->logger->debug($storerespo);
            $storeresp = json_decode($storerespo);
            $this->logger->debug("store response:", $storeresp);
            if ($storeresp[0]->code == "200") {
                $storeresp1 = explode(",", $storeresp[0]->description);
            /*    if(strpos($storeresp1[1], ":") !== false){
                    $storeresp2 = explode(":",$storeresp1[1]);
                    $storeresp_arr['invoice_id'] = trim($storeresp2[1], '"');
                }else{
                    $storeresp_arr['invoice_id'] = "";
                }    */
                $storeresp_arr['invoice_id'] = "";
            }
            $storeerr = curl_error($curl);
            curl_close($curl);
            $storeresp_arr['request_data'] = $storerow;
            $storeresp_arr['response_data'] = $storeresponse;
            $storeresp_arr['error_data'] = $storeerr;
            
            $this->logger->debug("", $storeresp_arr);

            if (!empty($eshopitems)) {
                
                $combain_response[] = [
                'Eshop_response' => $eshopresp_arr,
                'store_response' => $storeresp_arr
                ];
                $this->logger->debug("", $combain_response);
                return $combain_response;
            } else {
                return $storeresp_arr;
            }
            
        }
    }

    /**
     * Retrieve config data
     *
     * @param $OrderNumber
     * @return array
     */
    public function callErpNF($OrderNumber)
    {
        $this->logger->debug('ERP called order with GV product with order number '.$OrderNumber);
        $this->logger->info('This callErpNF function called'.$OrderNumber);
        $order = $this->orderFactory->loadByIncrementId($OrderNumber);
        $shipping_address = $order->getShippingAddress()->getData();
        $regionId = $order->getShippingAddress()->getData('region_id');
        
        $this->logger->debug("", $shipping_address);
        
        $billing_address = $order->getBillingAddress()->getData();
        
        $this->logger->debug('SHIPPING sate code is'.$order->getShippingAddress()->getData('region_id'));
        
        $region = $this->regionFactory->create()->load($regionId);
        $regioncode = $region->getCode();
        $this->logger->debug($region->getCode());

        $eshopitems=[];
        $storeitems=[];
        $fall_pico_charges =0;
        $juspay_txn_id = '';
        $totalQty = 0;
        foreach ($order->getAllVisibleItems() as $item) {
            $product = $this->productloader;
			$categoryName = strtolower($product->getCategoryName());
			$isQtyDecimal = 0;
			if ($product->getExtensionAttributes()->getStockItem()) {
				$isQtyDecimal = $product->getExtensionAttributes()->getStockItem()->getIsQtyDecimal();
			}
			$matType = '';
			$matQty = 0;
			$perMtrCost = 0;
			$productSize = '';
			$qty = number_format($item->getQtyOrdered(),1);
			$productprice = $item->getBaseOriginalPrice();
			if(($isQtyDecimal) == 1 && ($categoryName== "fabric")) { 
				$matType = 'RM';
				$matQty = number_format($item->getQtyOrdered(),1);
				$perMtrCost= $item->getBaseOriginalPrice();
				$productprice = $item->getBaseRowTotalInclTax();
				$productprice = number_format( (float) $productprice, 4, '.', '');
				$qty = 1;
			}
			if('configurable'==$item->getProductType()){
				$productSize = $product->getAttributeText('size');
				$matType = 'R';
			}
					             
            $productId = $product->getIdBySku($item->getSku());
            if (substr($item->getSku(), 0, 2) != "GV") {
                if (substr($item->getSku(), 0, 2) === "ES") {
                    if ($productId) {
                        $product->load($productId);					
						$qty = (int)$item->getQtyOrdered();
						$price_diff = ($item->getBasePrice()-$item->getBaseOriginalPrice())*($qty);
						$fall_pico_charges = $fall_pico_charges + ($price_diff*$item->getQtyOrdered());
						$options = $item->getProductOptions();
						
                        $eshopitems[] = [
							'ESCODE'        => $item->getSku(),
							'PRODUCTPRICE'  => $productprice,
							'QTY'           => (int)$item->getQtyOrdered(),
							'PRODUCTDESC'   => $product->getData('article_type'),
							"COLOR"         => $product->getAttributeText('color'),
							"PRODUCTSIZE"   => $productSize,
							"FALL_PICO"     => $price_diff,
							"ITM_PACKINGCOST" => "0.0000",
							"ITM_SHIPPINGCOST" => "0.0000",
							"MAT_TYPE"=> $matType,
							"MTR"=> $matQty,
							"PER_MTR_COST"=> $perMtrCost
                        ];
                    }
                    $this->logger->debug('Eshop items added');
                } else {
                    if ($productId) {
                        $product->load($productId);
						$qty = (int)$item->getQtyOrdered();
                        $price_diff = ($item->getBasePrice()-$item->getBaseOriginalPrice())*($qty);
						$fall_pico_charges = $fall_pico_charges+($price_diff*$item->getQtyOrdered());
                        $options = $item->getProductOptions();
                        $this->logger->debug('be code of item is'.$product->getData('be_code'));
                        $storeitems[] = [
							'ESCODE'        => $item->getSku(),
							'PRODUCTPRICE'  => $productprice,
							'QTY'           => (int)$item->getQtyOrdered(),
							'PRODUCTDESC'   => $product->getData('article_type'),
							"COLOR"         => $product->getAttributeText('color'),
							"BRANCH_CODE"   => $product->getData('physical_store_code'),
							"PRODUCTSIZE"   => $productSize,
							"FALL_PICO"     => $price_diff,
							"ITM_PACKINGCOST" => "0.0000",
							"ITM_SHIPPINGCOST" => "0.0000",
							"MAT_TYPE"=> $matType,
							"MTR"=> $matQty,
							"PER_MTR_COST"=> $perMtrCost
                        ];
                    }
                }
            }
        }
        $order_transaction = $this->getTransactionRecord($order->getId());
		$orderpaymentid = '';
		if (isset($order_transaction['txn_id']) && $order_transaction['txn_id']!='' ) {
			$orderpaymentid = $order_transaction['txn_id'];
		}
		$paymentTranData = $order->getPayment()->getData();
		if(isset($paymentTranData['last_trans_id']) && $paymentTranData['last_trans_id']!=''){
			$orderpaymentid = $paymentTranData['last_trans_id'];
		}
		$paymentMode = $order->getPayment()->getMethodInstance()->getCode();
		if($orderpaymentid == '' && $paymentMode=='adminrazorpay'){
			$orderComment = '';
			foreach ($order->getStatusHistoryCollection(true) as $_item){
				$orderComment = $_item->getComment();
				
			}
			$orderpaymentid = $orderComment;
		
		}
        
        if($paymentMode=='juspay'){
			$orderComment = '';
            $juspay_txn_id = $orderpaymentid;
			foreach ($order->getStatusHistoryCollection(true) as $_item){
                if (str_contains($_item->getComment(), 'epg_txn_id') && str_contains($_item->getComment(), 'Gateway Response')) {
                    $jsonString = trim(str_replace("Gateway Response :",'',$_item->getComment()),": ");
                    $jsonString = str_replace("{",'',$jsonString);
                    $jsonString = str_replace("}",'',$jsonString);
                    $jsonString = str_replace('":"',':',$jsonString);
                    $commentArray = explode('"', $jsonString);
                    foreach($commentArray as $value){
                        if(str_contains($value, 'epg_txn_id')){
                            $orderpaymentid =  substr($value, strpos($value, ":") + 1);
                        }
                    }    
                }		
			}
		
		}        
        if (!empty($eshopitems)) {
            $eshopitems[0]["ITM_PACKINGCOST"] = $order->getData("base_fee");
            $eshopitems[0]["ITM_SHIPPINGCOST"] = $order->getData("base_shipping_incl_tax");
        } else {
            $storeitems[0]["ITM_PACKINGCOST"] = $order->getData("base_fee");
            $storeitems[0]["ITM_SHIPPINGCOST"] = $order->getData("base_shipping_incl_tax");
        }

        if ($shipping_address['country_id'] == "IN") {
            if (trim(strtolower($shipping_address['region'])) == "karnataka") {
                $ordertype = "LOCAL";
            } else {
                $ordertype = "INTERSTATE";
            }
        } else {
            $ordertype = "EXPORT";
        }
        
        if (!empty($storeitems)) {
            $storedata = [];
			$roundOffGrandTotal = floor($order->getData("base_grand_total"));
			$roundOffValue = ($order->getData("base_original_grand_total"))-($roundOffGrandTotal);
			$roundOffValue = $roundOffValue>0?$roundOffValue:0;              
            $storedata["ORDERID"] = $order->getIncrementId();
			$storedata["ORDERDATE"] = $order->getData("created_at");
			$storedata["SUBTOTAL"] = $order->getData("base_subtotal")-$fall_pico_charges;
			$storedata["PACKINGCHARGES"] = $order->getData("base_fee");
			$storedata["SHIPPINGCHARDES"] = $order->getData("base_shipping_incl_tax");
			$storedata["GRANDTOTAL"] = (int)$roundOffGrandTotal;
			$storedata["TOTALQTY"] = (int)$totalQty;
			$order_currency_code = $order->getData("order_currency_code");
			if('INR'!=$order_currency_code){
				$roundOffValue = 0;
			}
			$storedata["ROUNDOFF"] = $roundOffValue;
			$storedata["PAYMENTMODE"] = $order->getPayment()->getMethodInstance()->getCode();   
			$storedata["BANKTRANID"] = $orderpaymentid;
            $storedata["JUSPAYTXNID"] = $juspay_txn_id;
			// check this
			$storedata["ORDERTYPE"] = $ordertype;
			$storedata["SHIPPINGNAME"] = $shipping_address['firstname']." " .$shipping_address['lastname'];
			$storedata["SHIPPINGADD1"] = $shipping_address['street'];
			$storedata["SHIPPINGADD2"] = "";
			$storedata["SHIPPINGCITY"] = $shipping_address['city'];
			$storedata["SHIPPINGSTATE"] = $shipping_address['region'];
			$storedata["DL_STATECODE"] = $regioncode;
			$storedata["SHIPPINGPINCODE"] = $shipping_address['postcode'];
			$storedata["SHIPPINGMOBILENO"] = $shipping_address['telephone'];
			$storedata["SHIPPINGCOUNTRY"] = $shipping_address['country_id'];
			$storedata["ORDERMAILID"] = $order->getData('customer_email');
			$storedata["BILLINGNAME"] = $billing_address['firstname'].$billing_address['lastname'];
			$storedata["BILLINGADD1"] = $billing_address['street'];
			$storedata["BILLINGADD2"] = "";
			$storedata["BILLINGCITY"] = $billing_address['city'];
			$storedata["BILLINGSTATE"] = $billing_address['region'];
			$storedata["BILLINGPINCODE"] = $billing_address['postcode'];
			$storedata["BILLINGMOBILENO"] = $billing_address['telephone'];
			$storedata["BILLINGCOUNTRY"] = $billing_address['country_id'];
			$storedata["PRODUCTDETAILS"] = $storeitems;
            $storerow = json_encode($storedata);
			$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
			$logger = new \Zend_Log();
			$logger->addWriter($writer);		
			$logger->info('UpdateMemberProfile callErpNF->'.$storerow);	
			
  
            $this->logger->debug($storerow);

             /* Encrypting the data */
            $model = $this->encryptionkeyFactory;
            $storedata = $model->getCollection()->getLastItem()->getData();

            $encryption_key = $storedata['enc_key'];
            $encryption_iv = $storedata['enc_iv'];

            $key_pwd = substr(hash('sha256', $encryption_key, true), 0, 32);
            $cipher_method = 'aes-256-cbc';
            $crypted_token = base64_encode(openssl_encrypt(
                "[".$storerow."]",
                $cipher_method,
                $key_pwd,
                OPENSSL_RAW_DATA,
                $encryption_iv
            ));
            $logger->info('UpdateMemberProfile- callErpNF>'.$crypted_token);
            $this->logger->debug($crypted_token);

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, '"'.$crypted_token.'"');

            $storeConfig = $this->_scopeConfig;
            $storeurl = $storeConfig->getValue('erpsync/physical/store_sync_api_url');
            
            $storeserver_key = $storeConfig->getValue('erpsync/physical/store_server_key');

            curl_setopt($curl, CURLOPT_URL, $storeurl);
               curl_setopt($curl, CURLOPT_HTTPHEADER, [
                  'apikey:' . $storeserver_key,
                  'Content-Type: application/json',
               ]);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            
            $this->logger->debug('Store Encrypted data generated');

            $storeresponse = curl_exec($curl);
            $this->logger->info('Line dataphp debug start');
			$this->logger->info(print_r($storeresponse, true));
			$this->logger->info('Line dataphp debug end');
            $this->logger->debug('Store curl generated');
            
            $storerespo = "[".$storeresponse."]";
            $this->logger->debug($storerespo);
            $storeresp = json_decode($storerespo);
            $this->logger->debug("", $storeresp);
            if ($storeresp[0]->code == "200") {
                $storeresp1 = explode(",", $storeresp[0]->description);
            /*    if(strpos($storeresp1[1], ":") !== false){
                    $storeresp2 = explode(":",$storeresp1[1]);
                    $storeresp_arr['invoice_id'] = trim($storeresp2[1], '"');
                }else{
                    $storeresp_arr['invoice_id'] = "";
                }    */
                $storeresp_arr['invoice_id'] = "";
            } else {
                $storeresp_arr['invoice_id'] = "";
            }
            $storeerr = curl_error($curl);
            curl_close($curl);
            $storeresp_arr['request_data'] = $storerow;
            $storeresp_arr['response_data'] = $storeresponse;
            $storeresp_arr['error_data'] = $storeerr;
            
            $this->logger->debug("", $storeresp_arr);

                return $storeresp_arr;
            
        }
    }

    /**
     * Retrieve config data
     *
     * @param $enc_key
     * @param $enc_iv
     * @return string
     */
    public function sendApi($enc_key, $enc_iv)
    {

        $this->loggerErp->info('===Start Send Api===='.date('Y-m-d h:i:s'));
        try {
            $crypted_data = '[{"enc_key":"'.$enc_key.'","enc_iv":"'.$enc_iv.'"}]';
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $crypted_data);

            $storeConfig = $this->_scopeConfig;
            $store_enc_key_url = $storeConfig->getValue('erpsync/general/enc_key_api_url');
            $server_key =  $storeConfig->getValue('erpsync/general/server_key');
            $this->loggerErp->info('server_key:'.$server_key);
            $this->loggerErp->info('store_enc_key_url:'.$store_enc_key_url);
            curl_setopt($curl, CURLOPT_URL, $store_enc_key_url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
              'apikey:' . $server_key,
              'Content-Type: application/json',
            ]);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            $response = curl_exec($curl);
            $this->loggerErp->info('response=>'.print_r($response,true));
            $err = curl_error($curl);
            $this->loggerErp->info('err:'.$err);
            curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
        
        } catch (Exception $e) {
            $this->loggerErp->info('catch'.$e->getMessage());
            return $e->getMessage();
        }        
    }

    /**
     * Change enrcyption key
     */
    public function changeEncryptionkey()
    {
        $this->loggerErp->info('===Start===='.date('Y-m-d h:i:s'));
        try {
            $storeConfig = $this->_scopeConfig;
            $enc_iv = $storeConfig->getValue('erpsync/general/encryption_iv');
            $cipher_method = 'aes-256-cbc';
            $enc_key = openssl_digest(rand(), 'SHA256', true);
            $short_enc_key = substr($enc_key, 0, 16);
            $this->loggerErp->info('short_enc_key:'.base64_encode($short_enc_key));
            $model = $this->encryptionkeyFactory;
            $model->setEncKey(base64_encode($short_enc_key));
            $model->setEncIv($enc_iv);
            $model->setCreatedDate(date("Y-m-d H:i:s"));
            $model->save();
            $this->loggerErp->info('enc_iv:'.$enc_iv);
            $callenc = $this->sendApi(base64_encode($short_enc_key), $enc_iv);
            $this->loggerErp->info('callenc=>'.print_r($callenc,true));
            
            return $callenc;
        } catch (Exception $e) {
           $this->loggerErp->info('catch'.$e->getMessage());
            return $e->getMessage();
        }
        
    }
    
	public function getTransactionRecord($orderId)
    {
        $tableName = $this->resourceConnection->getTableName('sales_payment_transaction');

        //Initiate Connection
        $connection = $this->resourceConnection->getConnection();

        $select = $connection->select()
            ->from(
                ['c' => $tableName],
                ['order_id','txn_id']
            )->where("order_id = ?",$orderId);

        $records = $connection->fetchRow($select);
        return $records;
    }    
    
}
