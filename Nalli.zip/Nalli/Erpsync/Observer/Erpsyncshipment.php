<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Erpsyncshipment implements ObserverInterface
{
    /**
     * Data constructor.
     * @param \Nalli\Erpsync\Helper\Data $helper
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\Product $productloader
     * @param \Nalli\Erpsync\Model\Erpdispatch erpdispatchFactory
     */

    public function __construct(
        \Nalli\Erpsync\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\Product $productloader,
        \Nalli\Erpsync\Model\Erpdispatch $erpdispatchFactory
    ) {
        $this->_helper = $helper;
        $this->logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->productloader = $productloader;
        $this->erpdispatchFactory = $erpdispatchFactory;
    }

    /**
     * dispatch entered into List.
     *
     * @param Context $observer
     * @return $this
     */

    public function execute(Observer $observer)
    {
            $this->logger->debug('Shipment event function started');
            $trackinformation = [];
            $shipment = $observer->getEvent()->getShipment();
            $tracksCollection = $shipment->getTracksCollection();
            $order = $shipment->getOrder();
            $order_id = $order->getIncrementId();
            $order_date = $order->getCreatedAt();
            $incrementid = $shipment->getIncrementId();
            $this->logger->debug('Shipment Increment id '.$incrementid);

            $this->logger->debug('order details '.$order_id.' '.$order_date);
            $products = [];
            $item_skus = [];
            
        foreach ($shipment->getItems() as $item) {
            $products = $this->productloader->load($item->getProductId());
            if (substr($products->getSku(), 0, 2) != "ES") {
                        $this->logger->debug('order does not have GV or ES products');
            } else {
                array_push($item_skus, $products->getSku());
                        $this->logger->debug('order does have GV or ES products');
            }
        }
        if (empty($item_skus)) {
            $product = [];
            $itremsinfo = [];
            foreach ($shipment->getItems() as $items) {
                $product = $this->productloader->load($items->getProductId());
                
                $itremsinfo[] = [
                'ItemCode' => $product->getData('be_code'),
                'SKUCode' => $product->getSku(),
                'ProductPrice' => (float)$product->getPrice(),
                'Branch' => $product->getData('physical_store_code')
                      ];
            }

            if ($tracksCollection) {
                foreach ($tracksCollection->getItems() as $track) {
                    $trackinformation = [
                        'TrackingNo' => $track->getTrackNumber(),
                        'CarrierDetails' => $track->getTitle(),
                        'TrackerDate' => date("Y-m-d H:i:s"),
                        'OrderId' => $order_id,
                        'OrderDate' => $order_date,
                        'ProductDetails' => $itremsinfo
                    ];
                }
            }

            if ($trackinformation) {
                $this->logger->critical("critical:", $trackinformation);

                $storerow = json_encode($trackinformation);

                $this->logger->debug($storerow);

                $storeConfig = $this->_scopeConfig;
                $storeurl = $storeConfig->getValue('erpsync/dispatch/store_dispatch_api_url');

                $this->logger->debug('Store API url '.$storeurl);

                $storeserver_key = $storeConfig->getValue('erpsync/dispatch/dispatch_server_key');
                $this->logger->debug('Store API server_key '.$storeserver_key);

                $curl = curl_init();

                curl_setopt_array($curl, [
                    CURLOPT_URL => $storeurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>$storerow,
                    CURLOPT_HTTPHEADER => [
                        'apikey: '.$storeserver_key,
                        'Content-Type: application/json'
                    ],
                ]);

                $storeresponse = curl_exec($curl);

                $this->logger->debug('Store curl generated');

                $storerespo = "[".$storeresponse."]";
                $this->logger->debug($storerespo);
                $storeresp = json_decode($storerespo);
                $this->logger->debug("debug:", $storeresp);

                $storeerr = curl_error($curl);
                curl_close($curl);
                $storeresp_arr['request_data'] = $storerow;
                $storeresp_arr['response_data'] = $storeresponse;
                $storeresp_arr['error_data'] = $storeerr;
                $this->logger->debug("debuglog: ", $storeresp_arr);
                $model = $this->erpdispatchFactory;
                $dataset = [
                    'order_id' => $order_id,
                    'shipping_id' =>$incrementid,
                    'request_data' => $storerow,
                    'response_data'=> $storeresponse,
                ];
                try {
                    $model->setData($dataset)->save();
                } catch (Exception $e) {
                    $this->logger->debug('erp catch message ' . $e->getMessage());
                }
                $this->logger->debug('dispatch entered into the list');
            }
        }
    }
}
