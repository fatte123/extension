<?php
/**
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */

namespace Nalli\Erpsync\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Erpsync implements ObserverInterface
{

    /**
     * @var helper
     */
    private $helper;

    /**
     * @var logger
     */
    protected $logger;

    /**
     * @var scopeConfig
     */
    protected $scopeConfig;

    /**
     * @var erporderFactory
     */
    protected $erporderFactory;

    /**
     * Data constructor.
     * @param \Nalli\Erpsync\Helper\Data $helper
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Nalli\Erpsync\Model\Erporder $erporderFactory
     */

    public function __construct(
        \Nalli\Erpsync\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Nalli\Erpsync\Model\Erporder $erporderFactory
    ) {
        $this->_helper = $helper;
        $this->logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->erporderFactory = $erporderFactory;
    }

    /**
     * Save order data
     *
     * @return $this
     * @param $observer
     */
    public function execute(Observer $observer)
    {
        $this->logger->debug('Observer event function started');
        $erpsync_select = $this->_scopeConfig->getValue('erpsync/general/erpsync_select');

        if ($erpsync_select == 1) {
            $invoice = $observer->getEvent()->getInvoice();
            $order = $invoice->getOrder();
            $order_state = $order->getStatus();
            $order_total = $order->getData("base_grand_total");
            $item_skus = [];

            $total_cond = $this->_scopeConfig->getValue('erpsync/general/grand_total');

            if (($order_state == 'processing') && ($order_total <= $total_cond)) {
                /*foreach ($order->getAllItems() as $item) {
                    if (substr($item->getSku(), 0, 2) != "GV") {
                        $this->logger->debug('order does not have GV');
                    } else {
                        array_push($item_skus, $item->getSku());
                    }
                }*/
                if (empty($item_skus)) {

                    $order_id = $order->getIncrementId();
                    $collection = $this->erporderFactory->getCollection()
                                                ->addFieldToFilter('order_id', $order_id)->getLastItem();
                    if (!$collection->getData()) {
                        $model = $this->erporderFactory;
                        $dataset = [
                            'order_id' => $order_id,
                            'sync_status' =>'no',
                            'grand_total' => $order_total,
                            'order_date' => $order->getCreatedAt(),
                            'sync_date' => '',
                            'updated_date' => '',
                            'response_status'=>'',
                            "invoice_id" => '',
                        ];
                        try {
                            $model->setData($dataset)->save();
                        } catch (Exception $e) {
                            $this->logger->debug('erp catch message ' . $e->getMessage());
                        }
                        $this->logger->debug('Order entered into the list');
                    }
                } else {
                    
                    foreach ($order->getAllItems() as $item) {
                        if (substr($item->getSku(), 0, 2) == "ES") {
                            $this->logger->debug('order has NF product with ES and GV');
                        } else {
                            array_push($item_skus, $item->getSku());
                        }
                    }
                    if (!empty($item_skus)) {

                                   $order_id = $order->getIncrementId();
                                   $collection = $this->erporderFactory->getCollection()
                                                ->addFieldToFilter('order_id', $order_id)->getLastItem();
                        if (!$collection->getData()) {
                            $model = $this->erporderFactory;
                            $dataset = [
                            'order_id' => $order_id,
                            'sync_status' =>'no',
                            'grand_total' => $order_total,
                            'order_date' => $order->getCreatedAt(),
                            'sync_date' => '',
                            'updated_date' => '',
                            'response_status'=>'',
                            "invoice_id" => '',
                            ];
                            try {
                                $model->setData($dataset)->save();
                            } catch (Exception $e) {
                                $this->logger->debug('erp catch message ' . $e->getMessage());
                            }
                            $this->logger->debug('Order entered into the list');
                        }
                    }
                }
            }
        }
    }
}
