<?php
/**
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */

namespace Nalli\Erpsync\Setup;

use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('erpsync');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'erpsync_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'order_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'invoice_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'flag',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'request_data',
                                Table::TYPE_TEXT
                            )
                            ->addColumn(
                                'response_data',
                                Table::TYPE_TEXT
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }

            //creating erporder table

            $tableName = $setup->getTable('erporder');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'erporder_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'order_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'sync_status',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'grand_total',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'order_date',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'sync_date',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'updated_date',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'response_status',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'invoice_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }

                //creating encryption key table

                $tableName = $setup->getTable('encryptionkey');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'encryptionkey_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'enc_key',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'enc_iv',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'created_date',
                                Table::TYPE_DATETIME
                            )
                            ->addIndex(
                                $setup->getIdxName(
                                    'encryption_key',
                                    ['created_date'],
                                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                                ),
                                ['created_date'],
                                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }
            
            // creating erpdispatch table
            
        $tableName = $setup->getTable('erpdispatch');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'erpdispatch_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'order_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'shipping_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'request_data',
                                Table::TYPE_TEXT
                            )
                            ->addColumn(
                                'response_data',
                                Table::TYPE_TEXT
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }
        $setup->endSetup();
    }
}
