<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Model\ResourceModel\Encryptionkey;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var $_idFieldName
     */
    protected $_idFieldName = 'encryptionkey_id';

    /**
     * @var $_eventPrefix
     */
    protected $_eventPrefix = 'nalli_erpsync_encryptionkey_collection';

    /**
     * @var $_eventObject
     */
    protected $_eventObject = 'encryptionkey_collection';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Nalli\Erpsync\Model\Encryptionkey::class,
            \Nalli\Erpsync\Model\ResourceModel\Encryptionkey::class
        );
    }
}
