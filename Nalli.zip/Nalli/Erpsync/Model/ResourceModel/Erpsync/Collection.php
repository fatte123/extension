<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Nalli\Erpsync\Model\ResourceModel\Erpsync;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var $_idFieldName
     */
    protected $_idFieldName = 'erpsync_id';
    
    /**
     * @var $_idFieldName
     */
    protected $_eventPrefix = 'nalli_erpsync_erpsync_collection';

    /**
     * @var $_idFieldName
     */
    protected $_eventObject = 'erpsync_collection';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Nalli\Erpsync\Model\Erpsync::class, \Nalli\Erpsync\Model\ResourceModel\Erpsync::class);
    }
}
