<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
 
namespace Nalli\Erpsync\Model;

class Encryptionkey extends \Magento\Framework\Model\AbstractModel implements
    \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'nalli_erpsync_encryptionkey';

    protected $_cacheTag = 'nalli_erpsync_encryptionkey';

    protected $_eventPrefix = 'nalli_erpsync_encryptionkey';

    protected function _construct()
    {
        $this->_init(\Nalli\Erpsync\Model\ResourceModel\Encryptionkey::class);
    }

    /**
     * @return int
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return $values
     */
    public function getDefaultValues()
    {
        $values = [];
        return $values;
    }
}
