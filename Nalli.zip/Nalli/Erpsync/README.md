## Nalli_Erpsync
-------------
This module contain Erpsync orders data.


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Erpsync
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
ERP Sync Dashboard, you can review those data from admin gid.


## Copyright
---------
Copyright (c) 2021. 18th DigiTech Team. All rights reserved.