<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_CustomApi
 */
 
namespace Nalli\CustomApi\Api;

interface CustomInterface
{
    /**
     * GET for Post api
     * @param string $attribute
     * @param string $att_value
     * @return string
     */
     
    public function getInstockProduct(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);
}
