<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_CustomApi
 */
 
namespace Nalli\CustomApi\Model\Api;

use Psr\Log\LoggerInterface;

class Custom extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     */
    protected $productCollectionFactory;
    
    /*
     *@var LoggerInterface $logger,
     */
    protected $logger;
    
    /*
     *@var Magento\CatalogInventory\Helper\Stock $stockFilter
     */
    protected $stockFilter;
     
     /*
      *@var \Magento\Framework\View\Element\Template\Context $context,
      */
    protected $context;
	
    /*
     *@var \Magento\CatalogInventory\Api\StockStateInterface $stockState,
     */
    protected $stockState;
    
    /*
     *@param  \Magento\Framework\View\Element\Template\Context $context,
     *@param  \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
     *@param  \Magento\CatalogInventory\Helper\Stock $stockFilter,
	 *@param  \Magento\CatalogInventory\Api\StockStateInterface $stockState,
	 *@param  \Magento\Store\Model\StoreManagerInterface $storeManager,
     *@param  LoggerInterface $logger,
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\CatalogInventory\Helper\Stock $stockFilter,
        \Magento\CatalogInventory\Api\StockStateInterface $stockState,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        LoggerInterface $logger,
        array $data = []
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->_stockFilter = $stockFilter;
        $this->stockState = $stockState;
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
        $this->logger = $logger;
        parent::__construct($context, $data);
    }
    
    /**
     * @inheritdoc
     */
    
    public function getInstockProduct(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->productCollectionFactory->create();
        //$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
        $status = \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED;
        //$collection->addAttributeToFilter('status', $status);
        
        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }
		$collection->joinField(
    'stock_status', 'cataloginventory_stock_status', 'stock_status', 'product_id=entity_id', '{{table}}.stock_id=1', 'left'
)->addFieldToFilter('stock_status', array('eq' => \Magento\CatalogInventory\Model\Stock\Status::STATUS_IN_STOCK)); 
        $collection->addAttributeToSelect('*');   
        $totalCount = $collection->getSize();     
 		$page = $searchCriteria->getCurrentPage() ?? 1;
        $pageSize = $searchCriteria->getPageSize() ?? 100;
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);                

        foreach ($collection as $product) {			
			$_product = $this->loadMyProduct($product->getSku());
			$categoryName = strtolower($_product->getCategoryName());
			$isQtyDecimal = $_product->getExtensionAttributes()->getStockItem()->getIsQtyDecimal();
			$image = $_product->getData('image');
			$thumbnail = $_product->getData('thumbnail');
			$small_image = $_product->getData('small_image');
			$imageUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);		
			$matType = '';
			$qty = '';
			$perMtrCost = '';
			$productSize = '';
			if(($isQtyDecimal) == 1 && ($categoryName == "fabric")) { 
					$matType = 'RM';
					$qty = number_format($this->getStockQty($_product->getId()),1);
			}
			if($product->getAttributeText('size')){
				$productSize = $product->getAttributeText('size');
				$matType = 'R';
			}			
            $data[] = [
                    'sku' => $product->getSku(),
                    'be_code' => $product->getData('be_code'),
                    'created_at' => $product->getData('created_at'),
                    'updated_at' => $product->getData('updated_at'),
                    'status' => $product->getData('status'),
                    'visibility' => $product->getData('visibility'),
                    'physical_store_code' => $product->getData('physical_store_code'),
                    'name' => $product->getData('name'),
                    'meta_title' => $product->getData('meta_title'),
                    'price' => $product->getData('price'),
                    'article_type' => $product->getData('article_type'),
                    'color' => $product->getAttributeText('color'),
                    'blouse' => $product->getAttributeText('blouse'),
                    'border' => $product->getAttributeText('border'),
                    'border_type' => $product->getAttributeText('border_type'),
                    'material' => $product->getAttributeText('material'),
                    'price_bucket' => $product->getData('price_bucket'),
                    'qty' => $this->getStockQty($product->getId()),                    
                    'MAT_TYPE'=> $matType,
                    'COLOR'=> $product->getAttributeText('color'),
                    'PRODUCTSIZE'=> $productSize,
					'BAL_MTR' => $qty,
					'product_type' => $product->getData('type_id'),
					'product_image' => $imageUrl.'catalog/product'.$image,
					'product_thumbnail' => $imageUrl.'catalog/product'.$thumbnail,
					'product_small_image' => $imageUrl.'catalog/product'.$small_image					
                ];
        }
        if(isset($_GET['fields'])&&($_GET['fields']=='total_count')){
			$data = [];
			$data[]['total_count'] = $totalCount;
		}        
        if (!isset($data)) {
            $data[] = "no items found";
        }
        //$returnArray = json_encode($data);
        return $data;
    }
    
    public function getStockQty($productId, $websiteId = null)
    {
        return $this->stockState->getStockQty($productId, $websiteId);
    }
    
    public function loadMyProduct($sku)
{
    return $this->productRepository->get($sku);
}
}
