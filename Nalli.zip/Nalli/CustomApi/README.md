# Nalli_CustomApi

This module contain some product json data

## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_CustomApi
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage

{base_url}rest/V1/instock?
searchCriteria[filterGroups][0][filters][0][field]=entity_id
&searchCriteria[filterGroups][0][filters][0][value]=26597

goto postman {base_url}rest/V1/instock/
