<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\InStockAdvance\Api\Data;

interface InstockAdvacneInterface
{

    const ATTRIBUTE_SET_ID = 'attribute_set_id';
    const MAGENTOONE_VIEWS = 'magentoone_views';
    const VIEWS_IMPRESSIONS = 'views_impressions';
    const REQUIRED_OPTIONS = 'required_options';
    const MAGENTOONE_TOTALIMPRESSIONS = 'magentoone_totalimpressions';
    const COLOR = 'color';
    const UPDATED_IN = 'updated_in';
    const FABRIC_PURITY = 'fabric_purity';
    const MATERIAL = 'material';
    const TYPE_ID = 'type_id';
    const CREATED_AT = 'created_at';
    const OCCASION = 'occasion';
    const CREATED_IN = 'created_in';
    const VISIBILITY = 'visibility';
    const SMALL_IMAGE = 'small_image';
    const ORNAMENTATION_TYPE = 'ornamentation_type';
    const URL_KEY = 'url_key';
    const PRICE = 'price';
    const ATC = 'atc';
    const MAGENTOONE_UPLOAD = 'magentoone_upload';
    const ROW_ID = 'row_id';
    const BORDER = 'border';
    const ARTICLE_TYPE = 'article_type';
    const MAGENTOONE_ATC = 'magentoone_atc';
    const AGE = 'age';
    const HAS_OPTIONS = 'has_options';
    const ATC_COUNT = 'atc_count';
    const STORE_CODE = 'store_code';
    const ID = 'id';
    const ATC_VIEWS = 'atc_views';
    const TOTAL_IMPRESSIONS = 'total_impressions';
    const SKU = 'sku';
    const ZARI_TYPE = 'zari_type';
    const TECHNIQUE = 'technique';
    const STATUS = 'status';
    const BORDER_TYPE = 'border_type';
    const INSTOCKADVACNE_ID = 'instockadvacne_id';
    const PATTERN = 'pattern';
    const STYLE_OF_WORK = 'style_of_work';
    const UPDATED_AT = 'updated_at';
    const NO_OF_VIEWS = 'no_of_views';
    const COUNTER = 'counter';
    const BLOUSE = 'blouse';
    const IMAGE = 'image';
    const STOCK_ITEM = 'stock_item';
    const SUPPLIER_CODE = 'supplier_code';
    const NAME = 'name';
    const STORE_ID = 'store_id';
    const CATEGORY_IDS = 'category_ids';
    const EVENT = 'event';

    /**
     * Get instockadvacne_id
     * @return string|null
     */
    public function getInstockadvacneId();

    /**
     * Set instockadvacne_id
     * @param string $instockadvacneId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setInstockadvacneId($instockadvacneId);

    /**
     * Get id
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     * @param string $id
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setId($id);

    /**
     * Get attribute_set_id
     * @return string|null
     */
    public function getAttributeSetId();

    /**
     * Set attribute_set_id
     * @param string $attributeSetId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setAttributeSetId($attributeSetId);

    /**
     * Get type_id
     * @return string|null
     */
    public function getTypeId();

    /**
     * Set type_id
     * @param string $typeId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setTypeId($typeId);

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setSku($sku);

    /**
     * Get has_options
     * @return string|null
     */
    public function getHasOptions();

    /**
     * Set has_options
     * @param string $hasOptions
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setHasOptions($hasOptions);

    /**
     * Get required_options
     * @return string|null
     */
    public function getRequiredOptions();

    /**
     * Set required_options
     * @param string $requiredOptions
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setRequiredOptions($requiredOptions);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get row_id
     * @return string|null
     */
    public function getRowId();

    /**
     * Set row_id
     * @param string $rowId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setRowId($rowId);

    /**
     * Get created_in
     * @return string|null
     */
    public function getCreatedIn();

    /**
     * Set created_in
     * @param string $createdIn
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setCreatedIn($createdIn);

    /**
     * Get updated_in
     * @return string|null
     */
    public function getUpdatedIn();

    /**
     * Set updated_in
     * @param string $updatedIn
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setUpdatedIn($updatedIn);

    /**
     * Get atc_count
     * @return string|null
     */
    public function getAtcCount();

    /**
     * Set atc_count
     * @param string $atcCount
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setAtcCount($atcCount);

    /**
     * Get article_type
     * @return string|null
     */
    public function getArticleType();

    /**
     * Set article_type
     * @param string $articleType
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setArticleType($articleType);

    /**
     * Get border
     * @return string|null
     */
    public function getBorder();

    /**
     * Set border
     * @param string $border
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setBorder($border);

    /**
     * Get border_type
     * @return string|null
     */
    public function getBorderType();

    /**
     * Set border_type
     * @param string $borderType
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setBorderType($borderType);

    /**
     * Get blouse
     * @return string|null
     */
    public function getBlouse();

    /**
     * Set blouse
     * @param string $blouse
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setBlouse($blouse);

    /**
     * Get color
     * @return string|null
     */
    public function getColor();

    /**
     * Set color
     * @param string $color
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setColor($color);

    /**
     * Get counter
     * @return string|null
     */
    public function getCounter();

    /**
     * Set counter
     * @param string $counter
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setCounter($counter);

    /**
     * Get fabric_purity
     * @return string|null
     */
    public function getFabricPurity();

    /**
     * Set fabric_purity
     * @param string $fabricPurity
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setFabricPurity($fabricPurity);

    /**
     * Get magentoone_upload
     * @return string|null
     */
    public function getMagentooneUpload();

    /**
     * Set magentoone_upload
     * @param string $magentooneUpload
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setMagentooneUpload($magentooneUpload);

    /**
     * Get magentoone_views
     * @return string|null
     */
    public function getMagentooneViews();

    /**
     * Set magentoone_views
     * @param string $magentooneViews
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setMagentooneViews($magentooneViews);

    /**
     * Get magentoone_totalimpressions
     * @return string|null
     */
    public function getMagentooneTotalimpressions();

    /**
     * Set magentoone_totalimpressions
     * @param string $magentooneTotalimpressions
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setMagentooneTotalimpressions($magentooneTotalimpressions);

    /**
     * Get magentoone_atc
     * @return string|null
     */
    public function getMagentooneAtc();

    /**
     * Set magentoone_atc
     * @param string $magentooneAtc
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setMagentooneAtc($magentooneAtc);

    /**
     * Get material
     * @return string|null
     */
    public function getMaterial();

    /**
     * Set material
     * @param string $material
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setMaterial($material);

    /**
     * Get no_of_views
     * @return string|null
     */
    public function getNoOfViews();

    /**
     * Set no_of_views
     * @param string $noOfViews
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setNoOfViews($noOfViews);

    /**
     * Get occasion
     * @return string|null
     */
    public function getOccasion();

    /**
     * Set occasion
     * @param string $occasion
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setOccasion($occasion);

    /**
     * Get ornamentation_type
     * @return string|null
     */
    public function getOrnamentationType();

    /**
     * Set ornamentation_type
     * @param string $ornamentationType
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setOrnamentationType($ornamentationType);

    /**
     * Get pattern
     * @return string|null
     */
    public function getPattern();

    /**
     * Set pattern
     * @param string $pattern
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setPattern($pattern);

    /**
     * Get price
     * @return string|null
     */
    public function getPrice();

    /**
     * Set price
     * @param string $price
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setPrice($price);

    /**
     * Get small_image
     * @return string|null
     */
    public function getSmallImage();

    /**
     * Set small_image
     * @param string $smallImage
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setSmallImage($smallImage);

    /**
     * Get store_code
     * @return string|null
     */
    public function getStoreCode();

    /**
     * Set store_code
     * @param string $storeCode
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setStoreCode($storeCode);

    /**
     * Get style_of_work
     * @return string|null
     */
    public function getStyleOfWork();

    /**
     * Set style_of_work
     * @param string $styleOfWork
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setStyleOfWork($styleOfWork);

    /**
     * Get technique
     * @return string|null
     */
    public function getTechnique();

    /**
     * Set technique
     * @param string $technique
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setTechnique($technique);

    /**
     * Get total_impressions
     * @return string|null
     */
    public function getTotalImpressions();

    /**
     * Set total_impressions
     * @param string $totalImpressions
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setTotalImpressions($totalImpressions);

    /**
     * Get url_key
     * @return string|null
     */
    public function getUrlKey();

    /**
     * Set url_key
     * @param string $urlKey
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setUrlKey($urlKey);

    /**
     * Get image
     * @return string|null
     */
    public function getImage();

    /**
     * Set image
     * @param string $image
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setImage($image);

    /**
     * Get zari_type
     * @return string|null
     */
    public function getZariType();

    /**
     * Set zari_type
     * @param string $zariType
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setZariType($zariType);

    /**
     * Get age
     * @return string|null
     */
    public function getAge();

    /**
     * Set age
     * @param string $age
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setAge($age);

    /**
     * Get views_impressions
     * @return string|null
     */
    public function getViewsImpressions();

    /**
     * Set views_impressions
     * @param string $viewsImpressions
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setViewsImpressions($viewsImpressions);

    /**
     * Get atc_views
     * @return string|null
     */
    public function getAtcViews();

    /**
     * Set atc_views
     * @param string $atcViews
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setAtcViews($atcViews);

    /**
     * Get atc
     * @return string|null
     */
    public function getAtc();

    /**
     * Set atc
     * @param string $atc
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setAtc($atc);

    /**
     * Get stock_item
     * @return string|null
     */
    public function getStockItem();

    /**
     * Set stock_item
     * @param string $stockItem
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setStockItem($stockItem);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setStatus($status);

    /**
     * Get visibility
     * @return string|null
     */
    public function getVisibility();

    /**
     * Set visibility
     * @param string $visibility
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setVisibility($visibility);
    /**
     * Get Supplier Code
     * @return string|null
     */
    public function getSupplierCode();

    /**
     * Set Supplier Code
     * @param string $code
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setSupplierCode($code);
    /**
     * Get Name
     * @return string|null
     */
    public function getName();

    /**
     * Set Name
     * @param string $name
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setName($name);
    /**
     * Get Category Ids
     * @return string|null
     */
    public function getCategoryIds();

    /**
     * Set Category Ids
     * @param string $id
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setCategoryIds($id);
    /**
     * Get Event
     * @return string|null
     */
    public function getEvent();

    /**
     * Set Event
     * @param string $event
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setEvent($event);
    /**
     * Get Store Id
     * @return string|null
     */
    public function getStoreId();

    /**
     * Set Store Id
     * @param string $storeId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     */
    public function setStoreId($storeId);
}

