<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\InStockAdvance\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface InstockAdvacneRepositoryInterface
{

    /**
     * Save InstockAdvacne
     * @param \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface $instockAdvacne
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface $instockAdvacne
    );

    /**
     * Retrieve InstockAdvacne
     * @param string $instockadvacneId
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($instockadvacneId);

    /**
     * Retrieve InstockAdvacne matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Nalli\InStockAdvance\Api\Data\InstockAdvacneSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete InstockAdvacne
     * @param \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface $instockAdvacne
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface $instockAdvacne
    );

    /**
     * Delete InstockAdvacne by ID
     * @param string $instockadvacneId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($instockadvacneId);
}

