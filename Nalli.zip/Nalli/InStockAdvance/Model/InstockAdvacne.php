<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\InStockAdvance\Model;

use Magento\Framework\Model\AbstractModel;
use Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface;

class InstockAdvacne extends AbstractModel implements InstockAdvacneInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne::class);
    }

    /**
     * @inheritDoc
     */
    public function getInstockadvacneId()
    {
        return $this->getData(self::INSTOCKADVACNE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setInstockadvacneId($instockadvacneId)
    {
        return $this->setData(self::INSTOCKADVACNE_ID, $instockadvacneId);
    }

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * @inheritDoc
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @inheritDoc
     */
    public function getAttributeSetId()
    {
        return $this->getData(self::ATTRIBUTE_SET_ID);
    }

    /**
     * @inheritDoc
     */
    public function setAttributeSetId($attributeSetId)
    {
        return $this->setData(self::ATTRIBUTE_SET_ID, $attributeSetId);
    }

    /**
     * @inheritDoc
     */
    public function getTypeId()
    {
        return $this->getData(self::TYPE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setTypeId($typeId)
    {
        return $this->setData(self::TYPE_ID, $typeId);
    }

    /**
     * @inheritDoc
     */
    public function getSku()
    {
        return $this->getData(self::SKU);
    }

    /**
     * @inheritDoc
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * @inheritDoc
     */
    public function getHasOptions()
    {
        return $this->getData(self::HAS_OPTIONS);
    }

    /**
     * @inheritDoc
     */
    public function setHasOptions($hasOptions)
    {
        return $this->setData(self::HAS_OPTIONS, $hasOptions);
    }

    /**
     * @inheritDoc
     */
    public function getRequiredOptions()
    {
        return $this->getData(self::REQUIRED_OPTIONS);
    }

    /**
     * @inheritDoc
     */
    public function setRequiredOptions($requiredOptions)
    {
        return $this->setData(self::REQUIRED_OPTIONS, $requiredOptions);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * @inheritDoc
     */
    public function getRowId()
    {
        return $this->getData(self::ROW_ID);
    }

    /**
     * @inheritDoc
     */
    public function setRowId($rowId)
    {
        return $this->setData(self::ROW_ID, $rowId);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedIn()
    {
        return $this->getData(self::CREATED_IN);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedIn($createdIn)
    {
        return $this->setData(self::CREATED_IN, $createdIn);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedIn()
    {
        return $this->getData(self::UPDATED_IN);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedIn($updatedIn)
    {
        return $this->setData(self::UPDATED_IN, $updatedIn);
    }

    /**
     * @inheritDoc
     */
    public function getAtcCount()
    {
        return $this->getData(self::ATC_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function setAtcCount($atcCount)
    {
        return $this->setData(self::ATC_COUNT, $atcCount);
    }

    /**
     * @inheritDoc
     */
    public function getArticleType()
    {
        return $this->getData(self::ARTICLE_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setArticleType($articleType)
    {
        return $this->setData(self::ARTICLE_TYPE, $articleType);
    }

    /**
     * @inheritDoc
     */
    public function getBorder()
    {
        return $this->getData(self::BORDER);
    }

    /**
     * @inheritDoc
     */
    public function setBorder($border)
    {
        return $this->setData(self::BORDER, $border);
    }

    /**
     * @inheritDoc
     */
    public function getBorderType()
    {
        return $this->getData(self::BORDER_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setBorderType($borderType)
    {
        return $this->setData(self::BORDER_TYPE, $borderType);
    }

    /**
     * @inheritDoc
     */
    public function getBlouse()
    {
        return $this->getData(self::BLOUSE);
    }

    /**
     * @inheritDoc
     */
    public function setBlouse($blouse)
    {
        return $this->setData(self::BLOUSE, $blouse);
    }

    /**
     * @inheritDoc
     */
    public function getColor()
    {
        return $this->getData(self::COLOR);
    }

    /**
     * @inheritDoc
     */
    public function setColor($color)
    {
        return $this->setData(self::COLOR, $color);
    }

    /**
     * @inheritDoc
     */
    public function getCounter()
    {
        return $this->getData(self::COUNTER);
    }

    /**
     * @inheritDoc
     */
    public function setCounter($counter)
    {
        return $this->setData(self::COUNTER, $counter);
    }

    /**
     * @inheritDoc
     */
    public function getFabricPurity()
    {
        return $this->getData(self::FABRIC_PURITY);
    }

    /**
     * @inheritDoc
     */
    public function setFabricPurity($fabricPurity)
    {
        return $this->setData(self::FABRIC_PURITY, $fabricPurity);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneUpload()
    {
        return $this->getData(self::MAGENTOONE_UPLOAD);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneUpload($magentooneUpload)
    {
        return $this->setData(self::MAGENTOONE_UPLOAD, $magentooneUpload);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneViews()
    {
        return $this->getData(self::MAGENTOONE_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneViews($magentooneViews)
    {
        return $this->setData(self::MAGENTOONE_VIEWS, $magentooneViews);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneTotalimpressions()
    {
        return $this->getData(self::MAGENTOONE_TOTALIMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneTotalimpressions($magentooneTotalimpressions)
    {
        return $this->setData(self::MAGENTOONE_TOTALIMPRESSIONS, $magentooneTotalimpressions);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneAtc()
    {
        return $this->getData(self::MAGENTOONE_ATC);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneAtc($magentooneAtc)
    {
        return $this->setData(self::MAGENTOONE_ATC, $magentooneAtc);
    }

    /**
     * @inheritDoc
     */
    public function getMaterial()
    {
        return $this->getData(self::MATERIAL);
    }

    /**
     * @inheritDoc
     */
    public function setMaterial($material)
    {
        return $this->setData(self::MATERIAL, $material);
    }

    /**
     * @inheritDoc
     */
    public function getNoOfViews()
    {
        return $this->getData(self::NO_OF_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setNoOfViews($noOfViews)
    {
        return $this->setData(self::NO_OF_VIEWS, $noOfViews);
    }

    /**
     * @inheritDoc
     */
    public function getOccasion()
    {
        return $this->getData(self::OCCASION);
    }

    /**
     * @inheritDoc
     */
    public function setOccasion($occasion)
    {
        return $this->setData(self::OCCASION, $occasion);
    }

    /**
     * @inheritDoc
     */
    public function getOrnamentationType()
    {
        return $this->getData(self::ORNAMENTATION_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setOrnamentationType($ornamentationType)
    {
        return $this->setData(self::ORNAMENTATION_TYPE, $ornamentationType);
    }

    /**
     * @inheritDoc
     */
    public function getPattern()
    {
        return $this->getData(self::PATTERN);
    }

    /**
     * @inheritDoc
     */
    public function setPattern($pattern)
    {
        return $this->setData(self::PATTERN, $pattern);
    }

    /**
     * @inheritDoc
     */
    public function getPrice()
    {
        return $this->getData(self::PRICE);
    }

    /**
     * @inheritDoc
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * @inheritDoc
     */
    public function getSmallImage()
    {
        return $this->getData(self::SMALL_IMAGE);
    }

    /**
     * @inheritDoc
     */
    public function setSmallImage($smallImage)
    {
        return $this->setData(self::SMALL_IMAGE, $smallImage);
    }

    /**
     * @inheritDoc
     */
    public function getStoreCode()
    {
        return $this->getData(self::STORE_CODE);
    }

    /**
     * @inheritDoc
     */
    public function setStoreCode($storeCode)
    {
        return $this->setData(self::STORE_CODE, $storeCode);
    }

    /**
     * @inheritDoc
     */
    public function getStyleOfWork()
    {
        return $this->getData(self::STYLE_OF_WORK);
    }

    /**
     * @inheritDoc
     */
    public function setStyleOfWork($styleOfWork)
    {
        return $this->setData(self::STYLE_OF_WORK, $styleOfWork);
    }

    /**
     * @inheritDoc
     */
    public function getTechnique()
    {
        return $this->getData(self::TECHNIQUE);
    }

    /**
     * @inheritDoc
     */
    public function setTechnique($technique)
    {
        return $this->setData(self::TECHNIQUE, $technique);
    }

    /**
     * @inheritDoc
     */
    public function getTotalImpressions()
    {
        return $this->getData(self::TOTAL_IMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setTotalImpressions($totalImpressions)
    {
        return $this->setData(self::TOTAL_IMPRESSIONS, $totalImpressions);
    }

    /**
     * @inheritDoc
     */
    public function getUrlKey()
    {
        return $this->getData(self::URL_KEY);
    }

    /**
     * @inheritDoc
     */
    public function setUrlKey($urlKey)
    {
        return $this->setData(self::URL_KEY, $urlKey);
    }

    /**
     * @inheritDoc
     */
    public function getImage()
    {
        return $this->getData(self::IMAGE);
    }

    /**
     * @inheritDoc
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     * @inheritDoc
     */
    public function getZariType()
    {
        return $this->getData(self::ZARI_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setZariType($zariType)
    {
        return $this->setData(self::ZARI_TYPE, $zariType);
    }

    /**
     * @inheritDoc
     */
    public function getAge()
    {
        return $this->getData(self::AGE);
    }

    /**
     * @inheritDoc
     */
    public function setAge($age)
    {
        return $this->setData(self::AGE, $age);
    }

    /**
     * @inheritDoc
     */
    public function getViewsImpressions()
    {
        return $this->getData(self::VIEWS_IMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setViewsImpressions($viewsImpressions)
    {
        return $this->setData(self::VIEWS_IMPRESSIONS, $viewsImpressions);
    }

    /**
     * @inheritDoc
     */
    public function getAtcViews()
    {
        return $this->getData(self::ATC_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setAtcViews($atcViews)
    {
        return $this->setData(self::ATC_VIEWS, $atcViews);
    }

    /**
     * @inheritDoc
     */
    public function getAtc()
    {
        return $this->getData(self::ATC);
    }

    /**
     * @inheritDoc
     */
    public function setAtc($atc)
    {
        return $this->setData(self::ATC, $atc);
    }

    /**
     * @inheritDoc
     */
    public function getStockItem()
    {
        return $this->getData(self::STOCK_ITEM);
    }

    /**
     * @inheritDoc
     */
    public function setStockItem($stockItem)
    {
        return $this->setData(self::STOCK_ITEM, $stockItem);
    }

    /**
     * @inheritDoc
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * @inheritDoc
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * @inheritDoc
     */
    public function getVisibility()
    {
        return $this->getData(self::VISIBILITY);
    }

    /**
     * @inheritDoc
     */
    public function setVisibility($visibility)
    {
        return $this->setData(self::VISIBILITY, $visibility);
    }

    /**
     * @inheritDoc
     */
    public function getSupplierCode()
    {
        return $this->getData(self::SUPPLIER_CODE);
    }

    /**
     * @inheritDoc
     */
    public function setSupplierCode($code)
    {
        return $this->setData(self::SUPPLIER_CODE, $code);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getCategoryIds()
    {
        return $this->getData(self::CATEGORY_IDS);
    }

    /**
     * @inheritDoc
     */
    public function setCategoryIds($id)
    {
        return $this->setData(self::CATEGORY_IDS, $id);
    }

    /**
     * @inheritDoc
     */
    public function getEvent()
    {
        return $this->getData(self::EVENT);
    }

    /**
     * @inheritDoc
     */
    public function setEvent($event)
    {
        return $this->setData(self::EVENT, $event);
    }

    /**
     * @inheritDoc
     */
    public function getStoreId()
    {
        return $this->getData(self::STORE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }
}

