<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\InStockAdvance\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Nalli\InStockAdvance\Api\Data\InstockAdvacneInterface;
use Nalli\InStockAdvance\Api\Data\InstockAdvacneInterfaceFactory;
use Nalli\InStockAdvance\Api\Data\InstockAdvacneSearchResultsInterfaceFactory;
use Nalli\InStockAdvance\Api\InstockAdvacneRepositoryInterface;
use Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne as ResourceInstockAdvacne;
use Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne\CollectionFactory as InstockAdvacneCollectionFactory;

class InstockAdvacneRepository implements InstockAdvacneRepositoryInterface
{

    /**
     * @var InstockAdvacneInterfaceFactory
     */
    protected $instockAdvacneFactory;

    /**
     * @var InstockAdvacne
     */
    protected $searchResultsFactory;

    /**
     * @var InstockAdvacneCollectionFactory
     */
    protected $instockAdvacneCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var ResourceInstockAdvacne
     */
    protected $resource;


    /**
     * @param ResourceInstockAdvacne $resource
     * @param InstockAdvacneInterfaceFactory $instockAdvacneFactory
     * @param InstockAdvacneCollectionFactory $instockAdvacneCollectionFactory
     * @param InstockAdvacneSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceInstockAdvacne $resource,
        InstockAdvacneInterfaceFactory $instockAdvacneFactory,
        InstockAdvacneCollectionFactory $instockAdvacneCollectionFactory,
        InstockAdvacneSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->instockAdvacneFactory = $instockAdvacneFactory;
        $this->instockAdvacneCollectionFactory = $instockAdvacneCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(InstockAdvacneInterface $instockAdvacne)
    {
        try {
            $this->resource->save($instockAdvacne);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the instockAdvacne: %1',
                $exception->getMessage()
            ));
        }
        return $instockAdvacne;
    }

    /**
     * @inheritDoc
     */
    public function get($instockAdvacneId)
    {
        $instockAdvacne = $this->instockAdvacneFactory->create();
        $this->resource->load($instockAdvacne, $instockAdvacneId);
        if (!$instockAdvacne->getId()) {
            throw new NoSuchEntityException(__('InstockAdvacne with id "%1" does not exist.', $instockAdvacneId));
        }
        return $instockAdvacne;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->instockAdvacneCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(InstockAdvacneInterface $instockAdvacne)
    {
        try {
            $instockAdvacneModel = $this->instockAdvacneFactory->create();
            $this->resource->load($instockAdvacneModel, $instockAdvacne->getInstockadvacneId());
            $this->resource->delete($instockAdvacneModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the InstockAdvacne: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($instockAdvacneId)
    {
        return $this->delete($this->get($instockAdvacneId));
    }
}

