<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\InStockAdvance\Cron;

use Magento\Framework\Exception\CouldNotSaveException;
use  Nalli\InStockAdvance\Model\ResourceModel\InstockAdvacne\Collection;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Eav\Model\Config;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class ImportCol
{
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * @var Collection
     */
    protected $queryColTable;
    /**
     * @var ResourceConnection
     */
    protected $_resource;
    /**
     * @var Config
     */
    protected $eavConfig;
    /**
     * @var CollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * Constructor
     *
     * @param LoggerInterface $logger
     * @param Collection $queryColTable
     * @param ResourceConnection $_resource
     * @param Config $eavConfig
     * @param CollectionFactory $productCollectionFactory
     */
    public function __construct(
        LoggerInterface $logger,
        Collection $queryColTable,
        ResourceConnection $_resource,
        Config $eavConfig,
        CollectionFactory $productCollectionFactory

    )
    {
        $this->logger = $logger;
        $this->queryColTable = $queryColTable;
        $this->_resource = $_resource;
        $this->eavConfig = $eavConfig;
        $this->productCollectionFactory = $productCollectionFactory;
    }

    /**
     * Execute the cron
     *
     * @return void
     */
    public function execute()
    {
        //die('sffdfsd');
        $resource = $this->_resource;

        $connection = $resource->getConnection();

        $collection = $this->getProductCollection();

        try {

            $existingData = $this->queryColTable;

            if ($existingData->count() > 0) {
                $connection->truncateTable('nalli_instockadvance_instockadvacne');
                echo "\n";
                echo __("Table is truncated.");
                echo "\n";
            }
            $bulkInsert = [];
            foreach ($collection as $records) {
                $bulkInsert[] = $records->getData();
            }
            // bulk insert full
            $connection->insertMultiple('nalli_instockadvance_instockadvacne', $bulkInsert);
            echo __('Data Import Successfully.');
            echo "\n";
        }catch (CouldNotSaveException $exception) {
            $this->logger->debug("In Stock Advance:: ".$exception->getMessage());
        }
    }

    private function getProductCollection()
    {
        $now = date("Y-m-d h:i:s");
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('sku');
        $collection->addAttributeToSelect('name');
        $collection->addAttributeToSelect('entity_id');
        $collection->addAttributeToSelect('created_at');
        $attributes = ['atc_count', 'article_type', 'border', 'border_type', 'blouse', 'color', 'counter', 'fabric_purity', 'magentoone_upload', 'magentoone_views', 'magentoone_totalimpressions', 'magentoone_atc', 'material', 'no_of_views', 'occasion', 'ornamentation_type', 'pattern', 'price', 'small_image', 'store_code', 'style_of_work', 'supplier_code', 'technique', 'total_impressions', 'url_key','image', 'zari_type'];

        foreach ($attributes as $attribute) {
            $eav = $this->eavConfig->getAttribute('catalog_product', $attribute);

            $collection->getSelect()
                ->joinLeft(
                    [$attribute => $eav->getBackendTable()],
                    //To resolved filter error chnages made entity_id to value_id
                    "e.entity_id = {$attribute}.row_id AND
        {$attribute}.attribute_id = {$eav->getAttributeId()}",
                    [$attribute => 'value']
                );
        }

        $collection->getSelect()->columns("IF( IFNULL(`magentoone_upload`.`value`, 0) = 0, DATEDIFF('".$now."', `created_at`), DATEDIFF('".$now."', `magentoone_upload`.`value`) ) as age");

        $collection->getSelect()->columns("(((IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0)) / (IFNULL(`total_impressions`.`value`,0) + IFNULL(`magentoone_totalimpressions`.`value`,0))) * 1000) as views_impressions");

        $collection->getSelect()->columns("(((IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) / (IFNULL(`no_of_views`.`value`,0) + IFNULL(`magentoone_views`.`value`,0))) * 100) as atc_views");

        $collection->getSelect()->columns("(IFNULL(`atc_count`.`value`,0) + IFNULL(`magentoone_atc`.`value`,0)) as atc");

        $collection->setFlag('has_stock_status_filter', true)
            ->joinField(
                'stock_item',
                'cataloginventory_stock_item',
                'is_in_stock',
                'product_id=entity_id',
                'is_in_stock=1'
            );

        $collection->addAttributeToFilter('status', 1);

        $collection->addAttributeToFilter('visibility', 4);

        //$collection->getSelect()->limit(10);

        $collection->getSelect()->group('e.entity_id');

        //$this->stockInventory->addInStockFilterToCollection($collection);

        $sku = 'ES';
        $collection->addAttributeToFilter('sku', [
            ['like' => '%'.$sku.'%'], //spaces on each side
            ['like' => '%'.$sku], //space before and ends with $needle
            ['like' => $sku.'%'] // starts with needle and space after
        ]);
        return $collection;
    }

}
