<?php
/**
 * Module registration file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Nalli_Customordergrid
 */
 
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Nalli_Customordergrid',
    __DIR__
);
