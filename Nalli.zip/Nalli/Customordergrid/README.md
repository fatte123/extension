## Nalli_Erpsync
-------------
This module contain Transaction Id column in sales order admin grid


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Customordergrid
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
Customordergrid module is used to add a Transaction Id column in sales order admin grid.


## Copyright
---------
Copyright (c) 2021. 18th DigiTech Team. All rights reserved.