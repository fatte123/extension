<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_CustomOrdergrid
 */
namespace Nalli\Customordergrid\Cron;


use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class UpdateOrderGridData
{
    private $logger;
    private $resourceConnection;
    protected $entityIdList=[];
    protected $entityIdListWithErpInvoiceId=[];    
    public function __construct(
        LoggerInterface $logger,
        ResourceConnection $resourceConnection
    ) {
        $this->logger = $logger;
        $this->resourceConnection = $resourceConnection;
    }
    
    public function execute()
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/UpdateOrderGridData.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);        
        $logger->info('===Start===='.date('Y-m-d h:i:s'));
        $connection  = $this->resourceConnection->getConnection();
        $erporder   = $connection->getTableName('erporder');
        $sales_order_gtid   = $connection->getTableName('sales_order_grid');
        $sales_payment_transaction   = $connection->getTableName('sales_payment_transaction');
      
        $erpOrders = $this->getErporderRecords();
        $incrementIds = [];
        $dataList = [];
       
        foreach ($erpOrders as $data) { 
            $order_id = $data['order_id'];
            $incrementIds[] = $order_id;
            $dataList[$order_id]   = $data['invoice_id'];
        }
        $logger->info('dataList=>'.print_r($dataList,true));    
        $this->preapreErpInvoiceIdOrderIdList($incrementIds, $dataList);
        
        $invoiceIdUpdate = $this->doBulkUpdateInvoiceId();
        
        if($invoiceIdUpdate){
            //echo 'Erp Invoice Id Update';
            $logger->info('Erp Invoice Id Update');
        }

        $transactionOrders = $this->getTransactionRecords();
        $logger->info('transactionOrders=>'.print_r($transactionOrders,true));
        $transactionIdUpdate = $this->doBulkUpdateTransactionId($transactionOrders);
        if($transactionIdUpdate){
            //echo 'Transaction Id Update';
            $logger->info('Transaction Id Update.');
        }
         $logger->info('===End====');
    }
    
    public function getErporderRecords()
    {
        $tableName = $this->resourceConnection->getTableName('erporder');
        $connection = $this->resourceConnection->getConnection();
        $invoice_id = '>0';
        $scopedate = "CURDATE()";
        $orscopedate = "DATE_SUB(CURDATE(),INTERVAL 1 DAY)";

         $select = $connection->select()
            ->from(
                ['c' => $tableName],
                ['order_id','invoice_id']
            )->where("invoice_id > ?",0);            
        $whereCondition = str_replace("'","", $connection->quoteInto("date(c.updated_date) = ?", $scopedate));
        $whereCondition2 = str_replace("'","",$connection->quoteInto("date(c.updated_date) = ?", $orscopedate));
        $select->where($whereCondition)->orwhere($whereCondition2);

        $records = $connection->fetchAll($select);
        return $records;
    }
    
    public function getTransactionRecords()
    {
        $tableName = $this->resourceConnection->getTableName('sales_payment_transaction');

        //Initiate Connection
        $connection = $this->resourceConnection->getConnection();
        $invoice_id = '>0';
        $scopedate = "CURDATE()";
        $orscopedate = "DATE_SUB(CURDATE(),INTERVAL 1 DAY)";
        $select = $connection->select()
            ->from(
                ['c' => $tableName],
                ['order_id','txn_id']
            )->where("order_id > ?",0);            
        $whereCondition = str_replace("'","", $connection->quoteInto("date(c.created_at) = ?", $scopedate));
        $whereCondition2 = str_replace("'","",$connection->quoteInto("date(c.created_at) = ?", $orscopedate));
        $select->where($whereCondition)->orwhere($whereCondition2);

        $records = $connection->fetchAll($select);
        return $records;
    }
    
    private function doBulkUpdateTransactionId($bulkUpdateData) 
    {
        $connection = $this->resourceConnection->getConnection();
        $newUpdateData = [];
        if ($bulkUpdateData) {
            $conditions = [];
            foreach ($bulkUpdateData as $data) {
                $case = $connection->quoteInto('?', $data['order_id']);
                $result = $connection->quoteInto('?', $data['txn_id']); 
                $conditions[$case] = $result;
                $newUpdateData[$data['order_id']] = $data['txn_id'];
            }
            $txn_id = $connection->getCaseSql('entity_id', $conditions, 'transaction_id');
            $where = ['entity_id IN (?)' => array_keys($newUpdateData)];
            
            try {
                $connection->beginTransaction();
                $connection->update($connection->getTableName('sales_order_grid'), ['transaction_id' => $txn_id], $where);
                
                $connection->commit();
                return true;
            } catch (\Exception $e) {
                $connection->rollBack();
                return false;
            }
        }
        return false;
    } 
    
    private function doBulkUpdateInvoiceId() 
    {
        $connection = $this->resourceConnection->getConnection();
   
        $newUpdateData = [];
        if ($this->entityIdListWithErpInvoiceId) {
            $conditions = [];
            foreach ($this->entityIdListWithErpInvoiceId as $key=>$value) {
                $case = $connection->quoteInto('?', $key);
                $result = $connection->quoteInto('?', $value);
                $conditions[$case] = $result;
                $newUpdateData[$key] = $value;
            }
            $invoice_id = $connection->getCaseSql('entity_id', $conditions, 'invoice_id');
            $where = ['entity_id IN (?)' => array_keys($this->entityIdListWithErpInvoiceId)];
            
            try {
                $connection->beginTransaction();
                $connection->update($connection->getTableName('sales_order_grid'), ['invoice_id' => $invoice_id], $where);
                $connection->commit();
                return true;
            } catch (\Exception $e) {
                $connection->rollBack();
                return false;
            }
        }
        return false;
    }    

    private function preapreErpInvoiceIdOrderIdList($incrementIds, $dataList)
    {
        $connection = $this->resourceConnection->getConnection();
        $dataVal = [];
        $incrementIdsStr = "'" .implode("','", $incrementIds). "'";
        $result = $connection->fetchAll(
            "SELECT entity_id,increment_id FROM " . $connection->getTableName('sales_order_grid') . " WHERE 1 AND increment_id IN ($incrementIdsStr)"
        );
        if ($result) {
            foreach ($result as $value) {
                $this->entityIdList[] = $value['entity_id'];
                $dataVal[$value['entity_id']] = $dataList[$value['increment_id']];
            }
            $this->entityIdListWithErpInvoiceId = $dataVal;
            return true;
        } else {
            return false;
        }
    }   
   
}  
