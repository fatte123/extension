<?php
namespace Nalli\Customordergrid\Controller\Index;
error_reporting(E_ALL);
ini_set('display_errors', '1');


class Index extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Nalli\Customordergrid\Cron\UpdateOrderGridData $updateOrderGridData
    )
    {
		$this->updateOrderGridData = $updateOrderGridData;
        return parent::__construct($context);
    }

    public function execute()
    {
		 
        echo $this->updateOrderGridData->execute();
        echo 'Done';
        exit;
    }
}
