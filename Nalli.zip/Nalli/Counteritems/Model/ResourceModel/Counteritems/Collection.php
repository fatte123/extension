<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Nalli\Counteritems\Model\ResourceModel\Counteritems;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'counteritems_id';
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            \Nalli\Counteritems\Model\Counteritems::class,
            \Nalli\Counteritems\Model\ResourceModel\Counteritems::class
        );
    }
}
