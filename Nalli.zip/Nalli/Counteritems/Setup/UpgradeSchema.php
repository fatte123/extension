<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Nalli\Counteritems\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
   
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {

        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.2.0', '<')) {
                $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test2y.log');
                $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
                $logger->info('nee text message');
                $installer->run('ALTER TABLE counteritems ADD upldprd varchar(255)');
        }
        $installer->endSetup();
    }
}
