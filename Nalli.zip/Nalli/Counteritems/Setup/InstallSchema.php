<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
  
namespace Nalli\Counteritems\Setup;

use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('counteritems');
        if ($conn->isTableExists($tableName) != true) {
            $table = $conn->newTable($tableName)
                            ->addColumn(
                                'counteritems_id',
                                Table::TYPE_INTEGER,
                                11,
                                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true]
                            )
                            ->addColumn(
                                'parent_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'counter_id',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'counter_name',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'sos',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'lwsos',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'sold',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'str',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'lwstr',
                                Table::TYPE_TEXT,
                                255
                            )
                            ->addColumn(
                                'created_time',
                                Table::TYPE_DATETIME
                            )
                            ->addColumn(
                                'update_time',
                                Table::TYPE_DATETIME
                            )
                            ->setOption('charset', 'utf8');
            $conn->createTable($table);
        }
        $setup->endSetup();
    }
}
