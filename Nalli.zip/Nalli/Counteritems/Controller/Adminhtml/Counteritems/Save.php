<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Nalli\Counteritems\Controller\Adminhtml\Counteritems;

use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;

class Save extends \Magento\Backend\App\Action
{
    protected $_counteritemsFactory;
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\Http $request,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
        \Nalli\Counteritems\Model\CounteritemsFactory $counteritemsFactory
    ) {
        $this->request = $request;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->_counteritemsFactory = $counteritemsFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $files = $this->getRequest()->getFiles()->toArray();
        if (!$data) {
            $this->_redirect('counteritems/counteritems/add/');
            return;
        }
        if (isset($files['bulk_file_upload']['name']) && $files['bulk_file_upload']['name'] != '') {
            $this->_bulkUpload();
        } else {
            try {
                if (array_key_exists('counteritems_id', $data)) {
                    $rowData =  $this->_counteritemsFactory->create()->load($data['counteritems_id']);
                    date_default_timezone_set("Asia/Calcutta");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData->setData($data);
                    $rowData->save();
                } else {
                    date_default_timezone_set("Asia/Calcutta");
                    $data['created_time'] = date("Y-m-d h:i:sa");
                    $data['update_time'] = date("Y-m-d h:i:sa");
                    $rowData1 =  $this->_counteritemsFactory->create();
                    $rowData1->setData($data);
                    $rowData1->save();
                }
                    $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
            } catch (\Exception $e) {
                $this->messageManager->addError(__($e->getMessage()));
            }
        }
        $this->_redirect('counteritems/counteritems/index/');
    }

    protected function _bulkUpload()
    {
        /*ini_set('display_errors', 1);
        error_reporting(E_ALL);*/
        
        date_default_timezone_set("Asia/Calcutta");
        try {
            $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'bulk_file_upload']);
            $uploaderFactory->setAllowedExtensions(['CSV', 'csv']);
            $fileAdapter = $this->adapterFactory->create();
            $uploaderFactory->setAllowRenameFiles(true);
            $destinationPath = $this->filesystem
            ->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('counteritems');
            $result = $uploaderFactory->save($destinationPath);
            if (!$result) {
                throw new LocalizedException(
                    __('File cannot be saved to path: $1', $destinationPath)
                );
            }
            $fileHandler = Magento\Framework\Filesystem\DriverInterface::fileOpen(
                $destinationPath."/".$result['file'],
                'r'
            );
            $i = 0;
            if ($fileHandler) {
                $colNames = Magento\Framework\Filesystem\DriverInterface::fileGetCsv($fileHandler);
                foreach ($colNames as &$colName) {
                    $colName = trim($colName);
                }
                $requiredColumns = ['counter_id', 'counter_name', 'sos', 'sold', 'str'];
                $requiredColumnsPositions = [];

                foreach ($requiredColumns as $columnName) {
                    $found = array_search($columnName, $colNames);
                    if (false !== $found) {
                        $requiredColumnsPositions[] = $found;
                    } else {
                        $this->messageManager->addError('Corrupt file');
                        $this->_redirect('counteritems/counteritems/save/option/2/');
                        return;
                    }
                }
                while (($currentRow = Magento\Framework\Filesystem\DriverInterface::fileGetCsv(
                    $fileHandler
                )) !== false) {
                    foreach ($requiredColumnsPositions as $index) {
                        if (isset($currentRow[$index])) {
                            $csvDataRow[$colNames[$index]] = trim($currentRow[$index]);
                        }
                    }
                    if (isset($csvDataRow['counter_id']) && $csvDataRow['counter_id'] !== '') {
                        $csvData[] = $csvDataRow;
                    }
                }
                Magento\Framework\Filesystem\DriverInterface::fileClose($fileHandler);
                
                $deletebaseitems = $this->_counteritemsFactory->create()->getCollection()
                ->addFieldToFilter('parent_id', 'base');
                foreach ($deletebaseitems as $deletebaseitem) {
                    $baseitemdel = $this->_counteritemsFactory->create()->load($deletebaseitem->getId());
                    $baseitemdel->delete();
                }
                
                $added = 0;
                $present = 0;
                $error = "";

                foreach ($csvData as $productdata) {
                        $model = $this->_counteritemsFactory->create();
                        $model->setParentId('base');
                        $model->setCounterId($productdata['counter_id']);
                        $model->setCounterName($productdata['counter_name']);
                        $model->setSos($productdata['sos']);
                        $model->setSold($productdata['sold']);
                        $model->setStr($productdata['str']);
                        $model->setCreatedTime(date("Y-m-d H:i:s"));
                        $model->save();
                        $added++;
                }
                $succmsg = $added ." items added";
                $this->messageManager->addSuccess(__($succmsg));
                if ($error) {
                    $errmsg = "Items already present: " .$error;
                    $this->messageManager->addError(__($errmsg));
                }
                $this->_redirect('*/*/index', ['parent_id' => 'base']);
                return;
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            return;
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Nalli_Counteritems::save');
    }
}
