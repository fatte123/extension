<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Nalli\Counteritems\Block\Adminhtml\Counteritems\Custom;

use Magento\Backend\Block\Widget\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Button implements ButtonProviderInterface
{
    /**
     * @var Context
     */
    protected $context;
    protected $_backendUrl;
    protected $_storeManager;
    /**
     * @param Context $context
     */
    public function __construct(
        Context $context,
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->context = $context;
        $this->_backendUrl = $backendUrl;
         $this->_storeManager = $storeManager;
    }
/**
 * @return array
 */
    public function getButtonData()
    {
        $base_url = $this->_storeManager->getStore()->getBaseUrl();
        $callback_url =$this->_backendUrl->getUrl("countermaster/countermaster/populate");
        $data = [];
            $data = [
                'id' => 'bulk',
                'name' => 'bulk',
                'label' => __('Populate'),
                'class' => 'primary',
                'url' => $callback_url
            ];
            return $data;
    }

    public function getOption()
    {
        return $this->context->getRequest()->getParam('option');
    }
}
