<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Nalli\Counteritems\Block\Adminhtml\Counteritems\Edit;

/**
 * Adminhtml Add New Row Form.
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $customButton;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Nalli\Counteritems\Block\Adminhtml\Counteritems\Custom\Button $customButton,
        array $data = []
    ) {
        $this->customButton = $customButton;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /*$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $blockObj= $objectManager->get('Nalli\Counteritems\Block\Adminhtml\Counteritems\Custom\Button');*/
         $option = $this->customButton->getOption();
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form',
                            'enctype' => 'multipart/form-data',
                            'action' => $this->getData('action'),
                            'method' => 'post'
                        ]
            ]
        );
        if ($model->getCounteritemsId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Item'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('counteritems_id', 'hidden', ['name' => 'counteritems_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Item'), 'class' => 'fieldset-wide']
            );
        }
        if ($option == '2') {
            
            $fieldset->addField(
                'bulk_file_upload',
                'file',
                [
                    'name' => 'bulk_file_upload',
                    'label' => __('File'),
                    'id' => 'bulk_file_upload',
                    'title' => __('File'),
                ]
            );
        }

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
