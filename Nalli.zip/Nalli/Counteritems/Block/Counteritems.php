<?php
/**
 * @category   Nalli
 * @package    Nalli_Counteritems
 * @author     nalli.com
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Nalli\Counteritems\Block;

class Counteritems extends \Magento\Framework\View\Element\Template
{
    protected $httpContext;

    protected $timezone;
    
     /**
      * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
      */
    protected $productCollectionFactory;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $_orderCollectionFactory;

    /*
     *@var \Magento\Framework\Url\Helper\Data $helper
     */
    public $helper;
    
     /*
     *@var \Magento\Customer\Model\Session $Session
     */
    public $Session;

    protected $stockFilter;

     /*
     *@var \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper
     */
    public $WeeklyreportHelper;

     /*
     *@var \Nalli\Countermaster\Helper\Data $WeeklyreportHelper
     */
    public $CountermasterHelper;

    /**
     * @var \Magento\Framework\Locale\CurrencyInterface
     */
    protected $currency;

    /**
     * @var \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory
     */
    protected $CountermasterFactory;

    /**
     * @var \Nalli\Countermaster\Model\ResourceModel\Counteritems\CollectionFactory
     */
    protected $CounteritemsFactory;
    
    /*
     *@var \Magento\Framework\App\Response\Http $Http
     */
    public $Http;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Framework\Url\Helper\Data $helper,
        \Magento\Customer\Model\SessionFactory  $Session,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\CatalogInventory\Helper\Stock $stockFilter,
        \Nalli\Weeklyreport\Helper\Data $WeeklyreportHelper,
        \Nalli\Countermaster\Helper\Data $CountermasterHelper,
        \Magento\Framework\App\Response\Http $Http,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Framework\Locale\CurrencyInterface $currency,
        \Nalli\Countermaster\Model\ResourceModel\Countermaster\CollectionFactory $CountermasterFactory,
        \Nalli\Counteritems\Model\ResourceModel\Counteritems\CollectionFactory $CounteritemsFactory,
        array $data = []
    ) {
        $this->httpContext = $httpContext;
        $this->timezone = $timezone;
        $this->helper = $helper;
        $this->Session = $Session;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->stockFilter = $stockFilter;
        $this->WeeklyreportHelper = $WeeklyreportHelper;
        $this->CountermasterHelper = $CountermasterHelper;
        $this->httpresponse = $Http;
        $this->currency = $currency;
        $this->CountermasterFactory = $CountermasterFactory;
        $this->CounteritemsFactory = $CounteritemsFactory;
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__(' '));
        
        return parent::_prepareLayout();
    }

    public function gettimezone()
    {
        return $this->timezone->formatDate(date("Y-m-d H:i:s"), \IntlDateFormatter::MEDIUM, true);
    }

    /*
     *return \Nalli\Weeklyreport\Helper\Data  class functions
     */
    public function getWeeklyreportHelper()
    {
        return $this->WeeklyreportHelper;
    }
    /*
     *return \Nalli\Countermaster\Helper\Data  class functions
     */
    public function getCountermasterHelper()
    {
        return $this->CountermasterHelper;
    }
    /*
     *return \Magento\Framework\Url\Helper\Data class function
     */
    public function getUrlHelper()
    {
        return $this->helper;
    }
    public function getProductCollectionCount()
    {
        $productCollection = $this->productCollectionFactory->create();
        $productCollection->addAttributeToSelect('*');
        $productCollection->addAttributeToFilter('status', 1);
        $productCollection->addAttributeToFilter('visibility', ['4']);
        // $this->stockFilter->addInStockFilterToCollection($productCollection);
        $sku = 'ES';
        $productCollection->addAttributeToFilter('sku', [
                   ['like' => '%'.$sku.'%'], //spaces on each side
                   ['like' => '%'.$sku], //space before and ends with $needle
                   ['like' => $sku.'%'] // starts with needle and space after
        ]);
        $productCollection->addAttributeToFilter('category_name', [
                    ['nlike' => '%Dhoti%'], //spaces on each side
        ]);
        $productCollection->addAttributeToFilter('category_name', [
                    ['nlike' => '%Fabric%'], //spaces on each side
        ]);         
        $productCollection->setFlag('has_stock_status_filter', true)
        ->joinField(
            'stock_item',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            'is_in_stock=1'
        );
        
        /*$productCollection->getSelect()->joinLeft(
            [ 'stocktable' => 'cataloginventory_stock_status' ],
            'e.entity_id = stocktable.product_id',
            []
        );
        $subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM
                                        inventory_reservation GROUP BY sku)');
        $joinConditions = 'e.sku = reservetable.sku';
        $productCollection->getSelect()->joinLeft(
            [ 'reservetable' => $subquery ],
            $joinConditions,
            []
        )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")
                    ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");*/

        return $productCollection->getSize();
    }
    
    public function getOffProductCollectionCount()
    {
        $off_productCollection =  $this->productCollectionFactory->create();
        $off_productCollection->addAttributeToSelect('*');
        $off_productCollection->addAttributeToFilter('status', 1);
        $off_productCollection->addAttributeToFilter('visibility', ['4']);
        // $this->stockFilter->addInStockFilterToCollection($off_productCollection);
        $sku = 'ES';
        $off_productCollection->addAttributeToFilter('sku', [
                    ['nlike' => '%'.$sku.'%'], //spaces on each side
        ]);
        $off_productCollection->addAttributeToFilter('sku', [
                    ['nlike' => '%GV%'], //spaces on each side
        ]);
        $off_productCollection->addAttributeToFilter('category_name', [
                    ['nlike' => '%Dhoti%'], //spaces on each side
        ]);
        $off_productCollection->addAttributeToFilter('category_name', [
                    ['nlike' => '%Fabric%'], //spaces on each side
        ]);          
        $off_productCollection->setFlag('has_stock_status_filter', true)
        ->joinField(
            'stock_item',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            'is_in_stock=1'
        );
        
        /*$off_productCollection->getSelect()->joinLeft(
            [ 'stocktable' => 'cataloginventory_stock_status' ],
            'e.entity_id = stocktable.product_id',
            []
        );
        $off_subquery = new \Zend_Db_Expr('(SELECT sku, SUM(quantity) as salableqty FROM
                                           inventory_reservation GROUP BY sku)');
        $off_joinConditions = 'e.sku = reservetable.sku';
        $off_productCollection->getSelect()->joinLeft(
            [ 'reservetable' => $off_subquery ],
            $off_joinConditions,
            []
        )->columns("(IFNULL(reservetable.salableqty,0) + stocktable.qty) AS final_qty")
                 ->where("(IFNULL(reservetable.salableqty,0) + stocktable.qty) > 0");*/

        return $off_productCollection->getSize();
    }

    public function getOrderCollectionCount()
    {
        $collection = $this->_orderCollectionFactory->create()
        ->addAttributeToFilter('status', 'processing');

        return $collection->getSize();
    }
    
    public function getDateOrderCollectionCount($from)
    {
        $datecollection = $this->_orderCollectionFactory->create()
        ->addAttributeToFilter('status', 'processing');
        $datecollection->addFieldToFilter('created_at', ['lt'=>$from]);
        
        return $datecollection->getSize();
    }
    
    /*
     *return customer login or not
     */
    public function chechLogin()
    {
        return $this->Session->create()->isLoggedIn();
    }
    
    public function getCustomerEmail()
    {
        return $this->Session->create()->getCustomer()->getEmail();
    }

    public function setRedirect($path)
    {
        return $this->httpresponse->setRedirect($path);
    }

    /**
     * Function returns store currency symbol
     */
    public function getCurrencySymbol($code)
    {
        return $this->currency->getCurrency($code)->getSymbol();
    }

    public function getActiveCounterItems()
    {
        
        $counteritems = [];
        $countermaster = $this->CountermasterFactory->create()->addFieldToFilter('status', 1);
        if (count($countermaster)>0):
             $counteritems = $this->CounteritemsFactory->create()->addFieldToFilter(
                 'parent_id',
                 $countermaster->getLastItem()->getId()
             );
        endif;
        return $counteritems;
    }
}
