## Nalli_Dashboard
-------------
This module contain Custom customer account dashboard functionalities.


## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Dashboard
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
Custom Dashboard functionalities of Account page,recentview listing page,whishlist page,order history page.


## Copyright
---------
Copyright (c) 2022. 18th DigiTech Team. All rights reserved.