<?php
 /**
  * Custom Account Dashboard
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Dashboard
  */
namespace Nalli\Dashboard\Block;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\Data\ShipmentItemInterface;
use Magento\Sales\Api\ShipmentItemRepositoryInterface;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Magento\Framework\UrlInterface;

class Display extends \Magento\Framework\View\Element\Template
{
    /**
     * @var WishlistCollectionFactory
     */
    protected $_wishlistCollectionFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Customer\Model\SessionFactory $customer
     * @param \Magento\Reports\Block\Product\Viewed $recentlyViewed
     * @param \Magento\Customer\Model\AddressFactory $addressFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\Helper\Image $imageUrl
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ShipmentItemRepositoryInterface $shipmentItem
     * @param ShipmentRepositoryInterface $shipmentRepository
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Wishlist\Helper\Data $wishlistHelper
     * @param \Magento\Shipping\Helper\Data $shippinghelper
     * @param \Magento\Catalog\Helper\Image $_imageHelper
     */

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\SessionFactory $customer,
        \Magento\Reports\Block\Product\Viewed $recentlyViewed,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Helper\Image $imageUrl,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        ShipmentItemRepositoryInterface $shipmentItem,
        ShipmentRepositoryInterface $shipmentRepository,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Wishlist\Helper\Data $wishlistHelper,
        \Magento\Shipping\Helper\Data $shippinghelper,
        \Magento\Catalog\Helper\Image $_imageHelper
    ) {
        parent::__construct($context);
        $this->customer = $customer;
        $this->recentlyViewed = $recentlyViewed;
        $this->addressFactory = $addressFactory;
        $this->productFactory = $productFactory;
        $this->imageUrl = $imageUrl;
        $this->priceHelper = $priceHelper;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->shipmentItem = $shipmentItem;
        $this->shipmentRepository = $shipmentRepository;
        $this->logger = $logger;
        $this->helperData = $wishlistHelper;
        $this->shippinghelper = $shippinghelper;
        $this->urlInterface = $context->getUrlBuilder();
        $this->_imageHelper = $_imageHelper;
    }

    /**
     * Fetch shipment data
     * @param $orderItemId
     * @return string
     */
    public function getShipmentItem(int $orderItemId): ?array
    {
        $searchCriteria = $this->searchCriteriaBuilder->addFilter('order_item_id', $orderItemId)->create();
 
        $shipmentItems = null;
        try {
            $shipment = $this->shipmentItem->getList($searchCriteria);
            if ($shipment->getTotalCount()) {
                $shipmentItems = $shipment->getItems();
                foreach ($shipmentItems as $items) {
                     $shipment = $this->shipmentRepository->get($items->getParentId());
                     // print_r($shipment->getCreatedAt());
                    if ($shipment) {
                        return $shipment->getData();
                    } else {
                        return false;
                    }
                     
                }
                    
            } else {
                return null;
            }
        } catch (Exception $e) {
            $this->logger->critical($e->getMessage());
            
        }
    }
	
	 /**
     * Fetch customer name
     * @return string
     */
    public function getCustomerDetail()
    {
        // print_r(get_class_methods($this->customer)); die();
        $customer = $this->customer->create();
        // print_r($customer->getCustomer()->getData()); exit;
        if ($customer->isLoggedIn()) {
            return $customer->getCustomer();
        }
    }
	
    /**
     * Fetch customer name
     * @return string
     */
    public function getCustomerName()
    {
        // print_r(get_class_methods($this->customer)); die();
        $customer = $this->customer->create();
        // print_r($customer->getCustomer()->getData()); exit;
        if ($customer->isLoggedIn()) {
            return $customer->getCustomer()->getFirstname();
        }
    }
    /**
     * Check customer session
     * @return string
     */
    public function redirectIfNotLoggedIn()
    {
        $customer = $this->customer->create();
        if (!$customer->isLoggedIn()) {
            $customer->setAfterAuthUrl($this->urlInterface->getCurrentUrl());
            $customer->authenticate();
        }
    }
    /**
     * Fetch customer Telephone
     * @param $defbilling
     * @return string
     */
    public function getCustomerTelephone($defbilling)
    {
        $this->addressFactory = $this->addressFactory->create();
        $billingAddress = $this->addressFactory->load($defbilling);
        return $billingAddress->getTelephone();
    }

    /**
     * Get most viewed collection
     * @return array
     */
    public function getMostRecentlyViewed()
    {
        $col = $this->recentlyViewed->getItemsCollection()->addAttributeToSelect('*')->load();
          return $col;
    }

    /**
     * load product by id
     * @param $prodid
     * @return array
     */
    public function getProductLoader($prodid)
    {
        return $this->productFactory->create()->load($prodid);
    }

    /**
     * Get image
     * @param $product
     * @return string
     */
    public function getImageUrl($product)
    {
        return $imageUrl = $this->imageUrl->init($product, 'product_base_image')
                ->setImageFile($product->getImage()) // image,small_image,thumbnail
                ->resize(350)
                ->getUrl();
    }

    /**
     * Get image
     * @param $product
     * @return string
     */
    public function getImageUrlorder($product)
    {
        return $imageUrl = $this->imageUrl->init($product, 'product_base_image')
                ->setImageFile($product->getImage()) // image,small_image,thumbnail
                ->resize(100)
                ->getUrl();
    }

    /**
     * Instance of Pricing
     * @param $price
     * @return string
     */
    public function getPrice($price)
    {
        return $this->priceHelper->currency($price, true, false);
    }

    /**
     * Get wishlist allow
     * @return bool
     */
    public function getWishlistAllow()
    {
        return $this->helperData->isAllow();
    }

    /**
     * Get Order track url
     * @return bool
     */
    public function getOrderTrackUrl($_order)
    {
        return $this->shippinghelper->getTrackingPopupUrlBySalesModel($_order);
    }
    
    /*
     *@return image helper
     */
     
    public function imageHelper()
    {
        return $this->_imageHelper;
    }
}
