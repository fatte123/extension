<?php
 /**
  * Custom Account Dashboard
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Dashboard
  */
namespace Nalli\Dashboard\Block;

class WishlistProducts extends \Magento\Framework\View\Element\Template
{
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Wishlist\Model\WishlistFactory $wishlist
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Webapi\Rest\Request $request
     * @param \Magento\Catalog\Helper\Image $imageUrl
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Wishlist\Model\WishlistFactory $wishlist,
        \Magento\Customer\Model\SessionFactory $customer,
        \Magento\Catalog\Helper\Image $imageUrl,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        array $data = []
    ) {
        $this->wishlist = $wishlist;
        $this->customer = $customer;
        $this->imageUrl = $imageUrl;
        $this->priceHelper = $priceHelper;
        parent::__construct($context, $data);
    }
    /**
     * @return array
     */
    public function getWishlistByCustomerId()
    {
        $customer = $this->customer->create();
        $this->wishlist = $this->wishlist->create();
        // print_r(get_class_methods($wishlist)); exit;
        // print_r($customer->getCustomer()->getId()); exit;
        $customerId = $customer->getCustomer()->getId();
        $this->_productCollection = $this->wishlist->loadByCustomerId($customerId)
        ->getItemCollection();//->setPageSize(10)->setCurPage(1);
        $this->_productCollection->setOrder('position', 'DESC');
        return $this->_productCollection;
    }

    /**
     * @param $product
     * @return string
     */
    public function getImageUrl($product)
    {
        return $imageUrl = $this->imageUrl->init($product, 'product_base_image')
                ->setImageFile($product->getImage()) // image,small_image,thumbnail
                ->resize(350) 
                ->getUrl();
    }

    /**
     * Get Currency Price
     * @param $price
     * @return string
     */
    public function getPrice($price)
    {
        return $this->priceHelper->currency($price, true, false);
    }
}
