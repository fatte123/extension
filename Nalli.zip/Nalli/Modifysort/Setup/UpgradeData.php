<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Modifysort
 */
namespace Nalli\Modifysort\Setup;

use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Eav\Setup\EavSetup; 

class UpgradeData implements UpgradeDataInterface 
{
    public function __construct(
        EavSetup $eavSetupFactory
        ) 
    { 
        $this->eavSetupFactory = $eavSetupFactory; 
    } 
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context) { 
        $setup->startSetup();
        $this->eavSetupFactory->updateAttribute(\Magento\Catalog\Model\Product::ENTITY, 'created_at', 'used_for_sort_by', 1); 
        $setup->endSetup(); 
    } 

}