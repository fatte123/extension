<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Modifysort
 */
namespace Nalli\Modifysort\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
	 /**
     * Eav setup factory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactor;
	/**
     * Init
     *
     * @param EavSetupFactory $eavSetupFactory eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }
	
	public function upgrade( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
		$installer = $setup;

		$installer->startSetup();

		if(version_compare($context->getVersion(), '1.0.0', '<')) {
		
		$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
		$eavSetup->updateAttribute( \Magento\Catalog\Model\Product::ENTITY, 'created_at', 'used_for_sort_by', 1);
		}



		$installer->endSetup();
	}
}