<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Modifysort
 */
 
namespace Nalli\Modifysort\Block\Product\ProductList;

class Toolbar extends \Magento\Catalog\Block\Product\ProductList\Toolbar
{
    public function setCollection($collection)
    {
        $this->_collection = $collection;
        $this->_collection->setCurPage($this->getCurrentPage());

        $limit = (int) $this->getLimit();
        if ($limit) {
            $this->_collection->setPageSize($limit);
        }

        if ($this->getCurrentOrder()) {
            // Costruisco la custom query
            switch ($this->getCurrentOrder()) {
                case 'new_arrivals':
                 $this->_collection->setOrder('created_at', $this->getCurrentDirectionReverse());
					break;
                case 'name':
                    $this->_collection->setOrder('name', 'DESC');
                    break;
                case 'low_to_high':
                    $this->_collection->setOrder('price', 'ASC');
                    break;
                case 'high_to_low':
                    $this->_collection->setOrder('price', 'DESC');
                    break;
                
                case 'bestseller':
                    $this->_collection->getSelect()->joinLeft(
                        'sales_order_item',
                        'e.entity_id = sales_order_item.product_id',
                        ['qty_ordered' => 'SUM(sales_order_item.qty_ordered)']
                    )
                        ->group('e.entity_id')
                        ->order('qty_ordered DESC');
                    break;
                default:
                    $this->_collection->setOrder($this->getCurrentOrder(), $this->getCurrentDirection());
                    break;
            }
        }
        //echo $this->_collection->getSelect();die;
        return $this;
    }
	
	/**
     * Return Reverse direction of current direction
     *
     * @return string
     */
    public function getCurrentDirectionReverse()
    {
        if ($this->getCurrentDirection() == 'asc') {
            return 'desc';
        } elseif ($this->getCurrentDirection() == 'desc') {
            return 'asc';
        } else {
            return $this->getCurrentDirection();
        }
    }
}
