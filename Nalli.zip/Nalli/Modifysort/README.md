# Nalli_Modifysort

This module contain sort by options.

## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Nalli_Modifysort
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage

goto https://www.nalli.com/ and any list page to check all the sort by obtion's
