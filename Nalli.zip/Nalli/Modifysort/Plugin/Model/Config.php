<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Modifysort
 */
 
namespace Nalli\Modifysort\Plugin\Model;

use Magento\Store\Model\StoreManagerInterface;

class Config
{
    protected $_storeManager;

    public function __construct(
        StoreManagerInterface $storeManager
    ) {
        $this->_storeManager = $storeManager;
    }

    /**
     * Adding custom options and changing labels
     *
     * @param \Magento\Catalog\Model\Config $catalogConfig
     * @param [] $options
     * @return []
     */
    public function afterGetAttributeUsedForSortByArray(\Magento\Catalog\Model\Config $catalogConfig, $options)
    {
        //Remove specific default sorting options
        unset($options['position']);
        unset($options['name']);
        unset($options['price']);
		unset($options['created_at']);
        //Changing label
        $customOption['position'] = __('Relevance');

        //New sorting options
        $customOption['new_arrivals'] = __('New Products');
        $customOption['high_to_low'] = __('Price: High to Low');
        $customOption['low_to_high'] = __('Price: Low to High');
		
		

        //Merge default sorting options with custom options
        $options = array_merge($customOption, $options);

        return $options;
    }
}
