<?php

namespace Nalli\SoldProductAdvanced\Console;

use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\Collection as SoldProductCol;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Sales\Model\ResourceModel\Order\Item\Collection as OrderItemCollection;
use Magento\Eav\Model\Config;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\File\Csv;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;

class UpdateCounter extends Command
{
    public const TABLE_NAME = 'nalli_soldproductadvanced';
    /**
     * collection limit
     *
     */
    public const LIMIT = 'limit';
    /**
     * collection offset
     */
    public const OFFSET = 'offset';

    /**
     * @var Config
     */
    protected Config $eavConfig;
    /**
     * @var OrderItemCollection
     */
    protected OrderItemCollection $orderItemsCollection;
    /**
     * @var SoldProductCol
     */
    protected SoldProductCol $soldProductCol;
    /**
     * @var ResourceConnection|string|null
     */
    protected $_resource;
    /**
     * @var DirectoryList
     */
    protected $directoryList;
/**
 * @var Csv
 */
    protected $csv;
/**
 * @var File
 */
    protected $file;

    /**
     * @inheritDoc
     */
    public function __construct(
        ResourceConnection $_resource,
        SoldProductCol $soldProductCol,
        OrderItemCollection $orderItemsCollection,
        Config $eavConfig,
        DirectoryList $directoryList,
        Csv $csv,
        File $file,
        string $name = null
    ) {
        parent::__construct($name);
        $this->eavConfig = $eavConfig;
        $this->orderItemsCollection = $orderItemsCollection;
        $this->soldProductCol = $soldProductCol;
        $this->_resource = $_resource;
        $this->directoryList = $directoryList;
        $this->csv = $csv;
        $this->file = $file;
    }

    /**
     * Function to write values from CSV file
     *
     * @param string $csvFile
     * @param array $uniqueKey
     * @param \Magento\Framework\DB\Adapter\AdapterInterface $connection
     * @param OutputInterface $output
     * @param \Zend_Log $logger
     * @return void
     * @throws \Exception
     */
    public function writeFromCsv(
        string $csvFile,
        array $uniqueKey,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection,
        OutputInterface $output,
        \Zend_Log $logger
    ) {
        try {
            if ($this->file->isExists($csvFile)) {
                $this->csv->setDelimiter(",");
                $data = $this->csv->getData($csvFile);

                if (!empty($data)) {
                    foreach (array_slice($data, 1) as $key => $value) {
                        $columnFirst = trim($value[0]);
                        $bind = ['counter' => trim($value[7])];
                        $where = ['sku' . ' = ?' => $columnFirst];

                        if (in_array($columnFirst, $uniqueKey)) {
                            $connection->update(self::TABLE_NAME, $bind, $where);
                        }
                    }
                }
            } else {
                $output->writeln(__('Csv File not exist'));
            }
        } catch (FileSystemException $exception) {
            $logger->info($exception->getMessage());
        }
    }

    /**
     * Configure console command
     *
     * @return void
     */
    protected function configure()
    {
        $options = [
            new InputOption(
                self::LIMIT,
                null,
                InputOption::VALUE_OPTIONAL,
                'Limit'
            ),
            new InputOption(
                'csvfile',
                null,
                InputOption::VALUE_REQUIRED,
                'CSV File'
            )
        ];
        $this->setName('upload:soldproduct:counter');
        $this->setDescription('Update SoldProduct Counter');
        $this->setDefinition($options);

        parent::configure();
    }

    /**
     *  Update sold product Counter data
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $writer = new \Zend_Log_Writer_Stream(
            BP . '/var/log/console_soldcounter.log'
        );
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $csvFilePath = $input->getOption('csvfile');

        $resource = $this->_resource;
        $connection = $resource->getConnection();
        $existingRecord = $this->soldProductCol;
        $allSku = [];

        if ($existingRecord->count() > 0) {
            foreach ($existingRecord as $key => $value) {
                $allSku[] = $value['sku'];
            }
            $uniqueKey =array_unique($allSku);
            $rootDirectory = $this->directoryList->getRoot();
            $csvFile = $rootDirectory . "/var/log/" . $csvFilePath;
            $this->writeFromCsv($csvFile, $uniqueKey, $connection, $output, $logger);
        }
    }
}
