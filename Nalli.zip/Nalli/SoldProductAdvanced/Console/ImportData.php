<?php

namespace Nalli\SoldProductAdvanced\Console;

use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\Collection as SoldProductCol;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Sales\Model\ResourceModel\Order\Item\Collection as OrderItemCollection;
use Magento\Eav\Model\Config;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\App\ResourceConnection;

class ImportData extends Command
{
    public const TABLE_NAME = 'nalli_soldproductadvanced';
    /**
     * collection limit
     *
     */
    public const LIMIT = 'limit';
    /**
     * collection offset
     */
    public const OFFSET = 'offset';

    /**
     * @var Config
     */
    protected Config $eavConfig;
    /**
     * @var OrderItemCollection
     */
    protected OrderItemCollection $orderItemsCollection;
    /**
     * @var SoldProductCol
     */
    protected SoldProductCol $soldProductCol;
    /**
     * @var ResourceConnection|string|null
     */
    protected $_resource;

    /**
     * @inheritDoc
     */
    public function __construct(
        ResourceConnection $_resource,
        SoldProductCol $soldProductCol,
        OrderItemCollection $orderItemsCollection,
        Config $eavConfig,
        string $name = null
    ) {
        parent::__construct($name);
        $this->eavConfig = $eavConfig;
        $this->orderItemsCollection = $orderItemsCollection;
        $this->soldProductCol = $soldProductCol;
        $this->_resource = $_resource;
    }

    /**
     * Configure console command
     *
     * @return void
     */
    protected function configure()
    {
        $options = [
            new InputOption(
                self::LIMIT,
                null,
                InputOption::VALUE_OPTIONAL,
                'Limit'
            ),
            new InputOption(
                self::OFFSET,
                null,
                InputOption::VALUE_OPTIONAL,
                'Offset'
            )
        ];
        $this->setName('import:soldproductadv');
        $this->setDescription('Import SoldProductAdvance');
        $this->setDefinition($options);

        parent::configure();
    }

    /**
     *  Import sold product data
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $writer = new \Zend_Log_Writer_Stream(
            BP . '/var/log/console_soldproduct.log'
        );
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $collection = $this->getDataCollection();
        $limitConf = $input->getOption(self::LIMIT);
        $offsetConf = $input->getOption(self::OFFSET);
        if ($limitConf) {
            $collection->getSelect()->limit(
                $limitConf,
                $offsetConf??''
            );
        }
        try {
            $resource = $this->_resource;
            $connection = $resource->getConnection();
            $existingRecord = $this->soldProductCol;
            if ($existingRecord->count() > 0) {
                $select = $connection->select()->from(
                    self::TABLE_NAME,
                    '(item_id)'
                )->order('soldproductadvance_id desc')
                ->limit(1);

                $lastDate = $connection->fetchOne($select);

                $collection->getSelect()
                    ->where('main_table.item_id > ?', $lastDate);
                $logger->info("Count: ". $collection->count());
            }

            $bulkInsert = [];
            $log = [];
            foreach ($collection as $record) {
                $bulkInsert[] = $record->getData();
            }
            $totalRecords = $collection->count();
            $pageSize = $limitConf;
            $page = 1;
            $log['error_count'] = 0;

            if ($bulkInsert) {
                $totalPages = ceil($totalRecords / $pageSize);
                if ($totalRecords > $pageSize) {
                    while ($page <= $totalPages) {
                        $offset = ($page - 1) * $pageSize;
                        $pageData = array_slice($bulkInsert, $offset, $pageSize, true);
                        if ($this->doBulkUpdate($pageData)) {
                            $log['status'] = 'Success';
                            $log['import_log'] = "Record Updated successfully -for Page: {$page}, Offset: {$offset}";
                            $logger->info('', $log);
                        } else {
                            $log['status'] = 'Error';
                            $log['error_count'] += count($pageData);
                            $log['import_log'] = "Error during update - Page: {$page}, Offset: {$offset}";
                            $logger->info('', $log);
                        }
                        $page++;
                    }
                } else {
                    if ($this->doBulkUpdate($bulkInsert)) {
                        $log['status'] = 'Success';
                        $log['import_log'] ="Record Updated successfully.";
                        $logger->info('', $log);
                    } else {
                        $log['status'] = 'Error';
                        $log['error_count'] += count($bulkInsert);
                        $log['import_log'] ="Error during update";
                        $logger->info('', $log);
                    }
                }
            }
        } catch (CouldNotSaveException $exception) {
            $logger->info($exception->getMessage());
        }
    }

    /**
     * Do bulk insert
     *
     * @param array $pageData
     * @return bool
     */
    private function doBulkUpdate($pageData)
    {
        $connection = $this->_resource->getConnection();
        if ($pageData) {
            try {
                $connection->beginTransaction();
                $connection->insertMultiple(self::TABLE_NAME, $pageData);
                $connection->commit();
                return true;
            } catch (\Exception $ex) {
                $connection->rollBack();
                return false;
            }
        }
        return false;
    }

    /**
     * Get Collection
     *
     * @return OrderItemCollection
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function getDataCollection()
    {
        $collection = $this->orderItemsCollection;
        $collection->addFieldToSelect('item_id');
        $collection->addAttributeToSelect('sku');
        $collection->addAttributeToSelect('product_id');
        $collection->addAttributeToSelect('name');
        $collection->addAttributeToSelect('base_price');
        $collection->getSelect()->joinLeft(
            'sales_order',
            'main_table.order_id = sales_order.entity_id',
            ['increment_id', 'status', 'order_date' => 'created_at',
                'billing_address_id', 'shipping_address_id'
            ]
        );

        $collection->getSelect()

            ->joinLeft(
                'sales_order_address as billaddr',
                'sales_order.billing_address_id = billaddr.entity_id',
                [
                    'billing_country' => 'country_id',
                    'billing_city' => 'city',
                    'billing_region' => 'region'
                ]
            )
            ->joinLeft(
                'sales_order_address as shipaddr',
                'sales_order.shipping_address_id = shipaddr.entity_id',
                [
                    'shipping_country' => 'country_id',
                    'shipping_city' => 'city',
                    'shipping_region' => 'region'
                ]
            );

        $collection->getSelect()->joinLeft(
            'catalog_product_entity',
            'main_table.product_id = catalog_product_entity.entity_id',
            [
                'product_created_at' => 'created_at',
                'product_sku' => 'sku'
            ]
        );

        $attributes = [
            'atc_count', 'article_type', 'border',
            'border_type', 'blouse', 'color',
            'counter', 'fabric_purity',
            'magentoone_upload', 'magentoone_views', 'magentoone_totalimpressions',
            'magentoone_atc', 'material', 'no_of_views',
            'occasion', 'ornamentation_type', 'pattern',
            'price', 'small_image', 'store_code',
            'style_of_work', 'supplier_code', 'technique',
            'total_impressions', 'url_key','image', 'zari_type'
        ];

        foreach ($attributes as $attribute) {
            $eav = $this->eavConfig->getAttribute('catalog_product', $attribute);
            $collection->getSelect()

                ->joinLeft(
                    [$attribute => $eav->getBackendTable()],
                    "main_table.product_id = {$attribute}.row_id AND

                        {$attribute}.attribute_id = {$eav->getAttributeId()}",
                    [$attribute => 'value']
                );

        }
        $collection->getSelect()->columns(
            "IF( IFNULL(`magentoone_upload`.`value`, 0) = 0,
            DATEDIFF(`sales_order`.`created_at`, `catalog_product_entity`.`created_at`),
             DATEDIFF(`sales_order`.`created_at`, `magentoone_upload`.`value`) ) as age"
        );

        $collection->getSelect()->columns(
            "(((IFNULL(`no_of_views`.`value`,0)
            + IFNULL(`magentoone_views`.`value`,0)) / (IFNULL(`total_impressions`.`value`,0)
            + IFNULL(`magentoone_totalimpressions`.`value`,0))) * 1000) as views_impressions"
        );

        $collection->getSelect()->columns("(((IFNULL(`atc_count`.`value`,0)
        + IFNULL(`magentoone_atc`.`value`,0)) / (IFNULL(`no_of_views`.`value`,0)
        + IFNULL(`magentoone_views`.`value`,0))) * 100) as atc_views");

        $collection->getSelect()->columns("(IFNULL(`atc_count`.`value`,0)
        + IFNULL(`magentoone_atc`.`value`,0)) as atc");

        $collection->getSelect()->group('main_table.item_id');
        return $collection;
    }
}
