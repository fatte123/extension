<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Model;

use Magento\Framework\Model\AbstractModel;
use Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface;

class SoldProductAdvance extends AbstractModel implements SoldProductAdvanceInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance::class);
    }

    /**
     * @inheritDoc
     */
    public function getSoldproductadvanceId()
    {
        return $this->getData(self::SOLDPRODUCTADVANCE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSoldproductadvanceId($soldproductadvanceId)
    {
        return $this->setData(self::SOLDPRODUCTADVANCE_ID, $soldproductadvanceId);
    }

    /**
     * @inheritDoc
     */
    public function getSku()
    {
        return $this->getData(self::SKU);
    }

    /**
     * @inheritDoc
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * @inheritDoc
     */
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getBasePrice()
    {
        return $this->getData(self::BASE_PRICE);
    }

    /**
     * @inheritDoc
     */
    public function setBasePrice($basePrice)
    {
        return $this->setData(self::BASE_PRICE, $basePrice);
    }

    /**
     * @inheritDoc
     */
    public function getIncrementId()
    {
        return $this->getData(self::INCREMENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setIncrementId($incrementId)
    {
        return $this->setData(self::INCREMENT_ID, $incrementId);
    }

    /**
     * @inheritDoc
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * @inheritDoc
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * @inheritDoc
     */
    public function getOrderDate()
    {
        return $this->getData(self::ORDER_DATE);
    }

    /**
     * @inheritDoc
     */
    public function setOrderDate($orderDate)
    {
        return $this->setData(self::ORDER_DATE, $orderDate);
    }

    /**
     * @inheritDoc
     */
    public function getBillingAddressId()
    {
        return $this->getData(self::BILLING_ADDRESS_ID);
    }

    /**
     * @inheritDoc
     */
    public function setBillingAddressId($billingAddressId)
    {
        return $this->setData(self::BILLING_ADDRESS_ID, $billingAddressId);
    }

    /**
     * @inheritDoc
     */
    public function getShippingAddressId()
    {
        return $this->getData(self::SHIPPING_ADDRESS_ID);
    }

    /**
     * @inheritDoc
     */
    public function setShippingAddressId($shippingAddressId)
    {
        return $this->setData(self::SHIPPING_ADDRESS_ID, $shippingAddressId);
    }

    /**
     * @inheritDoc
     */
    public function getBillingCountry()
    {
        return $this->getData(self::BILLING_COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setBillingCountry($billingCountry)
    {
        return $this->setData(self::BILLING_COUNTRY, $billingCountry);
    }

    /**
     * @inheritDoc
     */
    public function getBillingCity()
    {
        return $this->getData(self::BILLING_CITY);
    }

    /**
     * @inheritDoc
     */
    public function setBillingCity($billingCity)
    {
        return $this->setData(self::BILLING_CITY, $billingCity);
    }

    /**
     * @inheritDoc
     */
    public function getBillingRegion()
    {
        return $this->getData(self::BILLING_REGION);
    }

    /**
     * @inheritDoc
     */
    public function setBillingRegion($billingRegion)
    {
        return $this->setData(self::BILLING_REGION, $billingRegion);
    }

    /**
     * @inheritDoc
     */
    public function getShippingCountry()
    {
        return $this->getData(self::SHIPPING_COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setShippingCountry($shippingCountry)
    {
        return $this->setData(self::SHIPPING_COUNTRY, $shippingCountry);
    }

    /**
     * @inheritDoc
     */
    public function getShippingCity()
    {
        return $this->getData(self::SHIPPING_CITY);
    }

    /**
     * @inheritDoc
     */
    public function setShippingCity($shippingCity)
    {
        return $this->setData(self::SHIPPING_CITY, $shippingCity);
    }

    /**
     * @inheritDoc
     */
    public function getShippingRegion()
    {
        return $this->getData(self::SHIPPING_REGION);
    }

    /**
     * @inheritDoc
     */
    public function setShippingRegion($shippingRegion)
    {
        return $this->setData(self::SHIPPING_REGION, $shippingRegion);
    }

    /**
     * @inheritDoc
     */
    public function getProductCreatedAt()
    {
        return $this->getData(self::PRODUCT_CREATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setProductCreatedAt($productCreatedAt)
    {
        return $this->setData(self::PRODUCT_CREATED_AT, $productCreatedAt);
    }

    /**
     * @inheritDoc
     */
    public function getProductSku()
    {
        return $this->getData(self::PRODUCT_SKU);
    }

    /**
     * @inheritDoc
     */
    public function setProductSku($productSku)
    {
        return $this->setData(self::PRODUCT_SKU, $productSku);
    }

    /**
     * @inheritDoc
     */
    public function getAtcCount()
    {
        return $this->getData(self::ATC_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function setAtcCount($atcCount)
    {
        return $this->setData(self::ATC_COUNT, $atcCount);
    }

    /**
     * @inheritDoc
     */
    public function getArticleType()
    {
        return $this->getData(self::ARTICLE_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setArticleType($articleType)
    {
        return $this->setData(self::ARTICLE_TYPE, $articleType);
    }

    /**
     * @inheritDoc
     */
    public function getBorder()
    {
        return $this->getData(self::BORDER);
    }

    /**
     * @inheritDoc
     */
    public function setBorder($border)
    {
        return $this->setData(self::BORDER, $border);
    }

    /**
     * @inheritDoc
     */
    public function getBorderType()
    {
        return $this->getData(self::BORDER_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setBorderType($borderType)
    {
        return $this->setData(self::BORDER_TYPE, $borderType);
    }

    /**
     * @inheritDoc
     */
    public function getBlouse()
    {
        return $this->getData(self::BLOUSE);
    }

    /**
     * @inheritDoc
     */
    public function setBlouse($blouse)
    {
        return $this->setData(self::BLOUSE, $blouse);
    }

    /**
     * @inheritDoc
     */
    public function getColor()
    {
        return $this->getData(self::COLOR);
    }

    /**
     * @inheritDoc
     */
    public function setColor($color)
    {
        return $this->setData(self::COLOR, $color);
    }

    /**
     * @inheritDoc
     */
    public function getCounter()
    {
        return $this->getData(self::COUNTER);
    }

    /**
     * @inheritDoc
     */
    public function setCounter($counter)
    {
        return $this->setData(self::COUNTER, $counter);
    }

    /**
     * @inheritDoc
     */
    public function getFabricPurity()
    {
        return $this->getData(self::FABRIC_PURITY);
    }

    /**
     * @inheritDoc
     */
    public function setFabricPurity($fabricPurity)
    {
        return $this->setData(self::FABRIC_PURITY, $fabricPurity);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneUpload()
    {
        return $this->getData(self::MAGENTOONE_UPLOAD);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneUpload($magentooneUpload)
    {
        return $this->setData(self::MAGENTOONE_UPLOAD, $magentooneUpload);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneViews()
    {
        return $this->getData(self::MAGENTOONE_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneViews($magentooneViews)
    {
        return $this->setData(self::MAGENTOONE_VIEWS, $magentooneViews);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneTotalimpressions()
    {
        return $this->getData(self::MAGENTOONE_TOTALIMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneTotalimpressions($magentooneTotalimpressions)
    {
        return $this->setData(self::MAGENTOONE_TOTALIMPRESSIONS, $magentooneTotalimpressions);
    }

    /**
     * @inheritDoc
     */
    public function getMagentooneAtc()
    {
        return $this->getData(self::MAGENTOONE_ATC);
    }

    /**
     * @inheritDoc
     */
    public function setMagentooneAtc($magentooneAtc)
    {
        return $this->setData(self::MAGENTOONE_ATC, $magentooneAtc);
    }

    /**
     * @inheritDoc
     */
    public function getMaterial()
    {
        return $this->getData(self::MATERIAL);
    }

    /**
     * @inheritDoc
     */
    public function setMaterial($material)
    {
        return $this->setData(self::MATERIAL, $material);
    }

    /**
     * @inheritDoc
     */
    public function getNoOfViews()
    {
        return $this->getData(self::NO_OF_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setNoOfViews($noOfViews)
    {
        return $this->setData(self::NO_OF_VIEWS, $noOfViews);
    }

    /**
     * @inheritDoc
     */
    public function getOccasion()
    {
        return $this->getData(self::OCCASION);
    }

    /**
     * @inheritDoc
     */
    public function setOccasion($occasion)
    {
        return $this->setData(self::OCCASION, $occasion);
    }

    /**
     * @inheritDoc
     */
    public function getOrnamentationType()
    {
        return $this->getData(self::ORNAMENTATION_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setOrnamentationType($ornamentationType)
    {
        return $this->setData(self::ORNAMENTATION_TYPE, $ornamentationType);
    }

    /**
     * @inheritDoc
     */
    public function getPattern()
    {
        return $this->getData(self::PATTERN);
    }

    /**
     * @inheritDoc
     */
    public function setPattern($pattern)
    {
        return $this->setData(self::PATTERN, $pattern);
    }

    /**
     * @inheritDoc
     */
    public function getPrice()
    {
        return $this->getData(self::PRICE);
    }

    /**
     * @inheritDoc
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * @inheritDoc
     */
    public function getSmallImage()
    {
        return $this->getData(self::SMALL_IMAGE);
    }

    /**
     * @inheritDoc
     */
    public function setSmallImage($smallImage)
    {
        return $this->setData(self::SMALL_IMAGE, $smallImage);
    }

    /**
     * @inheritDoc
     */
    public function getStoreCode()
    {
        return $this->getData(self::STORE_CODE);
    }

    /**
     * @inheritDoc
     */
    public function setStoreCode($storeCode)
    {
        return $this->setData(self::STORE_CODE, $storeCode);
    }

    /**
     * @inheritDoc
     */
    public function getStyleOfWork()
    {
        return $this->getData(self::STYLE_OF_WORK);
    }

    /**
     * @inheritDoc
     */
    public function setStyleOfWork($styleOfWork)
    {
        return $this->setData(self::STYLE_OF_WORK, $styleOfWork);
    }

    /**
     * @inheritDoc
     */
    public function getSupplierCode()
    {
        return $this->getData(self::SUPPLIER_CODE);
    }

    /**
     * @inheritDoc
     */
    public function setSupplierCode($supplierCode)
    {
        return $this->setData(self::SUPPLIER_CODE, $supplierCode);
    }

    /**
     * @inheritDoc
     */
    public function getTechnique()
    {
        return $this->getData(self::TECHNIQUE);
    }

    /**
     * @inheritDoc
     */
    public function setTechnique($technique)
    {
        return $this->setData(self::TECHNIQUE, $technique);
    }

    /**
     * @inheritDoc
     */
    public function getTotalImpressions()
    {
        return $this->getData(self::TOTAL_IMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setTotalImpressions($totalImpressions)
    {
        return $this->setData(self::TOTAL_IMPRESSIONS, $totalImpressions);
    }

    /**
     * @inheritDoc
     */
    public function getUrlKey()
    {
        return $this->getData(self::URL_KEY);
    }

    /**
     * @inheritDoc
     */
    public function setUrlKey($urlKey)
    {
        return $this->setData(self::URL_KEY, $urlKey);
    }

    /**
     * @inheritDoc
     */
    public function getImage()
    {
        return $this->getData(self::IMAGE);
    }

    /**
     * @inheritDoc
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     * @inheritDoc
     */
    public function getZariType()
    {
        return $this->getData(self::ZARI_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setZariType($zariType)
    {
        return $this->setData(self::ZARI_TYPE, $zariType);
    }

    /**
     * @inheritDoc
     */
    public function getAge()
    {
        return $this->getData(self::AGE);
    }

    /**
     * @inheritDoc
     */
    public function setAge($age)
    {
        return $this->setData(self::AGE, $age);
    }

    /**
     * @inheritDoc
     */
    public function getViewsImpressions()
    {
        return $this->getData(self::VIEWS_IMPRESSIONS);
    }

    /**
     * @inheritDoc
     */
    public function setViewsImpressions($viewsImpressions)
    {
        return $this->setData(self::VIEWS_IMPRESSIONS, $viewsImpressions);
    }

    /**
     * @inheritDoc
     */
    public function getAtcViews()
    {
        return $this->getData(self::ATC_VIEWS);
    }

    /**
     * @inheritDoc
     */
    public function setAtcViews($atcViews)
    {
        return $this->setData(self::ATC_VIEWS, $atcViews);
    }

    /**
     * @inheritDoc
     */
    public function getAtc()
    {
        return $this->getData(self::ATC);
    }

    /**
     * @inheritDoc
     */
    public function setAtc($atc)
    {
        return $this->setData(self::ATC, $atc);
    }
}

