<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class SoldProductAdvance extends AbstractDb
{

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('nalli_soldproductadvanced', 'soldproductadvance_id');
    }
}

