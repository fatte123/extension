<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface;
use Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterfaceFactory;
use Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceSearchResultsInterfaceFactory;
use Nalli\SoldProductAdvanced\Api\SoldProductAdvanceRepositoryInterface;
use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance as ResourceSoldProductAdvance;
use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\CollectionFactory as SoldProductAdvanceCollectionFactory;

class SoldProductAdvanceRepository implements SoldProductAdvanceRepositoryInterface
{

    /**
     * @var ResourceSoldProductAdvance
     */
    protected $resource;

    /**
     * @var SoldProductAdvance
     */
    protected $searchResultsFactory;

    /**
     * @var SoldProductAdvanceCollectionFactory
     */
    protected $soldProductAdvanceCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var SoldProductAdvanceInterfaceFactory
     */
    protected $soldProductAdvanceFactory;


    /**
     * @param ResourceSoldProductAdvance $resource
     * @param SoldProductAdvanceInterfaceFactory $soldProductAdvanceFactory
     * @param SoldProductAdvanceCollectionFactory $soldProductAdvanceCollectionFactory
     * @param SoldProductAdvanceSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceSoldProductAdvance $resource,
        SoldProductAdvanceInterfaceFactory $soldProductAdvanceFactory,
        SoldProductAdvanceCollectionFactory $soldProductAdvanceCollectionFactory,
        SoldProductAdvanceSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->soldProductAdvanceFactory = $soldProductAdvanceFactory;
        $this->soldProductAdvanceCollectionFactory = $soldProductAdvanceCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(
        SoldProductAdvanceInterface $soldProductAdvance
    ) {
        try {
            $this->resource->save($soldProductAdvance);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the soldProductAdvance: %1',
                $exception->getMessage()
            ));
        }
        return $soldProductAdvance;
    }

    /**
     * @inheritDoc
     */
    public function get($soldProductAdvanceId)
    {
        $soldProductAdvance = $this->soldProductAdvanceFactory->create();
        $this->resource->load($soldProductAdvance, $soldProductAdvanceId);
        if (!$soldProductAdvance->getId()) {
            throw new NoSuchEntityException(__('SoldProductAdvance with id "%1" does not exist.', $soldProductAdvanceId));
        }
        return $soldProductAdvance;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->soldProductAdvanceCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(
        SoldProductAdvanceInterface $soldProductAdvance
    ) {
        try {
            $soldProductAdvanceModel = $this->soldProductAdvanceFactory->create();
            $this->resource->load($soldProductAdvanceModel, $soldProductAdvance->getSoldproductadvanceId());
            $this->resource->delete($soldProductAdvanceModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the SoldProductAdvance: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($soldProductAdvanceId)
    {
        return $this->delete($this->get($soldProductAdvanceId));
    }
}

