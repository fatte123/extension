<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Cron;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\App\ResourceConnection;
use Nalli\SoldProductAdvanced\Model\ResourceModel\SoldProductAdvance\Collection as SoldProductCol;
use Magento\Sales\Model\ResourceModel\Order\Item\Collection as OrderItemCollection;
use Magento\Eav\Model\Config;
use Magento\Store\Model\StoreManagerInterface;

class SoldProduct
{
    public const TABLE_NAME = 'nalli_soldproductadvanced';
    public const XML_CRON_CONF = 'soldproduct/general/enable';
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * @var SoldProductCol
     */
    protected $soldProductCol;
    /**
     * @var ResourceConnection
     */
    protected $_resource;
    /**
     * @var OrderItemCollection
     */
    protected $orderItemsCollection;
    /**
     * @var Config
     */
    protected $eavConfig;
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor
     *
     * @param LoggerInterface $logger
     * @param ResourceConnection $_resource
     * @param SoldProductCol $soldProductCol
     * @param OrderItemCollection $orderItemsCollection
     * @param Config $eavConfig
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        LoggerInterface $logger,
        ResourceConnection $_resource,
        SoldProductCol $soldProductCol,
        OrderItemCollection $orderItemsCollection,
        Config $eavConfig,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
    ) {
        $this->logger = $logger;
        $this->soldProductCol = $soldProductCol;
        $this->_resource = $_resource;
        $this->orderItemsCollection = $orderItemsCollection;
        $this->eavConfig = $eavConfig;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Import Sold Product Advance
     *
     * @return void
     */
    public function execute()
    {
        if ($this->getConfigData()) {

            $resource = $this->_resource;
            $connection = $resource->getConnection();
            $collection = $this->getDataCollection();
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/soldAdvproduct.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);

            try {
                $existingData = $this->soldProductCol;
                if ($existingData->count() > 0) {
                    $select = $connection->select()->from(
                        self::TABLE_NAME,
                        '(item_id)'
                    )->order('soldproductadvance_id desc')
                        ->limit(1);
                    $lastDate = $connection->fetchOne($select);
                    $collection->getSelect()
                        ->where('main_table.item_id > ?', $lastDate);
                    $logger->info("Count: ". $collection->count());
                }
                $bulkInsert = [];
                $log = [];
                foreach ($collection as $record) {
                    $bulkInsert[] = $record->getData();
                }
                $totalRecords = $collection->count();
                $pageSize = 1000;
                $page = 1;
                $log['error_count'] = 0;
                if ($bulkInsert) {
                    $totalPages = ceil($totalRecords / $pageSize);
                    $this->sendDataInChunk($totalRecords, $pageSize, $page, $totalPages, $bulkInsert, $log, $logger);
                }
            } catch (CouldNotSaveException $exception) {
                $this->logger->debug("Sold Product Advance Cron:: " . $exception->getMessage());
                $logger->info($exception->getMessage());
            }
        }
    }

    /**
     * Get Cron Config value
     *
     * @return bool
     */
    private function getConfigData()
    {
        return (bool) $this->scopeConfig->getValue(
            self::XML_CRON_CONF,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Do Bulk Update in DB
     *
     * @param array $pageData
     * @return bool
     */
    private function doBulkUpdate($pageData)
    {
        $connection = $this->_resource->getConnection();
        if ($pageData) {
            try {
                $connection->beginTransaction();
                $connection->insertMultiple(self::TABLE_NAME, $pageData);
                $connection->commit();
                return true;
            } catch (\Exception $ex) {
                $this->logger->debug("Sold Product Advance: ". $ex->getMessage());
                $connection->rollBack();
                return false;
            }
        }
        return false;
    }

    /**
     * Get Sold Product Collection
     *
     * @return OrderItemCollection
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function getDataCollection()
    {
        $collection = $this->orderItemsCollection;
        $collection->addFieldToSelect('item_id');
        $collection->addAttributeToSelect('sku');
        $collection->addAttributeToSelect('product_id');
        $collection->addAttributeToSelect('name');
        $collection->addAttributeToSelect('base_price');
        $collection->getSelect()->joinLeft(
            'sales_order',
            'main_table.order_id = sales_order.entity_id',
            ['increment_id', 'status', 'order_date' => 'created_at', 'billing_address_id', 'shipping_address_id']
        );

        $collection->getSelect()

            ->joinLeft(
                'sales_order_address as billaddr',
                'sales_order.billing_address_id = billaddr.entity_id',
                ['billing_country' => 'country_id', 'billing_city' => 'city', 'billing_region' => 'region']
            )

            ->joinLeft(
                'sales_order_address as shipaddr',
                'sales_order.shipping_address_id = shipaddr.entity_id',
                ['shipping_country' => 'country_id', 'shipping_city' => 'city', 'shipping_region' => 'region']
            );

        $collection->getSelect()->joinLeft(
            'catalog_product_entity',
            'main_table.product_id = catalog_product_entity.entity_id',
            ['product_created_at' => 'created_at', 'product_sku' => 'sku']
        );

        $attributes = [
            'atc_count', 'article_type', 'border',
            'border_type', 'blouse', 'color',
            'counter', 'fabric_purity', 'magentoone_upload',
            'magentoone_views', 'magentoone_totalimpressions', 'magentoone_atc',
            'material', 'no_of_views', 'occasion',
            'ornamentation_type', 'pattern', 'price',
            'small_image', 'store_code', 'style_of_work',
            'supplier_code', 'technique', 'total_impressions',
            'url_key','image', 'zari_type'];

        foreach ($attributes as $attribute) {
            $eav = $this->eavConfig->getAttribute('catalog_product', $attribute);
            $collection->getSelect()

                ->joinLeft(
                    [$attribute => $eav->getBackendTable()],
                    "main_table.product_id = {$attribute}.row_id AND

                        {$attribute}.attribute_id = {$eav->getAttributeId()}",
                    [$attribute => 'value']
                );

        }
        $collection->getSelect()->columns(
            "IF( IFNULL(`magentoone_upload`.`value`, 0) = 0,
            DATEDIFF(`sales_order`.`created_at`, `catalog_product_entity`.`created_at`),
            DATEDIFF(`sales_order`.`created_at`, `magentoone_upload`.`value`) ) as age"
        );

        $collection->getSelect()->columns(
            "(((IFNULL(`no_of_views`.`value`,0)
             + IFNULL(`magentoone_views`.`value`,0)) / (IFNULL(`total_impressions`.`value`,0)
              + IFNULL(`magentoone_totalimpressions`.`value`,0))) * 1000) as views_impressions"
        );

        $collection->getSelect()->columns(
            "(((IFNULL(`atc_count`.`value`,0)
            + IFNULL(`magentoone_atc`.`value`,0)) / (IFNULL(`no_of_views`.`value`,0)
             + IFNULL(`magentoone_views`.`value`,0))) * 100) as atc_views"
        );

        $collection->getSelect()->columns("(IFNULL(`atc_count`.`value`,0)
        + IFNULL(`magentoone_atc`.`value`,0)) as atc");

        $collection->getSelect()->group('main_table.item_id');
        return $collection;
    }

    /**
     * Pass the data wih Page and offset limit
     *
     * @param int $totalRecords
     * @param int $pageSize
     * @param int $page
     * @param float $totalPages
     * @param array $bulkInsert
     * @param array $log
     * @param \Zend_Log $logger
     * @return void
     */
    public function sendDataInChunk(
        $totalRecords,
        $pageSize,
        $page,
        $totalPages,
        $bulkInsert,
        $log,
        \Zend_Log $logger
    ) {
        if ($totalRecords > $pageSize) {
            while ($page <= $totalPages) {
                $offset = ($page - 1) * $pageSize;
                $pageData = array_slice($bulkInsert, $offset, $pageSize, true);
                if ($this->doBulkUpdate($pageData)) {
                    $log['status'] = 'Success';
                    $log['import_log'] = "Record Updated successfully -for Page:
                                {$page}, Offset: {$offset}";
                    $this->logger->info("Sold Product Advance::", $log);
                    $logger->info($log['import_log']);
                } else {
                    $log['status'] = 'Error';
                    $log['error_count'] += count($pageData);
                    $log['import_log'] = "Error during update - Page: {$page}, Offset: {$offset}";
                    $this->logger->info("Sold Product Advance::", $log);
                    $logger->info($log['import_log']);
                }
                $page++;
            }
        } else {
            if ($this->doBulkUpdate($bulkInsert)) {
                $log['status'] = 'Success';
                $log['import_log'] = "Record Updated successfully.";
                $this->logger->info("Sold Product Advance::", $log);
                $logger->info($log['import_log']);
            } else {
                $log['status'] = 'Error';
                $log['error_count'] += count($bulkInsert);
                $log['import_log'] = "Error during update";
                $this->logger->info("Sold Product Advance::", $log);
                $logger->info($log['import_log']);
            }
        }
    }
}
