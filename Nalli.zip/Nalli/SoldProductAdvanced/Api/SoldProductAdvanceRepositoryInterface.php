<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SoldProductAdvanceRepositoryInterface
{

    /**
     * Save SoldProductAdvance
     * @param \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface $soldProductAdvance
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface $soldProductAdvance
    );

    /**
     * Retrieve SoldProductAdvance
     * @param string $soldproductadvanceId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($soldproductadvanceId);

    /**
     * Retrieve SoldProductAdvance matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete SoldProductAdvance
     * @param \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface $soldProductAdvance
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface $soldProductAdvance
    );

    /**
     * Delete SoldProductAdvance by ID
     * @param string $soldproductadvanceId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($soldproductadvanceId);
}

