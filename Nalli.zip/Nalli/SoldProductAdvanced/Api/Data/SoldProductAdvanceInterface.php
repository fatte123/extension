<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Api\Data;

interface SoldProductAdvanceInterface
{

    const MAGENTOONE_VIEWS = 'magentoone_views';
    const VIEWS_IMPRESSIONS = 'views_impressions';
    const MAGENTOONE_TOTALIMPRESSIONS = 'magentoone_totalimpressions';
    const COLOR = 'color';
    const FABRIC_PURITY = 'fabric_purity';
    const MATERIAL = 'material';
    const OCCASION = 'occasion';
    const SHIPPING_COUNTRY = 'shipping_country';
    const SMALL_IMAGE = 'small_image';
    const ORNAMENTATION_TYPE = 'ornamentation_type';
    const URL_KEY = 'url_key';
    const SUPPLIER_CODE = 'supplier_code';
    const PRICE = 'price';
    const ATC = 'atc';
    const PRODUCT_ID = 'product_id';
    const MAGENTOONE_UPLOAD = 'magentoone_upload';
    const SHIPPING_ADDRESS_ID = 'shipping_address_id';
    const BORDER = 'border';
    const ARTICLE_TYPE = 'article_type';
    const MAGENTOONE_ATC = 'magentoone_atc';
    const ORDER_DATE = 'order_date';
    const AGE = 'age';
    const BILLING_COUNTRY = 'billing_country';
    const ATC_COUNT = 'atc_count';
    const STORE_CODE = 'store_code';
    const BILLING_CITY = 'billing_city';
    const SHIPPING_REGION = 'shipping_region';
    const ATC_VIEWS = 'atc_views';
    const TOTAL_IMPRESSIONS = 'total_impressions';
    const SKU = 'sku';
    const INCREMENT_ID = 'increment_id';
    const ZARI_TYPE = 'zari_type';
    const BASE_PRICE = 'base_price';
    const SHIPPING_CITY = 'shipping_city';
    const TECHNIQUE = 'technique';
    const STATUS = 'status';
    const NAME = 'name';
    const SOLDPRODUCTADVANCE_ID = 'soldproductadvance_id';
    const BORDER_TYPE = 'border_type';
    const PATTERN = 'pattern';
    const PRODUCT_CREATED_AT = 'product_created_at';
    const STYLE_OF_WORK = 'style_of_work';
    const NO_OF_VIEWS = 'no_of_views';
    const BILLING_ADDRESS_ID = 'billing_address_id';
    const BILLING_REGION = 'billing_region';
    const COUNTER = 'counter';
    const PRODUCT_SKU = 'product_sku';
    const BLOUSE = 'blouse';
    const IMAGE = 'image';

    /**
     * Get soldproductadvance_id
     * @return string|null
     */
    public function getSoldproductadvanceId();

    /**
     * Set soldproductadvance_id
     * @param string $soldproductadvanceId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setSoldproductadvanceId($soldproductadvanceId);

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setSku($sku);

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId();

    /**
     * Set product_id
     * @param string $productId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setProductId($productId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setName($name);

    /**
     * Get base_price
     * @return string|null
     */
    public function getBasePrice();

    /**
     * Set base_price
     * @param string $basePrice
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBasePrice($basePrice);

    /**
     * Get increment_id
     * @return string|null
     */
    public function getIncrementId();

    /**
     * Set increment_id
     * @param string $incrementId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setIncrementId($incrementId);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setStatus($status);

    /**
     * Get order_date
     * @return string|null
     */
    public function getOrderDate();

    /**
     * Set order_date
     * @param string $orderDate
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setOrderDate($orderDate);

    /**
     * Get billing_address_id
     * @return string|null
     */
    public function getBillingAddressId();

    /**
     * Set billing_address_id
     * @param string $billingAddressId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBillingAddressId($billingAddressId);

    /**
     * Get shipping_address_id
     * @return string|null
     */
    public function getShippingAddressId();

    /**
     * Set shipping_address_id
     * @param string $shippingAddressId
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setShippingAddressId($shippingAddressId);

    /**
     * Get billing_country
     * @return string|null
     */
    public function getBillingCountry();

    /**
     * Set billing_country
     * @param string $billingCountry
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBillingCountry($billingCountry);

    /**
     * Get billing_city
     * @return string|null
     */
    public function getBillingCity();

    /**
     * Set billing_city
     * @param string $billingCity
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBillingCity($billingCity);

    /**
     * Get billing_region
     * @return string|null
     */
    public function getBillingRegion();

    /**
     * Set billing_region
     * @param string $billingRegion
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBillingRegion($billingRegion);

    /**
     * Get shipping_country
     * @return string|null
     */
    public function getShippingCountry();

    /**
     * Set shipping_country
     * @param string $shippingCountry
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setShippingCountry($shippingCountry);

    /**
     * Get shipping_city
     * @return string|null
     */
    public function getShippingCity();

    /**
     * Set shipping_city
     * @param string $shippingCity
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setShippingCity($shippingCity);

    /**
     * Get shipping_region
     * @return string|null
     */
    public function getShippingRegion();

    /**
     * Set shipping_region
     * @param string $shippingRegion
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setShippingRegion($shippingRegion);

    /**
     * Get product_created_at
     * @return string|null
     */
    public function getProductCreatedAt();

    /**
     * Set product_created_at
     * @param string $productCreatedAt
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setProductCreatedAt($productCreatedAt);

    /**
     * Get product_sku
     * @return string|null
     */
    public function getProductSku();

    /**
     * Set product_sku
     * @param string $productSku
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setProductSku($productSku);

    /**
     * Get atc_count
     * @return string|null
     */
    public function getAtcCount();

    /**
     * Set atc_count
     * @param string $atcCount
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setAtcCount($atcCount);

    /**
     * Get article_type
     * @return string|null
     */
    public function getArticleType();

    /**
     * Set article_type
     * @param string $articleType
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setArticleType($articleType);

    /**
     * Get border
     * @return string|null
     */
    public function getBorder();

    /**
     * Set border
     * @param string $border
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBorder($border);

    /**
     * Get border_type
     * @return string|null
     */
    public function getBorderType();

    /**
     * Set border_type
     * @param string $borderType
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBorderType($borderType);

    /**
     * Get blouse
     * @return string|null
     */
    public function getBlouse();

    /**
     * Set blouse
     * @param string $blouse
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setBlouse($blouse);

    /**
     * Get color
     * @return string|null
     */
    public function getColor();

    /**
     * Set color
     * @param string $color
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setColor($color);

    /**
     * Get counter
     * @return string|null
     */
    public function getCounter();

    /**
     * Set counter
     * @param string $counter
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setCounter($counter);

    /**
     * Get fabric_purity
     * @return string|null
     */
    public function getFabricPurity();

    /**
     * Set fabric_purity
     * @param string $fabricPurity
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setFabricPurity($fabricPurity);

    /**
     * Get magentoone_upload
     * @return string|null
     */
    public function getMagentooneUpload();

    /**
     * Set magentoone_upload
     * @param string $magentooneUpload
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setMagentooneUpload($magentooneUpload);

    /**
     * Get magentoone_views
     * @return string|null
     */
    public function getMagentooneViews();

    /**
     * Set magentoone_views
     * @param string $magentooneViews
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setMagentooneViews($magentooneViews);

    /**
     * Get magentoone_totalimpressions
     * @return string|null
     */
    public function getMagentooneTotalimpressions();

    /**
     * Set magentoone_totalimpressions
     * @param string $magentooneTotalimpressions
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setMagentooneTotalimpressions($magentooneTotalimpressions);

    /**
     * Get magentoone_atc
     * @return string|null
     */
    public function getMagentooneAtc();

    /**
     * Set magentoone_atc
     * @param string $magentooneAtc
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setMagentooneAtc($magentooneAtc);

    /**
     * Get material
     * @return string|null
     */
    public function getMaterial();

    /**
     * Set material
     * @param string $material
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setMaterial($material);

    /**
     * Get no_of_views
     * @return string|null
     */
    public function getNoOfViews();

    /**
     * Set no_of_views
     * @param string $noOfViews
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setNoOfViews($noOfViews);

    /**
     * Get occasion
     * @return string|null
     */
    public function getOccasion();

    /**
     * Set occasion
     * @param string $occasion
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setOccasion($occasion);

    /**
     * Get ornamentation_type
     * @return string|null
     */
    public function getOrnamentationType();

    /**
     * Set ornamentation_type
     * @param string $ornamentationType
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setOrnamentationType($ornamentationType);

    /**
     * Get pattern
     * @return string|null
     */
    public function getPattern();

    /**
     * Set pattern
     * @param string $pattern
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setPattern($pattern);

    /**
     * Get price
     * @return string|null
     */
    public function getPrice();

    /**
     * Set price
     * @param string $price
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setPrice($price);

    /**
     * Get small_image
     * @return string|null
     */
    public function getSmallImage();

    /**
     * Set small_image
     * @param string $smallImage
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setSmallImage($smallImage);

    /**
     * Get store_code
     * @return string|null
     */
    public function getStoreCode();

    /**
     * Set store_code
     * @param string $storeCode
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setStoreCode($storeCode);

    /**
     * Get style_of_work
     * @return string|null
     */
    public function getStyleOfWork();

    /**
     * Set style_of_work
     * @param string $styleOfWork
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setStyleOfWork($styleOfWork);

    /**
     * Get supplier_code
     * @return string|null
     */
    public function getSupplierCode();

    /**
     * Set supplier_code
     * @param string $supplierCode
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setSupplierCode($supplierCode);

    /**
     * Get technique
     * @return string|null
     */
    public function getTechnique();

    /**
     * Set technique
     * @param string $technique
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setTechnique($technique);

    /**
     * Get total_impressions
     * @return string|null
     */
    public function getTotalImpressions();

    /**
     * Set total_impressions
     * @param string $totalImpressions
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setTotalImpressions($totalImpressions);

    /**
     * Get url_key
     * @return string|null
     */
    public function getUrlKey();

    /**
     * Set url_key
     * @param string $urlKey
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setUrlKey($urlKey);

    /**
     * Get image
     * @return string|null
     */
    public function getImage();

    /**
     * Set image
     * @param string $image
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setImage($image);

    /**
     * Get zari_type
     * @return string|null
     */
    public function getZariType();

    /**
     * Set zari_type
     * @param string $zariType
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setZariType($zariType);

    /**
     * Get age
     * @return string|null
     */
    public function getAge();

    /**
     * Set age
     * @param string $age
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setAge($age);

    /**
     * Get views_impressions
     * @return string|null
     */
    public function getViewsImpressions();

    /**
     * Set views_impressions
     * @param string $viewsImpressions
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setViewsImpressions($viewsImpressions);

    /**
     * Get atc_views
     * @return string|null
     */
    public function getAtcViews();

    /**
     * Set atc_views
     * @param string $atcViews
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setAtcViews($atcViews);

    /**
     * Get atc
     * @return string|null
     */
    public function getAtc();

    /**
     * Set atc
     * @param string $atc
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface
     */
    public function setAtc($atc);
}

