<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Nalli\SoldProductAdvanced\Api\Data;

interface SoldProductAdvanceSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get SoldProductAdvance list.
     * @return \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface[]
     */
    public function getItems();

    /**
     * Set sku list.
     * @param \Nalli\SoldProductAdvanced\Api\Data\SoldProductAdvanceInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

