<?php 
 /**
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Saveaddress
  */
  
namespace Nalli\Saveaddress\Plugin;

use Magento\Framework\Exception\StateException;

class ShippingInformationManagementPlugin
{
	public function __construct(
	 \Magento\Customer\Model\Session $customerSession,
	 \Magento\Customer\Model\AddressFactory $AddressFactory
	){
	 $this->customerSession = $customerSession;
	 $this->addressFactory = $AddressFactory;
	}
    public function aroundSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        \Closure $proceed,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
		$address = $addressInformation->getShippingAddress();
        $address_save = $address->getData();
        $customerSession = $this->customerSession;
		if ($customerSession->isLoggedIn()) {
			if(count($customerSession->getCustomer()->getAddresses()) <= 0) {
				$customerId = $customerSession->getCustomer()->getId();
		        $addresss = $this->addressFactory;
		        $address = $addresss->create();
				
		        $address->setCustomerId($customerId);
		        $address->setFirstname($address_save['firstname']);
		        $address->setLastname($address_save['lastname']);
				$address->setCountryId($address_save['country_id']);
		        $address->setPostcode($address_save['postcode']);
		        $address->setCity($address_save['city']);
		        $address->setRegion($address_save['region']);
				if(isset($address_save['region_id'])) {
					$address->setRegionId($address_save['region_id']);
				}
		        $address->setTelephone($address_save['telephone']);
				if(isset($address_save['company'])) {
					$address->setCompany($address_save['company']);
				}
		        $address->setStreet($address_save['street']);
		        $address->setIsDefaultBilling('1');
		        $address->setIsDefaultShipping('1');
		        $address->setSaveInAddressBook('1');
		        $address->save();
	    	}
		}
        return $proceed($cartId, $addressInformation);
    }
}
?>