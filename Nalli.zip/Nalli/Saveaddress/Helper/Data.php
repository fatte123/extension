<?php
/**
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Saveaddress
  */
  
namespace Nalli\Saveaddress\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper 
{
    public function __construct(
		\Magento\Customer\Model\Address $customerAddress
	){
		$this->customerAddress = $customerAddress;
	}
	
	public function loadCustomerAddress($id) {
		return $this->customerAddress ->load($id);
	}
}