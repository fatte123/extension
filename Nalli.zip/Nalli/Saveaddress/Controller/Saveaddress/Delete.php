<?php
/**
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Saveaddress
 */
namespace Nalli\Saveaddress\Controller\Saveaddress;

class Delete extends \Magento\Framework\App\Action\Action
{
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Customer\Model\Address $customerAddress,
		\Magento\Framework\Message\ManagerInterface $messageManager
	){
		$this->_pageFactory = $pageFactory;
		$this->customerSession = $customerSession;
		$this->customerAddress = $customerAddress;
		$this->messageManager = $messageManager;
		return parent::__construct($context);
	}
	
    public function execute()
    {
		$addressId = $this->getRequest()->getParam('id', false);
		if ($addressId) {
			
			$customerSession = $this->customerSession;
			if($customerSession->isLoggedIn()) {
				$customerId = $customerSession->getCustomer()->getId();
				$address = $this->customerAddress->load($addressId);
				// Validate address_id <=> customer_id			
				if ($address && $address->getCustomerId() == $customerId) {
					try {
						$address->delete();
						$this->messageManager->addSuccess("The address has been deleted.");
					} catch (Exception $e){
						$this->messageManager->addError("An error occurred while deleting the address.");
					}
				} else {
					$this->messageManager->addError("The address does not belong to this customer.");
				}
			} else {
				$this->messageManager->addError("The address does not belong to this customer.");
			}
        }
		$this->_redirect('checkout');	
	   
    }
}