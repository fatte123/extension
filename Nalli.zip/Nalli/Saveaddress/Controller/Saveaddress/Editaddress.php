<?php
/**
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Saveaddress
  */
namespace Nalli\Saveaddress\Controller\Saveaddress; 

class Editaddress extends \Magento\Framework\App\Action\Action
{
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Customer\Model\Address $customerAddress,
		\Magento\Framework\View\Result\Page $resultPage,
		\Magento\Framework\Message\ManagerInterface $messageManager
	){
		$this->customerSession = $customerSession;
		$this->customerAddress = $customerAddress;
		$this->resultPage = $resultPage;
		$this->messageManager = $messageManager;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}
	
    public function execute()
    {
		$addressId = $this->getRequest()->getPost('id', false); 
		if ($addressId) {
			$customerSession = $this->customerSession;
			if($customerSession->isLoggedIn()) {
			   $customerId = $customerSession->getCustomer()->getId();
			   $address = $this->customerAddress->load($addressId);
				// Validate address_id <=> customer_id			
				if ($address && $address->getCustomerId() == $customerId) {
					try {
						$resultpage = $this->resultPage;
						$block = $resultpage->getLayout()->createBlock(\Magento\Customer\Block\Address\Edit::class)->setTemplate("Magento_Checkout::onepage/editaddress.phtml")->toHtml();
						echo json_encode(array('result' => 1, 
							'block' => $block
							)
						); die;
					} catch (Exception $e){
						echo json_encode(array('result' => 0, 
							'msg' => $e->getMessage()
							)
						); die;
					}
				} else {
					echo json_encode(array('result' => 0, 
						'msg' => "The address does not belong to this customer."
						)
					); die;
				}
			} else {
				echo json_encode(array('result' => 0, 
					'msg' => "The address does not belong to this customer."
					)
				); die;
			}
        }
		echo json_encode(array('result' => 0, 
			'msg' => "ID missing"
			)
		); die;
	   
    }
}