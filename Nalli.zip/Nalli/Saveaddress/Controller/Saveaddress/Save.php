<?php
/**
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Saveaddress
  */
  
namespace Nalli\Saveaddress\Controller\Saveaddress;

class Save extends \Magento\Framework\App\Action\Action
{
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Customer\Model\AddressFactory $AddressFactory,
		\Magento\Framework\Message\ManagerInterface $messageManager
	){
		$this->_pageFactory = $pageFactory;
		$this->customerSession = $customerSession;
		$this->addressFactory = $AddressFactory;
		$this->messageManager = $messageManager;
		return parent::__construct($context);
	}
	
    public function execute()
    {
		if($data = $this->getRequest()->getPost()) {
			try {
				$customerSession = $this->customerSession;
				if ($customerSession->isLoggedIn()) {
					$customerId = $customerSession->getCustomer()->getId();
					$addresss = $this->addressFactory;
					$address = $addresss->create();
					
					$address->setCustomerId($customerId);
					$address->setFirstname($data['firstname']);
					$address->setLastname($data['lastname']);
					$address->setCountryId($data['country_id']);
					$address->setPostcode($data['postcode']);
					$address->setCity($data['city']);
					$address->setRegion($data['region']);
					if(isset($data['region_id'])) {
						$address->setRegionId($data['region_id']);
					}
					$address->setTelephone($data['telephone']);
					if(isset($data['company'])) {
						$address->setCompany($data['company']);
					}
					$address->setStreet($data['street']);
					$address->setIsDefaultBilling('1');
					$address->setIsDefaultShipping('1');
					$address->setSaveInAddressBook('1');
					$save = $address->save();
					if($save){
					 $this->messageManager->addSuccess("Your address has been successfully saved");
					}
				}
			} catch (\Exception $e) {
				$message = __($e->getMessage());
				$this->messageManager->addError($message);
				
			}
		}
		$this->_redirect('checkout');	   
	   
    }
}