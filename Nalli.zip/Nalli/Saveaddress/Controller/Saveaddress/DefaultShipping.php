<?php
/**
  *
  * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Nalli_Saveaddress
  */
  
namespace Nalli\Saveaddress\Controller\Saveaddress;

use Psr\Log\LoggerInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Checkout\Model\Session as CheckoutSession;


class DefaultShipping extends \Magento\Framework\App\Action\Action
{ 
	
	/*
	 *@var CustomerRepositoryInterface 
	 */
	private $customerRepository; 
	/*
	 *@var AddressRepositoryInterface 
	 */ 
	private $addressRepository; 
	/*
	 *@var LoggerInterface 
	 */ 
	private $logger;
 	
 	public function __construct( 
	  \Magento\Framework\App\Action\Context $context,
	  \Magento\Framework\View\Result\PageFactory $pageFactory, 
	  CheckoutSession $checkoutSession,
	  \Magento\Customer\Model\AddressFactory $addressFactory,
	  CustomerRepositoryInterface $customerRepository, 
	  AddressRepositoryInterface $addressRepository,
	  \Magento\Customer\Model\Session $customerSession,
	  JsonFactory $resultJsonFactory,
	  \Magento\Checkout\Model\Cart $cart,
	  LoggerInterface $logger 
	 )
	 { 
	  $this->_pageFactory = $pageFactory;
	  $this->checkoutSession = $checkoutSession;
	  $this->addressFactory  = $addressFactory;
	  $this->customerRepository = $customerRepository; 
	  $this->addressRepository = $addressRepository; 
	  $this->customerSession = $customerSession;
	  $this->resultJsonFactory = $resultJsonFactory;
	  $this->cart             = $cart;
	  $this->logger = $logger; 
	  return parent::__construct($context);
	 }
	/** 
	 *assign default shipping address 
	 @param int $customerId * 
	 @param int $addressId * 
	 @return void 
	*/
	public function execute()
    {
		ob_start();
		$resultJson = $this->resultJsonFactory->create();
		if($data = $this->getRequest()->getPost()) {
			$addressId = $this->getRequest()->getPost('id', false);
			if(!empty($addressId)){
			$customerSession = $this->customerSession;
			if ($customerSession->isLoggedIn()) {
				try {
					$customerId = $customerSession->getCustomer()->getId();
					$this->setShippingAddress($customerId,$addressId);
					$this->checkoutSession->getQuote()->save();
					$this->cart->getQuote()->setTriggerRecollect(1);
                    $this->cart->getQuote()->collectTotals();
                    $this->cart->getQuote()->save();
					return $resultJson->setData(['result' => 1]);
				} catch (\Exception $e) {
					return $resultJson->setData(['result' => 0,'error'=>'Exception']);
					$this->logger->critical($e->getMessage());
				}
			}else{
				return $resultJson->setData(['result' => 0,'error'=>'else']);
			}
			return $resultJson->setData(['result' => 0]);
			}
		}
	}
    
	public function setShippingAddress(int $customerId, int $addressId) 
    { 
	   try { 
		   $address = $this->addressRepository->getById($addressId)->setCustomerId($customerId); 
		   $address->setIsDefaultShipping(true); 
		   $address->setIsDefaultBilling(true);
		   $this->addressRepository->save($address); 
	   } catch (\Exception $exception) { 
	  	 $this->logger->critical($exception); 
	   } 
    }
    /**
     * @return int
     */
    public function getQuoteId()
    {
       return (int)$this->checkoutSession->getQuote()->getId();
	}
	
	

}