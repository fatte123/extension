define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/totals',
    'Magento_Checkout/js/model/quote',
], function (Component, totals, quote) {
    'use strict';

    return Component.extend({
        totals: quote.getTotals(),
        defaults: {
            template: 'Nalli_PriceRoundOff/summary/rounded-price'
        },
        isDisplayed: function () {
            if (this.getPureValue() != 0) {
                return true;
            }
        },
        getPureValue: function () {
            var roundedOffPrice = 0;
            if (totals.getSegment('rounded_price')) {
                return totals.getSegment('rounded_price').value;
            }
            return roundedOffPrice;
        },
        getTitle: function(){
            var roundedOffTitle= '';
            if (totals.getSegment('rounded_price')) {
                return totals.getSegment('rounded_price').title;
            }
            return roundedOffTitle;
        },
        getValue: function () {
            return this.getFormattedPrice(this.getPureValue());
        },
    });
});
