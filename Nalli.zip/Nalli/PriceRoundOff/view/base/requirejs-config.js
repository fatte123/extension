var config = {
    'config': {
        'mixins': {
            'Magento_Catalog/js/price-utils': {
                'Nalli_PriceRoundOff/js/price-utils-mixin': true
            }
        }
    }
};
