<?php

namespace Nalli\PriceRoundOff\Plugin\Model\Quote\Address\Total;

class Grand
{

    public function afterCollect(
      \Magento\Quote\Model\Quote\Address\Total\Grand $subject, 
      $result, 
      \Magento\Quote\Model\Quote $quote, 
      \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment, 
      \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        if($quote->getQuoteCurrencyCode()=='INR'){
            $grandTotal = $total->getGrandTotal();
            $baseGrandTotal = $total->getBaseGrandTotal();
            
            $address = $shippingAssignment->getShipping()->getAddress();
    
            if ($address->getAddressType() == 'shipping') { 
                $quote->setOriginalGrandTotal($grandTotal);
                $quote->setBaseOriginalGrandTotal($baseGrandTotal);
            }
    
            $roundedGrandTotalValue = floor($grandTotal);
            $baseRoundedGrandTotalValue = floor($baseGrandTotal);
    
            $total->setGrandTotal($roundedGrandTotalValue);
            $total->setBaseGrandTotal($baseRoundedGrandTotalValue);
            return $result;
        }
        return $result;
    }

}
