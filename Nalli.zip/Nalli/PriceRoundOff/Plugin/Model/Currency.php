<?php

namespace Nalli\PriceRoundOff\Plugin\Model;

class Currency
{
    protected $_localeFormat;
    
    public function __construct(
       \Magento\Framework\Locale\FormatInterface $localeFormat
    ) {
        $this->_localeFormat = $localeFormat;

    }
    
    public function beforeFormatTxt(\Magento\Directory\Model\Currency $subject, $price, $options =[])
    {
        if (!is_numeric($price)) {
            $price = $this->_localeFormat->getNumber($price);
        }
        /**
         * Fix problem with 12 000 000, 1 200 000
         *
         * %f - the argument is treated as a float, and presented as a floating-point number (locale aware).
         * %F - the argument is treated as a float, and presented as a floating-point number (non-locale aware).
         */
        $price = sprintf("%F", $price);

        $precision = isset($options['precision']) ? $options['precision'] : 2;
        $zeroDecimal = (round($price, $precision) == round($price, 0));
        if ($zeroDecimal) {
            $options['precision'] = 0;
        }
        
        return [$price,$options];
    }

}
