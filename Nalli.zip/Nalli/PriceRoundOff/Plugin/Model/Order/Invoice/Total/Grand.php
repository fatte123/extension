<?php

namespace Nalli\PriceRoundOff\Plugin\Model\Order\Invoice\Total;

class Grand
{

    public function afterCollect(
      \Magento\Sales\Model\Order\Invoice\Total\Grand $subject, 
      $result, 
      \Magento\Sales\Model\Order\Invoice $invoice
    ) {
        
        if($invoice->getOrderCurrencyCode()=='INR'){
            
            $grandTotal = $invoice->getGrandTotal();
            $baseGrandTotal = $invoice->getGrandTotal();
            
            $invoice->setOriginalGrandTotal($grandTotal);
            $invoice->setBaseOriginalGrandTotal($baseGrandTotal);
    
            $roundedGrandTotalValue = floor($grandTotal);
            $baseRoundedGrandTotalValue = floor($baseGrandTotal);
            
            $invoice->setGrandTotal($roundedGrandTotalValue);
            $invoice->setBaseGrandTotal($baseRoundedGrandTotalValue);
            return $subject;
        }
        
        return $subject;
    }

}
