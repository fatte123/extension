<?php

namespace Nalli\PriceRoundOff\Helper;

class Data
{
    public function getPrecision($price)
    {
        $options = array();
        $defaultPrecision = 2;
        $isZeroDecimal = (round($price, $defaultPrecision) == round($price, 0));
        if ($isZeroDecimal) {
            $defaultPrecision = 0;
        }
        $options['precision'] = $defaultPrecision;
        return $options;
    }

    public function getLabel($roundedValue)
    {
        $label = __('Rounded down');
        if ($roundedValue < 0) {
            $label = __('Rounded down');
        }
        return $label;
    }
}
