<?php

namespace Nalli\PriceRoundOff\Block\Sales\Order\Totals;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Nalli\PriceRoundOff\Helper\Data;

class GrandTotalRoundedOff extends Template
{
    protected $_helper;

    public function __construct(Data $helper, Context $context, array $data = [])
    {
        $this->_helper = $helper;
        parent::__construct($context, $data);
    }

    public function getSource()
    {
        return $this->getParentBlock()->getSource();
    }

    public function initTotals()
    {
        $roundedValue=0;
        $roundedValue = $this->getSource()->getGrandTotal() - $this->getSource()->getOriginalGrandTotal();
        if($this->getSource()->getOrderCurrencyCode()!='INR'){
             return $this;
        }
        if ((float)$roundedValue == 0) {
            return $this;
        }
        if (!$this->getSource()->getOriginalGrandTotal()) {
            return $this;
        }
        $baseRoundedValue = $this->getSource()->getBaseGrandTotal() - $this->getSource()->getBaseOriginalGrandTotal();
        $total = new \Magento\Framework\DataObject(
            [
                'code' => 'rounded_price',
                'value' => $roundedValue,
                'base_value' => $baseRoundedValue,
                'label' => __($this->_helper->getLabel($roundedValue))
            ]
        );
        $this->getParentBlock()->addTotal($total, 'saved_price');
        return $this;
    }
}
