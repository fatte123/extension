<?php

namespace Nalli\PriceRoundOff\Block\Widget\Grid\Column\Renderer;

class Currency extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\Currency
{
    protected $priceHelper;
    
    public function __construct(
        \Magento\Backend\Block\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\Currency\DefaultLocator $currencyLocator,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Magento\Framework\Locale\CurrencyInterface $localeCurrency,
        \Nalli\PriceRoundOff\Helper\Data $priceHelper,
        array $data = []
    ) {
        parent::__construct($context,$storeManager,$currencyLocator,$currencyFactory,$localeCurrency,$data);
        $this->priceHelper = $priceHelper;
    }
    
   public function render(\Magento\Framework\DataObject $row)
    {
        if ($data = (string)$this->_getValue($row)) {
            $currency_code = $this->_getCurrencyCode($row);
            $data = floatval($data) * $this->_getRate($row);
            $sign = (bool)(int)$this->getColumn()->getShowNumberSign() && $data > 0 ? '+' : '';
            $data = sprintf("%f", $data);
            $options = $this->priceHelper->getPrecision($data);
            $data = $this->_localeCurrency->getCurrency($currency_code)->toCurrency($data,$options);
            return $sign . $data;
        }
        return $this->getColumn()->getDefault();
    }
}
