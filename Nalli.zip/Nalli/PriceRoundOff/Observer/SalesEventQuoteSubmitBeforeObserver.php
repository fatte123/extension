<?php

namespace Nalli\PriceRoundOff\Observer;

use Magento\Framework\Event\ObserverInterface;

class SalesEventQuoteSubmitBeforeObserver implements ObserverInterface
{
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quote = $observer->getEvent()->getQuote();
        if($quote->getQuoteCurrencyCode()=='INR'){
            $originalGrandTotal = $quote->getOriginalGrandTotal();
            $originalBaseGrandTotal = $quote->getBaseOriginalGrandTotal();
            if (!$originalGrandTotal || !$originalBaseGrandTotal) {
                return $this;
            }
            $order = $observer->getEvent()->getOrder();
            $order->setData('original_grand_total', $originalGrandTotal);
            $order->setData('base_original_grand_total', $originalBaseGrandTotal);
            return $this;
        }
        return $this;
    }

}
