<?php

namespace Nalli\PriceRoundOff\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Nalli\PriceRoundOff\Helper\Data;

class Price extends \Magento\Catalog\Ui\Component\Listing\Columns\Price
{
    protected $priceHelper;
    
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Magento\Framework\Locale\CurrencyInterface $localeCurrency,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
         Data $priceHelper,
        array $components = [],
        array $data = []
    ) {
		$this->storeManager = $storeManager;
        parent::__construct($context, $uiComponentFactory, $localeCurrency, $storeManager,$components,$data);
        $this->priceHelper = $priceHelper;
    }
    
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $store = $this->storeManager->getStore(
                    $this->context->getFilterParam('store_id', \Magento\Store\Model\Store::DEFAULT_STORE_ID)
            );
            $currency = $this->localeCurrency->getCurrency($store->getBaseCurrencyCode());

            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item[$fieldName])) {
                    $price = sprintf("%f",$item[$fieldName]);
                    $options = $this->priceHelper->getPrecision($price);
                    $item[$fieldName] = $currency->toCurrency($price, $options);
                }
            }
        }

        return $dataSource;
    }
}
