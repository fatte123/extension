<?php

namespace Nalli\PriceRoundOff\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Nalli\PriceRoundOff\Helper\Data;

class General extends \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\General
{
    protected $priceHelper;
    
    public function __construct(
        LocatorInterface $locator,
        ArrayManager $arrayManager,
        Data $priceHelper
    ) {
        $this->priceHelper = $priceHelper;
        parent::__construct($locator, $arrayManager);
    }
    
    /**
     * @var CurrencyInterface
     */
    private $localeCurrency;

    protected function formatPrice($value)
    {
        if (!is_numeric($value)) {
            return null;
        }

        $store = $this->locator->getStore();
        $currency = $this->getLocaleCurrency()->getCurrency($store->getBaseCurrencyCode());
        $options = $this->priceHelper->getPrecision($value);
        $options['display'] = \Magento\Framework\Currency::NO_SYMBOL;
        $value = $currency->toCurrency($value,$options);
        return $value;
    }

   private function getLocaleCurrency()
    {
        if ($this->localeCurrency === null) {
            $this->localeCurrency = \Magento\Framework\App\ObjectManager::getInstance()
                ->get(\Magento\Framework\Locale\CurrencyInterface::class);
        }
        return $this->localeCurrency;
    }
}
