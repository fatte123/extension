<?php

namespace Nalli\PriceRoundOff\Ui\DataProvider\Product\Form\Modifier;

use Magento\Framework\Locale\CurrencyInterface;
use Nalli\PriceRoundOff\Helper\Data;

class Eav extends \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\Eav
{

    /**
     * @var CurrencyInterface
     */
    private $localeCurrency;
    private $priceHelper;

    protected function formatPrice($value)
    {
        if (!is_numeric($value)) {
            return null;
        }

        $store = $this->storeManager->getStore();
        $currency = $this->getLocaleCurrency()->getCurrency($store->getBaseCurrencyCode());
        $options = $this->getPriceHelper()->getPrecision($value);
        $options['display'] = \Magento\Framework\Currency::NO_SYMBOL;
        $value = $currency->toCurrency($value,$options);
        return $value;
    }

    private function getLocaleCurrency()
    {
        if ($this->localeCurrency === null) {
            $this->localeCurrency = \Magento\Framework\App\ObjectManager::getInstance()->get(CurrencyInterface::class);
        }
        return $this->localeCurrency;
    }
    
    private function getPriceHelper()
    {
        if ($this->priceHelper === null) {
            $this->priceHelper = \Magento\Framework\App\ObjectManager::getInstance()->get(Data::class);
        }
        return $this->priceHelper;
    }

}
