<?php

namespace Nalli\PriceRoundOff\Model\Sales\Address\Total;

use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;
use Magento\Quote\Model\Quote as CoreQuote;
use Magento\Quote\Model\Quote\Address\Total;

class Rounded extends AbstractTotal
{

    public function fetch(CoreQuote $quote, Total $total)
    {
        $result = [];
        if($quote->getQuoteCurrencyCode()=="INR"){
            $roundedValue = $quote->getGrandTotal() - $quote->getOriginalGrandTotal();
            if ($quote->getOriginalGrandTotal() && ($roundedValue != 0)) {
                $result = [
                    'code' => $this->getCode(),
                    'title' => $this->getDataLabel($roundedValue),
                    'value' => $roundedValue,
                    'area' => 'footer'
                ];
            }
        }
        return $result;
    }

    public function getDataLabel($roundedValue)
    {
        $label = __('Rounded Down');
        if ($roundedValue < 0) {
            $label = __('Rounded Down');
        }
        return $label;
    }

}
