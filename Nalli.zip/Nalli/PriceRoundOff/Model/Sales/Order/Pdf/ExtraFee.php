<?php 
declare(strict_types=1);

namespace Nalli\PriceRoundOff\Model\Sales\Order\Pdf;

use Nalli\PriceRoundOff\Helper\Data;

class ExtraFee extends \Magento\Sales\Model\Order\Pdf\Total\DefaultTotal
{
    /**
     * @var \Magento\Tax\Helper\Data
     */
    protected $_taxHelper;

    /**
     * @var \Magento\Tax\Model\Calculation
     */
    protected $_taxCalculation;

    /**
     * @var \Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory
     */
    protected $_taxOrdersFactory;
    
    protected $_helper;

    /**
     * Initialize dependencies
     *
     * @param \Magento\Tax\Helper\Data $taxHelper
     * @param \Magento\Tax\Model\Calculation $taxCalculation
     * @param \Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory $ordersFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Tax\Helper\Data $taxHelper,
        \Magento\Tax\Model\Calculation $taxCalculation,
        \Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory $ordersFactory,
        Data $helper,
        array $data = []
    ) {
		$this->_helper = $helper;
        parent::__construct($taxHelper,$taxCalculation,$ordersFactory,$data);
    }

    /**
     * Get array of arrays with totals information for display in PDF
     * array(
     *  $index => array(
     *      'amount'   => $amount,
     *      'label'    => $label,
     *      'font_size'=> $font_size
     *  )
     * )
     *
     * @return array
     */
    public function getTotalsForDisplay()
    {
        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;
        $roundedValue =0;
		if($this->getOrder()->getOrderCurrencyCode()!='INR'){
              return [];
        }
		$roundedValue = $this->getOrder()->getGrandTotal() - $this->getOrder()->getOriginalGrandTotal();
        if ((float)$roundedValue == 0) {
            return [];
        }
        if (!$this->getOrder()->getOriginalGrandTotal()) {
            return [];
        }
        $baseRoundedValue = $this->getOrder()->getBaseGrandTotal() - $this->getOrder()->getBaseOriginalGrandTotal();
		
        return [
            [
                'amount' => $this->getAmountPrefix() . $baseRoundedValue,
                'label' =>  __($this->_helper->getLabel($roundedValue)) . ':',
                'font_size' => $fontSize,
            ]
        ];
    }

  }
