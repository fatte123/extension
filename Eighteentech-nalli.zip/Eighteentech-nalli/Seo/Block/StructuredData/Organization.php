<?php

namespace Eighteentech\Seo\Block\StructuredData;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Eighteentech\Seo\Helper\Data as HelperData;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\Data\StockItemInterface;
use Magento\Catalog\Helper\Data;

class Organization extends Template
{
	
	protected $helperData;
	protected $objectFactory;	
	protected $registry;
	protected $product;
	protected $store;
	protected $priceHelper;
	
	protected $_reviewFactory;
    protected $_voteFactory;
    protected $_urlInterface;
    
     protected $_catalogData = null;
     protected $_resource;
	protected $_logo;  
	protected $currencyCode;  
    private $stockRegistry;	  
    
	public function __construct(
		Context $context,
		HelperData $helperData,
		\Magento\Framework\Registry $registry,	
		\Magento\Store\Model\StoreManagerInterface $store,
		\Magento\Framework\Pricing\Helper\Data $priceHelper,
		\Magento\Review\Model\Rating\Option\VoteFactory $voteFactory, 
		\Magento\Review\Model\ReviewFactory $reviewFactory,
		\Magento\Framework\UrlInterface $urlInterface,
		\Magento\Framework\App\ResourceConnection $resourceConnection,
		 \Magento\Theme\Block\Html\Header\Logo $logo,
		 \Magento\Directory\Model\CurrencyFactory $currencyFactory,
		StockRegistryInterface $stockRegistry,
		Data $catalogData,
		array $data = []
	)
	{
		$this->helperData       = $helperData;	
		$this->registry = $registry;
		$this->store = $store; 
		$this->priceHelper = $priceHelper; 
		$this->_reviewFactory = $reviewFactory;
        $this->_voteFactory = $voteFactory;
        $this->_catalogData = $catalogData;
        $this->_urlInterface = $urlInterface;
        $this->_resource = $resourceConnection;
        $this->_logo = $logo;
		$this->currencyCode = $currencyFactory->create();
        $this->stockRegistry = $stockRegistry;
		parent::__construct($context, $data);
	}

	public function getHelper()
	{
		return $this->helperData;
	}
	
	/**
     * Get logo image URL
     *
     * @return string
     */
    public function getLogoSrc()
    {    
        return $this->_logo->getLogoSrc();
    }
    /**
     * Retrieve logo image URL
     *
     * @return string
     */
    public function getLogoUrl()
    {
        $folderName = \Magento\Config\Model\Config\Backend\Image\Logo::UPLOAD_DIR;
        $storeLogoPath = $this->_scopeConfig->getValue(
            'design/header/logo_src',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $path = $folderName . '/' . $storeLogoPath;
        $logoUrl = $this->_urlBuilder
                ->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) . $path;

        if ($storeLogoPath !== null && is_file($path)) {
            $url = $logoUrl;
        } elseif ($this->getLogoFile()) {
            $url = $this->getViewFileUrl($this->getLogoFile());
        } else {
            $url = $this->getViewFileUrl('images/logo.svg');
        }
        return $url;
    }
	
	public function getProductName(){
		return addslashes($this->getCurrentProduct()->getName());
	}
	public function getProductSku(){
		return $this->getCurrentProduct()->getSku();
	}
	public function getProductDescription(){
		return addslashes($this->getCurrentProduct()->getDescription());
	}
	public function getProductImageUrl(){	
		
		$productImageUrl = '';		

		$image = $this->getCurrentProduct()->getImage();
		if($image != '')
			$productImageUrl = $this->store->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $image;	
		return $productImageUrl;
	}
	public function getProductUrl(){	
		return $this->getCurrentProduct()->getProductUrl();
	}
	public function getProducPrice(){	
		
		$productCurrency = $this->getProductPriceCurrency();
		$productPrice = $this->getCurrentProduct()->getFinalPrice();
		$currency = $this->currencyCode->load('INR');
		$productPrice = round($currency->convert($productPrice,$productCurrency));		
		return $productPrice;
	}
	public function getProductPriceCurrency(){			
		return $this->store->getStore()->getCurrentCurrency()->getCode();	
	}
	public function getGtin(){			
		return $this->store->getStore()->getGtin();	
	}	

	
	public function getCrumbs() {
        $evercrumbs = array();

    $evercrumbs[] = array(
        'label' => 'Home',
        'title' => 'Go to Home Page',
        'link' => $this->store->getStore()->getBaseUrl(),
        'key' => 'home'
    );

    $path = $this->_catalogData->getBreadcrumbPath();
    $product = $this->getCurrentProduct();
    $categoryCollection = clone $product->getCategoryCollection();
    //$categoryCollection->clear();
    $categoryCollection->addAttributeToSort('level', $categoryCollection::SORT_ORDER_DESC)->addAttributeToFilter('path', array('like' => "1/" . $this->store->getStore()->getRootCategoryId() . "/%"));
    $categoryCollection->setPageSize(1);
    $breadcrumbCategories = $categoryCollection->getFirstItem()->getParentCategories();
    foreach ($breadcrumbCategories as $category) {
        $evercrumbs[] = array(
            'label' => $category->getName(),
            'title' => $category->getName(),
            'link' => $category->getUrl(),
            'key' => $category->getUrlKey()
        );
    }


    $evercrumbs[] = array(
            'label' => $product->getName(),
            'title' => $product->getName(),
            'link' => $this->store->getStore()->getBaseUrl().$product->getUrlKey(),
            'key' => $product->getUrlKey()
        );

    return $evercrumbs;
    
    }
    public function getCurrentUrl() {
		return $this->_urlInterface->getCurrentUrl();
	}
    
	public function getCurrentProduct(){    
		if (is_null($this->product)) {
            $this->product = $this->registry->registry('product');

            if (!$this->product->getId()) {
                throw new LocalizedException(__('Failed to initialize product'));
            }
        }
        return $this->product;
    }    
    public function getCurrentCategory()
    {
      
        return $this->registry->registry('current_category');
    } 
    
	public function getProductInStock()
    {
        $productId = $this->getCurrentProduct()->getId();
        $stockItem = $this->stockRegistry->getStockItem($productId);
        $isInStock = $stockItem ? $stockItem->getIsInStock() : false;
        if($isInStock){
            return 'InStock';
        }else{
            return 'OutStock';
        }

    }          
}
