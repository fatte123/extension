<?php

namespace Eighteentech\Seo\Helper;


use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	const XML_GERERAL_GOOGLEANALYTIC_ENABLED = 'wd_homebanner/structuredConfiguration/active';
	const XML_GERERAL_OSD_STREETADDRESS = 'wd_homebanner/structuredConfiguration/streetAddress';
	const XML_GERERAL_OSD_ADDRESSLOCALITY = 'wd_homebanner/structuredConfiguration/addressLocality';
	const XML_GERERAL_OSD_ADDRESSREGION = 'wd_homebanner/structuredConfiguration/addressRegion';
	const XML_GERERAL_OSD_POSTCODE = 'wd_homebanner/structuredConfiguration/postalCode';
	const XML_GERERAL_OSD_ADDRESSCOUNTRY = 'wd_homebanner/structuredConfiguration/addressCountry';
	const XML_GERERAL_OSD_SOCIALPROFILES = 'wd_homebanner/structuredConfiguration/socialProfiles';
	const XML_GERERAL_OSD_ORG_PHONE = 'wd_homebanner/structuredConfiguration/orgTelephone';
	const XML_GERERAL_OSD_ORG_NAME = 'wd_homebanner/structuredConfiguration/orgName';
	const XML_GERERAL_OSD_ORG_ALTERNATENAME = 'wd_homebanner/structuredConfiguration/orgAlternateName';
	
	
	 /**
	* @var \Magento\Framework\App\Config\ScopeConfigInterface
	*/
	protected $scopeConfig;

	protected $_countryFactory;


	/**
     * @param \Magento\Framework\App\Helper\Context $context
     */
	public function __construct(\Magento\Framework\App\Helper\Context $context,
	 \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	 \Magento\Directory\Model\CountryFactory $countryFactory
	) {
		  
		 $this->scopeConfig = $scopeConfig;
		  $this->_countryFactory = $countryFactory;
		parent::__construct($context);
	}
	
	public function isEnabled(){			
		return $this->scopeConfig->getValue(self::XML_GERERAL_GOOGLEANALYTIC_ENABLED, ScopeInterface::SCOPE_STORE);
	}
	
	public function getStreetAddress(){			
		return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_STREETADDRESS, ScopeInterface::SCOPE_STORE);
	}
	public function getAddressLocality(){			
		return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ADDRESSLOCALITY, ScopeInterface::SCOPE_STORE);
	}
	public function getAddressRegion(){			
		return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ADDRESSREGION, ScopeInterface::SCOPE_STORE);
	}
	public function getAddressPostcode(){			
		return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_POSTCODE, ScopeInterface::SCOPE_STORE);
	}
	public function getAddressCountry(){			
		$countryCode = $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ADDRESSCOUNTRY, ScopeInterface::SCOPE_STORE);		
		return $this->getCountryname($countryCode);
	}
	
	
    public function getSocialProfiles()
    {		
		$socialProfile = '';
		$profileData = $this->scopeConfig->getValue(self::XML_GERERAL_OSD_SOCIALPROFILES, ScopeInterface::SCOPE_STORE);	
		if($profileData){			
			$socialProfile = array_filter(explode("\n", $profileData));			
		}		
		return $socialProfile;
    }
    
   
    public function getOrganisationPhone(){			
		 return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ORG_PHONE, ScopeInterface::SCOPE_STORE);		
		
	}
	public function getOrganisationName(){			
		 return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ORG_NAME, ScopeInterface::SCOPE_STORE);		
		
	}
	public function getOrganisationAlternateName(){			
		 return $this->scopeConfig->getValue(self::XML_GERERAL_OSD_ORG_ALTERNATENAME, ScopeInterface::SCOPE_STORE);		
		
	}
	
	public function getHelper(){	
		return $this->helperData;
	}
	
	public function getCountryname($countryCode){    
		$countryName = '';
        $country = $this->_countryFactory->create()->loadByCode($countryCode);
        $countryName = $country->getName();
        return $countryName;
    }


}
