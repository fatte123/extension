<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Model;

use Magento\Framework\Model\AbstractModel;

class Otp extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Eighteentech\CustomerLogin\Model\ResourceModel\Otp::class);
    }
}
