<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Model\Data;

use Eighteentech\CustomerLogin\Api\Data\ResponseInterface;

class Response implements \Eighteentech\CustomerLogin\Api\Data\ResponseInterface
{
    protected $id;
    protected $customerId;
    protected $customerToken;
    protected $isMobileAlreadyExist;
    protected $isMobileAlreadyVerified;
    protected $userCartId;

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @inheritDoc
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getCustomerId()
    {
        return $this->customerId;
    }

    /**
     * @inheritdoc
     */
    public function setCustomerId($customerId)
    {
        $this->customerId = $customerId;
        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getCustomerToken()
    {
        return $this->customerToken;
    }

    /**
     * @inheritdoc
     */
    public function setCustomerToken($customerToken)
    {
        $this->customerToken = $customerToken;
        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getIsMobileAlreadyExist()
    {
        return $this->isMobileAlreadyExist;
    }

    /**
     * @inheritdoc
     */
    public function setIsMobileAlreadyExist($isMobileAlreadyExist)
    {
        $this->isMobileAlreadyExist = $isMobileAlreadyExist;
        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getIsMobileAlreadyVerified()
    {
        return $this->isMobileAlreadyVerified;
    }

    /**
     * @inheritdoc
     */
    public function setIsMobileAlreadyVerified($isMobileAlreadyVerified)
    {
        $this->isMobileAlreadyVerified = $isMobileAlreadyVerified;
        return $this;
    }

    /**
     * Get User Cart ID
     *
     * @return string|null
     */
    public function getUserCartId()
    {
        return $this->userCartId;
    }

    /**
     * Set User Cart ID
     *
     * @api
     * @param string|null $userCartId
     * @return $this
     */
    public function setUserCartId($userCartId)
    {
        $this->userCartId = $userCartId;
        return $this;
    }
}
