<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Model;

use Magento\Framework\Math\Random;
use Magento\Customer\Api\GroupManagementInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Stdlib\StringUtils as StringHelper;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Eighteentech\CustomerLogin\Model\OtpFactory;
use Eighteentech\CustomerLogin\Model\CustomerVerifiedNumberFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Url\DecoderInterface;
use Magento\Customer\Model\Authentication;
use Magento\Customer\Model\CustomerRegistry;
use Magento\Framework\Exception\State\UserLockedException;
use Eighteentech\CustomerLogin\Helper\Data;

class Account
{
    protected $customerFactory;
    protected $customerDataFactory;
    protected $storeManager;
    protected $customerGroupManagement;
    protected $transportBuilder;
    protected $randomString;
    protected $curlClient;
    protected $stringHelper;
    protected $dataObjectHelper;
    protected $otpFactory;
    protected $coreSession;
    protected $timezone;
    protected $modelDate;
    private $scopeConfig;
    private $urlDecoder;
    protected $verifiedNumberFactory;
    protected $authenticationModel;
    protected $customerRegistry;
    protected $vaildTypes = ['login', 'forgotpassword', 'register', 'edit', 'cod', 'changepassword'];
    public $loginHelper;

    const XML_PATH_MINIMUM_PASSWORD_LENGTH = 'customer/password/minimum_password_length';
    const XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER = 'customer/password/required_character_classes_number';
    const XML_PATH_RECIPIENT_EMAIL = 'contact/email/recipient_email';
    const MAX_PASSWORD_LENGTH = 256;
    const OTP_LIMIT = 'otp_config/otp_identity/otp_limit_identity';
    const EXPIRE_OTP = 'otp_config/otp_identity/otp_expire_identity';
    const BLOCKED_OTP = 'otp_config/otp_identity/blocked_otp_identity';
    const CHARS_DIGITS = '123456789';

    public function __construct(
        \Magento\Customer\Api\Data\CustomerInterfaceFactory $customerDataFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        GroupManagementInterface $customerGroupManagement,
        TransportBuilder $transportBuilder,
        Random $randamStringGenerator,
        CustomerFactory $customerFactory,
        Curl $curlClient,
        ScopeConfigInterface $scopeConfig,
        StringHelper $stringHelper,
        CustomerRepositoryInterface $customerRepository,
        OtpFactory $otpFactory,
        SessionManagerInterface $coreSession,
        TimezoneInterface $timezone,
        DateTime $modelDate,
        DecoderInterface $urlDecoder,
        CustomerVerifiedNumberFactory $verifiedNumberFactory,
        Authentication $authenticationModel,
        CustomerRegistry $customerRegistry,
        Data $loginHelper
    ) {
        $this->customerFactory = $customerFactory;
        $this->storeManager = $storeManager;
        $this->customerGroupManagement = $customerGroupManagement;
        $this->transportBuilder = $transportBuilder;
        $this->randomString = $randamStringGenerator;
        $this->customerDataFactory = $customerDataFactory;
        $this->curlClient = $curlClient;
        $this->scopeConfig = $scopeConfig;
        $this->stringHelper = $stringHelper;
        $this->customerRepository = $customerRepository;
        $this->otpFactory = $otpFactory;
        $this->coreSession = $coreSession;
        $this->timezone = $timezone;
        $this->dateModel = $modelDate;
        $this->urlDecoder = $urlDecoder;
        $this->verifiedNumberFactory = $verifiedNumberFactory;
        $this->authenticationModel = $authenticationModel;
        $this->customerRegistry = $customerRegistry;
        $this->loginHelper = $loginHelper;
    }

    public function buildCustomerData($name, $email, $mobilenumber, $Lastname = null)
    {
        $customerDataObject = $this->customerDataFactory->create();
        $store = $this->storeManager->getStore();
        $customerDataObject->setGroupId(
            $this->customerGroupManagement->getDefaultGroup($store->getId())->getId()
        );
        $customerDataObject->setWebsiteId($store->getWebsiteId());
        $customerDataObject->setStoreId($store->getId());
        $customerDataObject->setFirstname($name);
        $customerDataObject->setLastname($Lastname);
        $customerDataObject->setEmail(trim($email));
        $customerDataObject->setCustomAttribute('mobile', trim($mobilenumber));
        $customerDataObject->setCustomAttribute('mobile_verified', 0); 
		
        return $customerDataObject;
    }

    public function validateParams($name, $mobilenumber)
    {
        if (empty($name)) {
            throw new InputException(__('Name is required field'));
        }
        /*if (empty($mobilenumber)) {
            throw new InputException(__('Mobilenumber is required field'));
        }*/ else {
			if(!empty($mobilenumber)){
            $mobileNumber = trim($mobilenumber);
            //if (!is_numeric($mobileNumber) || strlen($mobileNumber) != 10) {
            if (!is_numeric($mobileNumber)) {
                throw new InputException(__('Please enter Valid Mobilenumber'));
            }
		    }
        }
        return true;
    }

    public function validateMobileNumber($mobilenumber)
    {
		/*if(!empty($mobilenumber)){
			if (!preg_match('/^[1-9][0-9]$/', $mobilenumber)) {
				throw new LocalizedException(__('Please provide valid mobilenumber'));
			}
	    }*/
    }

    public function sendOtpEmail($otpString, $customerEmail, $customerName, $templateId)
    {
        $variables = ['name' => $customerName, 'otp' => $otpString];
        $storeId = $this->storeManager->getStore()->getId();
        $transport = $this->transportBuilder->setTemplateIdentifier($templateId);
        $transport->setTemplateOptions(['area' => 'frontend', 'store' => $storeId]);
        $transport->setTemplateVars($variables);
        $transport->setFrom('general');
        // you can config general email address in Store -> Configuration -> General -> Store Email Addresses
        $transport->addTo($customerEmail);
        $transportObject = $transport->getTransport();
        $transportObject->sendMessage();
        return true;
    }

    public function getCustomerByEmail($customerEmail)
    {
        $store = $this->storeManager->getStore();
        $customerInfo = $this->customerRepository->get($customerEmail, $store->getWebsiteId());
        if ($customerInfo->getId()) {
            return $customerInfo->getId();
        }
        return false;
    }

    public function getCustomerNameByEmail($customerEmail)
    {
        $store = $this->storeManager->getStore();
        $customerInfo = $this->customerRepository->get($customerEmail, $store->getWebsiteId());
        if ($customerInfo->getId()) {
            return $customerInfo->getFirstName();
        } else {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Emailaddress not Registered with us'));
        }
    }
    
    public function triggerSms($mobileNumber, $otpString, $otpMessage, $dlt_id = null)
    {
        $apiKey = $this->loginHelper->getKey();
        
        if (!empty($dlt_id)) {
            //$smsUrl = "http://api.msg91.com/api/sendotp.php
                 // ?authkey=154979AV69wWI8U9N5934fced&mobile=91" . $mobileNumber .
                 // "&message=" . urlencode($otpMessage) . "&sender=SHYAWY&otp=" . $otpString . "&DLT_TE_ID=" . $dlt_id;
        } else {
                 // $smsUrl = "http://api.msg91.com/api/sendotp.php?authkey=154979AV69wWI8U9N5934fced
                 // &mobile=91" . $mobileNumber . "&message=" . urlencode($otpMessage) . "
                 // &sender=SHYAWY&otp=" . $otpString;
        }
        //$otpMessage = "Hi Your OTP is: 6533 for your account, It will expire in 3 minutes.";
        $apiurl ="https://api-alerts.kaleyra.com/v4/?api_key=".$apiKey."&message=".urlencode($otpMessage)."&sender=NALOTP&to=".trim($mobileNumber)."&method=sms&template_id=1407165397553684242";
        
        $ch = $this->curlClient;
        $ch->setOption(CURLOPT_RETURNTRANSFER, true);
        $ch->setOption(CURLOPT_ENCODING, '');
        $ch->setOption(CURLOPT_MAXREDIRS, 10);
        $ch->setOption(CURLOPT_TIMEOUT, 0);
        $ch->setOption(CURLOPT_FOLLOWLOCATION, true);
        $ch->setOption(CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $ch->setOption(CURLOPT_CUSTOMREQUEST, 'POST');
        $ch->get($apiurl);
        $result =  $ch->getBody();
        return true;
    }

    public function triggerResendOtpSms($mobileNumber, $otpString, $otpMessage)
    {
        $apiKey = $this->loginHelper->getKey();
        $apiurl ="https://api-alerts.kaleyra.com/v4/?api_key=".$apiKey."&message=".urlencode($otpMessage)."&sender=NALOTP&to=".trim($mobileNumber)."&method=sms&template_id=1407165397553684242";
        $ch = $this->curlClient;
        $ch->setOption(CURLOPT_RETURNTRANSFER, true);
        $ch->setOption(CURLOPT_ENCODING, '');
        $ch->setOption(CURLOPT_MAXREDIRS, 10);
        $ch->setOption(CURLOPT_TIMEOUT, 0);
        $ch->setOption(CURLOPT_FOLLOWLOCATION, true);
        $ch->setOption(CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $ch->setOption(CURLOPT_CUSTOMREQUEST, 'POST');
        $ch->get($apiurl);
        $result =  $ch->getBody();
        return true;
    }

    public function getOtpString()
    {
        return $this->randomString->getRandomString(6, self::CHARS_DIGITS);
    }

    public function validateOtpParams($username, $type)
    {
        if (!in_array($type, $this->vaildTypes)) {
            throw new LocalizedException('Provide Valid value for Type');
        }
        if (empty($username)) {
            throw new LocalizedException('Username is required');
        }
    }

    public function getCustomerId($username)
    {
        $result = [];
        if (preg_match('/^[0-9][0-9]{0,10}$/', $username)) {
            $type = 'mobile';
            if (!preg_match('/^[6-9][0-9]{9}$/', $username)) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Mobile Number is not correct.'));
            } else {
                $customerInfo = $this->getVerifiedCustomerInfo($username);
                if ($customerInfo) {
                    if (!$this->checkMobileAlreadyVerified($customerInfo['id'], $username)) {
                        throw new \Magento\Framework\Exception\NoSuchEntityException(
                            __('Mobile Number is not verified')
                        );
                    }
                } else {
                    throw new \Magento\Framework\Exception\NoSuchEntityException(
                        __('Mobile Number not Registered with us')
                    );
                }
                $customerId = $customerInfo['id'];
            }
        } else {
            $type = 'email';
            if (!\Zend_Validate::is(trim($username), 'EmailAddress')) {
                throw new LocalizedException(__('Please enter vaild email.'));
            }
            $customerId = $this->getCustomerByEmail($username);
            if (!$customerId) {
                throw new \Magento\Framework\Exception\NoSuchEntityException(
                    __('Emailaddress not Registered with us')
                );
            }
        }
        $result['type'] = $type;
        $result['customerId'] = $customerId;
        return $result;
    }

    public function checkPasswordStrength($password)
    {
        $length = $this->stringHelper->strlen($password);
        if ($length > self::MAX_PASSWORD_LENGTH) {
            throw new InputException(
                __(
                    'Please enter a password with at most %1 characters.',
                    self::MAX_PASSWORD_LENGTH
                )
            );
        }
        $configMinPasswordLength = $this->getMinPasswordLength();
        if ($length < $configMinPasswordLength) {
            throw new InputException(
                __(
                    'Please enter a password with at least %1 characters.',
                    $configMinPasswordLength
                )
            );
        }
        if ($this->stringHelper->strlen(trim($password)) != $length) {
            throw new InputException(__('The password can\'t begin or end with a space.'));
        }
        $requiredCharactersCheck = $this->makeRequiredCharactersCheck($password);
        if ($requiredCharactersCheck !== 0) {
            throw new InputException(
                __(
                    'Minimum of different classes of characters in password is %1.' .
                    ' Classes of characters: Lower Case, Upper Case, Digits, Special Characters.',
                    $requiredCharactersCheck
                )
            );
        }
    }

    protected function getMinPasswordLength()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_MINIMUM_PASSWORD_LENGTH);
    }

    public function getRecipientEmail()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_RECIPIENT_EMAIL);
    }

    public function getSessionLifeTime()
    {
        return $this->scopeConfig->getValue(
            \Magento\Framework\Session\Config::XML_PATH_COOKIE_LIFETIME,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    protected function makeRequiredCharactersCheck($password)
    {
        $counter = 0;
        $requiredNumber = $this->scopeConfig->getValue(self::XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER);
        $return = 0;
        if (preg_match('/[0-9]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[A-Z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[a-z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[^a-zA-Z0-9]+/', $password)) {
            $counter++;
        }
        if ($counter < $requiredNumber) {
            $return = $requiredNumber;
        }
        return $return;
    }

    public function getCustomerByMobileNumber($mobileNumber)
    {
        $info = [];
        $customerInfo = $this->customerFactory->create()->getCollection()
            ->addAttributeToSelect("*")
            ->addAttributeToFilter("mobile", $mobileNumber)->getFirstItem();
        if ($customerInfo->getId()) {
            $info['id'] = $customerInfo->getId();
            $info['email'] = $customerInfo->getEmail();
            return $info;
        }
        return false;
    }
    
    public function getCustomerById($id)
    {
        $info = [];
        $customerInfo = $this->customerFactory->create()->getCollection()
            ->addAttributeToSelect("*")
            //->addAttributeToFilter("id", $id)
            ->addAttributeToFilter('entity_id', ['eq' => $id])
            ->getFirstItem();
        if ($customerInfo->getId()) {
            $info['id'] = $customerInfo->getId();
            $info['email'] = $customerInfo->getEmail();
            $info['mobile'] = $customerInfo->getMobile();
            return $info;
        }
        return false;
    }

    public function generateSendOtp($customerId, $type, $quoteId, $username, $source)
    {
        //Get collection
        $blockOtpTime = $this->scopeConfig->getValue(self::BLOCKED_OTP, ScopeInterface::SCOPE_STORE);
        $otpLimit = $this->scopeConfig->getValue(self::OTP_LIMIT, ScopeInterface::SCOPE_STORE);
        $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
        $otpFactory = $this->otpFactory->create();
        if ($type == "cod") {
            $blockedOtp = $otpFactory->getCollection()
                ->addFieldToFilter('quote_id', $quoteId)
                //->addFieldToFilter('is_blocked', 1)
                ->setOrder('id', 'DESC')
                ->getFirstItem();
        } else {
            $blockedOtp = $otpFactory->getCollection()
                ->addFieldToFilter('customer_id', $customerId)
                //->addFieldToFilter('is_blocked', 1)
                ->setOrder('id', 'DESC')
                ->getFirstItem();
        }

        $otpCount = $blockedOtp->getOtpCount();
        $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
        $isBlockedOtp = $blockedOtp->getIsBlocked();
        
        if (!$blockedOtp->getId()) {
            $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, 1);
            $result['id'] = $otpRow->getId();
            $result['otpType'] = 'sendotp';
            $result['otpString'] = $otpRow->getOtp();
            return $result;
        } else {
            if ($isBlockedOtp==0 && $otpCount < $otpLimit) {
                $sentTime = $this->timezone->date($blockedOtp->getSentTime())->format('Y-m-d H:i:s');
                $intervalTimeInMinutes = $this->getTimeInterval($currentTime, $sentTime);
                $otpString = $blockedOtp->getOtp();
                
                    $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, $otpCount+1);
                    $result['id'] = $otpRow->getId();
                    $result['otpType'] = 'sendotp';
                    $result['otpString'] = $otpRow->getOtp();
                    return $result;
                         
            } else {
                if ($isBlockedOtp) {
                    $blockedTime = $blockedOtp->getBlockedStartTime();
                    $blockIntervalTimeInMinutes = $this->getTimeInterval($currentTime, $blockedTime);
                    
                    if ($blockIntervalTimeInMinutes > $blockOtpTime) {
                        $blockedOtp->setBlockedStartTime('')->setIsBlocked(0)->setIsExpired(1)->save();
                        $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, 1);
                        $result['id'] = $otpRow->getId();
                        $result['otpType'] = 'sendotp';
                        $result['otpString'] = $otpRow->getOtp();
                        return $result;
                    } else {
                        throw new LocalizedException(__('You have crossed the Maximum otp limit. 
						so, please try again later'));
                    }
                } else {
                   
					$blockedOtp->setBlockedStartTime($currentTime)->setIsBlocked(1)->save();
                    throw new LocalizedException(
                        __('You have crossed the Maximum otp limit. so, please try again later.')
                    );
                }
            }
        }
    }

    public function expireAndSaveOtp(
        $customerId = null,
        $type = null,
        $quoteId = null,
        $username = null,
        $source = null,
        $otpCount = 0
    ) {
        $otpFactory = $this->otpFactory->create();
        if ($type == 'cod') {
            $otpCollection = $otpFactory->getCollection()
            ->addFieldToFilter('quote_id', $quoteId)
            ->addFieldToFilter('is_expired', 0);
        } else {
            $otpCollection = $otpFactory->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->addFieldToFilter('is_expired', 0);
        }
        if (count($otpCollection)) {
            foreach ($otpCollection as $otp) {
                $otp->setIsExpired(1)->save();
            }
        }
        $otpString = $this->getOtpString();
        $otpRow = $otpFactory->setOtp($otpString)->setOtpType($type)->setCustomerId($customerId)
            ->setQuoteId($quoteId)->setOtpCount($otpCount)->setUsername($username)->setSource($source)
            ->save();
        return $otpRow;
    }

    public function generateResendOtp($customerId, $type, $quoteId, $username, $source)
    {
        $result = [];
        $otpLimit = $this->scopeConfig->getValue(self::OTP_LIMIT, ScopeInterface::SCOPE_STORE);
        $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
        $otpBlockTime = $this->scopeConfig->getValue(self::BLOCKED_OTP, ScopeInterface::SCOPE_STORE);
        $otpFactory = $this->otpFactory->create();
        
        if ($type == 'cod') {
            $otpInfo = $otpFactory->getCollection()
                ->addFieldToFilter('quote_id', $quoteId)
                ->setOrder('id', 'DESC')
                ->getFirstItem();
        } else {
            $otpInfo = $otpFactory->getCollection()
                ->addFieldToFilter('customer_id', $customerId)
                ->setOrder('id', 'DESC')
                ->getFirstItem();
        }
        $otpCount = $otpInfo->getOtpCount();
        $isBlockedOtp = $otpInfo->getIsBlocked();
        $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
        
        if ($isBlockedOtp == 0 && $type != $otpInfo->getOtpType()) {
            $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, 1);
            $result['id'] = $otpRow->getId();
            $result['otpType'] = 'sendotp';
            $result['otpString'] = $otpRow->getOtp();
            return $result;
        } elseif ($isBlockedOtp == 0 && $otpCount < $otpLimit) {
            $sentTime = $this->timezone->date($otpInfo->getSentTime())->format('Y-m-d H:i:s');
            $intervalTimeInMinutes = $this->getTimeInterval($currentTime, $sentTime);
            $otpString = $otpInfo->getOtp();

            if ($intervalTimeInMinutes <= $otpExpireTime) {
                $otpInfo->setOtpCount($otpCount + 1)
                ->setSentTime($this->dateModel->gmtDate('Y-m-d H:i:s'))->save();
                $result['id'] = $otpInfo->getId();
                $result['otpType'] = 'resendotp';
                $result['otpString'] = $otpString;
                return $result;
            } else {
                $otpInfo->setIsExpired(1)->save();
                $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, $otpCount + 1);
                $result['id'] = $otpRow->getId();
                $result['otpType'] = 'sendotp';
                $result['otpString'] = $otpRow->getOtp();
                return $result;
            }
        } else {
            if ($isBlockedOtp) {
                $blockIntervalTimeInMinutes = $this->getTimeInterval(
                    $currentTime,
                    $otpInfo->getBlockedStartTime()
                );
           	if ($blockIntervalTimeInMinutes > $otpBlockTime) {
                    $otpInfo->setBlockedStartTime('')->setIsBlocked(0)->setIsExpired(1)->save();
                    $otpRow = $this->expireAndSaveOtp($customerId, $type, $quoteId, $username, $source, 1);
                    $result['id'] = $otpRow->getId();
                    $result['otpType'] = 'sendotp';
                    $result['otpString'] = $otpRow->getOtp();
                    return $result;
                } else {
                    throw new LocalizedException(
                        __('You have crossed the Maximum otp limit. so, please try again later.')
                    );
                }
            } else {
                $otpInfo->setBlockedStartTime($currentTime)->setIsBlocked(1)->save();
                throw new LocalizedException(
                    __('You have crossed the Maximum otp limit. so, please try again later')
                );
            }
        }
    }

    public function getTimeIntervalFail($currentTime, $time)
    {
        $intervalTimeInMinutes = '';
        $timeDiff = date_diff(date_create($currentTime), date_create($time));
        $intervalTime = $timeDiff->format("%h:%i:%s");
        $timesplit = explode(':', $intervalTime);
        $intervalTimeInMinutes = ($timesplit[0] * 60) + ($timesplit[1]);
        return $intervalTimeInMinutes;
    }
    
    public function getTimeInterval($currentTime, $time)
    {
        $intervalTimeInMinutes = 0;
        $timeDiff = date_diff(date_create($currentTime), date_create($time));
        $intervalTimeInMinutes = $timeDiff->y * 365 * 30 * 24 * 60;
        $intervalTimeInMinutes = $timeDiff->m * 30 * 24 * 60;
        $intervalTimeInMinutes = $timeDiff->days * 24 * 60;
        $intervalTimeInMinutes += $timeDiff->h * 60;
        $intervalTimeInMinutes += $timeDiff->i;

        return $intervalTimeInMinutes;
    }

    public function verifyUserOtp($customerId, $originalOtp, $type, $quoteId)
    {
        $otpFactory = $this->otpFactory->create();
        $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
        if ($type == 'cod') {
            $otpCollection = $otpFactory->getCollection()
            ->addFieldToFilter('quote_id', $quoteId)
            ->addFieldToFilter('otp_type', $type)
            ->addFieldToFilter('is_expired', 0)
            ->getFirstItem();
        } else {
            $otpCollection = $otpFactory->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->addFieldToFilter('otp_type', $type)
            ->addFieldToFilter('is_expired', 0)
            ->getFirstItem();
        }
        $otpId = $otpCollection->getId();
        $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
        $sentTime = $this->timezone->date($otpCollection->getSentTime())->format('Y-m-d H:i:s');
        $timeIntervalInMinutes = $this->getTimeInterval($currentTime, $sentTime);
        
        if ($otpId && $timeIntervalInMinutes <= $otpExpireTime) {
            if ($otpCollection->getIsVerified() == 0) {
                $otp = $otpCollection->getOtp();
                if (trim($originalOtp) != trim($otp)) {
                    if ($customerId != '' || $customerId!==null) {
                        $this->authenticationModel->processAuthenticationFailure($customerId);
                        if ($this->isLocked($customerId)) {
                            throw new UserLockedException(__('Maximum verification attempts reached.
							 Retry in 24 hours.'));
                        } else {
                            throw new LocalizedException(__('OTP invalid or expired'));
                        }
                    } else {
                        throw new LocalizedException(__('OTP invalid or expired'));
                    }
                }
                $otpCollection->setIsExpired(1);
                $otpCollection->setIsVerified(1);
                $otpCollection->save();
            } else {
                throw new LocalizedException(__('This OTP is not valid. Please reload the page and try again.'));
            }
        } else {
            throw new LocalizedException(__('The entered OTP is expired.'));
        }
        return true;
    }
    
    public function getOtpRow($id)
    {
        $otpFactory = $this->otpFactory->create();
        return $otpFactory->getCollection()->addFieldToFilter('id', $this->urlDecoder->decode($id))->getFirstItem();
    }

    protected function checkMobileAlreadyVerified($customerId, $mobilenumber)
    {
        $verifiedNumbersModel = $this->verifiedNumberFactory->create();
        $collections = $verifiedNumbersModel->getCollection()
        //->addFieldToFilter('customer_id', $customerId)
        ->addFieldToFilter('mobilenumber', trim($mobilenumber));
        $count = count($collections);
        if ($count > 0) {
            return true;
        }
        return false;
    }

    public function getVerifiedCustomerInfo($mobilenumber)
    {
        $verifiedNumbersModel = $this->verifiedNumberFactory->create();
        $collections = $verifiedNumbersModel->getCollection()
        ->addFieldToFilter('mobilenumber', trim($mobilenumber))
        ->getFirstItem();
        if ($collections->getCustomerId()) {
            $data = $this->getCustomerById($collections->getCustomerId());
            $info['id']=$data['id'];
            $info['email']=$data['email'];
            return $info;
        }
        return false;
    }

    /**
     * @inheritdoc
     */
    public function isLocked($customerId)
    {
        $currentCustomer = $this->customerRegistry->retrieve($customerId);
        return $currentCustomer->isCustomerLocked();
    }
}
