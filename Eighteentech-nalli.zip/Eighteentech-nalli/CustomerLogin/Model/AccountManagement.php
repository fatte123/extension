<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Model;

use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Framework\Exception\StateException;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Eighteentech\CustomerLogin\Model\CustomerVerifiedNumberFactory;
use Eighteentech\CustomApi\Helper\Cart as CartHelper;
use Magento\Framework\App\ObjectManager;
use Magento\Customer\Model\CustomerRegistry;
use Magento\Customer\Model\Customer\CredentialsValidator;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Session\SaveHandlerInterface;
use Magento\Customer\Model\ResourceModel\Visitor\CollectionFactory;
use Magento\Framework\Intl\DateTimeFactory;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Escaper;
use Magento\Customer\Model\Registration;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Quote\Api\GuestCartRepositoryInterface;
use Magento\Framework\Url\EncoderInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Eighteentech\CustomerLogin\Helper\Data;

class AccountManagement implements \Eighteentech\CustomerLogin\Api\AccountManagementInterface
{
    protected $verifiedNumberFactory;
    protected $responseInterface;
    protected $escaper;
    protected $registration;
    private $cookieMetadataManager;
    private $cookieMetadataFactory;
    private $resultInterface;
    private $accountModel;
    private $coreAccountManagementInterface;
    private $customerUrl;
    private $tokenModelFactory;
    private $encryptor;
    private $customerRegistry;
    private $credentialsValidator;
    private $sessionManager;
    private $saveHandler;
    private $visitorCollectionFactory;
    private $dateTimeFactory;
    private $scopeConfig;
    protected $_guestCartRepository;
    protected $urlEncoder;
    protected $_eventManager;
    protected $cartHelper;
    private $storeManager;
    protected $_rewardData;
    protected $_rewardFactory;
    protected $checkoutSession;
    protected $customerModel;
    protected $customerFactory;
    /*
     *@var Eighteentech\CustomerLogin\Helper\Data
     */
    public $loginHelper;
    
    /**
     * @var \Eighteentech\CustomerLogin\Logger\Logger
     */
    protected $_logger;

    const EXPIRE_OTP = 'otp_config/otp_identity/otp_expire_identity';
    const DEFAULT_SOURCE = 'api';

    public function __construct(
        \Eighteentech\CustomerLogin\Api\Data\ResultInterfaceFactory $resultInterface,
        \Eighteentech\CustomerLogin\Api\Data\ResponseInterfaceFactory $responseInterface,
        Account $accountModel,
        AccountManagementInterface $coreAccountManagementInterface,
        CustomerUrl $customerUrl,
        TokenModelFactory $tokenModelFactory,
        CustomerRepositoryInterface $customerRepository,
        EncryptorInterface $encryptor,
        CustomerVerifiedNumberFactory $verifiedNumberFactory,
        CustomerRegistry $customerRegistry,
        Escaper $escaper,
        Registration $registration,
        CustomerSession $session,
        CredentialsValidator $credentialsValidator,
        SessionManagerInterface $sessionManager,
        SaveHandlerInterface $saveHandler,
        CollectionFactory $visitorCollectionFactory,
        DateTimeFactory $dateTimeFactory,
        ScopeConfigInterface $scopeConfig,
        GuestCartRepositoryInterface $guestCartRepository,
        EncoderInterface $urlEncoder,
        EventManager $eventManager,
        CartHelper $cartHelper,
        StoreManagerInterface $storeManager,
        CheckoutSession $checkoutSession,
        \Magento\Reward\Helper\Data $rewardData,
        \Magento\Reward\Model\RewardFactory $rewardFactory,
        \Magento\Customer\Model\Customer $customerModel,
        \Magento\Customer\Model\ResourceModel\CustomerFactory $customerFactory,
        Data $loginHelper,
        \Eighteentech\CustomerLogin\Logger\Logger $logger
    ) {
        $this->resultInterface = $resultInterface;
        $this->accountModel = $accountModel;
        $this->coreAccountManagementInterface = $coreAccountManagementInterface;
        $this->customerUrl = $customerUrl;
        $this->tokenModelFactory = $tokenModelFactory;
        $this->customerRepository = $customerRepository;
        $this->encryptor = $encryptor;
        $this->verifiedNumberFactory = $verifiedNumberFactory;
        $this->responseInterface = $responseInterface;
        $this->customerRegistry = $customerRegistry;
        $this->credentialsValidator = $credentialsValidator;
        $this->sessionManager = $sessionManager;
        $this->saveHandler = $saveHandler;
        $this->visitorCollectionFactory = $visitorCollectionFactory;
        $this->dateTimeFactory = $dateTimeFactory;
        $this->escaper = $escaper;
        $this->registration = $registration;
        $this->session = $session;
        $this->scopeConfig = $scopeConfig;
        $this->_guestCartRepository = $guestCartRepository;
        $this->urlEncoder = $urlEncoder;
        $this->_eventManager = $eventManager;
        $this->cartHelper = $cartHelper;
        $this->storeManager = $storeManager;
        $this->_rewardData = $rewardData;
        $this->_rewardFactory = $rewardFactory;
        $this->checkoutSession = $checkoutSession;
        $this->customerModel = $customerModel;
        $this->customerFactory = $customerFactory;
        $this->loginHelper = $loginHelper;
        $this->_logger = $logger;
    }

    /**
     * @inheritdoc
     */
    public function createCustomerAccount(
        $name,
        $email,
        $password,
        $mobilenumber,
        $source = self::DEFAULT_SOURCE,
        $guestCartId = null
    ) {

        $result = $this->resultInterface->create();

        if (!$this->registration->isAllowed()) {
            return $this->frameResponseJson(false, __('Registration is not allowed.'));
        }
        if ($source != self::DEFAULT_SOURCE) {
            if ($this->session->isLoggedIn()) {
                return $this->frameResponseJson(false, __('You have already logged in.'));
            }
           
        }
		$this->session->regenerateId();
        try {
            //Validate Request param for Empty Value
            $this->accountModel->validateParams($name, $mobilenumber);
            $isMobileAlreadyExist = false;
            if ($mobilenumber && $this->accountModel->getVerifiedCustomerInfo($mobilenumber)) {
                $mobilenumber = '';
                $isMobileAlreadyExist = true;
            }
			$redirectUrl = '';
            $customer = $this->accountModel->buildCustomerData($name, $email, $mobilenumber);
			
            $customerDataObject = $this->coreAccountManagementInterface->createAccount($customer, trim($password),$redirectUrl);
			$this->_eventManager->dispatch(
                'customer_register_success',
                ['account_controller' => $this, 'customer' => $customerDataObject]
            );
            $result->setStatus(true);
			
            $confirmationStatus = $this->coreAccountManagementInterface
            ->getConfirmationStatus($customerDataObject->getId());
			
			
            //$this->addRewardPoints($customer->getEmail());
            $this->_eventManager->dispatch(
                'popup_customer_register_success',
                ['customer' => $customerDataObject]
            );
			
		
			if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                $email = $this->customerUrl->getEmailConfirmationUrl($customer->getEmail());
                $result->setMessage(__('You must confirm your account. Please check your email for
                the confirmation link.'));
            } else {
                if ($source == self::DEFAULT_SOURCE) {
                    $response = $this->generateCustomerToken($customerDataObject->getId());
                    $response->setCustomerId($customerDataObject->getId());
                    $response->setIsMobileAlreadyExist($isMobileAlreadyExist);

                    if ($guestCartId) {
                        $userCartId = 0;
                        $userCartId = $this->cartHelper->mergeCart($guestCartId, $customerDataObject->getId());
                        $response->setUserCartId($userCartId);
						
                    }

                    $result->setResponse($response);
                } else {
                    $this->session->setCustomerDataAsLoggedIn($customerDataObject);
                    $response = $this->responseInterface->create();
                    $response->setIsMobileAlreadyExist($isMobileAlreadyExist);
					$result->setResponse($response);
                    if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
                        $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
                        $metadata->setPath('/');
                        $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
                    }
                }
            }
            
			
			$quote = $this->checkoutSession->getQuote();
			if($quote){
				$this->checkoutSession->getQuote()->setCustomerIsGuest(0)->collectTotals()->save();
			} 
            return $result;
        } catch (StateException $e) {
			$this->_logger->info($e->getMessage());
            return $this->frameResponseJson(false, __('Email id already registered, try to login now.'));
        } catch (InputException $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        }
    }
	
	
    /**
     * @inheritdoc
     */
    public function login($username, $password, $source = self::DEFAULT_SOURCE, $guestCartId = null)
    {
        $trimedUsername = trim($username);
        $trimedPassword = trim($password);
        if ($source != self::DEFAULT_SOURCE) {
            if ($this->session->isLoggedIn()) {
                return $this->frameResponseJson(false, __('You have already logged in.'));
            }
        }
        if (empty($trimedUsername) || empty($trimedPassword)) { // Validation for Empty
            return $this->frameResponseJson(false, __('Username and password are required.'));
        }
        try {
            if (preg_match('/^[1-9][0-9]{0,10}$/', $trimedUsername)) {
                // to validate if user's mobile is verified or not (sunshine)
                //todo
                if ($this->checkMobileAlreadyVerified(0, trim($username))) {
                     $customerInfo = $this->accountModel->getVerifiedCustomerInfo($trimedUsername);
                     $trimedUsername = $customerInfo['email'];

                } else {
                    return $this->frameResponseJson(false, __('Mobile Number is not verified.'));
                }
            }
            $customer = $this->coreAccountManagementInterface->authenticate($trimedUsername, $trimedPassword);
            if ($source == self::DEFAULT_SOURCE) {
                $customerId = $customer->getId();
                $response = $this->generateCustomerToken($customerId);
                if ($guestCartId) {
                    $userCartId = 0;
                    $userCartId = $this->cartHelper->mergeCart($guestCartId, $customerId);
                    $response->setUserCartId($userCartId);
					
                }
                return $this->frameResponseJson(true, null, $response);
            } else {
                $this->setCookieAndSession($customer);
                $response = $this->responseInterface->create();
                $customerId = $customer->getId();
                $response->setCustomerId($customerId);
				return $this->frameResponseJson(true, __('Logged in successfully.'), $response);
            }
        } catch (EmailNotConfirmedException $e) {
            $value = $this->customerUrl->getEmailConfirmationUrl($trimedUsername);
            return $this->frameResponseJson(false, __('This account is not confirmed.
            <a href="%1">Click here</a> to resend confirmation email.', $value));
        } catch (UserLockedException $e) {
            return $this->frameResponseJson(false, __('Maximum verification attempts reached. Retry in 24 hours.'));
        } catch (AuthenticationException $e) {
            if ($e->getMessage()=='The account is locked.') {
                $message = __('Maximum verification attempts reached. Retry in 24 hours.');
            } else {
                $message = __('Invalid login or password.');
            }
            return $this->frameResponseJson(false, $message);
        } catch (LocalizedException $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, __('An unspecified error occurred. Please
            contact us for assistance.'));
        }
    }

    protected function setCookieAndSession($customer)
    {
        $this->session->setCustomerDataAsLoggedIn($customer);
        $this->session->regenerateId();
        $this->checkoutSession->loadCustomerQuote();
        if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
            $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
            $metadata->setPath('/');
            $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
        }
    }

    private function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
		
    }

    private function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }

    /**
     * @inheritdoc
     */
    public function sendOtp($source = 'api', $type = 'login', $username = null, $customerId = null, $quoteId = null)
    {
        
        
        $result = $this->resultInterface->create();
        $response = $this->responseInterface->create();
        try {
            $mobile = '';
            if ($type != 'cod') {
                $this->accountModel->validateOtpParams($username, $type);
            }
            if (in_array($type, ['register', 'edit'])) {
                $usernameType = 'mobile';
                $this->accountModel->validateMobileNumber(trim($username));

                /*$oldCustomerInfo = $this->accountModel->getCustomerByMobileNumber($username);
                if ($oldCustomerInfo && $oldCustomerInfo['id'] != $customerId) {
                    $response->setIsMobileAlreadyExist(true);
                    return $this->frameResponseJson(
                        false,
                        __('The mobile number is already associated with another account.'),
                        $response
                    );
                }*/
                if ($this->checkMobileAlreadyVerified($customerId, $username)) {
                    $this->updatePrimaryMobileNumber($customerId, $username);
                    $result->setStatus(false);
                    $result->setMessage('The given mobile number has been already verified.');
                    return $result;
                }

                // validate customer ID with mobile number (Sunshine)
                if ($customerId) {
                    $oldCustomer = $this->accountModel->getCustomerById($customerId);
                    if (!$oldCustomer) {
                        return $this->frameResponseJson(
                            false,
                            __('Customer ID is not associated with any account.')
                        );
                    } elseif ($oldCustomer && $oldCustomer['mobile'] && $oldCustomer['mobile'] != trim($username)) {
                        return $this->frameResponseJson(
                            false,
                            __('The mobile number is not associated with this customer ID.')
                        );
                    }
                }
            }
            if (in_array($type, ['forgotpassword', 'login'])) {
                $customerInfo = $this->accountModel->getCustomerId($username);
                $customerId = $customerInfo['customerId'];
                $usernameType = $customerInfo['type'];
            }
            if ($type == 'changepassword') {
                $customer = $this->customerRepository->getById($customerId);
                if (!empty($customer->getCustomAttribute('mobile'))) {
                    $mobile = $customer->getCustomAttribute('mobile')->getValue();
                }
            }
            if ($type == 'cod') {
                $quote = $this->_guestCartRepository->get($quoteId);
                if (empty($quote->getShippingAddress()->getTelephone())) {
                    $result->setStatus(false);
                    $result->setMessage('Shipping address is not set.');
                    return $result;
                }
                $username = $quote->getShippingAddress()->getTelephone();
            }
           
           $otpRow = $this->accountModel->generateSendOtp($customerId, $type, $quoteId, $username, $source);
            switch ($type) {
                case 'forgotpassword':
                     $emailTemplate = 'forgotpassword_email_send';
                     $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpRow['otpString']);
                     $dlt_id="1707160991346071395";
                    break;
                case 'changepassword':
                    $usernameType = 'email-mobile';
                    $emailTemplate = 'changepassword_email_send';
                    $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpRow['otpString']);
                    break;
                case 'edit':
                case 'register':
                    $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpRow['otpString']);
                    $dlt_id="1707160991329036193";
                    break;
                case 'cod':
                    $usernameType = 'mobile';
                    $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
                    $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpRow['otpString']);
                    $dlt_id="1707160095571351767";
                    break;
                default:
                    $emailTemplate = 'login_email_send';
                    $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpRow['otpString']);
                    //$templateText = $this->loginHelper->getTemplateText();
                    //$otpMessage = __($templateText, $otpRow['otpString']);
                    $dlt_id="1707160095568332657";
                    break;
            }
            if ($usernameType == 'email') {
                $customerName = $this->accountModel->getCustomerNameByEmail($username);
                $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                    return $this->frameResponseJson(
                        false,
                        __('Email Verification Required.')
                    );
                } else {
                    $this->accountModel->sendOtpEmail($otpRow['otpString'], $username, $customerName, $emailTemplate);
                    $message = __('OTP sent to %1. Kindly check your inbox/spam.', $username);
                }
            }
            if ($usernameType == 'mobile' || ($mobile && $usernameType != 'email-mobile')) {
                if ($mobile && !empty($mobile)) {
                    $username = $mobile;
                }
                $this->accountModel->triggerSms($username, $otpRow['otpString'], $otpMessage, $dlt_id);
                $message = __('OTP sent to %1.', $username);
            }
            if ($usernameType == 'email-mobile') {
                $customerName = $this->accountModel->getCustomerNameByEmail($username);
                $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                    return $this->frameResponseJson(
                        false,
                        __('Email Verification Required.')
                    );
                } else {
                    $this->accountModel->sendOtpEmail($otpRow['otpString'], $username, $customerName, $emailTemplate);
                    $message = __('OTP sent Successfully. Kindly check your inbox/spam and also in 
					SMS if your number is verfied!');
                }
                $result = $this->isMobileVerified($customerId, $mobile);
                if ($result->getStatus()) {
                    if ($mobile && !empty($mobile)) {
                        $username = $mobile;
                    }
                    $this->accountModel->triggerSms($username, $otpRow['otpString'], $otpMessage);
                }
            }
            $response->setId($this->urlEncoder->encode($otpRow['id']));
            $result->setStatus(true);
            $result->setMessage($message);
            $result->setResponse($response);
            return $result;
        } catch (NoSuchEntityException $e) {
            $result->setStatus(false);
            $result->setMessage(__('Account does not exist (or) Mobile number not verified'));
        } catch (\Exception $e) {
            $result->setStatus(false);
            $result->setMessage($e->getMessage());
        }
        return $result;
    }

    protected function updateOtpExpired($customerId, $mobilenumber = null)
    {
        $customerInfo = $this->customerRepository->getById($customerId);
        if ($mobilenumber) {
            $customerInfo->setCustomAttribute('mobile', $mobilenumber);
        }
        $this->customerRepository->save($customerInfo);
        return true;
    }

    /**
     * @inheritdoc
     */
    public function verifyOtp($id, $otp, $guestCartId = null)
    {
        $result = $this->resultInterface->create();
        try {
            $otpRow = $this->accountModel->getOtpRow($id);
            $username = $otpRow->getUsername();
            $type = $otpRow->getOtpType();
            $quoteId = $otpRow->getQuoteId();
            $customerId = $otpRow->getCustomerId();
            $source = $otpRow->getSource();
            $userCartId = null;

            $this->accountModel->validateOtpParams($username, $type);
            if (in_array($type, ['forgotpassword', 'login'])) {
                $customerInfo = $this->accountModel->getCustomerId($username);
            }
            $this->accountModel->verifyUserOtp($customerId, $otp, $type, $quoteId);
            $this->session->setOtpId($id);
            // merge guest cart
            if ($guestCartId) {
                $userCartId = 0;
                $userCartId = $this->cartHelper->mergeCart($guestCartId, $customerId);
            }

            switch (trim($type)) {
                case 'login':
                    $result = $this->loginAfterVerify(
                        $customerInfo,
                        $customerId,
                        $result,
                        $username,
                        $source,
                        $userCartId
                    );
                    break;
                case 'register':
                    $result = $this->registrationAfterVerify(
                        $username,
                        $customerId,
                        $result,
                        $userCartId
                    );
                    break;
                case 'edit':
                    $result = $this->updateAfterVerify($username, $customerId, $result);
                    break;
                case 'cod':
                    $result = $this->codAfterVerify($customerId, $quoteId, $result);
                    break;
                default:
                    $result->setStatus(true);
                    $result->setMessage(__('OTP verified successfully.'));
                    break;
            }
        } catch (\Exception $e) {
            $result->setStatus(false);
            $result->setMessage($e->getMessage());
        }
        return $result;
    }

    protected function loginAfterVerify(
        $customerInfo,
        $customerId,
        $result,
        $username,
        $source,
        $userCartId
    ) {
        if ($customerInfo['type'] == 'mobile') {
            $this->updateVerifiedNumber($username, $customerId);
        }
        if ($source == self::DEFAULT_SOURCE) {
            $response = $this->generateCustomerToken($customerId);
        } else {
            $customer = $this->customerRepository->getById($customerId);
            $this->setCookieAndSession($customer);
            
            $response = $this->responseInterface->create();
            $response->setCustomerToken($customer->getEmail());
        }
        $this->updateOtpExpired($customerId);

        if ($userCartId) {
            $response->setUserCartId($userCartId);
        }
        $result->setStatus(true);
        $result->setResponse($response);
        $result->setMessage(__('Logged in successfully.'));
        return $result;
    }

    protected function registrationAfterVerify($username, $customerId, $result, $userCartId)
    {
        $this->saveVerifiedNumber($username, $customerId);
        $this->updateOtpExpired($customerId, $username);
        $response = $this->responseInterface->create();
        $result->setStatus(true);
        if ($userCartId) {
            $response->setUserCartId($userCartId);
            $result->setResponse($response);
        }
        $customerToken = $this->tokenModelFactory->create()
        ->createCustomerToken($customerId)->getToken();
        $response->setCustomerToken($customerToken);
        $result->setResponse($response);
        
        $result->setMessage(__('OTP verified successfully.'));
        return $result;
    }

    protected function updateAfterVerify($username, $customerId, $result)
    {
        $this->updatePrimaryMobileNumber($customerId, $username);
        $this->saveVerifiedNumber($username, $customerId);
        $this->updateOtpExpired($customerId);
        $result->setStatus(true);
        $result->setMessage(__('OTP verified successfully.'));
        return $result;
    }

    public function codAfterVerify($customerId, $quoteId, $result)
    {
        //Handled Guest verify for COD OTP Verification
        $quote = $this->_guestCartRepository->get($quoteId);
        if (empty($quote->getShippingAddress()->getTelephone())) {
            $result->setStatus(false);
            $result->setMessage('Shipping address is not set.');
            return $result;
        }
        $username = $quote->getShippingAddress()->getTelephone();
        if ($customerId) {
            if (!$this->checkMobileAlreadyVerified($customerId, $username)) {
                $this->saveVerifiedNumber($username, $customerId);
                //$this->setPrimaryMobileNumber($username, $customerId);
            }
        }
        $result->setStatus(true);
        $result->setMessage(__('OTP verified successfully.'));
        return $result;
    }

    public function resendOtp($id)
    {
        $response = $this->responseInterface->create();
        try {
            $otpRow = $this->accountModel->getOtpRow($id);
            $username = $otpRow->getUsername();
            $type = $otpRow->getOtpType();
            $quoteId = $otpRow->getQuoteId();
            $customerId = $otpRow->getCustomerId();
            $source = $otpRow->getSource();
            $usernameType = '';
            $message = '';
            $mobile = '';
            if (in_array($type, ['register', 'edit'])) {
                $usernameType = 'mobile';
            }
            if (in_array($type, ['forgotpassword', 'login'])) {
                $customerInfo = $this->accountModel->getCustomerId($username);
                $usernameType = $customerInfo['type'];
            }
            if ($type == 'changepassword') {
                $customer = $this->customerRepository->getById($customerId);
                if (!empty($customer->getCustomAttribute('mobile'))) {
                    $mobile = $customer->getCustomAttribute('mobile')->getValue();
                }
            }
            $otpInfo = $this->accountModel->generateResendOtp($customerId, $type, $quoteId, $username, $source);
            
            $otpString = $otpInfo['otpString'];
            if ($otpString && $otpInfo['otpType'] == 'resendotp') {
                if ($usernameType == 'email' || $type == 'changepassword') {
                    switch ($type) {
                        case 'forgotpassword':
                            $emailTemplate = 'forgotpassword_email_send';
                            break;
                        case 'changepassword':
                            $emailTemplate = 'changepassword_email_send';
                            break;
                        default:
                            $emailTemplate = 'login_email_send';
                            break;
                    }
                    $customerName = $this->accountModel->getCustomerNameByEmail($username);
                    $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                    if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                        return $this->frameResponseJson(
                            false,
                            __('Email Verification Required.')
                        );
                    } else {
                        $this->accountModel->sendOtpEmail($otpString, $username, $customerName, $emailTemplate);
                        $message = __('OTP sent to %1. Kindly check your inbox/spam.', $username);
                    }
                }
                if ($usernameType == 'mobile' || $mobile || $type == 'cod') {
                    if ($mobile) {
                        $username = $mobile;
                    }

                    if ($type == 'cod') {
                        $quote = $this->_guestCartRepository->get($quoteId);
                        if (empty($quote->getShippingAddress()->getTelephone())) {
                            return $this->frameResponseJson(false, __('Shipping address is not set.'));
                        }
                        $username = $quote->getShippingAddress()->getTelephone();
                    }
                    $otpMessage = __('Hi Your OTP is: %1 for your account, It will expire in 3
						minutes.', $otpString);
                    $this->accountModel->triggerResendOtpSms($username, $otpString, $otpMessage);
                    
                    //$this->accountModel->triggerSms($username,$otpString);
                    $message = __('OTP sent to %1.', $username);
                }
            } else {
                switch ($type) {
                    case 'forgotpassword':
                        $emailTemplate = 'forgotpassword_email_send';
                        $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpString);
                        $dlt_id="1707160991346071395";
                        break;
                    case 'changepassword':
                        $usernameType = 'email';
                        $emailTemplate = 'changepassword_email_send';
                        $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpString);
                        $dlt_id="1707160991346071395";
                        break;
                    case 'edit':
                    case 'register':
                        $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpString);
                        $dlt_id="1707160991329036193";
                        break;
                    case 'cod':
                        $usernameType = 'mobile';
                        $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
                        $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpString);
                        $dlt_id="1707160095571351767";
                        $quote = $this->_guestCartRepository->get($quoteId);
                        if (empty($quote->getShippingAddress()->getTelephone())) {
                            return $this->frameResponseJson(false, __('Shipping address is not set.'));
                        }
                        $username = $quote->getShippingAddress()->getTelephone();
                        break;
                    default:
                        $emailTemplate = 'login_email_send';
                        $otpMessage = __(' Hi, Nalli Silks welcomes you. Your OTP is: %1 for your account.', $otpString);
                        $dlt_id="1707160095568332657";
                        break;
                }

                if ($usernameType == 'email') {
                    $customerName = $this->accountModel->getCustomerNameByEmail($username);
                    $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                    if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                        return $this->frameResponseJson(
                            false,
                            __('Email Verification Required.')
                        );
                    } else {
                        $this->accountModel->sendOtpEmail($otpString, $username, $customerName, $emailTemplate);
                        $message = __('OTP sent to %1. Kindly check your inbox/spam.', $username);
                    }
                }
                if ($usernameType == 'mobile' || $mobile) {
                    if ($mobile) {
                        $username = $mobile;
                    }
                    $this->accountModel->triggerSms($username, $otpString, $otpMessage, $dlt_id);
                    $message = __('OTP sent to %1.', $username);
                }
            }
            $response->setId($this->urlEncoder->encode($otpInfo['id']));

            return $this->frameResponseJson(true, $message, $response);
        } catch (NoSuchEntityException $e) {
            return $this->frameResponseJson(false, __('Email Does not Exist'));
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        }
    }

    /**
     * @inheritdoc
     */
    public function setPassword($id, $password, $guestCartId = null)
    {

        try {
            $sessionOtpId = $this->session->getOtpId();
            $id = $sessionOtpId??$id;
            $otpRow = $this->accountModel->getOtpRow($id);
            $username = $otpRow->getUsername();
            $source = $otpRow->getSource();

            if (!$otpRow->getIsVerified()) {
                return $this->frameResponseJson(false, __('OTP is not verified. Please verify.'));
            }
            $mobileNumber = '';
            $response = null;
            if (empty($username)) {
                throw new LocalizedException('Username is required.');
            }
            if (preg_match('/^[1-9][0-9]{0,10}$/', $username)) {
                $mobileNumber = $username;
                $customerInfo = $this->accountModel->getVerifiedCustomerInfo($username);
                $username = $customerInfo['email'];
            }
            $this->accountModel->checkPasswordStrength($password);
            $customerId = $this->accountModel->getCustomerByEmail($username);
            if (!$customerId) {
                throw new LocalizedException(__('Invalid mobile number/email address.'));
            }

            $customer = $this->customerRepository->getById($customerId);
            $this->customerRepository->save($customer, $this->encryptor->getHash($password, true));
            if ($source == self::DEFAULT_SOURCE) {
                $this->updateVerifiedNumber($mobileNumber, $customerId);
                $this->updateOtpExpired($customerId);
                $response = $this->generateCustomerToken($customerId);
                if ($guestCartId) {
                    $userCartId = 0;
                    $response->setUserCartId($userCartId);
                }
            } else {
                $this->setCookieAndSession($customer);
            }
            $this->session->setOtpId('');
            return $this->frameResponseJson(true, __('Logged in successfully.'), $response);
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        }
    }

    protected function saveVerifiedNumber($mobilenumber, $customerId)
    {
        $verifiedNumbers = $this->verifiedNumberFactory->create();
        $verifiedNumbers->setMobilenumber($mobilenumber);
        $verifiedNumbers->setCustomerId($customerId);
        $result = $verifiedNumbers->save();
		$customer = $this->customerModel->load($customerId);
        $customerData = $customer->getDataModel();
        $customerData->setCustomAttribute('mobile_verified', 1);
        $customer->updateData($customerData);
        $customerResource = $this->customerFactory->create();
        $customerResource->saveAttribute($customer, 'mobile_verified');
    }

    protected function setPrimaryMobileNumber($mobilenumber, $customerId)
    {
        $oldCustomerInfo = $this->accountModel->getCustomerByMobileNumber($mobilenumber);
        if ($oldCustomerInfo) {
            return true;
        }
        $customerInfo = $this->customerRepository->getById($customerId);
        $isMobileAvailable = $customerInfo->getCustomAttribute('mobile');
        if (!$isMobileAvailable) {
            $customerInfo->setCustomAttribute('mobile', $mobilenumber);
            $this->customerRepository->save($customerInfo);
        }
    }

    protected function updateVerifiedNumber($mobileNumber, $customerId)
    {
        if (!empty($mobileNumber)) {
            $verifiedNumbersModel = $this->verifiedNumberFactory->create();
            $collection = $verifiedNumbersModel->getCollection()
                ->addFieldToFilter('customer_id', $customerId)
                ->addFieldToFilter('mobilenumber', $mobileNumber)->getFirstItem();
            if (!$collection->getId()) {
                $this->saveVerifiedNumber($mobileNumber, $customerId);
            }
        }
        return false;
    }

    protected function generateCustomerToken($customerId)
    {
        $response = $this->responseInterface->create();
        $customerToken = $this->tokenModelFactory->create()
        ->createCustomerToken($customerId)->getToken();
        $response->setCustomerToken($customerToken);
        return $response;
    }

    /**
     * {@inheritdoc}
     */
    public function isMobileVerified($customerId, $mobilenumber)
    {
        try {
            $isVerified = $this->checkCustomerMobileAlreadyVerified($customerId, $mobilenumber);
            return $this->frameResponseJson($isVerified);
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, $e->getMesaage());
        }
    }

    protected function checkCustomerMobileAlreadyVerified($customerId, $mobilenumber)
    {
        $verifiedNumbersModel = $this->verifiedNumberFactory->create();
        $collections = $verifiedNumbersModel->getCollection()
        ->addFieldToFilter('customer_id', $customerId)
        ->addFieldToFilter('mobilenumber', trim($mobilenumber));
        $count = count($collections);
        if ($count > 0) {
            return true;
        }
        return false;
    }

    protected function checkMobileAlreadyVerified($customerId, $mobilenumber)
    {
        $verifiedNumbersModel = $this->verifiedNumberFactory->create();
        $collections = $verifiedNumbersModel->getCollection()
        //->addFieldToFilter('customer_id', $customerId)
        ->addFieldToFilter('mobilenumber', trim($mobilenumber));
        $count = count($collections);
        if ($count > 0) {
            return true;
        }
        return false;
    }

    /**
     * Change customer password
     *
     * @param CustomerInterface $customer
     * @param string $newPassword
     * @return bool true on success
     * @throws InputException
     * @throws InvalidEmailOrPasswordException
     * @throws UserLockedException
     */
    public function changePasswordForCustomer($customer, $newPassword)
    {
        $customerEmail = $customer->getEmail();
        $this->credentialsValidator->checkPasswordDifferentFromEmail($customerEmail, $newPassword);
        $customerSecure = $this->customerRegistry->retrieveSecureData($customer->getId());
        $customerSecure->setRpToken(null);
        $customerSecure->setRpTokenCreatedAt(null);
        $this->accountModel->checkPasswordStrength($newPassword);
        $customerSecure->setPasswordHash($this->encryptor->getHash($newPassword, true));
        $this->destroyCustomerSessions($customer->getId());
        $this->customerRepository->save($customer);
        return true;
    }

    /**
     * Destroy all active customer sessions by customer id (current session will not be destroyed).
     * Customer sessions which should be deleted are collecting  from the "customer_visitor" table considering
     * configured session lifetime.
     *
     * @param string|int $customerId
     * @return void
     */
    private function destroyCustomerSessions($customerId)
    {
        $sessionLifetime = $this->accountModel->getSessionLifeTime();
        $dateTime = $this->dateTimeFactory->create();
        $activeSessionsTime = $dateTime->setTimestamp($dateTime->getTimestamp() - $sessionLifetime)
            ->format(DateTime::DATETIME_PHP_FORMAT);
        /** @var \Magento\Customer\Model\ResourceModel\Visitor\Collection $visitorCollection */
        $visitorCollection = $this->visitorCollectionFactory->create();
        $visitorCollection->addFieldToFilter('customer_id', $customerId);
        $visitorCollection->addFieldToFilter('last_visit_at', ['from' => $activeSessionsTime]);
        $visitorCollection->addFieldToFilter('session_id', ['neq' => $this->sessionManager->getSessionId()]);
        /** @var \Magento\Customer\Model\Visitor $visitor */
        foreach ($visitorCollection->getItems() as $visitor) {
            $sessionId = $visitor->getSessionId();
            $this->sessionManager->start();
            $this->saveHandler->destroy($sessionId);
            $this->sessionManager->writeClose();
        }
    }

    /*
     * {@inheritdoc}
     */
    public function checkAndUpdatePrimaryMobileNumber($customerId, $mobilenumber)
    {
        try {
            $oldCustomerInfo = $this->accountModel->getCustomerByMobileNumber($mobilenumber);
            if ($oldCustomerInfo && $oldCustomerInfo['id'] != $customerId) {
                $response = $this->responseInterface->create();
                $response->setIsMobileAlreadyExist(true);
                return $this->frameResponseJson(false, __('Mobile number is already associated with
                another account.'), $response);
            }
            if ($this->checkMobileAlreadyVerified($customerId, $mobilenumber)) {
                $this->updatePrimaryMobileNumber($customerId, $mobilenumber);
                $response = $this->responseInterface->create();
                $response->setIsMobileAlreadyVerified(true);
                return $this->frameResponseJson(false, __('Mobile number is already verified.'), $response);
            }
            return $this->frameResponseJson(true);
        } catch (\Exception $ex) {
            return $this->frameResponseJson(false, $ex->getMessage());
        }
    }

    protected function updatePrimaryMobileNumber($customerId, $mobilenumber = '')
    {
        $customerInfo = $this->customerRepository->getById($customerId);
        $customerInfo->setCustomAttribute('mobile', $mobilenumber);
        $this->customerRepository->save($customerInfo);
        return $customerInfo->getId();
    }

    protected function frameResponseJson($status, $message = null, $response = null)
    {
        $result = $this->resultInterface->create();
        $result->setStatus($status);
        $result->setMessage($message);
        $result->setResponse($response);
        return $result;
    }

    /**
     * @inheritdoc
     */
    public function isEmailPhoneAvailable($trimedUsername, $websiteId = null)
    {
        try {
            if ($websiteId === null) {
                $websiteId = $this->storeManager->getStore()->getWebsiteId();
            }
            if (preg_match('/^[1-9][0-9]{0,10}$/', $trimedUsername)) {
                $customerInfo = $this->accountModel->getCustomerByMobileNumber($trimedUsername);
                // to validate if user's mobile is verified or not (sunshine)
                //todo
                if (!$this->checkMobileAlreadyVerified($customerInfo['id'], trim($trimedUsername))) {
                    return true;
                }
                return false;
            } else {
                $this->customerRepository->get($trimedUsername, $websiteId);
                return false;
            }
            return false;
        } catch (NoSuchEntityException $e) {
            return true;
        }
        return true;
    }

    public function addRewardPoints($customerEmail)
    {
        if (!$this->_rewardData->isEnabledOnFront()) {
            return false;
        }

        $subscribeByDefault = $this->_rewardData->getNotificationConfig(
            'subscribe_by_default',
            $this->storeManager->getStore()->getWebsiteId()
        );

        try {
            $customerModel = $this->customerRegistry
                ->retrieveByEmail($customerEmail);
            $customer = $this->customerRepository->get($customerEmail, $this->storeManager->getStore()->getWebsiteId());
            $customerModel->setRewardUpdateNotification($subscribeByDefault);
            $customerModel->setRewardWarningNotification($subscribeByDefault);
            $customerModel->getResource()
                ->saveAttribute($customerModel, 'reward_update_notification');
            $customerModel->getResource()
                ->saveAttribute($customerModel, 'reward_warning_notification');

            $this->_rewardFactory->create()->setCustomer(
                $customer
            )->setActionEntity(
                $customer
            )->setStore(
                $this->storeManager->getStore()->getId()
            )->setAction(
                \Magento\Reward\Model\Reward::REWARD_ACTION_REGISTER
            )->updateRewardPoints();

        } catch (\Exception $e) {
            //save exception if something went wrong during saving reward
            //and allow to register customer
            $this->frameResponseJson(false, $e->getMessage());
        }

        return $customer;
    }
/**
 * @inheritdoc
 */
    public function verifyOtpGraphql($id, $otp, $apiUsername, $guestCartId = null)
    {
        $result = $this->resultInterface->create();
        try {
            $otpRow = $this->accountModel->getOtpRow($id);
            $username = $otpRow->getUsername();
            $type = $otpRow->getOtpType();
            $quoteId = $otpRow->getQuoteId();
            $customerId = $otpRow->getCustomerId();
            $source = $otpRow->getSource();
            $userCartId = null;
            if ($type!='cod' && $apiUsername!=$username) {
                throw new LocalizedException(__('Customer is not authorised.'));
            }
            $this->accountModel->validateOtpParams($username, $type);
            if (in_array($type, ['forgotpassword', 'login'])) {
                $customerInfo = $this->accountModel->getCustomerId($username);
            }
            $this->accountModel->verifyUserOtp($customerId, $otp, $type, $quoteId);
            $this->session->setOtpId($id);
            // merge guest cart
            if ($guestCartId) {
                $userCartId = 0;
                $userCartId = $this->cartHelper->mergeCart($guestCartId, $customerId);
            }

            switch (trim($type)) {
                case 'login':
                    $result = $this->loginAfterVerify(
                        $customerInfo,
                        $customerId,
                        $result,
                        $username,
                        $source,
                        $userCartId
                    );
                    break;
                case 'register':
                    $result = $this->registrationAfterVerify(
                        $username,
                        $customerId,
                        $result,
                        $userCartId
                    );
                    break;
                case 'edit':
                    $result = $this->updateAfterVerify($username, $customerId, $result);
                    break;
                case 'cod':
                    $result = $this->codAfterVerify($customerId, $quoteId, $result);
                    break;
                default:
                    $result->setStatus(true);
                    $result->setMessage(__('OTP verified successfully.'));
                    break;
            }
        } catch (\Exception $e) {
            $result->setStatus(false);
            $result->setMessage($e->getMessage());
        }
        return $result;
    }

    public function resendOtpGraphql($id, $apiUsername)
    {
        $response = $this->responseInterface->create();
        try {
            $otpRow = $this->accountModel->getOtpRow($id);
            $username = $otpRow->getUsername();
            $type = $otpRow->getOtpType();
            $quoteId = $otpRow->getQuoteId();
            $customerId = $otpRow->getCustomerId();
            $source = $otpRow->getSource();
            $isVerified = $otpRow->getIsVerified();
            $isExpired  = $otpRow->getIsExpired();

            $usernameType = '';
            $message = '';
            $mobile = '';
            if ($isVerified=='1') {
                throw new LocalizedException(__('OTP is already verified.'));
            }
            if ($type!='cod' && $apiUsername!=$username) {
                throw new LocalizedException(__('Customer is not authorised.'));
            }

            if (in_array($type, ['register', 'edit'])) {
                $usernameType = 'mobile';
            }
            if (in_array($type, ['forgotpassword', 'login'])) {
                $customerInfo = $this->accountModel->getCustomerId($username);
                $usernameType = $customerInfo['type'];
            }
            if ($type == 'changepassword') {
                $customer = $this->customerRepository->getById($customerId);
                if (!empty($customer->getCustomAttribute('mobile'))) {
                    $mobile = $customer->getCustomAttribute('mobile')->getValue();
                }
            }
            $otpInfo = $this->accountModel->generateResendOtp($customerId, $type, $quoteId, $username, $source);
            //$customerId = $this->accountModel->getCustomerByEmail($username);

            $otpString = $otpInfo['otpString'];
            if ($otpString && $otpInfo['otpType'] == 'resendotp') {
                if ($usernameType == 'email' || $type == 'changepassword') {
                    switch ($type) {
                        case 'forgotpassword':
                            $emailTemplate = 'forgotpassword_email_send';
                            break;
                        case 'changepassword':
                            $emailTemplate = 'changepassword_email_send';
                            break;
                        default:
                            $emailTemplate = 'login_email_send';
                            break;
                    }
                    $customerName = $this->accountModel->getCustomerNameByEmail($username);
                    $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                    if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                        return $this->frameResponseJson(
                            false,
                            __('Email Verification Required.')
                        );
                    } else {
                        $this->accountModel->sendOtpEmail($otpString, $username, $customerName, $emailTemplate);
                        $message = __('OTP sent to %1. Kindly check your inbox/spam.', $username);
                    }
                }
                if ($usernameType == 'mobile' || $mobile || $type == 'cod') {
                    if ($mobile) {
                        $username = $mobile;
                    }

                    if ($type == 'cod') {
                        $quote = $this->_guestCartRepository->get($quoteId);
                        if (empty($quote->getShippingAddress()->getTelephone())) {
                            return $this->frameResponseJson(false, __('Shipping address is not set.'));
                        }
                        $username = $quote->getShippingAddress()->getTelephone();
                    }

                    $this->accountModel->triggerResendOtpSms($username);
                    $message = __('OTP sent to %1.', $username);
                }
            } else {
                switch ($type) {
                    case 'forgotpassword':
                        $emailTemplate = 'forgotpassword_email_send';
                        $otpMessage = __('%1 is the OTP to reset your password at nalli.com. 
						For security reasons do not share this OTP with anyone else.', $otpString);
                        $dlt_id="1707160991346071395";
                        break;
                    case 'changepassword':
                        $usernameType = 'email';
                        $emailTemplate = 'changepassword_email_send';
                        $otpMessage = __('%1 is the OTP to reset your password at nalli.com. 
						For security reasons do not share this OTP with anyone else.', $otpString);
                        $dlt_id="1707160991346071395";
                        break;
                    case 'edit':
                    case 'register':
                        $otpMessage = __('%1 is the OTP to verify mobile number at nalli.com. 
						For security reasons do not share this OTP with anyone else.', $otpString);
                        $dlt_id="1707160991329036193";
                        break;
                    case 'cod':
                        $usernameType = 'mobile';
                        $otpExpireTime = $this->scopeConfig->getValue(self::EXPIRE_OTP, ScopeInterface::SCOPE_STORE);
                        $otpMessage = __('%1 is your OTP for the COD order at nalli.com. 
						This OTP is valid only for the next 30 mins. For security reasons do not share 
						this OTP with anyone else.', $otpString, $otpExpireTime);
                        $dlt_id="1707160095571351767";
                        $quote = $this->_guestCartRepository->get($quoteId);
                        if (empty($quote->getShippingAddress()->getTelephone())) {
                            return $this->frameResponseJson(false, __('Shipping address is not set.'));
                        }
                        $username = $quote->getShippingAddress()->getTelephone();
                        break;
                    default:
                        $emailTemplate = 'login_email_send';
                        $otpMessage = __('%1 is the OTP to login at nalli.com. For security
						 reasons do not share this OTP with anyone else.', $otpString);
                        $dlt_id="1707160095568332657";
                        break;
                }

                if ($usernameType == 'email') {
                    $customerName = $this->accountModel->getCustomerNameByEmail($username);
                    $confirmationStatus = $this->coreAccountManagementInterface->getConfirmationStatus($customerId);
                    if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                        return $this->frameResponseJson(
                            false,
                            __('Email Verification Required.')
                        );
                    } else {
                        $this->accountModel->sendOtpEmail($otpString, $username, $customerName, $emailTemplate);
                        $message = __('OTP sent to %1. Kindly check your inbox/spam.', $username);
                    }
                }
                if ($usernameType == 'mobile' || $mobile) {
                    if ($mobile) {
                        $username = $mobile;
                    }
                    $this->accountModel->triggerSms($username, $otpString, $otpMessage);
                    $message = __('OTP sent to %1.', $username);
                }
            }
            $response->setId($this->urlEncoder->encode($otpInfo['id']));

            return $this->frameResponseJson(true, $message, $response);
        } catch (NoSuchEntityException $e) {
            return $this->frameResponseJson(false, __('Account does not exist (or) Mobile number not verified'));
        } catch (\Exception $e) {
            return $this->frameResponseJson(false, $e->getMessage());
        }
    }
}
