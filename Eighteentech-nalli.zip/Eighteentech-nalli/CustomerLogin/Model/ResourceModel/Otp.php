<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db;

class Otp extends Db\AbstractDb
{

    protected function _construct()
    {
        $this->_init('eighteentech_otp', 'id');
    }
}
