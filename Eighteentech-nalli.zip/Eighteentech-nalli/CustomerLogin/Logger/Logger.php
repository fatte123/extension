<?php
namespace Eighteentech\CustomerLogin\Logger;

class Logger extends \Monolog\Logger
{
}
