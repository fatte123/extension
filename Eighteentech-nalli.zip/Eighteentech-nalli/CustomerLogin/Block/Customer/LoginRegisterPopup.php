<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */

namespace Eighteentech\CustomerLogin\Block\Customer;

use Magento\Framework\View\Element\Template;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Cms\Block\Block;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Data\Form\FormKey;

use Eighteentech\SocialLogin\Block\Google;
use Eighteentech\SocialLogin\Model\Facebook\Client as FacebookClient;

class LoginRegisterPopup extends Template
{
    protected $_customerSession;
    protected $_cmsBlock;
    protected $_jsonEncoder;
    protected $_formKey;
    protected $_googleBlock;
    protected $_facebookClient;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     * @param Data $helper
     * @param customerSession $customerSession
     */
    public function __construct(
        Template\Context $context,
        array $data,
        CustomerSession $customerSession,
        Block $cmsBlock,
        EncoderInterface $jsonEncoder,
        FormKey $formKey,
        Google $googleBlock,
        FacebookClient $facebookClient
    ) {
        $this->_customerSession = $customerSession;
        $this->_cmsBlock = $cmsBlock;
        $this->_jsonEncoder = $jsonEncoder;
        $this->_formKey = $formKey;
        $this->_googleBlock = $googleBlock;
        $this->_facebookClient = $facebookClient;
        parent::__construct($context, $data);
    }

    public function jsOptions()
    {
        $options = [
            'popupTitle' => $this->_cmsBlock->setBlockId('popup-offer-text-slider')->toHtml()
        ];
        return $this->_jsonEncoder->encode($options);
    }

    public function getFormKey()
    {
         return $this->_formKey->getFormKey();
    }

    public function jsOptionsForSocialLogin()
    {
        $options = [
            'googleLoginEnabled' => $this->_googleBlock->isEnabled(),
            'googleClientId' => $this->_googleBlock->clientId(),
            'callbackUrl' => $this->_googleBlock->callBackUrl(),
            'facebookLoginEnabled' => $this->_facebookClient->isEnabled(),
            'facebookAppId' => $this->_facebookClient->getClientId(),
            'fbCallbackUrl' => $this->getUrl('sociallogin/callback/facebook'),
            'logoutUrl' => $this->getUrl('customer/account/logout'),
            'disconnectUrl' => $this->getUrl('customer/account/logout'),
            'checkoutUrl' => $this->getUrl('checkout/'),
        ];
        return $this->_jsonEncoder->encode($options);
    }
}
