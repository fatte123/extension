<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */

namespace Eighteentech\CustomerLogin\Api;

interface AccountManagementInterface
{
    /**
     * Create Customer Account
     *
     * @api
     * @param string $name
     * @param string $email
     * @param string $password
     * @param string $mobilenumber
     * @param string|null $source
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function createCustomerAccount(
        $name,
        $email,
        $password,
        $mobilenumber,
        $source = 'api'
    );

    /**
     * Customer Login
     *
     * @api
     * @param string $username
     * @param string $password
     * @param string|null $source
     * @param string|null $guestCartId
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function login($username, $password, $source = 'api', $guestCartId = null);

    /**
     * Send OTP for Login/Forgot password with mobile/Email
     *
     * @api
     * @param string $source
     * @param string $type
     * @param string|null $username
     * @param int|null $customerId
     * @param string|null $quoteId
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function sendOtp($source = 'api', $type = 'login', $username = null, $customerId = null, $quoteId = null);

    /**
     * Verify OTP for Login/Forgot password
     *
     * @api
     * @param string $id
     * @param string $otp
     * @param string|null $guestCartId
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function verifyOtp($id, $otp, $guestCartId = null);

    /**
     * Resend OTP
     *
     * @api
     * @param string $id
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function resendOtp($id);

    /**
     * Set Password after Forgot password OTP verification
     *
     * @api
     * @param string $id
     * @param string $password
     * @param string|null $guestCartId
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function setPassword($id, $password, $guestCartId = null);
    
    /**
     * To check whether Given Mobile number already verified or Not
     *
     * @api
     * @param int $customerId
     * @param string $mobilenumber
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function isMobileVerified($customerId, $mobilenumber);

    /**
     * Change customer password
     *
     * @param CustomerInterface $customer
     * @param string $newPassword
     * @return bool true on success
     * @throws InputException
     * @throws InvalidEmailOrPasswordException
     * @throws UserLockedException
     */
    public function changePasswordForCustomer($customer, $newPassword);

    /**
     * To check and update primary mobile number
     *
     * @api
     * @param int $customerId
     * @param string $mobilenumber
     * @return \Eighteentech\CustomerLogin\Api\Data\ResultInterface
     */
    public function checkAndUpdatePrimaryMobileNumber($customerId, $mobilenumber);
    
    /**
     * Check if given email is associated with a customer account in given website.
     *
     * @param string $customerEmail
     * @param int $websiteId If not set, will use the current websiteId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isEmailPhoneAvailable($customerEmail, $websiteId = null);
	
}
