<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Api\Data;

interface ResponseInterface
{
    const ID = 'id';
    const CUSTOMER_ID = 'customer_id';
    const CUSTOMER_TOKEN = 'customer_token';
    const IS_MOBILE_ALREADY_EXIST = 'is_mobile_already_exist';
    const IS_MOBILE_ALREADY_VERIFIED = 'is_mobile_already_verified';
    const USER_CART_ID = 'user_cart_id';

    /**
     * Get ID
     *
     * @return string|null
     */
    public function getId();

    /**
     * Set ID
     *
     * @api
     * @param string|null $id
     * @return $this
     */
    public function setId($id);

    /**
     * Get Customer Id
     *
     * @return int|null
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @api
     * @param int|null $customerId
     * @return $this
     */
    public function setCustomerId($customerId);

    /**
     * Get Customer Token
     *
     * @return string|null
     */
    public function getCustomerToken();

    /**
     * Get Customer Token
     *
     * @api
     * @param string|null $customerToken
     * @return $this
     */
    public function setCustomerToken($customerToken);

    /**
     * Get Mobile Already Exist
     *
     * @return bool|null
     */
    public function getIsMobileAlreadyExist();

    /**
     * set Mobile Already Exist
     *
     * @api
     * @param bool|null $isMobileAlreadyExist
     * @return $this
     */
    public function setIsMobileAlreadyExist($isMobileAlreadyExist);

    /**
     * Get Mobile Already Verified against given customer
     *
     * @return bool|null
     */
    public function getIsMobileAlreadyVerified();

    /**
     * set Mobile Already
     *
     * @api
     * @param bool|null $isMobileAlreadyVerified
     * @return $this
     */
    public function setIsMobileAlreadyVerified($isMobileVerified);

    /**
     * Get User Cart ID
     *
     * @return string|null
     */
    public function getUserCartId();

    /**
     * Get Customer Token
     *
     * @api
     * @param string|null $userCartId
     * @return $this
     */
    public function setUserCartId($userCartId);
}
