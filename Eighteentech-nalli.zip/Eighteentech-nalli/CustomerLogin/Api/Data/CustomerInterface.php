<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Api\Data;

interface CustomerInterface
{
    const FIRSTNAME = 'name';
    const EMAIL = 'email';
    const PASSWORD = 'password';
    const MOBILENUMBER = 'mobilenumber';
    
    /**
     * Get First Name
     *
     * @return string
     */
    public function getName();

    /**
     * Set First Name
     *
     * @api
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     * Get Email
     *
     * @return string
     */
    public function getEmail();

    /**
     * Set Email
     *
     * @api
     * @param string$email
     * @return $this
     */
    public function setEmail($email);

    /**
     * Get Customer Id
     *
     * @return string
     */
    public function getPassword();

    /**
     * Set Customer Id
     *
     * @api
     * @param string $password
     * @return $this
     */
    public function setPassword($password);

    /**
     * set Mobile number
     *
     * @return string
     */
    public function getMobilenumber();

    /**
     * Get Mobile number
     *
     * @api
     * @param string $mobilenumber
     * @return $this
     */
    public function setMobilenumber($mobilenumber);
}
