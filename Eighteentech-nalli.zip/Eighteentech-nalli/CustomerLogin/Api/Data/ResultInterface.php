<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Api\Data;

interface ResultInterface
{
    const MESSAGE = 'message';
    const STATUS = 'status';
    const RESPONSE = 'response';
    
    /**
     * Get Status
     *
     * @return boolean|null
     */
    public function getStatus();

    /**
     * Set Status
     *
     * @api
     * @param boolean|null $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get Success/Error Message
     *
     * @return string|null
     */
    public function getMessage();

    /**
     * Set Success/Error Message
     *
     * @api
     * @param string|null $message
     * @return $this
     */
    public function setMessage($message);
    
    /**
     * Get Success/Error Message
     *
     * @return \Eighteentech\CustomerLogin\Api\Data\ResponseInterface|null
     */
    public function getResponse();

    /**
     * Set Success/Error Message
     *
     * @api
     * @param \Eighteentech\CustomerLogin\Api\Data\ResponseInterface|null $response
     * @return $this
     */
    public function setResponse($response);
}
