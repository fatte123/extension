<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_Eshipment
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\CustomerLogin\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_API_KEY = 'otp_config/sms_setting/api_key';
    const XML_PATH_SENDER_ID = 'otp_config/sms_setting/sender_id';
    const XML_PATH_TEMPLATE_REGISTER = 'otp_config/sms_setting/template_register';
    const XML_PATH_TEMPLATE_ID = 'otp_config/sms_setting/template_id';
   
    
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function getGeneralConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_HELLOWORLD .'general/'. $code, $storeId);
    }
    
    /*
     *@return sms api key
     */
    public function getKey($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_API_KEY, $storeId);
    }
    
    /*
     *@return senderId
     */
    public function getSenderId($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_SENDER_ID, $storeId);
    }
    
    /*
     *@return Template Text
     */
    public function getTemplateText($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_TEMPLATE_REGISTER, $storeId);
    }
    
    /*
     *@return template_id
     */
    public function getTemplateId($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_TEMPLATE_ID, $storeId);
    }
}
