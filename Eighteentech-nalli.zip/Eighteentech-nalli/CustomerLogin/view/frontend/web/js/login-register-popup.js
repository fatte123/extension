define([
   "jquery",
    "jquery/ui",
    "Magento_Ui/js/modal/modal",
    "Magento_Customer/js/customer-data",
    "mage/validation/validation",
    "text!Eighteentech_CustomerLogin/templates/modal-login.html",
    "mage/translate",
    "mage/cookies",
    "message",
    "mage/url"
], function ($, tabs, modal, customerData, validate, loginTpl, $t, cookies, message, url) {
    'use strict';
    $.widget('message.loginRegisterPopup', {
        options: {
            loginRegisterPopupId: '#login-register-popup',
            loginRegisterPageId: '#login-register-page',
            loginForm: 'form#login-form',
            registerForm: 'form#form-register-validate',
            forgotPasswordForm: 'form#form-forgotpassword',
            loginWrap: '#login-register-tabs',
            forgotpasswordWrap: '.forgot-password-wrap',
            backtoLoginLink: '.backto-login',
            usingOtpLink: '.using-otp-btn',
            forgotPasswordLink: '#forgotpassword',
            checkoutFromCartPageButton: "button[data-role='proceed-to-checkout']",
            registrationSuccessWrap: '.registration-success-wrap',
            ajaxResendOtpUrl: BASE_URL + 'rest/default/V1/customer/resendOtp/',
            ajaxVerifyOtpUrl: BASE_URL + 'rest/default/V1/customer/verifyOtp/',
            ajaxSendOtpUrl: BASE_URL + 'rest/default/V1/customer/sendOtp/',
            wishlistItemAddUrl: BASE_URL + 'rest/V1/wishlist/addProduct/',
            postType: 'POST',
            removeFromWishlist: 'is-active',
            iconSaved: 'icon-saved',
            returnDefined: false,
            showPasswordElement: '<i class="show-icon"></i>',
            hidePasswordElement: '<i class="hide-icon"></i>',
            otpVerifiedElement: '<i class="shy-tick"></i>',
            otpNotVerifiedElement: '<i class="shy-wrong"></i>',
            mobileNumberChangeElement: '<a class="mobile-change-number">' + $t('Change?') + '</a>',
            resendOtpElement: "<button class='button-as-link resend' type='button'>" + $t('Resend OTP') + "</button>",
            registrationSuccessMessage: $t('Thanks for registration. Please verify mobile number you have registered.'),
            registrationSuccessMessageWithMobileExist: $t('Thanks for registration. The mobile number you have given is already registered. Please update mobile number.'),
            timeLeft:30,
            timerId:'',
            otpId: '',
            messageElement: '.messages',
            regrexPattern: /^[6789]/,
            popupTitle: null,
            inputSelector: 'input[name="form_key"]',
            allowedCharacters: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            allowedLength: 16,
            productReviewModal: null
        },
        _create: function () {
            var self = this;

            customerData.invalidate(['customer']);
            customerData.reload(['customer']);
            customerData.reload(['cart']);
            $('body').trigger('contentUpdated');
            
            var minicart = $('[data-block="minicart"]');
            minicart.on('click', '#top-cart-btn-checkout', function (event) {
            event.preventDefault();
            if (self._isLoggedIn()) {
                window.location.href = BASE_URL + "checkout/";
            } else {
                $(".customer-popup").trigger("click");
                return false;
             }
            });
            
            $(".proceedtocheckout").click(function(event){
                event.preventDefault();
                if (self._isLoggedIn()) {
                     window.location.href = BASE_URL + "checkout/";
                } else {
                    $(".customer-popup").trigger("click");
                    return false; 
                 }
            });
            
            //$(".customerpopupwishlist").click(function(event){
            $(document).on('click', '.customerpopupwishlist', function() {
                event.preventDefault();
                if (self._isLoggedIn()) {
                     window.location.href = BASE_URL + "wishlist/"; 
                } else {
                    $(".customer-popup").trigger("click");
                    return false; 
                 }
            });
            
            
           /* Login Popup*/
            $(document).on('click', '.customer-popup', function(){
                
                self.openLoginPopup();
                $(this).addClass('popup-active');
                $('.login-register-popup').on('click','.action-close', function(){
                    self.resetAllData();
                    if($('.customer-popup').hasClass("popup-active")){
                        $('.customer-popup').removeClass('popup-active');
                    }
                    $('.continue-as-guest').addClass('no-display');
                });
            });
            /*$(document).on('click', '.after-login', function(){
                if (location.href.indexOf('customer/account/') == -1) {
                    window.location.href = BASE_URL + "customer/account";
                }
            });*/  
            self.popupActions();
            self.loginRegisterPageTab();
           // $(".account .logout .logout").attr("href", '#');
            $(document).on('click','.logout', function(event){
                event.preventDefault()
                self.ajaxLogout();
            });
        },
        
        _isLoggedIn: function() { 
            customerData.invalidate(['customer']);
            customerData.reload(['customer']);
            customerData.reload(['wishlist']);
            customerData.reload(['cart']);
            $('body').trigger('contentUpdated');
            var customerInfo = customerData.get('customer')();                     
            return customerInfo.firstname && customerInfo.fullname;                      
         },  
    
        openLoginPopup: function() {
            var self = this, options, popup;
            options = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                clickableOverlay: true,
                title: self.options.popupTitle,
                modalClass: "login-register-popup",
                buttons: false,
                showLoader: true,
                fixedPopup: true,
                heightStyle: "content",
                popupTpl: loginTpl
            };
            popup = $(self.options.loginRegisterPopupId).modal(options);
            popup.modal("openModal");
            self.loginRegisterTab();
           /* var swiper = new Swiper('.popup-login-topbar-offer.swiper-container', {
            autoplay: {
                delay: 3500
              },
            });*/
        },

        loginRegisterTab: function() {
            var self = this;
            $(self.options.loginRegisterPopupId).on('click','#login-register-tabs-list li a',function(e){
                e.preventDefault();
            });
            $(self.options.loginRegisterPopupId).on('click','#login-register-tabs-list li', function(){
                 var tabid = $(this).find("a").attr("href");
                 $("#login-register-tabs-list li,.login-register-tab div.login-register-tab").removeClass("active");
                 $(".login-register-tab").hide();
                 $(tabid).show();
                 $(this).addClass("active");
            });
        },
        loginRegisterPageTab: function() {
            var self = this;
            $(self.options.loginRegisterPageId).on('click','#login-register-tabs-list li a',function(e){
                e.preventDefault();
            });
            $(self.options.loginRegisterPageId).on('click','#login-register-tabs-list li', function(){
                 var tabid = $(this).find("a").attr("href");
                $("#login-register-tabs-list li,.login-register-tab div.login-register-tab").removeClass("active");
                 $(".login-register-tab").hide();
                 $(tabid).show();
                 $(this).addClass("active");
            });
        },

        popupActions: function(){
            var self = this;
            $(self.options.usingOtpLink).on('click', self.usingOtp.bind(this));
            $('.skip').on('click', self.skipVerifyAndLogin.bind(this));
            $('#veirfy-otp').on('click', self.verifyMobileOnRegistration.bind(this));
            $('.form-login').on('submit', function (event) {
                event.preventDefault();
                if ($('.form-login').valid()) {
                    self.ajaxLoginPost();
                    return false;
                }
            });
            $('.form-create-account').on('submit', function (event) {
                event.preventDefault();
                if ($('.form-create-account').valid()) {
                    self.ajaxRegisterPost();
                    return false;
                }
            });
            $(self.options.backtoLoginLink).on('click', function (e) {
                self.clearFormOnTabChange($(self.options.loginForm));
                self.showTemplate(e, 'back');
            });
            $(self.options.forgotPasswordLink).on('click', function (e) {
                self.showTemplate(e, 'login');
            });
            /* Show/hide password*/
            $(".show-hide-password").on('click', function () {
                if ($(this).hasClass('show')) {
                    $(this).html(self.options.hidePasswordElement);
                    $(".hide-show-text").attr("type", "text");
                    $(this).removeClass('show');
                } else {
                    $(this).addClass('show');
                    $(this).html(self.options.showPasswordElement);
                    $(".hide-show-text").attr("type", "password");
                }
            });

            $('.hide-show-text').on('input', function (e) {
                var passwordvalue = $(this).val();
                if (passwordvalue == '') {
                    $(".show-hide-password").html("");
                    $(".hide-show-text").attr("type", "password");
                } else {
                    $(this).closest(".shy-field").addClass("focused");
                    var passwordFieldType = $(this).attr('type');
                    if (passwordFieldType == 'password') {
                        $(".show-hide-password").html(self.options.showPasswordElement);
                        $(".show-hide-password").addClass('show');
                    } else {
                        $(".show-hide-password").html(self.options.hidePasswordElement);
                        $(".show-hide-password").removeClass('show');
                    }
                }
            });
            if ($(self.options.forgotPasswordForm)) {
                $('#form-forgotpassword').on('submit', function (event) {
                    event.preventDefault();
                    if ($('#form-forgotpassword').valid()) {
                        self.ajaxForgotpasswordPost(BASE_URL + "rest/default/V1/customer/sendOtp/");
                        return false;
                    }
                });
            }

            if ($(self.options.forgotPasswordForm)) {
                $('#form-forgotpassword .button').unbind().on('click', function (event) {
                    event.preventDefault();
                    if ($('#form-forgotpassword').valid()) {
                      $(self.options.forgotPasswordForm).find('#forgotpassword-email,#otp').prop("disabled", false);
                      self.ajaxForgotpassword();
                      $(self.options.forgotPasswordForm).find('#forgotpassword-email,#otp').prop("disabled", true);
                        return false;
                    }
                });
            }

            /* Show +91 on start typing*/
            $(self.options.loginForm).find('#login-email').keyup(function () {
                self.validateForNumber(this, 'login', $(self.options.loginForm), '#login-email');
            }).bind('input', function (e) {
                self.validateForNumber(this, 'login', $(self.options.loginForm), '#login-email');
            });
            $(self.options.forgotPasswordForm).find('#forgotpassword-email').keyup(function () {
                self.validateForNumber(this, 'forgotpassword', $(self.options.forgotPasswordForm), '#forgotpassword-email');
            }).bind('input', function () {
                self.validateForNumber(this, 'forgotpassword', $(self.options.forgotPasswordForm), '#forgotpassword-email');
            });
            $(self.options.registerForm).find('#mobilenumber').keyup(function () {
                self.validateForNumber(this, 'create', $(self.options.registerForm), '#mobilenumber');
            }).bind('input', function () {
                self.validateForNumber(this, 'create', $(self.options.registerForm), '#mobilenumber');
            });
            $('.magento_invitation-customer_account-create .form-create-account-invoite').find('#mobilenumber').keyup(function () {
                self.validateForNumber(this, 'create', $('.magento_invitation-customer_account-create .form-create-account-invoite'), '#mobilenumber');
            }).bind('input', function () {
                self.validateForNumber(this, 'create', $('.magento_invitation-customer_account-create .form-create-account-invoite'), '#mobilenumber');
            });
            $('.magento_invitation-customer_account-create .form-create-account-invoite').find('#password').keyup(function () {
               $('#password-confirmation').val($('#password').val());
            }).bind('input', function () {
                $('#password-confirmation').val($('#password').val());
            });

            $("#password-register").bind('input', function () {
                $(this).closest(".field").addClass("focused");

            });
           $('#verify-otp').bind('input', function () {
                var otp = $(this).val();
                if ((otp.length === 6)) {
                    self.ajaxVerifyOtp(self.options.otpId, otp);
                }
            });
            $('#otp').bind('input', function () {
                var otp = $(this).val();
                if ((otp.length === 6)) {
                    self.ajaxForgotPasswordVerifyOtp(self.options.otpId, otp);
                }
            });
            $('#registration-otp').bind('input', function () {
                var otp = $(this).val();
                if ((otp.length === 6)) {
                    self.ajaxRegistrationVerifyOtp(self.options.otpId, otp);
                }
            });
        },

        bindButtonClick() {
            var self = this;
            $(self.options.forgotPasswordForm).find('.resend').unbind().on('click', self.resendOtpForForgotPassword.bind(this));
            $(self.options.loginForm).find('.resend').unbind().on('click', self.resendOtpForLogin.bind(this));
            $(self.options.forgotPasswordForm).find('.mobile-change-number').unbind().on('click', self.allowEditEmailForForgotPassword.bind(this));
            $(self.options.loginForm).find('.mobile-change-number').unbind().on('click', self.allowEditEmailForLogin.bind(this));

            $(self.options.registrationSuccessWrap).find('.resend').unbind().on('click', self.resendOtpForRegistration.bind(this));

        },

    

      showTemplate: function (element, template) {
            if (template == 'back') {
                this.resetForm($(this.options.loginForm));
                $(this.options.forgotpasswordWrap).hide();
                this.allowEditEmailForLogin();
                $(this.options.loginWrap).show();
            } else {
                this.resetForm($(this.options.forgotPasswordForm));
                $(this.options.loginWrap).hide();
                this.allowEditEmailForForgotPassword();
                $(this.options.forgotpasswordWrap).show();

            }

        },

        resetForm: function (form) {
           form.trigger('reset');
           form.find('div.mage-error').hide();
           form.find('div').removeClass('focused');
           form.find('.hide-show-text').attr('type', 'password');
           form.find('.mobile-control-text').remove();
           $(".show-hide-password").html("");
        },

        resetAllData: function () {
            var self = this;
            self.clearTab();
            self.resetForm($(self.options.loginForm));
            self.resetForm($(self.options.registerForm));
            self.resetForm($(self.options.forgotPasswordForm));
            self.allowEditEmailForLogin();
            self.allowEditEmailForForgotPassword();

        },


        clearTab: function () {
            $('#login-register-tabs-list li:first-child').trigger('click');
            $(this.options.loginWrap).show();
            $('.forgot-password-wrap').hide();
        },

        allowEditEmailForForgotPassword: function (element) {
            $(this.options.forgotPasswordForm).find('.mobile-change-number, .resend-otp,.shy-tick,.shy-wrong').remove();
            $(this.options.forgotPasswordForm).find('#forgotpassword-email,#otp').prop("disabled", false);            $(this.options.forgotPasswordForm).find('#otp-verify, .otp , .password, .button').hide();
            $(this.options.forgotPasswordForm).find('.submit').show();
            $(this.options.forgotPasswordForm).find('#verify-otp').val('');
        },

        clearFormOnTabChange: function (form) {
            form.find('#otp-verify').hide();
            form.find('.mobile-change-number,.resend-otp,.mobile-control-text').remove();
            form.find('.password-control,.using-otp').show();
            form.find('div.password').show();
            form.find('.form .input-text').trigger('change');
            form.find('#mobilenumber,#login-email').removeClass("mobile-padding");
            form.find('#login-email').prop("disabled", false);
        },


        allowEditEmailForLogin: function () {
            $(this.options.loginForm).find('.mobile-change-number,.resend-otp,.shy-tick,.shy-wrong').remove();
            $(this.options.loginForm).find('#login-email').prop("disabled", false);
            $(this.options.loginForm).find('#otp-verify').hide();
            $(this.options.loginForm).find('.password-control,.using-otp').show();
            $(this.options.loginForm).find('div.password').show();
            $(this.options.loginForm).find('#verify-otp').val('');
        },


        usingOtp: function () {
           var self = this;
           $(self.options.loginForm).find('#login-email').validation();
           if ($(self.options.loginForm).find('#login-email').validation('isValid')) {
                var mobilenumber = $(self.options.loginForm).find('#login-email').val();
                $(self.options.loginForm).find('#login-email').prop("disabled", true);
                if ($(self.options.loginForm).find('.mobile-change-number').length == 0) {
                    $(self.options.loginForm).find('#login-email-error').before(self.options.mobileNumberChangeElement);

                }
                self.ajaxSendOtp(mobilenumber, 'login', self.options.ajaxSendOtpUrl);

            }

        },



        resendOtpForLogin: function (element) {
           var self = this;
           var formkey = $("input[name=form_key]").val();
            $(self.options.loginForm).find('#login-email').prop("disabled", false);
            if ($(self.options.loginForm).find('.mobile-change-number').length == 0) {
                $(self.options.loginForm).find('#login-email-error').before(self.options.mobileNumberChangeElement);
            }
            self.ajaxSendOtp('', '', self.options.ajaxResendOtpUrl, self.options.otpId);
        },
        verifyMobileOnRegistration: function () {
            var self = this;
            var mobilenumber = $(self.options.registerForm).find('#mobilenumber').val();
            self.ajaxSendRegistrationOtp(mobilenumber, 'register', self.options.ajaxSendOtpUrl);
        },



        resendOtpForForgotPassword: function (element) {
           var self = this;
            $(self.options.forgotPasswordForm).find('#forgotpassword-email,#otp').prop("disabled", false);
            $(self.options.forgotPasswordForm).find('.mobile-change-number').show();
            self.ajaxForgotpasswordPost(self.options.ajaxResendOtpUrl, self.options.otpId);
        },



        resendOtpForRegistration: function () {
            var self = this;
            self.ajaxSendRegistrationOtp('', '', self.options.ajaxResendOtpUrl, self.options.otpId);
        },

        ajaxLoginPost: function () {
            var self = this, payload;
            payload = {
                'username': $(self.options.loginForm).find('#login-email').val(),
                'password': $(self.options.loginForm).find('#pass').val(),
                'source': "html"
            };
            
          self.post(
               BASE_URL + "core/index",
                payload
            ).done(function (response) {
                
            /*after deleting cookies*/  
            self.post(
               BASE_URL + "rest/default/V1/customer/login/",
                payload
            ).done(function (response) {
                console.log('response=>'+response.status); 
                //alert('hi');
                if (response.status == 1) {
                    
                    self.displayMessage({
                        timeToHide: 4000,
                        messageType: 'success',
                        messageText: response.message, 
                        method: 'show'
                    });
                    var today = new Date().getFullYear()+'-'+("0"+(new Date().getMonth()+1)).slice(-2)+'-'+("0"+new Date().getDate()).slice(-2);     
                    smartech('contact', '1',  {'pk^email':$(self.options.loginForm).find('#login-email').val()},function() {
                    smartech('identify',$(self.options.loginForm).find('#login-email').val());
                    smartech('dispatch', 'Exiting User Login', { 
                    "logindate": today,
                    "logintype": "email"
                    }); }); 

                    if(typeof $("#login-register-popup").attr('data-back') !== 'undefined'){
                        if($("#login-register-popup").attr('data-back')=='review'){
                            self.closePopup();
                            $('body').trigger('contentUpdated') 
                            if (!!$.cookie('productId')) {
                            var productId = $.cookie('productId'); 
                                if (productId!="") {
                                    self.addProduct(productId);
                                    $.cookie("productId", null, { path: '/' });
                                }
                            }
                           /* setTimeout(function () {
                                $('.add-your-review').trigger('click');
                            }, 200);*/
                        } else {
                            self.reloadCustomer();
                            console.log(event.currentTarget);
                            var parentElm = $(event.currentTarget).parent();
                            if (parentElm.hasClass('ajax-popup-wishlist'))
                            {
                                event.stopPropagation();
                                event.preventDefault();
                            }
                            setTimeout(function () {
                            self.closePopup();
                            self.reloadCustomer();
                            self.refreshCookie();
                                setTimeout(function () {
                                    if (!self.options.returnDefined) {
                                        $(".after-login-link").trigger('click');
                                    }
                                }, 200);

                            }, 200);
                            
                            var productId = $.cookie('productId');
                            var wistype = $.cookie('wistype');
                            if((wistype=='popup') && (productId !="")) {
                                 self.addWishlistPopupProduct(productId,parentElm);
                            } else { 
                                if (productId!="") {
                                    self.addProduct(productId);
                                    $.cookie("productId", null, { path: '/' });
                                }
                            }
                            $(".customer-popup").removeClass( "customer-popup" ).addClass( "after-login" );
                            self.refreshCookie();

                        }
                    }else{
                        self.reloadCustomer();
                        self.refreshCookie();
                        if (!!$.cookie('productId')) {
                            var productId = $.cookie('productId'); // Get Cookie Value
                                if (productId!="") {
                                    self.addProduct(productId);
                                    $.cookie("productId", null, { path: '/' });
                                }
                        }
                        
                        
                        setTimeout(function () {
                            self.closePopup();
                            window.location.reload();
                        }, 200);
                    }
                } else {
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
            }).fail(function (response) {
          });
                
                
        }).fail(function (response) {
        });
            
            
    },

    
     addWishlistPopupProduct: function (productId,parentElm) {
            var self = this;
            $.ajax({
                url: self.options.wishlistItemAddUrl,
                data: JSON.stringify({productId: productId}),
                type: self.options.postType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    if (response.status) {
                        $('li.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('div.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('#view-page-wishlist').find('.icon-save').addClass(self.options.iconSaved);
                        $('#view-page-wishlist').removeClass(self.options.iconSaved);
                        $('#view-page-wishlist').addClass(self.options.iconSaved);
                        parentElm.find('a .icon-save').addClass(self.options.iconSaved);
                        parentElm.find('a.list-towishlist').addClass(self.options.iconSaved);
                        customerData.invalidate(['wishlist']);
                        customerData.reload(['wishlist']);
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });
                      } else {
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                    }
                }
            });
        },

    addProduct: function (productId) {
        if( productId ) {
            self = this;
            $.ajax({
                url: self.options.wishlistItemAddUrl,
                data: JSON.stringify({productId: productId}),
                type: self.options.postType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    if (response.status) {
                        $('li.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('div.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        customerData.invalidate(['wishlist']);
                        customerData.reload(['wishlist']);
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });                        
                    } else {
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                    }
                }
            });
          }
        },


        ajaxRegisterPost: function () {
            var self = this, payload;
            var s1 = $.cookie('s1')===null?'':$.cookie('s1');
            var s2 = $.cookie('s2')===null?'':$.cookie('s2');
            var utm_source = $.cookie('utm_Source')===null?'':$.cookie('utm_Source');
            var utm_medium = $.cookie('utm_Medium')===null?'':$.cookie('utm_Medium');
            var utm_campaign = $.cookie('utm_Campaign')===null?'':$.cookie('utm_Campaign');
            payload = {
                'name': $(self.options.registerForm).find('#firstname').val(),
                'email': $(self.options.registerForm).find('#registration-email').val(),
                'password': $(self.options.registerForm).find('#password-register').val(),
                'mobilenumber': $(self.options.registerForm).find('#mobilenumber').val(),
                's1':s1,
                's2':s2,
                'c':utm_campaign,
                'utm_source':utm_source,
                'utm_medium':utm_medium,
                'source': "html"
            };
            self.post(
                BASE_URL + "rest/default/V1/customer/create/",
                payload
            ).done(function (response) {
                customerData.invalidate(['customer']);
                customerData.reload(['customer']);
                self.reloadCustomer();
                self.refreshCookie();
                if (response.status) {
    var today = new Date().getFullYear()+'-'+("0"+(new Date().getMonth()+1)).slice(-2)+'-'+("0"+new Date().getDate()).slice(-2);                
    smartech('contact', '1', { 'pk^email': $(self.options.registerForm).find('#registration-email').val(), 'FIRST_NAME': $(self.options.registerForm).find('#firstname').val(),'mobile': $(self.options.registerForm).find('#mobilenumber').val() },
     function() { smartech('identify', $(self.options.registerForm).find('#registration-email').val() ); smartech('dispatch', 'register_nalli', { 'email': $(self.options.registerForm).find('#registration-email').val() , 'FIRST_NAME': $(self.options.registerForm).find('#firstname').val(),'mobile': $(self.options.registerForm).find('#mobilenumber').val(),'signupdate': today }); });                  
                    
                    if(typeof response.message !== 'undefined'){
                        self.displayMessage({
                            timeToHide: 6000,
                            messageType: 'success',
                            messageText: $t(response.message),
                            method: 'show'
                        });
                        self.closePopup();
                    }else{
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: $t('You are Successfully Registered'),
                            method: 'show'
                        });
                        
                    }
                    
                    if(typeof response.response.is_mobile_already_exist!=='undefined'){
                        if (response.response.is_mobile_already_exist == true) {
                          $(self.options.loginWrap).hide();
                          $('#message-content-mobile').html(self.options.registrationSuccessMessageWithMobileExist);
                          $('.registration-mobile-update-wrap').show();
                        } else {
                          $('#message-content').html(self.options.registrationSuccessMessage);
                          var mobilenumber = $(self.options.registerForm).find('#mobilenumber').val();
                          //$('#mobilenumber-display').text('+91' + mobilenumber);
                          $(self.options.loginWrap).hide();
                          if (mobilenumber.length < 10) {
                            $('.skip').trigger('click');
                          }
                          else if (mobilenumber.length > 10 ) {
                            $('.skip').trigger('click');
                          }
                          else if(!self.options.regrexPattern.test(mobilenumber)){
                            $('.skip').trigger('click');
                          }else{
                              $(self.options.registrationSuccessWrap).show();
                          }
                          
                          
                        }
                    }
                   
                    
                } else {
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
            }).fail(function (response) {
           });
        },

        ajaxSendRegistrationOtp: function (mobilenumber, action, url, otpId = '') {
            var self = this, payload;
            payload = {
                'username': mobilenumber,
                'type': action,
                'source': "html"
            };
            if (otpId != '') {
                payload = {
                    'id': otpId
                };
            }
            this.post(url, payload
            ).done(function (response) {
                if (response.status == 1) {
                    self.options.otpId = response.response.id;
                    self.displayMessage({
                        timeToHide: 4000,
                        messageType: 'success',
                        messageText: response.message,
                        method: 'show'
                    });
                    $('.registration-otp').show();
                    $('#veirfy-otp').hide();
                    $('.button-action-row').addClass("skip-only");
                    if ($(self.options.registrationSuccessWrap).find('.resend-otp').length == 0) {
                        $(self.options.registrationSuccessWrap).find('#regis-otp-error').after("<div class='resend-otp'>" + self.options.resendOtpElement + "</div>");
                        $('button.resend').prop('disabled', true);
                        self.options.timeLeft = 30;
                        self.options.timerId = setInterval(function(){
                            if (self.options.timeLeft == -1) {
                                $('button.resend').text('Resend OTP');
                                clearTimeout(self.options.timerId);
                                $('button.resend').prop('disabled', false);
                            } else {
                                $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                self.options.timeLeft--;
                            }
                        }, 1000);
                    }else{
                        $('button.resend').prop('disabled', true);
                        self.options.timeLeft = 30;
                        self.options.timerId = setInterval(function(){
                            if (self.options.timeLeft == -1) {
                                $('button.resend').text('Resend OTP');
                                clearTimeout(self.options.timerId);
                                $('button.resend').prop('disabled', false);
                            } else {
                                $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                self.options.timeLeft--;
                            }
                        }, 1000);
                    }
                } else {
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
                self.bindButtonClick();
            }).fail(function (response) {
           });
        },

        ajaxRegistrationVerifyOtp: function (otpId, otp) {
            var self = this, payload;
            payload = {
                'id': otpId,
                'otp': otp
            };
            this.post(
                self.options.ajaxVerifyOtpUrl,
                payload
            ).done(function (response) {
                if (response.status == 1) {
                    if (location.href.indexOf('customer/account/') > -1) {
                        setTimeout(function () {
                            location.reload();
                        }, 1000);
                    } else {
                        $(self.options.registrationSuccessWrap).find('.resend-otp').remove();
                        if ($(self.options.registrationSuccessWrap).find('.shy-tick').length == 0) {
                            $(self.options.registrationSuccessWrap).find('.shy-wrong').remove();
                            $(self.options.registrationSuccessWrap).find('#regis-otp-error').before(self.options.otpVerifiedElement);
                        }
                        $('body').trigger('contentUpdated');
                        setTimeout(function () {
                            self.closePopup();
                            setTimeout(function () {
                                window.location.reload();
                                /*window.location.href = BASE_URL + "customer/account";*/
                            }, 1000);
                        }, 1000);
                    }
                } else {
                    if ($(self.options.registrationSuccessWrap).find('.shy-wrong').length == 0) {
                        $(self.options.registrationSuccessWrap).find('.shy-tick').remove();
                        $(self.options.registrationSuccessWrap).find('#regis-otp-error').before(self.options.otpNotVerifiedElement);
                    }
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
            }).fail(function (response) {
          });
        },

        ajaxForgotpasswordPost: function (requestUrl, otpId = '') {
            var self = this, payload;
            payload = {
                'username': $(self.options.forgotPasswordForm).find('#forgotpassword-email').val(),
                'type': 'forgotpassword',
                'source': "html"
            };
            if (otpId != '') {
                payload = {
                    'id': otpId
                };
            }
            this.post(
                requestUrl,
                payload
            ).done(function (response) {
                if (response.status == 0) {
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                } else {
                    self.options.otpId = response.response.id;
                    $(self.options.forgotPasswordForm).find('.otp, .password, .button').show();
                    $(self.options.forgotPasswordForm).find('#otp').val('');
                    $(self.options.forgotPasswordForm).find('.shy-tick,.shy-wrong').remove();
                if ($(self.options.forgotPasswordForm).find('.mobile-change-number').length == 0) {
                        $(self.options.forgotPasswordForm).find('#forgotpassword-email').after(self.options.mobileNumberChangeElement);
                    }
                    if ($(self.options.forgotPasswordForm).find('.resend-otp').length == 0) {
                       $('.email-div').append("<div class='resend-otp'>" + self.options.resendOtpElement + "</div>");
                       $('button.resend').prop('disabled', true);
                        self.options.timeLeft = 30;
                        self.options.timerId = setInterval(function(){
                            if (self.options.timeLeft == -1) {
                                $('button.resend').text('Resend OTP');
                                clearTimeout(self.options.timerId);
                                $('button.resend').prop('disabled', false);
                            } else {
                                $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                self.options.timeLeft--;
                            }
                        }, 1000);
                    }else{
                        $('button.resend').prop('disabled', true);
                        self.options.timeLeft = 30;
                        self.options.timerId = setInterval(function(){
                            if (self.options.timeLeft == -1) {
                                $('button.resend').text('Resend OTP');
                                clearTimeout(self.options.timerId);
                                $('button.resend').prop('disabled', false);
                            } else {
                                $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                self.options.timeLeft--;
                            }
                        }, 1000);
                    }
                    self.displayMessage({
                        timeToHide: 4000,
                        messageType: 'success',
                        messageText: response.message,
                        method: 'show'
                    });
                    $(self.options.forgotPasswordForm).find('.submit').hide();
                    $(self.options.forgotPasswordForm).find('.button, #forgotpassword-email,#password').prop("disabled", true);
                    self.bindButtonClick();
                }
            }).fail(function (response) {
        });
       },

       ajaxForgotpassword: function () {
            var self = this, payload;
            payload = {
                'id': self.options.otpId,
                'password': $(self.options.forgotPasswordForm).find('#password').val()
            };
            this.post(
                BASE_URL + "rest/default/V1/customer/setPassword/",
                payload
            ).done(function (response) {
                if (response.status == 1) {
                    self.displayMessage({
                        timeToHide: 4000,
                        messageType: 'success',
                        messageText: response.message,
                        method: 'show'
                    });
                    if (location.href.indexOf('customer/account/') > -1) {
                        setTimeout(function () {
                            location.reload();
                        }, 1000);
                    } else {
                        self.reloadCustomer();
                        self.closePopup();
                        window.location.reload();
                        /*window.location.href = BASE_URL + "customer/account";*/
                        self.refreshCookie();
                    }
                } else {
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
            }).fail(function (response) {
            });
        },

        ajaxForgotPasswordVerifyOtp: function (otpId, otp) {
            var self = this, payload;
            payload = {
                'id': otpId,
                'otp': otp
            };
            this.post(
                BASE_URL + "rest/default/V1/customer/verifyOtp/",
                payload
            ).done(function (response) {
                if (response.status == 1) {
                    $('.forgot-password-wrap #password').prop("disabled", false);
                    $(self.options.forgotPasswordForm).find('.button').prop("disabled", false);
                    if ($(self.options.forgotPasswordForm).find('.shy-tick').length == 0) {
                       $(self.options.forgotPasswordForm).find('.shy-wrong').remove();
                       $(self.options.forgotPasswordForm).find('#otp-error').before(self.options.otpVerifiedElement);
                       $(self.options.forgotPasswordForm).find('#otp-error').hide();
                       $(self.options.forgotPasswordForm).find('#otp-error').html('');
                    }
                    self.displayMessage({
                        timeToHide: 4000,
                        messageType: 'success',
                        messageText: response.message,
                        method: 'show'
                    });
                    $(self.options.forgotPasswordForm).find('#otp').prop("disabled", true);
                } else {
                    if ($(self.options.forgotPasswordForm).find('.shy-wrong').length == 0) {
                        $(self.options.forgotPasswordForm).find('.shy-tick').remove();
                        $(self.options.forgotPasswordForm).find('#otp-error').before(self.options.otpNotVerifiedElement);
                        $(self.options.forgotPasswordForm).find('#otp-error').html(response.message);
                        $(self.options.forgotPasswordForm).find('#otp-error').show();
                    }
                }
            }).fail(function (response) {
          });
        },

        ajaxSendOtp: function (mobilenumber, action, url, otpId = '') {
            var self = this, payload;
            payload = {
                'username': mobilenumber,
                'type': action,
                'source': "html"
            };
            if (otpId != '') {
                payload = {
                    'id': otpId
                };
            }

            self.post(
               BASE_URL + "core/index",
                payload
            ).done(function (response) {
                self.post(
                    url,
                    payload
                ).done(function (response) {
                    if (response.status == 1) {
                        self.options.otpId = response.response.id;
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });
                        $(self.options.loginForm).find('#login-email').prop("disabled", true);
                        $(self.options.loginForm).find('.password-control,.using-otp').hide();
                        $(self.options.loginForm).find('div.password').hide();
                        $(self.options.loginForm).find('#otp-verify').show();
                        if ($(self.options.loginForm).find('.resend-otp').length == 0) {
                            $(self.options.loginForm).find('#login-email-error').after("<div class='resend-otp'>" + self.options.resendOtpElement + "</div>");
                            $('button.resend').prop('disabled', true);
                            self.options.timeLeft = 30;
                            self.options.timerId = setInterval(function(){
                                if (self.options.timeLeft == -1) {
                                    $('button.resend').text('Resend OTP');
                                    clearTimeout(self.options.timerId);
                                    $('button.resend').prop('disabled', false);
                                } else {
                                    $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                    self.options.timeLeft--;
                                }
                            }, 1000);
                        }else{
                            $('button.resend').prop('disabled', true);
                            self.options.timeLeft = 30;
                            self.options.timerId = setInterval(function(){
                                if (self.options.timeLeft == -1) {
                                    $('button.resend').text('Resend OTP');
                                    clearTimeout(self.options.timerId);
                                    $('button.resend').prop('disabled', false);
                                } else {
                                    $('button.resend').text('Resend OTP ('+self.options.timeLeft+')');
                                    self.options.timeLeft--;
                                }
                            }, 1000);
                        }
                    } else {
                       self.displayMessage({
                            timeToHide: 6000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });

                    }
                    self.bindButtonClick();
                }).fail(function (response) {
                });

                $('#login-email').prop("disabled", true);
            });  
        },

        ajaxVerifyOtp: function (otpId, otp) {
            var self = this, payload;
            payload = {
                'id': otpId,
                'otp': otp
            };
            this.post(
                self.options.ajaxVerifyOtpUrl,
                payload
            ).done(function (response) {
                if (response.status == 1) {
                    var today = new Date().getFullYear()+'-'+("0"+(new Date().getMonth()+1)).slice(-2)+'-'+("0"+new Date().getDate()).slice(-2);     
                    smartech('contact', '1',  {'pk^email':response.response.customer_token},function() {
                            smartech('identify',response.response.customer_token);
                            smartech('dispatch', 'Exiting User Login', { 
                            "logindate": today,
                            "logintype": "otp"
                            }); });                     
                    
                    $(self.options.loginForm).find('.resend-otp').remove();
                    self.reloadCustomer();
                    if ($(self.options.loginForm).find('.shy-tick').length == 0) {
                        $(self.options.loginForm).find('.shy-wrong').remove();
                        $(self.options.loginForm).find('#verify-otp-error').before(self.options.otpVerifiedElement);
                    }
                    if (location.href.indexOf('customer/account/') > -1) {
                        setTimeout(function () {
                            location.reload();
                        }, 1000);
                    } else {
                        setTimeout(function () {
                            self.closePopup();
                            setTimeout(function () {
                                window.location.reload();
                                /*window.location.href = BASE_URL + "customer/account";*/
                                self.displayMessage({
                                    timeToHide: 4000,
                                    messageType: 'success',
                                    messageText: response.message,
                                    method: 'show'
                                });
                            }, 1000);
                        }, 1000);
                        /*self.refreshCookie();*/
                    }
                } else {
                    if ($(self.options.loginForm).find('.shy-wrong').length == 0) {
                        $(self.options.loginForm).find('.shy-tick').remove();
                        $(self.options.loginForm).find('#verify-otp-error').before(self.options.otpNotVerifiedElement);
                    }
                    self.displayMessage({
                        timeToHide: 6000,
                        messageType: 'error',
                        messageText: response.message,
                        method: 'show'
                    });
                }
            }).fail(function (response) {
            });
        },


        skipVerifyAndLogin: function () {
            if (location.href.indexOf('customer/account/') > -1) {
                setTimeout(function () {
                    location.reload();
                }, 1000);
            } else {
                var self = this;
                $('body').trigger('contentUpdated');
                customerData.invalidate(['customer']);
                customerData.reload(['customer']);
                customerData.reload(['wishlist']);
                customerData.reload(['cart']);
                this.closePopup();
                setTimeout(function () {
                    window.location.reload();
                   /* window.location.href = BASE_URL + "customer/account";*/
                }, 1000);
            }
        },



        reloadCustomer: function () {
           customerData.invalidate(['customer']);
            customerData.reload(['customer']);
            customerData.reload(['wishlist']);
            customerData.reload(['cart']);
            $('body').trigger('contentUpdated');
        },



        validateForNumber: function (element, area, targetElement, emailKey) {
           var self = this;
           var mobileNumber = $(element).val();
           $(element).val(mobileNumber);
            if ($.isNumeric(mobileNumber) && (self.options.regrexPattern.test(mobileNumber) && (mobileNumber.length <= 10))) {
                if (targetElement.find('.mobile-control-text').length == 0) {
                    //$(element).after('<span class="mobile-control-text">+91 </span>');
                }
                //targetElement.find('.mobile-control ' + emailKey).addClass("mobile-padding");
            } else {
                $('.mobile-control-text').remove();
                targetElement.find('.mobile-control ' + emailKey).removeClass("mobile-padding");
            }
        },

        closePopup: function () {
            var self = this;
            self.resetAllData();
            $(self.options.loginRegisterPopupId).modal("closeModal");
            $('.customer-popup').removeClass('popup-active');
        },
        post: function (url, data) {
            return $.ajax({
                url: url,
                type: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                showLoader: true
            });
        },

        displayMessage: function (options) {
            $(this.options.messageElement).message(options);
        },

        openReviewPopup: function () {
            var self = this, isCustomer = false, customer = customerData.get('customer');
            if (customer().email) {
                isCustomer = true;
            }
            var productreview = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                buttons: false,
                title: "We Love to Hear From you Rate it!!!",
                modalClass: "popup-center shy-product-review",
                clickableOverlay: true,
                heightStyle: "content",
                fixedPopup: true
            };
            self.options.productReviewModal = $('#form-content-wrapper').modal(productreview);
            $('body').trigger('processStart');
            if ($('#form-content-wrapper').html() !== '') {
                self.options.productReviewModal.modal("openModal");
            }
            $('body').trigger('processStop');
        },

        proceedToCheckout: function (event) {
            var cart = customerData.get('cart'), customer = customerData.get('customer');
            event.preventDefault();
            if (!customer().firstname) {
                $('.login-register-popup-wrapper').attr('data-back', 'checkout');
                this.openLoginPopup();
                return false;
            } else {
                location.href = this.options.checkoutUrl;
            }
        },

        refreshCookie: function () {
            var formKey = $.mage.cookies.get('form_key');
            if (!formKey) {
                formKey = this.generateRandomString(this.options.allowedCharacters, this.options.allowedLength);
                $.mage.cookies.set('form_key', formKey);
            }
            $(this.options.inputSelector).val(formKey);
        },
        generateRandomString: function (chars, length) {
            var result = '';
            length = length > 0 ? length : 1;
            while (length--) {
                result += chars[Math.round(Math.random() * (chars.length - 1))];
            }
            return result;
        },

        ajaxLogout: function () {
           var self = this;
           var postUrl = BASE_URL +'customer/account/logout';
                $.ajax({
                    url: postUrl,
                    type: "POST",
                    data: {code: ''},
                    showLoader: true,
                    success: function (response) {
                        console.log(response.status);
                        if (response.status == "success") {
                            $(self.options.messageElement).message({
                                timeToHide: 2000,
                                messageType: 'success',
                                messageText: response.msg,
                                method:'show'
                            });
                           window.location.reload();
                         
                        } else {
                            $(self.options.messageElement).message({
                                timeToHide: 2000,
                                messageType: 'error',
                                messageText: response.msg,
                                method: 'show'
                            });
                        }
                    },
                    error: function (response) {
                        $(self.options.messageElement).message({
                            timeToHide: 2000,
                            messageType: 'error',
                            messageText: response.msg,
                            method:'show'
                        });
                    }
                });
             return false;
        },        
        getStoreBalance: function () {}     
    });
    return $.message.loginRegisterPopup;
});

