var config = {
    map: {
        '*': {
            loginRegisterPopup: 'Eighteentech_CustomerLogin/js/login-register-popup'
        }
    }
};