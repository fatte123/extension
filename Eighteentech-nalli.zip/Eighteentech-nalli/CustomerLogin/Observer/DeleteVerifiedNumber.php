<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Eighteentech\CustomerLogin\Model\ResourceModel\CustomerVerifiedNumber\CollectionFactory;

class DeleteVerifiedNumber implements ObserverInterface
{
    protected $verifiedNoCollection;

    public function __construct(
        CollectionFactory $verifiedNoCollection
    ) {
        $this->verifiedNoCollection = $verifiedNoCollection;
    }

    public function execute(Observer $observer)
    {
        try {
            $customerId = $observer->getCustomer()->getId();
            $verifiedNoCollections = $this->verifiedNoCollection->create();
            $verifiedNoCollections->addFieldToFilter('customer_id', $customerId);
            $count = count($verifiedNoCollections);
            if ($count > 0) {
                foreach ($verifiedNoCollections as $verifiedNo) {
                    $verifiedNo->delete();
                }
            }
        } catch (\Exception $e) {
            $e->getMessage();
        }
    }
}
