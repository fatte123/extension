<?php

namespace Eighteentech\CustomerLogin\Observer;

use Magento\Checkout\Model\Session as CheckoutSession;

class UpdateCart implements \Magento\Framework\Event\ObserverInterface
{
	protected $quoteRepository;
	private $quote;
	 /**
     * @var CheckoutSession
     */
    private $checkoutSession;
	
	public function __construct(
      \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
	  \Magento\Quote\Model\Quote $quote,
	   CheckoutSession $checkoutSession
  	) {
        $this->quoteRepository = $quoteRepository;
		$this->quote = $quote;
		$this->checkoutSession = $checkoutSession;
    }
	
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		/*$customerId = $observer->getData('customer')->getId();
		$quoteId = (int)$this->checkoutSession->getQuote()->getId();
		$quote = $this->quoteRepository->get($quoteId);
		$quote->setCustomerId($customerId); // Whatever you want to update
		$this->quoteRepository->save($quote);*/
		
	}
}