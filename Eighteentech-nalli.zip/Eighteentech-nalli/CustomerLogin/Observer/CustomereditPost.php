<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Eighteentech\CustomerLogin\Model\ResourceModel\CustomerVerifiedNumber\CollectionFactory;

class CustomereditPost implements ObserverInterface
{
    protected $verifiedNoCollection;
    private $logger;
    protected $_customerRepositoryInterface;
    
    public function __construct(
        CollectionFactory $verifiedNoCollection,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->verifiedNoCollection = $verifiedNoCollection;
        $this->logger = $logger;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    public function execute(Observer $observer)
    {
        
        try {
            $event = $observer->getEvent();
            $customer = $observer->getCustomerDataObject();
            $customerId = $customer->getId();
            $customerData = $this->_customerRepositoryInterface->getById($customerId);
            $customerMobile = $customerData->getCustomAttribute('mobile')->getValue();
            $verifiedNoCollections = $this->verifiedNoCollection->create();
            $verifiedNoCollections->addFieldToFilter('customer_id', $customerId);
            $count = count($verifiedNoCollections);
            if ($count > 0) {
                foreach ($verifiedNoCollections as $verifiedNo) {
                    $postMobile = $verifiedNo->getMobilenumber();
                    if ($postMobile!=$customerMobile) {
                                   $verifiedNo->delete();
                                   $customerData->setCustomAttribute('mobile_verified', 0);
                                   $this->_customerRepositoryInterface->save($customerData);
                    }
                }
                
                return $this;
            }
           
        } catch (\Exception $e) {
            $e->getMessage();
        }
    }
}
