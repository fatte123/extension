<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerLogin
 *
 */
namespace Eighteentech\CustomerLogin\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Store\Model\StoreManagerInterface;

use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\RequestInterface;

class AddCustomerData implements ObserverInterface
{
        protected $customer;
        protected $customerFactory;
        protected $_storeManager;
       
        protected $_resultJsonFactory;
        protected $_resultPageFactory;
        protected $request;
        protected $_customerRepositoryInterface;
        
    public function __construct(
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\ResourceModel\CustomerFactory $customerFactory,
        \Magento\Framework\App\RequestInterface $request,
        JsonFactory $resultJsonFactory,
        StoreManagerInterface $storeManager,
        PageFactory $resultPageFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->customer = $customer;
        $this->customerFactory = $customerFactory;
        $this->request = $request;
        $this->_storeManager = $storeManager;
        
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $s1 = '';
        $s2 = '';
        $coupon = '';
        $utmSource = '';
        $utmMedium ='';
        
        $request_data = $observer->getEvent()->getData('request_data');
        $mobilenumber = $this->request->getParam('mobilenumber');
        $customerId = $observer->getEvent()->getData('customer')->getId();
        $customer = $this->customer->load($customerId);
        $customerData = $customer->getDataModel();
        $customerData->setCustomAttribute('mobile', $mobilenumber);
        $customer->updateData($customerData);
        $customerResource = $this->customerFactory->create();
        $customerResource->saveAttribute($customer, 'mobile');
      
        $customerobj = $this->_customerRepositoryInterface->getById($customerId);
        $websiteId = $this->_storeManager->getWebsite()->getId();
        $store = $this->_storeManager->getStore();
        $customerName = $customerobj->getFirstName();
        $customerEmail = $customerobj->getEmail();
        
        if ($mobilenumber!=null) {
            $customerMobile = $mobilenumber;
        } else {
            $customerMobile = '';
        }
        if ($request_data['s1']!="") {
            $s1 = $request_data['s1'];
        }
        if ($request_data['s2']!="") {
            $s2 = $request_data['s2'];
        }
        if ($request_data['c']!="") {
            $coupon = $request_data['c'];
        }
        if ($request_data['utm_source']!="") {
            $utmSource = $request_data['utm_source'];
        }
        if ($request_data['utm_medium']!="") {
            $utmMedium = $request_data['utm_medium'];
        }
        
        $pagename='Registration';
        
       /* $this->_model->autoSubscribe(
            $customerEmail,
            $customerMobile,
            $websiteId,
            $store,
            $s1,
            $s2,
            $utmSource,
            $utmMedium,
            $pagename
        );*/
    }
}
