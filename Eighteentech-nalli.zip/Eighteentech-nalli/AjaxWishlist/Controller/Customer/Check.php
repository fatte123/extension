<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Controller\Customer;

use Magento\Customer\Model\Session as customerSession;
use Magento\Framework\App\Action;
use Magento\Framework\Controller\Result\JsonFactory;

class Check extends Action\Action
{
    protected $_customerSession;
    protected $_resultJsonFactory;

    public function __construct(
        Action\Context $context,
        customerSession $customerSession,
        JsonFactory $resultJsonFactory
    ) {
        $this->_customerSession = $customerSession;
        $this->_resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->_customerSession->isLoggedIn();
        $resultJson = $this->_resultJsonFactory->create();
        return $resultJson->setData(['status' => $result]);
    }
}
