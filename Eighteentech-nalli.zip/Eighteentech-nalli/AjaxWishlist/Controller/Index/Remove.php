<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 

namespace Eighteentech\AjaxWishlist\Controller\Index;

use Magento\Framework\App\Action;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Controller\ResultFactory;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class Remove extends \Magento\Wishlist\Controller\Index\Remove
{

    public function __construct(
        Action\Context $context,
        WishlistProviderInterface $wishlistProvider,
        Validator $formKeyValidator,
        JsonFactory $resultJsonFactory
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        parent::__construct($context, $wishlistProvider, $formKeyValidator);
    }

    public function execute()
    {
       // Override Core Controller to Return as JSON for Ajax Call - (Wishlist Item Remove)
        $output = $this->_resultJsonFactory->create();
        $result = [];
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $result['error'] = __('Invalid Form Key');
            return $output->setData($result);
        }

        $id = (int) $this->getRequest()->getParam('item');
        $item = $this->_objectManager->create(\Magento\Wishlist\Model\Item::class)->load($id);
        if (!$item->getId()) {
            $result['error'] = __('Page not found.');
            return $output->setData($result);
        }
        $wishlist = $this->wishlistProvider->getWishlist($item->getWishlistId());
        if (!$wishlist) {
            $result['error'] = __('Page not found.');
            return $output->setData($result);
        }
        $wishlistItemCounts = 0;
        if ($wishlist) {
            $wishlistItems = $wishlist->getItemCollection();
            $wishlistItemCounts = $wishlistItems->count();
            $wishlistItemCounts--;
        }
        try {
            //For Adobe Implementation
            $sku = $item->getProduct()->getSku();
            $item->delete();
            $wishlist->save();
            $result['sku'] = $sku;
            $result['count'] = $wishlistItemCounts;
            $result['success'] = __('Product Removed From Your Wishlist.');
            return $output->setData($result);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $result['error'] = __('We can\'t delete the item from Wish List right now because of an error: %1.', $e->getMessage());
            return $output->setData($result);
        } catch (\Exception $e) {
            $result['error'] = __('We can\'t delete the item from Wish List right now %1', $e->getMessage());
            return $output->setData($result);
        }
    }
}
