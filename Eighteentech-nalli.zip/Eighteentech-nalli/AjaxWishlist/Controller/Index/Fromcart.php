<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 

namespace Eighteentech\AjaxWishlist\Controller\Index;

use Magento\Checkout\Helper\Cart as CartHelper;
use Magento\Checkout\Model\Cart as CheckoutCart;
use Magento\Framework\App\Action;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Wishlist\Helper\Data as WishlistHelper;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Model\ProductFactory;
use Magento\CatalogInventory\Api\StockRegistryInterfaceFactory;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;

class Fromcart extends \Magento\Wishlist\Controller\Index\Fromcart
{

    protected $_productFactory;
    protected $_stockRegistryInterface;

    public function __construct(
        Action\Context $context,
        WishlistProviderInterface $wishlistProvider,
        WishlistHelper $wishlistHelper,
        CheckoutCart $cart,
        CartHelper $cartHelper,
        Escaper $escaper,
        Validator $formKeyValidator,
        JsonFactory $resultJsonFactory,
        ProductFactory $productFactory,
        StockRegistryInterfaceFactory $stockRegistryInterface,
        \Eighteentech\Netcore\Helper\Data $helperNetcore
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct(
            $context,
            $wishlistProvider,
            $wishlistHelper,
            $cart,
            $cartHelper,
            $escaper,
            $formKeyValidator
        );
        $this->_productFactory = $productFactory;
        $this->_stockRegistryInterface = $stockRegistryInterface;
        $this->helperNetcore = $helperNetcore;
    }

    public function execute()
    {
        if (!$this->formKeyValidator->validate($this->getRequest())) {
             $output = $this->resultJsonFactory->create();
            $result['error'] = __('Form Key Validation Fails');
            return $output->setData($result);
        }

        $wishlist = $this->wishlistProvider->getWishlist();
        if (!$wishlist) {
            throw new NotFoundException(__('Page not found.'));
        }

        $itemId = (int) $this->getRequest()->getParam('itemId');
        if ($itemId) {
            return $this->processMoveToWishlist($itemId, $wishlist);
        }
    }

    public function processMoveToWishlist($itemId, $wishlist)
    {
        $output = $this->resultJsonFactory->create();
        $result = [];
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        try {
            $item = $this->cart->getQuote()->getItemById($itemId);
            if (!$item) {
                $result['error'] = __('The requested cart item doesn\'t exist.');
                return $output->setData($result);
            }

            $productId = $item->getProductId();
            $requestParams = [
                'product_id' => $productId,
                'super_attribute' => null
            ];

            $buyRequest = new \Magento\Framework\DataObject($requestParams);

            $wishlist->addNewItem($productId, $buyRequest);
            $smartechReturn = $this->helperNetcore->getCartJson($productId, '', 1);

            $this->cart->getQuote()->removeItem($itemId);
            $this->cart->save();

            $this->wishlistHelper->calculate();
            $wishlist->save();

            $result['sku'] = $item->getSku();
            $result['success'] = __('Moved to your Wishlist.');
            $result['items_qty_count'] = $this->cart->getQuote()->getItemsQty();
            $result['smartechevent'] = $smartechReturn;
            return $output->setData($result);
        } catch (LocalizedException $e) {
            $result['error'] = __('%1.', $e->getMessage());
            return $output->setData($result);
        } catch (\Exception $e) {


            $result['error'] = __('We can\'t move the item to the wish list.');
            return $output->setData($result);
        }
        return $resultRedirect->setUrl($this->cartHelper->getCartUrl());
    }
}
