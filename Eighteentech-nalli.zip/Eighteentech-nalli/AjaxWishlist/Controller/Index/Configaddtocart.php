<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */

namespace Eighteentech\AjaxWishlist\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Catalog\Model\Product;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Eav\Model\Entity\Attribute;
use Magento\Wishlist\Model\Wishlist;
use Magento\Framework\Controller\Result\JsonFactory;

class Configaddtocart extends Action
{
    protected $_cart;
    protected $_productRepository;
    protected $_entityAttribute;
    protected $_resultPageFactory;
    protected $_product;
    protected $_wishlist;
    protected $resultJsonFactory;

    public function __construct(
        Context $context,
        Cart $cart,
        Product $product,
        ProductRepositoryInterface $productRepository,
        PageFactory $resultPageFactory,
        Attribute $entityAttribute,
        Wishlist $wishlist,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\App\Request\Http $request
    ) {
        parent::__construct($context);

        $this->_cart = $cart;
        $this->_product = $product;
        $this->_productRepository = $productRepository;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_entityAttribute = $entityAttribute;
        $this->_wishlist = $wishlist;
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->request = $request;
    }

    public function execute()
    {

        try {
            $output = $this->_resultJsonFactory->create();
            $result = [];
            //Configurable Product Add to Cart
            $productId = $this->getRequest()->getParam("product");
            $qty = $this->getRequest()->getParam("qty");
            $size = $this->getRequest()->getParam('size');
            $customerId = $this->getRequest()->getParam('customer');
            $sizeAttributeId = $this->_entityAttribute->getIdByCode('catalog_product', 'size');
            $sizeattr = $this->_product->getResource()->getAttribute('size');
            if ($sizeattr->usesSource()) {
                $sizeoption_id = $sizeattr->getSource()->getOptionId($size);
            }

            $options = [
                'product' => $productId,
                "super_attribute" => [$sizeAttributeId => $sizeoption_id],
                "qty" => $qty
            ];

            $_product = $this->_productRepository->getById($productId);
            $optionLabel = $sizeattr->getSource()->getOptionText($sizeoption_id);
            $sku = $_product->getSku();
            $this->_cart->addProduct($_product, $options);
            $this->_cart->save();
            try {
                $wish = $this->_wishlist->loadByCustomerId($customerId);
                $items = $wish->getItemCollection();
                foreach ($items as $item) {
                    if ($item->getProductId() == $productId) {

                        $item->delete();
                        $wish->save();
                        //For Adobe implementation
                        $result['sku'] = $sku;
                        $result['optionLabel'] = $optionLabel;
                        $result['success'] = __(
                            'Item added to your Cart'
                        );
                        //For Adobe build datalayer data for cart item
                        $fullActionName = $this->request->getFullActionName();
                        $dataLayer = '';
                        $result['dataLayerItem'] = $dataLayer;

                        return $output->setData($result);
                    }
                }
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $result['error'] = __('We can\'t add the item to Wish List right now: %1.', $e->getMessage());
                return $output->setData($result);
            }
        } catch (\Exception $e) {
            $result['error'] = __($e->getMessage());
            return $output->setData($result);
        }
    }
}
