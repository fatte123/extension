<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Block\Customer\Wishlist\Item\Column;

use Magento\Catalog\Block\Product\Context;
use Magento\Framework\App\Http\Context as HTTPContext;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Helper\Product\Configuration;
use Magento\Eav\Model\Entity\Attribute;

class Cart extends \Magento\Wishlist\Block\Customer\Wishlist\Item\Column\Cart
{
    protected $_productFactory;
    protected $_product;
    protected $_config;
    protected $_attribute;

    public function __construct(
        Context $context,
        HTTPContext $httpContext,
        $data,
        ProductFactory $productFactory,
        Product $product,
        Configuration $config,
        Attribute $attribute
    ) {
        $this->_productFactory = $productFactory;
        $this->_product = $product;
        $this->_config = $config;
        $this->_attribute = $attribute;
        parent::__construct($context, $httpContext, $data);
    }

    public function getProductType($productId)
    {
        $product = $this->_productFactory->create();
        $product = $product->load($productId);
        $productType = $product->getTypeId();
        return $productType;
    }

    public function getAttributeOptions($id)
    {
        $product = $this->_productFactory->create();
        $product = $product->load($id);
        $productType = $product->getTypeId();
        if ($productType == 'configurable') {
            $productAttributeOptions = $product->getTypeInstance(true)->getConfigurableAttributesAsArray($product);
            $attributeOptions = [];

            foreach ($productAttributeOptions as $productAttribute) {
                $attributeOptions[$productAttribute['label']]['attribute_code'] = $productAttribute['attribute_code'];
                foreach ($productAttribute['values'] as $attribute) {
                    $attributeOptions[$productAttribute['label']]['values']
                    [$attribute['value_index']] = $attribute['store_label'];
                }
            }

            return $attributeOptions;
        }
    }

    public function getConfiguredOptions($item)
    {
        $options = $this->_config->getOptions($item);
        foreach ($options as $index => $option) {
            if (is_array($option) && array_key_exists('value', $option)) {
                if (!(array_key_exists('has_html', $option) && $option['has_html'] === true)) {
                    if (is_array($option['value'])) {
                        foreach ($option['value'] as $key => $value) {
                            $option['value'][$key] = $this->escapeHtml($value);
                        }
                    } else {
                        $option['value'] = $this->escapeHtml($option['value']);
                    }
                }
                $options[$index]['value'] = $option['value'];
            }
        }

        return $options;
    }

    public function getAttributeId($attribute)
    {
        $attributeId = $this->_attribute->getIdByCode('catalog_product', $attribute);
        return $attributeId;
    }

    public function getAttributeOptionId($attribute, $attributeOption)
    {
        $sizeAttribute = $this->_product->getResource()->getAttribute($attribute);
        if ($sizeAttribute->usesSource()) {
            $sizeOptionId = $sizeAttribute->getSource()->getOptionId($attributeOption);
            return $sizeOptionId;
        }
    }
}
