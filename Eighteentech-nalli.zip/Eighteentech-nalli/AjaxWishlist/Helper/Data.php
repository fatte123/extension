<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Cms\Block\Block;
use Magento\Framework\Json\EncoderInterface;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Customer\Model\SessionFactory;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Eighteentech\GA4\Helper\DataLayer;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $cmsBlock;
    protected $jsonEncoder;
    protected $wishlist;
    protected $session;
    protected $stockRegistry;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Eighteentech\GA4\Helper\DataLayer
     */
    protected $dataLayer;

    public function __construct(
        Context $context,
        Block $cmsBlock,
        EncoderInterface $jsonEncoder,
        WishlistFactory $wishlist,
        SessionFactory $session,
        StockRegistryInterface $stockRegistry,
        StoreManagerInterface $storeManager,
        DataLayer $dataLayer
    ) {
        $this->cmsBlock = $cmsBlock;
        $this->jsonEncoder = $jsonEncoder;
        $this->wishlist = $wishlist;
        $this->session = $session;
        $this->stockRegistry = $stockRegistry;
        $this->storeManager = $storeManager;
        $this->dataLayer = $dataLayer;
        parent::__construct($context);
    }

    public function ajaxJsOptions()
    {
        $options = [
            'checkoutUrl' => $this->_getUrl('checkout/cart/index/'),
            'loginCheckUrl' => $this->_getUrl('ajaxwishlist/customer/check'),
            'popupTitle' => $this->cmsBlock->setBlockId('offer-text-slider-wrap')->toHtml()
        ];
        return $this->jsonEncoder->encode($options);
    }

    public function ajaxWishlistOptions()
    {
        $options = [
            'loginCheckUrl' => $this->_getUrl('ajaxwishlist/customer/check'),
            'popupTitle' => $this->cmsBlock->setBlockId('offer-text-slider-wrap')->toHtml()
        ];
        return $this->jsonEncoder->encode($options);
    }

    public function getWishlistProductIds()
    {
        $wishlistDeatils = [];
        if (!empty($this->session->create()->getCustomerId())) {
            $wishlistCollection = $this->wishlist->create()->loadByCustomerId($this->session->create()
            ->getCustomerId(), true)->getItemCollection();
            if (count($wishlistCollection) > 0) {
                foreach ($wishlistCollection->getData() as $wishlistItem) {
                    $wishlistDeatils[] = trim($wishlistItem['product_id']);
                }
            }
        }
        return $wishlistDeatils;
    }

    public function getAjaxWishlistProductIds()
    {
        return $this->jsonEncoder->encode($this->getWishlistProductIds());
    }

    public function getStockStatus($productId)
    {
        return $this->stockRegistry->getStockItem($productId)->getIsInStock();
    }

        /**
     * @param \Magento\Catalog\Model\Product $product
     * @param array $buyRequest
     * @param \Magento\Wishlist\Model\Item $wishlistItem
     * @return array
     */
    public function addToWishListPushData($product, $buyRequest, $wishlistItem)
    {
        $result = [];

        //$result['event'] = 'add_to_wishlist';
        //$result['eventLabel'] = html_entity_decode($product->getName());
        $result['ecommerce'] = [];
        $result['ecommerce']['currency'] = $this->getCurrencyCode();
        $result['ecommerce']['value'] = number_format($product->getPriceInfo()->getPrice('final_price')->getValue(), 2, '.', '');
        //$result['ecommerce']['add'] = [];
        $result['ecommerce']['items'] = [];
        $productData = $this->dataLayer->prepareProductData($product);
        $result['ecommerce']['items'][] = $productData;

        return $result;
    }

    /**
     * @return string
     */
    public function getCurrencyCode()
    {
        return $this->storeManager->getStore()->getCurrentCurrencyCode();
    }

    /**
     * Get store name
     *
     * @return string
     */
    public function getStoreName()
    {
        return $this->storeManager->getStore()->getName();
    }
}
