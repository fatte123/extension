<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */

namespace Eighteentech\AjaxWishlist\Helper;

use Magento\CatalogInventory\Model\ResourceModel\Stock\StatusFactory;
use Magento\CatalogInventory\Model\Spi\StockRegistryProviderInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Request\Http;

class Stock extends \Magento\CatalogInventory\Helper\Stock
{
    protected $request;

    public function __construct(
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        StatusFactory $stockStatusFactory,
        StockRegistryProviderInterface $stockRegistryProvider,
        Http $request
    ) {
        $this->request = $request;
        parent::__construct($storeManager, $scopeConfig, $stockStatusFactory, $stockRegistryProvider);
    }

    /**
     * Add only is in stock products filter to product collection
     *
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $collection
     * @return void
     */
    public function addIsInStockFilterToCollection($collection)
    {
        $stockFlag = 'has_stock_status_filter';
        if (!$collection->hasFlag($stockFlag)) {
            $isShowOutOfStock = $this->scopeConfig->getValue(
                \Magento\CatalogInventory\Model\Configuration::XML_PATH_SHOW_OUT_OF_STOCK,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );

            //Starts: custom code for show the out of stock products only in wistlist
            if (((($this->request->getRouteName() == 'wishlist' && $this->request->getControllerName() == 'index')
             && ($this->request->getActionName() == 'index' || $this->request->getActionName() == 'fromcart'))
             || ($this->request->getRouteName() == 'customer' && $this->request->getControllerName() == 'section'
             && $this->request->getActionName() == 'load')) && !$isShowOutOfStock) {
                $isShowOutOfStock = true;
            }
            //ends: custom code

            $resource = $this->getStockStatusResource();
            $resource->addStockDataToCollection(
                $collection,
                !$isShowOutOfStock
            );
            $collection->setFlag($stockFlag, true);
        }
    }
}
