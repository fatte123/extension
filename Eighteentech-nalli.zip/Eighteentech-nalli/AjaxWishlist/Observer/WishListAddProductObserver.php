<?php

namespace Eighteentech\AjaxWishlist\Observer;

use Magento\Framework\Event\ObserverInterface;

class WishListAddProductObserver implements ObserverInterface
{
    /**
     * @var \WeltPixel\GoogleTagManager\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;
    
    protected $logger;


    /**
     * @param \WeltPixel\GoogleTagManager\Helper\Data $helper
     */
    public function __construct(\WeltPixel\GoogleTagManager\Helper\Data $helper,
                                \Magento\Customer\Model\Session $customerSession,
                                \Psr\Log\LoggerInterface $logger)
    {
        $this->helper = $helper;
        $this->customerSession = $customerSession;
        $this->logger = $logger;
   }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return self
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if (!$this->helper->isEnabled()) {
            return $this;
        }
		
        $product = $observer->getData('product');
        $wishlistItem = $observer->getData('item'); 
        $buyRequest = $wishlistItem->getBuyRequest()->getData(); 

        $this->customerSession->setAddToWishListData($this->helper->addToWishListPushData($product, $buyRequest, $wishlistItem));
        $this->logger->info("111111"); 
        
        //die('this is testing event'); 

        return $this;
    }
}
