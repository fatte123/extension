<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Model\Data;

use Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface;

class WishlistResponse implements \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface
{
    protected $wishlistItemId;
    protected $sku;
    protected $wishevent;
    protected $smartechevent;

    /**
     * @inheritDoc
     */
    public function getWishlistItemId()
    {
        return $this->wishlistItemId;
    }

    /**
     * @inheritDoc
     */
    public function setWishlistItemId($wishlistItemId)
    {
        $this->wishlistItemId = $wishlistItemId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getSku()
    {
        return $this->sku;
    }

    /**
     * @inheritDoc
     */
    public function setSku($sku)
    {
        $this->sku = $sku;
        return $this;
    }
    
    /**
     * @inheritDoc
     */
    public function getWishevent()
    {
        return $this->wishevent;
    }
    
    /**
     * @inheritDoc
     */
    public function setWishevent($wishevent)
    {
        $this->wishevent = $wishevent;
        return $this;
    }
    /**
     * @inheritDoc
     */
    public function getSmartechevent()
    {
        return $this->smartechevent;
    }
    
    /**
     * @inheritDoc
     */
    public function setSmartechevent($smartechevent)
    {
        $this->smartechevent = $smartechevent;
        return $this;
    }    
}
