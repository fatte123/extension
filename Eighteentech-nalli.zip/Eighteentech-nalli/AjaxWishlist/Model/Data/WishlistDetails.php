<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Model\Data;

class WishlistDetails implements \Eighteentech\AjaxWishlist\Api\Data\WishlistDetailsInterface
{

    protected $status;
    protected $message;
    protected $response;
    protected $wishevent;
    protected $smartechevent;

    /**
     * {@inheritdoc}
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * {@inheritdoc}
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * {@inheritdoc}
     */
    public function setStatus($status)
    {
        $this->status = $status;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setMessage($message)
    {
        $this->message = $message;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * {@inheritdoc}
     */
    public function setResponse($response)
    {
        $this->response = $response;
        return $this;
    }
    
    /**
     * @inheritDoc
     */
    public function getWishevent()
    {
      return  $this->wishevent ;
    }
    
    /**
     * @inheritDoc
     */
    public function setWishevent($wishevent)
    {
        $this->wishevent = $wishevent;
        return $this;
    }
     /**
     * @inheritDoc
     */
    public function getSmartechevent()
    {
        return $this->smartechevent;
    }
    
    /**
     * @inheritDoc
     */
    public function setSmartechevent($smartechevent)
    {
        $this->smartechevent = $smartechevent;
        return $this;
    }    
}
