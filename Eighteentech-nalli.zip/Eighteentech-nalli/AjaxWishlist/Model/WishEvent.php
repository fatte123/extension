<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Model;

class WishEvent 
{
	/**
     * Core event manager proxy
     *
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * AjaxWishlist
     *
     * @var \Eighteentech\AjaxWishlist\Helper\Data
     */
    protected $ajaxWishlistHelper;
    
	public function __construct(
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		 \Magento\Framework\Event\ManagerInterface $eventManager,
		 \WeltPixel\GoogleTagManager\Helper\Data $helper,
		 \Magento\Customer\Model\Session $customerSession,
		 \Eighteentech\AjaxWishlist\Helper\Data $ajaxWishlistHelper
		 
	){
	 $this->jsonHelper = $jsonHelper;	
	 $this->helper = $helper;
	 $this->_eventManager = $eventManager; 
	 $this->customerSession = $customerSession;
	 $this->ajaxWishlistHelper = $ajaxWishlistHelper;
		
	}
	
	public function createEvent($wishlist, $product, $result){
		
		  /*$this->customerSession->setAddToWishListData($this->helper->addToWishListPushData($product, $result, $wishlist));*/
		  $this->customerSession->setAddToWishListData($this->ajaxWishlistHelper->addToWishListPushData($product, $result, $wishlist));
		  $data = [];
		  if ($this->customerSession->getAddToWishListData()) {
			$data[] = $this->customerSession->getAddToWishListData();
		  }
		 return [
            'datalayer' => $this->jsonHelper->jsonEncode($data)
        ];
	}
	
}

 /* $this->_eventManager->dispatch('eighteentech_add_product',
                ['wishlist' => $wishlist, 'product' => $product, 'item' => $result] 
            );*/
