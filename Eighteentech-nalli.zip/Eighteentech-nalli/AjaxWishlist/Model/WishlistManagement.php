<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Model;

use Eighteentech\AjaxWishlist\Api\WishlistManagementInterface;
use Eighteentech\AjaxWishlist\Api\Data\WishlistDetailsInterfaceFactory;
use Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterfaceFactory;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Quote\Api\GuestCartItemRepositoryInterfaceFactory;
use Magento\Quote\Api\GuestCartRepositoryInterfaceFactory;
use Eighteentech\CustomApi\Api\CustomerManagementInterfaceFactory;

class WishlistManagement implements WishlistManagementInterface
{

    /**
     * @var ProductRepository
     */
    protected $_productRepository;

    /**
     * @var WishlistFactory
     */
    protected $_wishlistFactory;

    /**
     * @var WishlistDetailsInterfaceFactory
     */
    protected $_wishlistDetailsFactory;

    /**
     * @var WishlistResponseInterfaceFactory
     */
    protected $_wishlistResponseFactory;
    protected $_guestCartItemRepositaryFactory;
    protected $_guestCartRepositaryFactory;
    protected $customerManagementFactory;
    
    protected $logger;
    
    /**
	 * @var \Magento\Framework\Event\ManagerInterface
	 */
    protected $_eventManager;

    public function __construct(
        WishlistFactory $wishlistFactory,
        ProductRepositoryInterface $productRepository,
        WishlistDetailsInterfaceFactory $wishlistDetailsFactory,
        WishlistResponseInterfaceFactory $wishlistResponseFactory,
        GuestCartItemRepositoryInterfaceFactory $guestCartItemRepositaryFactory,
        GuestCartRepositoryInterfaceFactory $guestCartRepositaryFactory,
        CustomerManagementInterfaceFactory $customerManagementFactory,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Psr\Log\LoggerInterface $logger,
        \Eighteentech\AjaxWishlist\Model\WishEvent $WishEvent,
        \Eighteentech\Netcore\Helper\Data $helperNetcore
	) {
        $this->_productRepository = $productRepository;
        $this->_wishlistFactory = $wishlistFactory;
        $this->_wishlistDetailsFactory = $wishlistDetailsFactory;
        $this->_wishlistResponseFactory = $wishlistResponseFactory;
        $this->_guestCartItemRepositaryFactory = $guestCartItemRepositaryFactory;
        $this->_guestCartRepositaryFactory = $guestCartRepositaryFactory;
        $this->customerManagementFactory = $customerManagementFactory;
        $this->_eventManager = $eventManager;
        $this->logger = $logger;
        $this->wishEvent = $WishEvent;
        $this->helperNetcore = $helperNetcore;
    }

    /**
     * {@inheritdoc}
     */
    public function addProductToWishlist($customerId, $productId, $configurations = null)
    {
        $requestParams = [];
        try {
            $wishlist = $this->_wishlistFactory->create()->loadByCustomerId($customerId, true);
            if (!$wishlist->getId() || !$customerId || $wishlist->getCustomerId() != $customerId) {
                $message = __('You cannot add products to this wishlist. Please try once again after re-login');
                return $this->_returnResponse($message);
            }
        } catch (\Exception $e) {
            $message = $e->getMessage();
            return $this->_returnResponse($message);
        }

        $productId = isset($productId) ? (int)$productId : null;
        if (!$productId) {
            $message = __("Product ID cannot be empty.");
            return $this->_returnResponse($message);
        }
        try {
            $product = $this->_productRepository->getById($productId);
            $sku = $product->getSku();
        } catch (\Exception $e) {
            $product = null;
        }
        if (!$product || !$product->isVisibleInCatalog()) {
            $message = __('This product does not exist.');
            return $this->_returnResponse($message);
        }
        try {
            $requestParams = [
                'product_id' => $productId,
                'super_attribute' => $configurations
            ];
            $buyRequest = new \Magento\Framework\DataObject($requestParams);
            $result = $wishlist->addNewItem($product, $buyRequest);
            $smartechReturn = '';
            if (is_string($result)) {
                $message = $result;
                return $this->_returnResponse($message);
            }

            try {
                $wishlist->save();
                $eventReturn = $this->wishEvent->createEvent($wishlist,$product,$result);
                $smartechReturn = $this->helperNetcore->getCartJson($productId, '', 1);
                
				//$str  = $this->helper->getScriptWishlistAdd($json);
               /* $this->logger->info("eighteentech_add_product121212"); 
                $this->_eventManager->dispatch('eighteentech_add_product',
                ['wishlist' => $wishlist, 'product' => $product, 'item' => $result] 
            );*/
            } catch (\Exception $e) {
				$this->logger->info($e->getMessage()); 
                return $this->_returnResponse($e->getMessage());  
            }
            $wishlistItemDetails = $this->customerManagementFactory->create()
            ->getWishlistItems($customerId)->getResponse()->getWishlistItems();
            $wishlistItemDetail = $wishlistItemDetails[count($wishlistItemDetails) - 1];
            $wishlistResponse['wishlist_item_id'] = $wishlistItemDetail->getWishlistItemId();
            $wishlistResponse['sku'] = $sku;
            $wishlistResponse['wishevent'] = $eventReturn;
            $wishlistResponse['smartechevent'] = $smartechReturn;
            //print_r($eventReturn); exit;
            $message = __('Added to your Wishlist.');
            
            return $this->_returnResponse($message, true, $wishlistResponse);
        } catch (\Exception $e) {
			$wishlistResponse['wishlist_item_id'] = ''; 
			$wishlistResponse['sku'] =$sku;
			$wishlistResponse['wishevent'] = '';
            $message = __(' %1', $e->getMessage());
            return $this->_returnResponse($message,false,$wishlistResponse);  
        }
    }

    private function _returnResponse($message, $status = false, $wishlistResponse = [])
    {
        $wishlistResponseInfo = $this->_wishlistDetailsFactory->create();
        $response = $this->_wishlistResponseFactory->create();
        $sku = $wishlistResponse['sku'];
        $wishlistItemId = $wishlistResponse['wishlist_item_id'];
        $wishevent = $wishlistResponse['wishevent'];
        $smartechevent = $wishlistResponse['smartechevent'];
        $response->setSku($sku);
        $response->setWishlistItemId($wishlistItemId);
        $wishlistResponseInfo->setWishevent($wishevent);
        $wishlistResponseInfo->setSmartechevent($smartechevent);
        $wishlistResponseInfo->setResponse($response);
        $wishlistResponseInfo->setStatus($status);
        $wishlistResponseInfo->setMessage($message);
        return $wishlistResponseInfo;
    }

    public function moveProductToWishlist($customerId, $cartId, $itemId)
    {
        $result = $this->_wishlistDetailsFactory->create();
        try {
            $quote = $this->_guestCartRepositaryFactory->create()->get($cartId);
            $item = $quote->getItemById($itemId);

            if (empty($item) || empty($item->getId())) {
                $result->setStatus(false);
                $result->setMessage(__('The requested cart item doesn\'t exist.'));
                return $result;
            }

            if ($item->getQuoteId() == $quote->getId()) {
                $configurations = null;
                $wishlistResult = $this->addProductToWishlist($customerId, $item->getProductId(), $configurations);
                if ($wishlistResult->getStatus()) {
                    try {
                        $this->_guestCartItemRepositaryFactory->create()->deleteById($cartId, $itemId);
                    } catch (\Exception $e) {
                        $result->setStatus(false);
                        $result->setMessage(__($e->getMessage()));
                        return $result;
                    }
                } else {
                    $result->setStatus(false);
                    $result->setMessage($wishlistResult->getMessage());
                    return $result;
                }
                $product = $this->_productRepository->getById($item->getProductId());

                $result->setStatus(true);
                $result->setMessage(__(str_replace('%1', $product->getName(), "%1 has been moved to your wish list.")));
                return $result;
            } else {
                $result->setStatus(false);
                $result->setMessage(__(str_replace(["%1", "%2"], [$cartId, $itemId], "Cart %1 doesn't 
				contain item %2")));
                return $result;
            }
        } catch (\Exception $e) {
            $result->setStatus(false);
            $result->setMessage(__($e->getMessage()));
            return $result;
        }
    }
}

?>