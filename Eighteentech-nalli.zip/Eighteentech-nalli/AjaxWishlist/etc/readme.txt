GraphQL Schema: AjaxWishlist Module
###################################


#####################
## Add to Wishlist ##
#####################
# Add product to customer's wishlist

mutation{
  addToWishlist(productId:"21127") {
    status
    message
    data{
		id
		sku
    }    
  }
}
