var config = {
    map: {
        '*': {
            wishlistAddToCartScript: 'Eighteentech_AjaxWishlist/js/wishlist-add-to-cart',
            ajaxAddToWishlist: 'Eighteentech_AjaxWishlist/js/ajaxwishlist',
            listAjaxAddtoWishlist: 'Eighteentech_AjaxWishlist/js/product-ajaxwishlist',
            selectWishlist: 'Eighteentech_AjaxWishlist/js/select-wishlist-product'
        }
    }
};
