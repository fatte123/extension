/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'jquery',
    'message',
    'Magento_Customer/js/customer-data',
    'Eighteentech_CustomerLogin/js/login-register-popup',
	'jquery/jquery.cookie'
], function ($, message, customerData) {

    'use strict';

    $.widget('ajaxwishlist.ajaxAddToWishlist', {
        options: {
            loginCheckUrl: null,
            wishlistButtonSelector: '.list-towishlist',
            viewPageWishlistButton: '.view-towishlist',
            messagesPopup: '.messages',
            classsOnClickWishlist: 'add-wishlist',
            addtocartForm: '[data-role="tocart-form"]',
            ajaxCartPopupForm: '[data-role="tocart-popup-form"]',
            addtocartViewForm: '#product_addtocart_form',
            formKeyInputSelector: 'input[name="form_key"]',
            popupTitle: null,
            iconSaved: 'icon-saved',
            wishlistItemAddUrl: BASE_URL + 'rest/V1/wishlist/addProduct/',
            wishlistItemRemoveUrl: BASE_URL + 'rest/V1/wishlistItems/',
            getWishlistDetails: BASE_URL + 'rest/V1/wishlistItems/',
            postType: 'POST',
            deleteType: 'DELETE',
            getType: 'GET',
            removeFromWishlist: 'is-active'
        },
        _create: function () {
            var self = this;
            $(this.element).on('click', self.options.wishlistButtonSelector, self.checkLoginAndShowPopup.bind(this));
            $("#view-page-wishlist").on('click', self.checkLoginAndShowPopup.bind(this)); 
			$(document).ready( function() {
				if ($("a.customer-icon.after-login").length > 0){
					self.pdpWishlistLinkClass();
				}
			});
			
			$('#outofstock-popup-link').click(function(){				
				var productId = $('input[name="product"]').val();				
				self.outofstockWishlistLinkClass();				
			});	
			
        },
        
        outofstockWishlistLinkClass:  function () {
           var self = this;
           var productId = $('input[name="product"]').val(); 
           var selectedClass = '';
           var selectedarray = [];
			       
				$.ajax({
					url: self.options.getWishlistDetails,
					type: self.options.getType,
					showLoader: false,
					dataType: 'json',
					contentType: 'application/json',
					success: function (wishlistDetailsResponse) { 						
						if (wishlistDetailsResponse['response']['wishlist_count'] > 0) {
                        for (var index = 0; index < wishlistDetailsResponse['response']['wishlist_count']; index++) {							
							selectedarray.push($.trim(wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']));							
                            if (productId == wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']) {
                                selectedClass = 'icon-saved';
                            }                            
                        }
                       
                        if(selectedClass!=''){				
							
							setTimeout(function(){ 
								$('.ajax-popup-wishlist').find('a.list-towishlist.save-product').addClass(self.options.iconSaved);
								$('.ajax-popup-wishlist').find('.icon-save').addClass(self.options.iconSaved);
							}, 1000);							
						}
                       }
					}      
		   });
        
        				
		},
		
		pdpWishlistLinkClass:  function () {
           var self = this;
           var productId = $('input[name="product"]').val(); 
           var selectedClass = '';
           var selectedarray = [];			       
            $.ajax({
                url: self.options.getWishlistDetails,
                type: self.options.getType,
                showLoader: false,
                dataType: 'json',
                contentType: 'application/json',
                success: function (wishlistDetailsResponse) {					
                    if (wishlistDetailsResponse['response']['wishlist_count'] > 0) {
                        for (var index = 0; index < wishlistDetailsResponse['response']['wishlist_count']; index++) {							
							selectedarray.push($.trim(wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']));  
                            if (productId == wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']) {
                                selectedClass = 'icon-saved';
                            }
                        }
                    }
                    if(selectedClass!=''){
						$('#view-page-wishlist').addClass('icon-saved');
					}
					$('.secondary-item-wishlist a.action').each(function() {
						if($.inArray($(this).attr('data-product-id'), selectedarray) != -1) {							
							$(this).addClass('is-active');
						} else {
							$(this).removeClass('is-active');							
						} 
					  });
				 }
            });
        },
        
        checkLoginAndShowPopup: function (event) {
            var self = this;
            var obj = $(event.currentTarget).data('post');
            if (obj) {
                var action = obj.action;
                var parentElm = $(event.currentTarget).parent();

                /* Wishlist on ajaxcart popup */
                if (parentElm.hasClass('ajax-popup-wishlist'))
                {
                    event.stopPropagation();
                    event.preventDefault();
                    var data = $(this.element).serialize(); 					
                    var productId = $(this.element).find('input[name="product"]').val();
                    var form_key = $(this.element).find('input[name="form_key"]').val();
                    var qty = $(this.element).find('input[name="qty"]').val();
                    var formid = $(this.element).attr('id');
                    var page = formid + '-popup';

                }

                /* View page */
                if (parentElm.hasClass('view-wishlist')) {
                    var productId = $(self.options.addtocartViewForm).find('input[name="product"]').val();
                    var form_key = $(self.options.addtocartViewForm).find('input[name="form_key"]').val();
                    var qty = $(self.options.addtocartViewForm).find('input[name="qty"]').val();
                    var page = 'view';

                }
            }
            $.ajax({
                url: self.options.loginCheckUrl,
                type: 'GET',
                showLoader: true,
                success: function (response) {
                    if (response.status) {
                        /*  If user is logged in then add product to wishlist */

                        if(parentElm.find('a .icon-save').hasClass(self.options.iconSaved)){
                            self.removeProduct(productId,parentElm);
                        } else {
                            self.addProduct(productId,parentElm);
                        }
                    } else {
						$.cookie('productId', productId);
						$.cookie('wistype', 'popup');
                        $('.customer-popup').trigger('click');
                        $('.login-register-popup-wrapper').attr("data-back", "wishlist-" + page);
                    }
                },
                error: function (response) {

                }
            });
            return false;
        },

        addProduct: function (productId,parentElm) { 
            var self = this;
            $.ajax({
                url: self.options.wishlistItemAddUrl,
                data: JSON.stringify({productId: productId}),
                type: self.options.postType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    if (response.status) {
                        
                        $('li.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('div.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('#view-page-wishlist').find('.icon-save').addClass(self.options.iconSaved);
                        $('#view-page-wishlist').removeClass(self.options.iconSaved);
                        $('#view-page-wishlist').addClass(self.options.iconSaved);
                        parentElm.find('a .icon-save').addClass(self.options.iconSaved);
                        parentElm.find('a.list-towishlist').addClass(self.options.iconSaved);
                        customerData.invalidate(['wishlist']);
                        customerData.reload(['wishlist']);
                        
                        var dataLayer = window.dataLayer || [];
                        dataLayer.push({ ecommerce: null });

                        var data = {
                            event: 'add_to_wishlist',
                            ecommerce: $.parseJSON(response.wishevent)
                        };
                        
                        dataLayer.push(data);
                        
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });
                      } else {
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                    }
                }
            });
        },

        removeProduct: function (productId,parentElm) {
           var self = this;
            $.ajax({
                url: self.options.getWishlistDetails,
                type: self.options.getType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (wishlistDetailsResponse) {
                    if (wishlistDetailsResponse['response']['wishlist_count'] > 0) {
                        for (var index = 0; index < wishlistDetailsResponse['response']['wishlist_count']; index++) {
                            if (productId == wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']) {
                                var wishlistItemId = wishlistDetailsResponse['response']['wishlist_items'][index]['wishlist_item_id'];
                                index = wishlistDetailsResponse['response']['wishlist_count'] - 1;
                            }
                        }

                        $.ajax({
                            url: self.options.wishlistItemRemoveUrl + wishlistItemId,
                            type: self.options.deleteType,
                            showLoader: true,
                            dataType: 'json',
                            contentType: 'application/json',
                            success: function (response) {
                                if (response.status) {

                                    $('li.product-item').find('.' + productId).removeClass(self.options.removeFromWishlist);
                                    $('div.product-item').find('.' + productId).removeClass(self.options.removeFromWishlist);
                                    $('#view-page-wishlist').find('.icon-save').removeClass(self.options.iconSaved);
                                    $('#view-page-wishlist').removeClass(self.options.iconSaved);
                                    parentElm.find('a .icon-save').removeClass(self.options.iconSaved);
                                    parentElm.find('a.list-towishlist').removeClass(self.options.iconSaved);
                                    customerData.invalidate(['wishlist']);
                                    customerData.reload(['wishlist']);

                                    self.displayMessage({
                                        timeToHide: 4000,
                                        messageType: 'success',
                                        messageText: response.message,
                                        method: 'show'
                                    });

                                } else {
                                    self.displayMessage({
                                        timeToHide: 4000,
                                        messageType: 'error',
                                        messageText: response.message,
                                        method: 'show'
                                    });
                                }
                            }
                        });

                    }
                }
            });
        },

        displayMessage: function (options) {
            $(this.options.messagesPopup).message(options);
        },

        postParamsForList: function (params) {
            var formKey = $(this.options.formKeyInputSelector).val();
            if (formKey) {
                params.data['form_key'] = formKey;
            }
            return params.data;
        }

    });

    return $.ajaxwishlist.ajaxAddToWishlist;
});
