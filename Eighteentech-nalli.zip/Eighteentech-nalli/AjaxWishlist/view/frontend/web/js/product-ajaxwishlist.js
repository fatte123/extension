/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'jquery',
    'message',
    'Magento_Customer/js/customer-data',
	'jquery/jquery.cookie'
], function ($, message, customerData) {
    'use strict';
    var self;
    $.widget('ajaxwishlist.productAjaxAddToWishlist', {
        options: {
            loginCheckUrl: BASE_URL + 'ajaxwishlist/customer/check/',
            messagesPopup: '.messages',
            classsOnClickWishlist: 'add-wishlist',
            formKeyInputSelector: 'input[name="form_key"]',
            listPageAddToWishlist: '.towishlist',
            wishlistItemAddUrl: BASE_URL + 'rest/V1/wishlist/addProduct/',
            wishlistItemRemoveUrl: BASE_URL + 'rest/V1/wishlistItems/',
            getWishlistDetails: BASE_URL + 'rest/V1/wishlistItems/',
            postType: 'POST',
            getType: 'GET',
            deleteType: 'DELETE',
            removeFromWishlist: 'is-active'

        },
        _create: function () {
            self = this;
            this.element.on('click', self.checkLoginAndShowPopup.bind(this));
        },
        checkLoginAndShowPopup: function (event) {
            self = this;
            var form_key = $(this.options.formKeyInputSelector).val();
            var productId = this.element.find(self.options.listPageAddToWishlist).data('product-id');
            $('li.product-item').removeClass(self.options.classsOnClickWishlist);
            var parentLi = $(event.currentTarget).closest('li');
            parentLi.addClass(self.options.classsOnClickWishlist);
            $.ajax({
                url: self.options.loginCheckUrl,
                type: 'GET',
                showLoader: true,
                success: function (response) {
                    if (response.status) {
                        /*If user is logged in then add product to wishlist*/
                        if ($('li.product-item').find('.' + productId).hasClass(self.options.removeFromWishlist) || $('div.product-item').find('.' + productId).hasClass(self.options.removeFromWishlist)) {
                            self.removeProduct(productId);
                        } else {
                            self.addProduct(productId);
                        }                        
                    } else {
						$.cookie('productId', productId);
                        $('.customer-popup').trigger('click'); 
                        $('.login-register-popup-wrapper').attr("data-back", "wishlist-list");
                    }
                },
                error: function (response) {

                }
            });
            return false;
        },
        addProduct: function (productId) {
            self = this;
            $.ajax({
                url: self.options.wishlistItemAddUrl,
                data: JSON.stringify({productId: productId}),
                type: self.options.postType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (response) {
                    if (response.status) {
                        $('li.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        $('div.product-item').find('.' + productId).addClass(self.options.removeFromWishlist);
                        //customerData.invalidate(['wishlist']);
                        //customerData.reload(['wishlist']);
                        customerData.invalidate(['customer']);
						customerData.reload(['customer']);
						customerData.reload(['wishlist']);
						customerData.reload(['cart']);
						$('body').trigger('contentUpdated');
                        
                        // this is used for push the event on GTM (data layer)                      
						smartech('dispatch', 'Add to Wishlist',{"items": [response.smartechevent]});

                        var dataLayer = window.dataLayer || [];
                        dataLayer.push({ ecommerce: null });

                        var data = {
                            event: 'add_to_wishlist',
                            ecommerce: $.parseJSON(response.wishevent)
                        };
                        
                        dataLayer.push(data);
                        
                   		//window.dataLayer.push(response.wishevent);
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });                        
                    } else {
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                    }
                }
            });
        },

        removeProduct: function (productId) {
            self = this;
            $.ajax({
                url: self.options.getWishlistDetails,
                type: self.options.getType,
                showLoader: true,
                dataType: 'json',
                contentType: 'application/json',
                success: function (wishlistDetailsResponse) {
                    if (wishlistDetailsResponse['response']['wishlist_count'] > 0) {
                        for (var index = 0; index < wishlistDetailsResponse['response']['wishlist_count']; index++) {
                            if (productId == wishlistDetailsResponse['response']['wishlist_items'][index]['product_id']) {
                                var wishlistItemId = wishlistDetailsResponse['response']['wishlist_items'][index]['wishlist_item_id'];
                                index = wishlistDetailsResponse['response']['wishlist_count'] - 1;
                            }
                        }
                        $.ajax({
                            url: self.options.wishlistItemRemoveUrl + wishlistItemId,
                            type: self.options.deleteType,
                            showLoader: true,
                            dataType: 'json',
                            contentType: 'application/json',
                            success: function (response) {
                                if (response.status) {
                                    $('li.product-item').find('.' + productId).removeClass(self.options.removeFromWishlist);
                                    $('div.product-item').find('.' + productId).removeClass(self.options.removeFromWishlist);
                                    customerData.invalidate(['wishlist']);
                                    customerData.reload(['wishlist']);
                                    self.displayMessage({
                                        timeToHide: 4000,
                                        messageType: 'success',
                                        messageText: response.message,
                                        method: 'show'
                                    });
                                } else {
                                    self.displayMessage({
                                        timeToHide: 4000,
                                        messageType: 'error',
                                        messageText: response.message,
                                        method: 'show'
                                    });
                                }
                            }
                        });
                    }
                }
            });
        },

        displayMessage: function (options) {
            $(this.options.messagesPopup).message(options);
        }
    });
    return $.ajaxwishlist.productAjaxAddToWishlist;
});

