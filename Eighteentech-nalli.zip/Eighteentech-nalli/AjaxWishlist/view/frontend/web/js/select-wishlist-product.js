define([
    'jquery',
    'Magento_Customer/js/customer-data',
    'jquery/ui'
], function ($, customerData) {
    'use strict';
    $.widget('eighteentech.selectWishlist', {
        _create: function () {
            /*var self = this, customer;
            customer = customerData.get('customer');
            $('#view-page-wishlist').find('i').removeClass('icon-saved');
            $('#view-page-wishlist').find('span').html("SAVE");
            if ($('body').hasClass('catalog-product-view') && customer().email) {
                var wishlistItems = customerData.get('wishlist')();
                $.each(wishlistItems['items'], function (index, item) {
                    if ((item['product_id'] == $('#product_addtocart_form').find('input[name="product"]').val()) && !($('#view-page-wishlist').find('i').hasClass('icon-saved'))) {
                        $('#view-page-wishlist').find('i').addClass('icon-saved');
                        $('#view-page-wishlist').find('span').html("SAVED");
                    }
                });
            }*/
        }

    });
    return $.eighteentech.selectWishlist;
});