define([
    'jquery',
    'message',
], function ($) {
    'use strict';
    $.widget('ajaxwishlist.wishlistAddToCart', {
        options: {
            bindSubmit: true,
            dataAttribute: 'item-id',
            dataAttributeId: 'product-id',
            dataAttributeUrl: 'url',
            TypeAttribute: 'product-type',
            nameFormat: 'size[{0}]',
            textBoxFormat: 'super_attribute[{0}]',
            qtyFormat: 'qty[{0}]',
            size: '',
            color: '',
            productType: '',
            productId: '',
            url: '',
            configUrl: '',
            checkoutUrl: '',
            messagesPopup: '.messages',
        },
        /**
         * Uses Magento's validation widget for the form object.
         * @private
         */
        _create: function () {
            this.element.on('click', "#wishlist-cartsubmit", $.proxy(this._beforeAddToCart, this))
            this.element.on('click', ".delete", $.proxy(this._removeFromWishlist, this));
        },

        submitHandler: function (elem) {
            /* Submit form using AJAX for add to cart from wishlist page */
            var self = this;
            var size = this.options.size;
            var qty = this.options.qty;
            var productType = this.options.producttype;
            var checkoutUrl = this.options.checkoutUrl;

            if (productType === 'configurable') {
                var productId = this.options.productId;
                var configLink = this.options.configUrl;
                var customerId = $("input[name='customer']").val();

                $.ajax({
                    url: configLink,
                    type: "POST",
                    datatype: "json",
                    showLoader: true,
                    data: {product: productId, size: size, qty: qty, customer: customerId},
                    success: function (response) {
                        if (response.success) {
                            self.displayMessage({
                                timeToHide: 4000,
                                messageType: 'success',
                                messageText: response.success,
                                method: 'show'
                            });
                            window.location = checkoutUrl;

                        }
                        if (response.error) {
                            self.displayMessage({
                                timeToHide: 4000,
                                messageType: 'error',
                                messageText: response.error,
                                method: 'show'
                            });
                        }
                    }
                });
            }

            if (productType === 'simple') {
                var obj = this.options.url;
                var action = obj.action;
                var dataobj = obj.data;
                var itemId = dataobj.item;
                var uenc = dataobj.uenc;
                var formKey = $("input[name='form_key']").val();

                $.ajax({
                    url: action,
                    data: {item: itemId, qty: qty, uenc: uenc, form_key: formKey},
                    type: 'post',
                    showLoader: true,
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            self.displayMessage({
                                timeToHide: 4000,
                                messageType: 'success',
                                messageText: response.success,
                                method: 'show'
                            });
                            window.location = checkoutUrl;

                        }
                    }
                });
            }
        },

        _beforeAddToCart: function (event) {
            /* Get attribute options and qty for configurable products and qty for simple products */
            var self = this;
            var elem = $(event.currentTarget),
                productType = elem.data(this.options.TypeAttribute);
            this.options.producttype = productType;
            var itemId = elem.data(this.options.dataAttribute),
                qtyName = $.validator.format(this.options.qtyFormat, itemId),
                qtyValue = elem.parents().find('[name="' + qtyName + '"]').val();

            this.options.qty = qtyValue;
            if (productType == "configurable") {
                var productId = elem.data(this.options.dataAttributeId);
                this.options.productId = productId;
                var itemId = elem.data(this.options.dataAttribute),
                    sizeName = $.validator.format(this.options.nameFormat, itemId),
                    sizeValue = elem.parents().find('[name="' + sizeName + '"]').val();
                this.options.size = sizeValue;
                var itemId = elem.data(this.options.dataAttribute),
                    attrName = $.validator.format(this.options.textBoxFormat, itemId),
                    attrValue = elem.parents().find('[name="' + attrName + '"]').val(sizeValue);

                if (attrValue.valid()) {
                    self.submitHandler($(this));
                }
            }

            if (productType == "simple") {
                var dataurl = elem.data(this.options.dataAttributeUrl);
                this.options.url = dataurl;
                self.submitHandler($(this));
            }
        },

        _removeFromWishlist: function (event) {
            var self = this;
            event.stopPropagation();
            event.preventDefault();
            var obj = $(event.currentTarget).data('post');
            var action = obj.action;
            var data = obj.data;
            var itemId = data.item;
            var uenc = data.uenc;
            var formKey = $("input[name='form_key']").val();

            $.ajax({
                url: action,
                data: {item: itemId, uenc: uenc, form_key: formKey},
                type: 'post',
                showLoader: true,
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
						$('#block-collapsible-nav .my-wish-list strong').text('My Wishlist ('+response.count+')');
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.success,
                            method: 'show'
                        });
                        $(event.currentTarget).parents().closest("li").remove();
						/* Reload when no Wishlist Item */
						if (($(".product-items li").length) == 0) {
							location.reload();
						}
                    }
                    if (response.error) {
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.error,
                            method: 'show'
                        });

                    }
                    /* Reload when no Wishlist Item */
                    if (($(".product-items li").length) == 0) {
                        location.reload();
                    }
                }
            });
        },

        displayMessage: function (options) {
            $(this.options.messagesPopup).message(options);
        }
    });

    return $.ajaxwishlist.wishlistAddToCart;
});
