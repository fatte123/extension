define([
    'jquery',
    'mage/translate',
    'Magento_Ui/js/modal/modal',
    'Magento_Checkout/js/model/totals',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/action/get-totals',
    'Magento_Customer/js/customer-data',
    'message',
    'Eighteentech_CustomerLogin/js/login-register-popup'
], function ($, $t, modal, totals, quote, getTotalsAction, customerData, message) {
    'use strict';
    
    $.widget('ajaxwishlist.fromCartMoveToWishlist', $.message.loginRegisterPopup, {
        options: {
            bindSubmit: true,
            clickEvent: 'click',
            moveToWishlist: '.action-towishlist',
            removeItem: '.action-delete',
            cart: '.cart',
            itemId: '.itemId',
            hasError: '.hasError',
            productOfferNotifier: '.product-offer-notifier',
            productDetails: '.product-details',
            qtyCount: '.qt_count',
            checkoutUrl: '',
            messagesPopup: '.messages',
            popupTitle: null
        },

        _create: function () {

            if (this.options.bindSubmit) {
                this._bindSubmit();
            }
        },

        _bindSubmit: function () {
            this.element.on(this.options.clickEvent, this.options.moveToWishlist, $.proxy(this.checkLoginAndShowPopup, this));
            this.element.on(this.options.clickEvent, this.options.removeItem, $.proxy(this._removeItemFromCart, this));
        },

        checkLoginAndShowPopup: function (e) {
            var self = this;
            $.ajax({
                url: self.options.loginCheckUrl,
                type: 'GET',
                showLoader: true,
                success: function (response) {
                    if (response.status) {
                        self._moveToWishlist(e);
                    } else {
                        var itemId = $(e.currentTarget).closest(self.options.cart).find(self.options.itemId).val();
                        $(e.currentTarget).closest(self.options.cart).find(self.options.moveToWishlist).attr('id', 'cart-wishlist-' + itemId);
                        localStorage.setItem("itemId", itemId);

                        /* self.initObject(self.options.popupTitle); */
                        self.openLoginPopup();
                        $('#login-register-popup').attr("data-back", "wishlistcart");
                    }
                },
                error: function (response) {
                }
            });
            return false;
        },

        _moveToWishlist: function (event) {
            var self = this;
            event.stopPropagation();
            event.preventDefault();
            var obj = $(event.currentTarget).data('post');
            var action = obj.action;
            var data = obj.data;
            var itemid = $(event.currentTarget).closest(self.options.cart).find(self.options.itemId).val();
            var hasError = $(event.currentTarget).closest(self.options.cart).find(self.options.hasError).val();
            var formKey = $("input[name='form_key']").val();
            var quoteItemsCount = $("input[name='itemCount']").val();
            var checkoutUrl = this.options.checkoutUrl;
            $.ajax({
                url: action,
                data: {itemId: itemid, form_key: formKey},
                type: 'post',
                showLoader: true,
                dataType: 'json',
                success: function (response) {
                    if (response.success)
                    {
                        /* Get offer details for quote items after move-to-wishlist action */
                        $('#shopping-cart-table').trigger("cart_action_offer", []);

                        self.displayMessage({timeToHide: 4000, messageType: 'success', messageText: response.success, method: 'show'});
						smartech('dispatch', 'Add to Wishlist',{"items": [response.smartechevent]});
                        $(event.currentTarget).parents().closest(".cart-item").remove();

                        if (localStorage.getItem("itemId") != null) {
                            localStorage.removeItem("itemId")
                            setTimeout(function () {
                                window.location = checkoutUrl;
                            }, 4000);
                        }

                        quoteItemsCount--;
                        $("input[name='itemCount']").val(quoteItemsCount);
                        if (response.items_qty_count == 1) {
                            $(self.options.qtyCount).html(response.items_qty_count + ' Item');
                        } else {
                            $(self.options.qtyCount).html(response.items_qty_count + ' Item(s)');
                        }
                        if (($("input[name='itemCount']").val()) == 0 || hasError) {
                            window.location = checkoutUrl;
                        }
                        
                    }

                    if (response.error)
                    {
                        self.displayMessage({timeToHide: 4000, messageType: 'error', messageText: response.error, method: 'show'});
                    }
                    /* Trigger Totals Section */
                    var deferred = $.Deferred();
                    getTotalsAction([], deferred);

                    /* Reload Cart Sections */
                    customerData.invalidate(['cart']);
                    customerData.reload(['cart']);
                    
                }

            });
        },

        _removeItemFromCart: function (event) {
            var self = this;
            event.stopPropagation();
            event.preventDefault();
            var obj = $(event.currentTarget).data('post');
            var action = obj.action;
            var data = obj.data;
            var uenc = data.uenc;
            var itemid = $(event.currentTarget).closest(self.options.cart).find(self.options.itemId).val();
            var hasError = $(event.currentTarget).closest(self.options.cart).find(self.options.hasError).val();
            var formKey = $("input[name='form_key']").val();
            var checkoutUrl = this.options.checkoutUrl;
            var quoteItemsCount = $("input[name='itemCount']").val();
            $.ajax({
                url: action,
                data: {id: itemid, uenc: uenc, form_key: formKey},
                type: 'post',
                showLoader: true,
                dataType: 'json',
                success: function (response) {
                    if (response.success)
                    {
                        /* Get the offer details for quote items after remove action */
                        $('#shopping-cart-table').trigger("cart_action_offer", []);

                        self.displayMessage({timeToHide: 4000, messageType: 'success', messageText: response.success, method: 'show'});
                        $(event.currentTarget).parents().closest(".cart-item").remove();
                        quoteItemsCount--;
                        $("input[name='itemCount']").val(quoteItemsCount);
                        if (response.items_qty_count == 1) {
                            $(self.options.qtyCount).html(response.items_qty_count + ' Item');
                        } else {
                            $(self.options.qtyCount).html(response.items_qty_count + ' Item(s)');
                        }

                        if (($("input[name='itemCount']").val()) == 0 || hasError) {
                            window.location = checkoutUrl;
                        }
                        if(response.items_reload==1){
							window.location = checkoutUrl;
						}
                        
                    }
                    if (response.error)
                    {
                        self.displayMessage({timeToHide: 4000, messageType: 'error', messageText: response.error, method: 'show'});
                    }
                    /* Trigger Totals Section */
                    var deferred = $.Deferred();
                    getTotalsAction([], deferred);

                    /* Reload Cart Sections */
                    customerData.invalidate(['cart']);
                    customerData.reload(['cart']);                    
                }

            });
        },

        displayMessage: function (options) {
            $(this.options.messagesPopup).message(options);
        }        

    });
    return $.ajaxwishlist.fromCartMoveToWishlist;
});
