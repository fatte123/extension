<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Api;

/**
 * Interface WishlistManagementInterface
 * @api
 */
interface WishlistManagementInterface
{

    /**
     * Return Added wishlist item.
     *
     * @param int $customerId
     * @param int $productId
     * @param mixed|null $configurations
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistDetailsInterface
     */
    public function addProductToWishlist($customerId, $productId, $configurations = null);

    /**
     * Move item to wishlist from cart
     *
     * @api
     * @param int $customerId
     * @param string $cartId
     * @param int $itemId
     * @param mixed|null $configurations
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistDetailsInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException The specified cart does not exist.
     */
    public function moveProductToWishlist($customerId, $cartId, $itemId);
}
