<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Api\Data;

interface WishlistDetailsInterface
{

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus();

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage();

    /**
     * Set status
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * Set message
     *
     * @return $this
     */
    public function setMessage($message);

    /**
     * Get response
     *
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null
     */
    public function getResponse();

    /**
     * Set response
     * @param \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null $response
     * @return $this
     */
    public function setResponse($response);
    
     /**
     * Get response
     *
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null
     */
    public function getWishevent();
    
     /**
     * Set wishevent
     * @param \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null $wishevent
     * @return $this
     */
    public function setWishevent($wishevent);
     /**
     * Get smartechevent
     *
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null
     */        
    public function getSmartechevent();
     /**
     * Set smartechevent
     * @param \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null $smartechevent
     * @return $this
     */    
    public function setSmartechevent($smartechevent);     
}
