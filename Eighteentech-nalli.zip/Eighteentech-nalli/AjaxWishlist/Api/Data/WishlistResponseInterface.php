<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_AjaxWishlist
 *
 */
 
namespace Eighteentech\AjaxWishlist\Api\Data;

interface WishlistResponseInterface
{
    /**
     * Get wishlist item ID
     *
     * @return int|null $wishlistItemId
     */
    public function getWishlistItemId();

    /**
     * Set wishlist item ID
     *
     * @return $this
     */
    public function setWishlistItemId($wishlistItemId);

    /**
     * Get Sku
     *
     * @return string|null
     */
    public function getSku();

    /**
     * Set Sku
     * @param string $sku
     * @return $this
     *
     */
    public function setSku($sku);
    
     /**
     * Get wishevent
     *
     * @return string|null
     */
    public function getWishevent();

    /**
     * Set wishevent
     * @param string $wishevent
     * @return $this
     *
     */
    public function setWishevent($wishevent);
    
     /**
     * Get smartechevent
     *
     * @return \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null
     */        
    public function getSmartechevent();
     /**
     * Set smartechevent
     * @param \Eighteentech\AjaxWishlist\Api\Data\WishlistResponseInterface|null $smartechevent
     * @return $this
     */    
    public function setSmartechevent($smartechevent);    
}
