var config = {
    map: {
        '*': {
            eighteentechaccountedit: 'Eighteentech_CustomerAvatar/js/account-edit',
        }
    }
};
