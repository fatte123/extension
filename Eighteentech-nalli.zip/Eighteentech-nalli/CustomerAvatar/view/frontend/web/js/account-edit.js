define([
    'jquery',
    'Magento_Customer/js/customer-data',
    'mage/storage',
    'mage/translate',
    'message'
], function ($, customerData, storage, $t) {
    var self;
    $.widget('eighteentech.customeredit', {
        options: {
            accountVerifyClickElement: '.account-verify',
            changePasswordByOtp: "#change-password-by-otp",
            changePassword: "#change-password",
            accountEditForm: 'form.form-edit-account',
            messageElement: '.messages',
            resendOtpElement: "<button class='button-as-link resend pull-right' type='button'>" + $t('Resend OTP ?') + "</button>",
            mobileNumberChangeElement: '<a class="mobile-change-number">' + $t('Change?') + '</a>',
            otpVerifiedElement: '<i class="shy-tick"></i>',
            otpNotVerifiedElement: '<i class="shy-wrong"></i>',
            mobileVerifiedText: '<span class="verified">' + $t('Verified') + '<i class="shy-tick"></i></span>',
            verifyButton: '<a class="account-verify">' + $t("Verify Now ?") + '</a>',
            errorElement: '<div for="mobilenumber" generated="true" class="mage-error" id="mobilenumber-error">%s</div>',
            hiddenField: '<input type="hidden" name="mobilenumber" class="hidden-mobile" id="mobilenumber" />',
            resendOtpElementForChangePassword: "<button class='primary-button-light otp-resend' id='button-as-link-otp-resend-pull-right' type='button'>" + $t('Resend OTP') + "</button>",
            otpIdForEdit: '',
            otpIdForChangePassword: '',
            showPasswordElement: '<i class="show-icon"></i>',
            hidePasswordElement: '<i class="hide-icon"></i>',
            otpButtonIdForChangePassword: 'button-as-link-otp-resend-pull-right',
            resendOtpElementClass: '.button-as-link.resend.pull-right',
            timeLeft:30,
            timerId:'',
            regrexPattern: /^[6789]/
        },
        _create: function () {
            self = this;
            //If click the change password checkbox
            $(this.options.changePassword).click(function () {
                if (!$('#change-password').is(':checked') && $('#change-password-by-otp').is(':checked')) {
                    self.unsetFormField();
                }
            });

            $(this.options.changePasswordByOtp).click(function () {

                //If click the change password using otp checkbox
                if ($('#change-password-by-otp').is(':checked')) {
                    self.sendOtpForChangePassword();
                    $('.password .current').hide();
                    $('.new-password').hide();
                    $('#save-button').prop('disabled', true);
                    $('#otp-change-password').val('');
                    $('.account-otp-change-password').find('.shy-tick').remove();
                    $('.account-otp-change-password').find('.shy-wrong').remove();
                } else {
                   self.unsetFormField();
                }
            });
            this.element.find(self.options.accountVerifyClickElement).on('click', self.sendOtp.bind(this));
			$('#otp-myaccount').bind('input', function () {
                var otp = $(this).val();
                if ((otp.length === 6)) {
                    self.verifyOtp(otp);
                }
            });
            $('#otp-change-password').bind('input', function () {
                var otp = $(this).val();
                if ((otp.length === 6)) {
                    self.verifyOtpForChangePassword(otp);
                }
            });

            // Show/hide password
            $(".show-hide-password.current-password").on('click', function () {
                if ($(".show-hide-password.current-password").hasClass('show')) {
                    $(this).html(self.options.showPasswordElement);
                    $("#current-password").attr("type", "text");
                } else {
                    $(this).html(self.options.hidePasswordElement);
                    $("#current-password").attr("type", "password");

                }
            });

            $('#current-password').on('input', function (e) {
                var passwordvalue = $(this).val();
                if (passwordvalue == '') {
                    $(".show-hide-password.current-password").html("");
                    $("#current-password").attr("type", "password");
                } else {
                    var passwordFieldType = $(this).attr('type');
                    if (passwordFieldType == 'password') {
                        $(".show-hide-password.current-password").html(self.options.showPasswordElement);
                        $(".show-hide-password.current-password").addClass('show');
                    } else {
                        $(".show-hide-password.current-password").html(self.options.hidePasswordElement);
                        $(".show-hide-password.current-password").removeClass('show');
                    }
                }
            });

            // Show/hide password
            $(".show-hide-password.password").on('click', function () {
                if ($(this).hasClass('show')) {
                    $(this).html(self.options.hidePasswordElement);
                    $("#password").attr("type", "text");
                 } else {
                    $(this).html(self.options.showPasswordElement);
                    $("#password").attr("type", "password");
                }
            });

            $('#password').on('input', function (e) {
                var passwordvalue = $(this).val();
                if (passwordvalue == '') {
                    $(".show-hide-password.password").html("");
                    $("#password").attr("type", "password");
                } else {
                    var passwordFieldType = $(this).attr('type');
                    if (passwordFieldType == 'password') {
                        $(".show-hide-password.password").html(self.options.showPasswordElement);
                        $(".show-hide-password.password").addClass('show');
                    } else {
                        $(".show-hide-password.password").html(self.options.hidePasswordElement);
                        $(".show-hide-password.password").removeClass('show');
                    }
                }
            });

            // Show +91 on start typing
            $('form#form-validate').find('#mobilenumber').keyup(function () {
                self.validateForNumber(this, '#mobilenumber');
            }).bind('input', function (e) {
				var mobilenumber = $(this).val();
				var customer_mobile = $('#customer_mobile').val();
				if((mobilenumber !== customer_mobile) && ($('.account-verify').length !=0)){
						$('.account-verify').remove();
				}
                //self.validateForNumber(this, '#mobilenumber');
            });

            $('#mobilenumber').bind('input', function () {
                var mobilenumber = $(this).val();
                if ((mobilenumber.length == 10) && ($(self.options.accountEditForm).find('.verified').length == 0) && ($(self.options.accountEditForm).find('.account-verify').length == 0)) {
                    self.checkMobileNumber(mobilenumber);
                }

            });
            $('.delete-profile').on('click', self.deleteProfile.bind(this));
            if($('#mobilenumber').val()=='.'){
                $('#mobilenumber').val('');
            }
        },

        unsetFormField: function () {
            $("#change-password-by-otp").prop("checked", false);
            $('.account-otp-change-password').hide();
            $('.button-as-link.otp-resend').hide();
            if($('#is_social_login').val()==0){
                $('#current-password-field').show();
                $('#new-password-field').show();
            }            
            $('#save-button').prop('disabled', false);
            $('.shy-new-success').remove();
            $('.shy-new-wrong').remove();
            $('.resend-otp-in-change-password').remove();
            $('#button-as-link-otp-resend-pull-right').remove();
        },

        validateForNumber: function (element, emailKey) {
            var self = this;
            var mobileNumber = $(element).val();
            $(element).val(mobileNumber);

            if ($.isNumeric(mobileNumber) && (self.options.regrexPattern.test(mobileNumber) && (mobileNumber.length <= 10))) {
                if ($('form#form-validate').find('.mobile-control-text').length == 0){
                    //$(element).after('<span class="mobile-control-text">+91 </span>');
                }
               // $('form#form-validate').find('.mobile-control ' + emailKey).addClass("mobile-padding");

            } else {
                //console.log('removenumb'+mobileNumber);
                $('.mobile-control-text').remove();
                $('form#form-validate').find('.mobile-control ' + emailKey).removeClass("mobile-padding");
            }
        },

        deleteProfile: function (e) {
            e.preventDefault();
            var customerId = $(this.options.accountEditForm).find('#customer_id').val(); 
            $.ajax({
                url: BASE_URL + 'customeravatar/avatar/delete',
                data: {customer_id: customerId, is_ajax: true},
                type: 'GET',
                datatype: 'json',
                showLoader: true,
                success: function (response) {
                    if (response.status) {
                        $(self.options.messageElement).message({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method: 'show'
                        });
                        customerData.reload(['customer']);
                        setTimeout(function () {
                            window.location.href = BASE_URL + 'customer/account/edit';
                        }, 4000);
                    } else {
                        $(self.options.messageElement).message({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                    }
                },
                error: function (error) {

                }
            });
        },
        checkMobileNumber: function (mobilenumber) {
            $.ajax({
                url: BASE_URL + 'rest/default/V1/customer/checkPrimaryMobileNumber/',
                data: JSON.stringify({'mobilenumber': mobilenumber}),
                type: 'POST',
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (res) {
                    if (res.status) {
                        $('.account-info-mobile').find('.bar').after(self.options.verifyButton);
                        $('.verified').hide();
                        $('#mobilenumber-error').html('');
                        $('#mobilenumber-error').show();
                    } else {
                        if (res.response.is_mobile_already_verified) {
                            $('.account-info-mobile').find('.bar').after(self.options.mobileVerifiedText);
                            $(self.options.accountEditForm).find('#mobilenumber').prop('readonly', true);

                            if ($(self.element).find('#mobilenumber-error').length == 0) {
                                $('.verified').after(self.options.errorElement.replace('%s', res.message));
                            } else {
                                $('#mobilenumber-error').html(res.message);
                                $('#mobilenumber-error').show();
                            }
                        }
                        if (res.response.is_mobile_already_exist) {
                            if ($(self.element).find('#mobilenumber-error').length == 0) {
                                $('#mobilenumber').after(self.options.errorElement.replace('%s', res.message));
                            } else {
                                $('#mobilenumber-error').html(res.message);
                                $('#mobilenumber-error').show();
                            }
                        }

                    }
                    self.bindButtonClick();
                }
            });
        },

        sendOtp: function () {
            var mobileNumber = $(this.options.accountEditForm).find('#mobilenumber').val();
            $(self.element).find('#mobilenumber-error').remove();

           // if (mobileNumber && (mobileNumber.length == 10)) {
				 if (mobileNumber && (mobileNumber.length != 0)) {
                $.ajax({
                    url: BASE_URL + 'rest/default/V1/customer/sendOtp/',
                    data: JSON.stringify({username: mobileNumber, type: 'edit', 'source': 'html'}),
                    type: 'POST',
                    datatype: 'json',
                    contentType: 'application/json',
                    showLoader: true,
                    success: function (res) {
                        if (res.status == true) {
                            self.options.otpIdForEdit = res.response.id;
                            $('.account-otp').show();
                            if ($(self.element).find('.mobile-change-number').length == 0) {
                                $(self.element).find('#mobilenumber').after(self.options.mobileNumberChangeElement);
                            }
                            if ($(self.element).find('.resend-otp').length == 0) {
                                $('.mobile-change-number').after("<div class='resend-otp'>" + res.message + self.options.resendOtpElement + "</div>");
                                $('.mobile-otp').addClass('otp-enabled');
                            }
								$(self.options.resendOtpElementClass).prop('disabled', true);
                                self.options.timeLeft = 30;
								self.options.timerId = setInterval(self.resendCountdown, 1000);

                            $('.account-verify').hide();
                            $('#mobilenumber').prop("readonly", true);
                        } else {
                            if ($(self.element).find('#mobilenumber-error').length == 0) {
                                $('#mobilenumber').after(self.options.errorElement.replace('%s', res.message));
                            } else {
                                $('#mobilenumber-error').html(res.message);
                                $('#mobilenumber-error').show();
                            }
                        }
                        self.bindButtonClick();
                    }

                });

            } else {
                if ($(self.element).find('#mobilenumber-error').length == 0) {
                    $('.account-verify').after(self.options.errorElement.replace('%s', 'Enter valid mobile number.'));
                } else {
                    $('#mobilenumber-error').html('Enter valid mobile number.');
                    $('#mobilenumber-error').show();
                }
            }
        },
        sendOtpForChangePassword: function () {
            var customer = customerData.get('customer');
            var email = customer().email;
            if(email==undefined){
				email = $('#customer_email').val();
			}
            $(self.element).find('#mobilenumber-error').remove();
			var elem = document.getElementById('some_div');

            if (email) {
                $.ajax({
                    url: BASE_URL + 'rest/default/V1/customer/sendOtp/',
                    data: JSON.stringify({
                        username: email,
                        type: 'changepassword',
                        'source': "html"
                    }),
                    type: 'POST',
                    datatype: 'json',
                    contentType: 'application/json',
                    showLoader: true,
                    success: function (res) {
                        if (res.status == true) {
                            self.options.otpIdForChangePassword = res.response.id;
                            $('.account-otp-change-password').show();
                            if ($(self.element).find('.otp-resend').length == 0) {
                                $('.account-otp-change-password').after(self.options.resendOtpElementForChangePassword);
                                $('.myaccount-otp-wrap').after("<div class='resend-otp-in-change-password'>" + res.message + "</div>");
                                $('#'+self.options.otpButtonIdForChangePassword).prop('disabled', true);
                                self.options.timeLeft = 30;
								self.options.timerId = setInterval(self.resendCountdown, 1000);
                            }
                        } else {
                            self.displayMessage({
                                timeToHide: 6000,
                                messageType: 'error',
                                messageText: res.message,
                                method: 'show'
                            });
                        }
                        self.bindButtonClickForChangePassword();
                    }

                });

            }

        },
		resendCountdown: function() {
			if (self.options.timeLeft == -1) {
			$('#'+self.options.otpButtonIdForChangePassword).text('Resend OTP');
			$(self.options.resendOtpElementClass).text('Resend OTP');
				clearTimeout(self.options.timerId);
				self.resendEnable();
			} else {
				$('#'+self.options.otpButtonIdForChangePassword).text('Resend OTP ('+self.options.timeLeft+')');
				$(self.options.resendOtpElementClass).text('Resend OTP ('+self.options.timeLeft+')');
				self.options.timeLeft--;
			}
		},
		resendEnable: function() {
			$('#'+self.options.otpButtonIdForChangePassword).prop('disabled', false);
			$(self.options.resendOtpElementClass).prop('disabled', false);
		},
        verifyOtp: function (otp) {
            var self = this;

            $.ajax({
                url: BASE_URL + 'rest/default/V1/customer/verifyOtp/',
                data: JSON.stringify({"id": self.options.otpIdForEdit, "otp": otp}),
                type: 'POST',
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (res) {
                    if (res.status == true) {
                        $('.resend-otp,.mobile-change-number').remove();
                        $('#button-as-link-otp-resend-pull-right').remove();
                        if ($('.account-otp').find('.shy-tick').length == 0) {
                            $('.account-otp').find('.shy-wrong').remove();
                            $('.account-otp').find('#otp-error').before(self.options.otpVerifiedElement);
                        }
                        $('.account-info-mobile').find('.input-text').after(self.options.mobileVerifiedText);
                        $('.account-otp').hide();
                        $(self.element).find('#mobilenumber').prop("readonly", true);
                        customerData.reload(['customer']);
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: res.message,
                            method: 'show'
                        });
                    } else {
                        if ($('.account-otp').find('.shy-wrong').length == 0) {
                            $('.account-otp').find('.shy-tick').remove();
                            $('.account-otp').find('#otp-error').before(self.options.otpNotVerifiedElement);
                        }
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: res.message,
                            method: 'show'
                        });
                    }

                }
            });
        },
        verifyOtpForChangePassword: function (otp) {
            self = this;
            $.ajax({
                url: BASE_URL + 'rest/default/V1/customer/verifyOtp/',
                data: JSON.stringify({
                    "id": self.options.otpIdForChangePassword,
                    "otp": otp
                }),
                type: 'POST',
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (res) {
                    if (res.status == true) {
                        $('.resend-otp-in-change-password').remove();
                        $('#button-as-link-otp-resend-pull-right').remove();
                        if ($('.account-otp-change-password').find('.shy-tick').length == 0) {
                            $('.account-otp-change-password').find('.shy-wrong').remove();
                            $('.account-otp-change-password').find('#otp-change-password-error').before(self.options.otpVerifiedElement);
                        }
                        window.setTimeout(function () {                            
                            $('.new-password.field').show();
                            $('.account-otp-change-password').hide();
                            $('#save-button').prop('disabled', false);
                            $('#password').prop('disabled', false);                            
                        }, 2000);
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: res.message,
                            method: 'show'
                        });
                    } else {
                        if ($('.account-otp-change-password').find('.shy-wrong').length == 0) {
                            $('.account-otp-change-password').find('.shy-tick').remove();
                            $('.account-otp-change-password').find('#otp-change-password-error').before(self.options.otpNotVerifiedElement);
                        }
                        self.displayMessage({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: res.message,
                            method: 'show'
                        });
                    }
                }
            });
        },

        bindButtonClick: function () {
            var self = this;
            self.element.find('.resend').unbind().on('click', self.resendOtp.bind(this));
            self.element.find('.mobile-change-number').unbind().on('click', self.allowEdit.bind(this));
            self.element.find(self.options.accountVerifyClickElement).unbind().on('click', self.sendOtp.bind(this));
        },
        bindButtonClickForChangePassword: function () {
            var self = this;
            self.element.find('.otp-resend').unbind().on('click', self.resendOtpForChangePassword.bind(this));
        },
        allowEdit: function () {
            $('#mobilenumber').prop("readonly", false);
            $('.resend-otp,.mobile-change-number').remove();
            $('.account-otp').hide();
            $('.account-verify').show();
            $('.account-otp').find('.shy-tick').remove();
            $('.account-otp').find('.shy-wrong').remove();
            $('#otp').val('');
        },
        resendOtp: function () {
            $.ajax({
                url: BASE_URL + 'rest/default/V1/customer/resendOtp/',
                data: JSON.stringify({id: self.options.otpIdForEdit}),
                type: 'POST',
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (res) {
                    if (res.status == true) {
                        self.options.otpIdForEdit = res.response.id;
                        $('.account-otp').show();

                        if ($(self.element).find('.mobile-change-number').length == 0) {
                            $(self.element).find('#mobilenumber').after(self.options.mobileNumberChangeElement);
                        }
                        if ($(self.element).find('.resend-otp').length == 0) {
                            $('.mobile-change-number').after("<div class='resend-otp'>" + res.message + self.options.resendOtpElement + "</div>");
                            $('.mobile-otp').addClass('otp-enabled');
                        }
                        $(self.options.resendOtpElementClass).prop('disabled', true);
						self.options.timeLeft = 30;
						self.options.timerId = setInterval(self.resendCountdown, 1000);
                        $('.account-verify').hide();
                    }
                    else {
                        self.displayMessage({
                            timeToHide: 6000,
                            messageType: 'error',
                            messageText: res.message,
                            method: 'show'
                        });
                    }
                }
            });
            $('#mobilenumber').prop("disabled", true);
            self.bindButtonClick();
        },
        resendOtpForChangePassword: function () {
            var self = this;
            $.ajax({
                url: BASE_URL + 'rest/default/V1/customer/resendOtp/',
                data: JSON.stringify({
                    "id": self.options.otpIdForChangePassword
                }),
                type: 'POST',
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (res) {
                    if (res.status == true) {
                        self.options.otpIdForChangePassword = res.response.id;
                        $('.account-otp-change-password').show();
                        if ($(self.element).find('.otp-resend').length == 0) {
                            $('.mobile-change-number-in-change-password').after("<div class='resend-otp-in-change-password'>" + res.message + self.options.resendOtpElementForChangePassword + "</div>");
                        }
                        $('#'+self.options.otpButtonIdForChangePassword).prop('disabled', true);
                        self.options.timeLeft = 30;
						self.options.timerId = setInterval(self.resendCountdown, 1000);
                    }
                    else {
                        self.displayMessage({
                            timeToHide: 6000,
                            messageType: 'error',
                            messageText: res.message,
                            method: 'show'
                        });
                    }
                }
            });
            self.bindButtonClickForChangePassword();
        },
        displayMessage: function (options) {
            $(this.options.messageElement).message(options);
        }
    });
    return $.eighteentech.customeredit;
});
