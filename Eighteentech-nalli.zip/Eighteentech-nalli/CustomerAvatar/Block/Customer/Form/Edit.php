<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomerAvatar
 *
 */

namespace Eighteentech\CustomerAvatar\Block\Customer\Form;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\AccountManagementInterface;
use Eighteentech\CustomerLogin\Model\ResourceModel\CustomerVerifiedNumber\CollectionFactory;

class Edit extends \Magento\Customer\Block\Form\Edit
{
    protected $collection;
    
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Newsletter\Model\SubscriberFactory $subscriberFactory,
        CustomerRepositoryInterface $customerRepository,
        AccountManagementInterface $customerManagement,
        CollectionFactory $collection,
        array $data = []
    ) {
        $this->collection = $collection;
        parent::__construct(
            $context,
            $customerSession,
            $subscriberFactory,
            $customerRepository,
            $customerManagement,
            $data
        );
    }
    
    public function isMobileVerified()
    {
        $isVerified = false;
        $customer = $this->getCustomer();
        $customAttribute = $customer->getCustomAttribute('mobile');
        if ($customAttribute) {
            $mobileNumber = $customAttribute->getValue();
            $verifiedNumber = $this->collection->create()->addFieldToFilter('mobilenumber', $mobileNumber)
            ->addFieldToFilter('customer_id', $customer->getId())->getFirstItem();
            if ($verifiedNumber->getId()) {
                $isVerified = true;
            }
        }
        return $isVerified;
    }
    
    public function getMobileNumber()
    {
        $customer = $this->getCustomer();
        $customAttribute = $customer->getCustomAttribute('mobile');
        if ($customAttribute) {
            return $customAttribute->getValue();
        }
        return '';
    }
}
