<?php
namespace Eighteentech\SalesGridFallPico\Helper;

use \Magento\Framework\App\Helper\AbstractHelper as AbstractHelper;

class Data extends AbstractHelper
{
    
    protected $priceCurrency;

    public function __construct(
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency
    ) {
       
        $this->priceCurrency = $priceCurrency;
    }
     
     public function getCurrencyWithFormat($price)
    {
        return $this->priceCurrency->format($price,true,2);
    }
}
