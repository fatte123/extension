<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_SalesGridFallPico
 *
 */
 
namespace Eighteentech\SalesGridFallPico\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\View\Element\Context as Context;

class OptionPriceAfterAddtoCart implements ObserverInterface
{

    protected $_productRepository;

     /**
      * @var  $logger
      */
    protected $logger;

    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        Context $context,
        RequestInterface $request,
        CheckoutSession $checkoutSession
    ) {
        $this->logger = $logger;
        $this->_productRepository = $productRepository;
        $this->_request = $request;
        $this->checkoutSession = $checkoutSession;
    }
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
            
            $postData = $this->_request->getPost();

            $productId = $postData['product'];
            $item = $observer->getEvent()->getData('quote_item');
            $item = ($item->getParentItem() ? $item->getParentItem() : $item);
            $id = $item->getProductId();
            
            $product = $this->getProductById($id);
            if(isset($postData['options'])){
                foreach ($product->getOptions() as $options) {
                    if (!empty($options)) {
                        $optionData = $options->getValues();
                        foreach ($optionData as $data) {
                            $data->getPrice();
                        }
                        $this->logger->info("get option data : {$data->getPrice()}");                       
                        $item->setOptionPrice($data->getPrice());

                    }
                }
            }
    }

    public function getProductById($id)
    {
        return $this->_productRepository->getById($id);
    }
}
