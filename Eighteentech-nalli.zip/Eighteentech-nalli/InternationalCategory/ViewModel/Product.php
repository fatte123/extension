<?php

namespace Eighteentech\InternationalCategory\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class Product implements ArgumentInterface
{
    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $categoryModel;

    /**
     * Constructor
     *
     * @param \Magento\Catalog\Model\Category $categoryModel
     */
    public function __construct(
        \Magento\Catalog\Model\CategoryFactory $categoryModel
    ) {
        $this->categoryModel = $categoryModel;
    }

    /**
     * Get Is Omni Channel Data
     *
     * @param \Magento\Catalog\Model\Product $_product
     * @return array
     */
    public function getIsOmniChanelData(\Magento\Catalog\Model\Product $_product)
    {
        $catIds = $_product->getCategoryIds();
        $flag = 0;
        $result = [];
        foreach ($catIds as $catId) {
            $cate = $this->categoryModel->create();
            $category = $cate->load($catId);
            //echo "Omni ".$category->getIsOmni();

            if ($category->getIsOmni() && ($category->getThresholdPrice() != 'NULL')) {
                if ($category->getThresholdPrice() > (int)$_product->getPrice()) {
                    $flag = 1;
                    $result[$_product->getId()]['flag'] = $flag;
                    $result[$_product->getId()]['category'] = $category->getData();
                }
            }
        }
        return $result;
    }

    /**
     * Get International Details
     *
     * @param \Magento\Catalog\Model\Product $_product
     * @return array
     */
    public function getInternationalData(\Magento\Catalog\Model\Product $_product)
    {
        $catIds = $_product->getCategoryIds();
        $flag = 0;
        $result = [];
        foreach ($catIds as $catId) {
            $cate = $this->categoryModel->create();
            $category = $cate->load($catId);
            if ($category->getIsOmni()) {
                $flag = 1;
                $result[$_product->getId()]['flag'] = $flag;
                $result[$_product->getId()]['category'] = $category->getData();
            }
        }
        return $result;
    }
}
