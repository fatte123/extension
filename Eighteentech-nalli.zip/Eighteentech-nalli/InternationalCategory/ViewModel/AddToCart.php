<?php

namespace Eighteentech\InternationalCategory\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class AddToCart implements ArgumentInterface
{
    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $categoryModel;

    /**
     * Constructor
     *
     * @param \Magento\Catalog\Model\Category $categoryModel
     */
    public function __construct(
        \Magento\Catalog\Model\CategoryFactory $categoryModel
    ) {
        $this->categoryModel = $categoryModel;
    }

    /**
     * Get Is Omni Channel
     *
     * @param \Magento\Catalog\Model\Product $_product
     * @return array
     */
    public function getIsOmniChanelData(\Magento\Catalog\Model\Product $_product)
    {
        $catIds = $_product->getCategoryIds();
        $flag = 0;
        $result = [];
        foreach ($catIds as $catId) {
            $cate = $this->categoryModel->create();
            $category = $cate->load($catId);
            if ($category->getIsOmni() && ($category->getThresholdPrice() != 'NULL')) {
                if ($category->getThresholdPrice() > (int)$_product->getPrice()) {
                    $flag = 1;
                    $result[$_product->getId()]['flag'] = $flag;
                    $result[$_product->getId()]['category'] = $category->getData();
                }
            }
        }
        return $result;
    }
}
