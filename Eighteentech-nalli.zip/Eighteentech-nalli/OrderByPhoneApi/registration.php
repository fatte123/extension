<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_OrderByPhoneApi
 * @author     https://www.18thdigitech.com/
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Eighteentech_OrderByPhoneApi',
    __DIR__
);
