<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_OrderByPhoneApi
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\OrderByPhoneApi\Model;

use Eighteentech\OrderByPhoneApi\Api\OrderManagementInterface;
use Psr\Log\LoggerInterface;

class OrderManagement implements OrderManagementInterface
{
     /**
      * @var Psr\Log\LoggerInterface
      */
    protected $logger;
     /**
      * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
      */
    protected $_orderCollectionFactory;
     /**
      * @var \Magento\Store\Model\StoreManagerInterface
      */
    public $_storeManager;
    
    /**
     * @var \Magento\Framework\Webapi\Rest\Request
     */
    protected $request;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $curl;
    
    /**
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Webapi\Rest\Request $request
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     */
    public function __construct(
        LoggerInterface $logger,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Webapi\Rest\Request $request,
        \Magento\Framework\HTTP\Client\Curl $curl
    ) {
        $this->logger=$logger;
        $this->_storeManager=$storeManager;
        $this->_orderCollectionFactory=$orderCollectionFactory;
        $this->request = $request;
        $this->curl = $curl;
    }

    /**
     * Retrieve loaded order rest api with searchCriteria
     * @param $telephone
     * @return void
     */
    public function getOrderback($telephone)
    {
        try {
            //get the order entity_id  using phone number
            $collection=$this->getOrderCollection($telephone);
            $entity=[];
            foreach ($collection as $orders) {
                   $entity[] =  $orders->getData('entity_id');
            }
            //conver arry to string
            $orderidList = implode(',', $entity);
            $URL=$this->_storeManager->getStore()->getBaseUrl(); // your magento base url
            $tokens = $this->getAuthToken();
            /**send api request to get multiple order id*/
            header("Content-Type: application/json; charset=UTF-8");
            
            /**It will return all params which will pass from body of postman.*/
            $currentPage = $this->request->getParam('currentPage');
            if (!empty($currentPage)) {
                $currentPage;
            } else {
                $currentPage=1;
            }
            $pageSize = $this->request->getParam('pageSize');
            if (!empty($pageSize)) {
                $pageSize;
            } else {
                $pageSize=5;
            }

            $entityid = 'searchCriteria[filter_groups][0][filters][0][field]=entity_id&';
            $orderidl = 'searchCriteria[filter_groups][0][filters][0][value]='.$orderidList.'&';
            $condition = 'searchCriteria[filter_groups][0][filters][0][condition_type]=in&';
            $ordentityid = 'searchCriteria[sortOrders][1][field]=entity_id&';
            $sortor = 'searchCriteria[sortOrders][1][direction]=DESC&';
            $cpage = 'searchCriteria[currentPage]='.$currentPage.'&';
            $psize = 'searchCriteria[pageSize]='.$pageSize;

            $apiurl = $URL."rest/V1/orders/?".$entityid.$orderidl.$condition.$ordentityid.$sortor.$cpage.$psize;
            $ch = $this->curl;
            $ch->setOption(CURLOPT_ENCODING, 'UTF-8');
            $ch->setOption(CURLOPT_CUSTOMREQUEST, "GET");
            $ch->setOption(CURLOPT_RETURNTRANSFER, true);
            $ch->addHeader("Authorization", $tokens);
            $ch->addHeader("Content-Type", "application/json");
            $ch->addHeader("Accept", "application/json");
            
            $ch->get($apiurl);
            $result =  $ch->getBody();
            return print_r($result);

        } catch (\Exception $e) {
            $response=[];
            $response = ['message' => "some thing went wrong", 'trace' => $e->getMessage()];
            $this->logger->critical('Error message', ['exception' =>$e->getMessage()]);
        }
    }
    
    /**
     * Retrieve Order Collection using telephone
     * @param $telephone
     * @return array
     */
    public function getOrderCollection($telephone)
    {
        $telephoneOne = substr($telephone, 3);
        $telephoneTwo = substr($telephone, 2);
        $telephoneThree = substr($telephone, 1);
        
        $collection = $this->_orderCollectionFactory->create()
        /* Joined with `sales_order_address` to get telephone  */
        ->join(
            'sales_order_address',
            'sales_order_address.parent_id=main_table.entity_id',
            'sales_order_address.telephone'
        )
        /* Added `telephone` Filter */
        ->addFieldToFilter(
            'telephone',
            [
                ['eq' => $telephoneOne],
                ['eq' => $telephoneTwo],
                ['eq' => $telephoneThree],
                ['eq' => $telephone]
            ]
        )
        //filter telephone using billing and shipping
        ->addFieldToFilter(
            'address_type',
            [
                ['eq' => 'billing'],
                ['eq' => 'shipping']
            ]
        )
        ->distinct(true);
        return $collection;
    }
    
     /**
      * Retrieve Access Token
      */
    public function getAuthToken()
    {
        return $this->request->getHeader('Authorization');
    }
}
