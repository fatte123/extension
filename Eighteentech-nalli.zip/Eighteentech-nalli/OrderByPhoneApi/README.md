## Eighteentech_OrderByPhoneApi
-------------
- Integrate Magento 2 Rest Api to get order details from Phone number.

## INSTALLATION
-------------
In magento root directory, execute:

```bash
php bin/magento module:enable Eighteentech_OrderByPhoneApi
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Compatibility
-------------
- Magento >= 2.4.x
- Supports both Magento Opensource (Community) and Magento Commerce (Enterprise)


## Usage
---------
Returning Order details based on phone number.


## Copyright
---------
Copyright (c) 2021. 18th DigiTech Team. All rights reserved.