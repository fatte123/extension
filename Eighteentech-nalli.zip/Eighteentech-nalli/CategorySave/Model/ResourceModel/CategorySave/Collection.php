<?php
 /**
  * Category Save
  *
  * Copyright (c) 2022. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Eighteentech_CategorySave
  */
namespace Eighteentech\CategorySave\Model\ResourceModel\CategorySave;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var _idFieldName
     */
    protected $_idFieldName = 'entity_id';

    /**
     * @var _eventPrefix
     */
    protected $_eventPrefix = 'eighteentech_categorysave_collection';

    /**
     * @var _eventObject
     */
    protected $_eventObject = 'eighteentech_categorysave_scheduler';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Eighteentech\CategorySave\Model\CategorySave::class,
            \Eighteentech\CategorySave\Model\ResourceModel\CategorySave::class
        );
    }
}
