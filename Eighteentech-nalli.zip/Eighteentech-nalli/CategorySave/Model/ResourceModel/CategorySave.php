<?php
 /**
  * Category Save
  *
  * Copyright (c) 2022. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Eighteentech_CategorySave
  */
namespace Eighteentech\CategorySave\Model\ResourceModel;

class CategorySave extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('eighteentech_categorysave_scheduler', 'entity_id');
    }
}
