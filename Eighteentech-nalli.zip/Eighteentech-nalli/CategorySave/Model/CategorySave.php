<?php
 /**
  * Category Save
  *
  * Copyright (c) 2022. 18th DigiTech Team. All rights reserved.
  * @author: <mailto:info@18thdigitech.com>
  * @package Eighteentech_CategorySave
  */
namespace Eighteentech\CategorySave\Model;

class CategorySave extends \Magento\Framework\Model\AbstractModel implements
    \Magento\Framework\DataObject\IdentityInterface
{

    /**
     * @type const
     */
    const CACHE_TAG = 'eighteentech_categorysave_scheduler';

    /**
     * @var $_cacheTag
     */
    protected $_cacheTag = 'eighteentech_categorysave_scheduler';

    /**
     * @var $_eventPrefix
     */
    protected $_eventPrefix = 'eighteentech_categorysave_scheduler';

    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init(\Eighteentech\CategorySave\Model\ResourceModel\CategorySave::class);
    }

    /**
     * @return integer
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return array
     */
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
