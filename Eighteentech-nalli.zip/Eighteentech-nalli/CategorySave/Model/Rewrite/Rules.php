<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Eighteentech\CategorySave\Model\Rewrite;

use Magento\Framework\DB\Select;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\VisualMerchandiser\Model\Position\Cache;
use Magento\VisualMerchandiser\Model\Rules\Factory;
use Magento\VisualMerchandiser\Model\Rules\Rule\Collection\Fetcher;
use Magento\VisualMerchandiser\Model\ResourceModel\Rules as ResourceModelRules;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\App\ObjectManager;

/**
 * Class Rules
 *
 * @method bool getIsActive()
 * @method string getConditionsSerialized()
 *
 * @package Magento\VisualMerchandiser\Model
 * @api
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class Rules extends \Magento\VisualMerchandiser\Model\Rules
{
  

    /**
     * @var array
     */
    protected $notices = [];

    /**
     * @var CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var Attribute
     */
    protected $attribute;

    /**
     * @var Factory
     */
    protected $ruleFactory;

    /**
     * @var Fetcher
     */
    protected $fetcher;

    /**
     * @var Cache
     */
    private $cache;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param CollectionFactory $productCollectionFactory
     * @param StoreManagerInterface $storeManager
     * @param ManagerInterface $messageManager
     * @param ScopeConfigInterface $scopeConfig
     * @param Attribute $attribute
     * @param Factory $ruleFactory
     * @param Fetcher $fetcher
     * @param array $data
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param Cache|null $cache
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Registry $registry,
        CollectionFactory $productCollectionFactory,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager,
        ScopeConfigInterface $scopeConfig,
        Attribute $attribute,
        Factory $ruleFactory,
        Fetcher $fetcher,
        \Magento\Framework\App\RequestInterface $request,
        \Eighteentech\CategorySave\Model\CategorySaveFactory $categorySaveModelFactory,
        \Magento\VisualMerchandiser\Model\ResourceModel\Rules\CollectionFactory $rulesFactory,
        array $data = [],
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        Cache $cache = null
    ) {
       
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_storeManager = $storeManager;
        $this->_messageManager = $messageManager;
        $this->_scopeConfig = $scopeConfig;
        $this->attribute = $attribute;
        $this->ruleFactory = $ruleFactory;
        $this->fetcher = $fetcher;
        $this->cache = $cache ?: ObjectManager::getInstance()->get(Cache::class);
        $this->request = $request;
        $this->categorySaveModelFactory = $categorySaveModelFactory;
        $this->rulesFactory = $rulesFactory;
        parent::__construct($context, $registry, $productCollectionFactory, $storeManager, $messageManager, $scopeConfig, $attribute, $ruleFactory,
        $fetcher,$data, $resource ,$resourceCollection, $cache );
    }

    
   
    /**
     * Apply all rules
     *
     * @param Category $category
     * @param Collection $collection
     * @return void
     */
    public function applyAllRules(Category $category, Collection $collection)
    {
        $rules = $this->loadByCategory($category);

        if (!$rules || !$rules->getIsActive()) {
            return;
        }

        try {
            $conditions = $rules->getConditions();
        } catch (\Zend_Exception $e) {
            $this->_messageManager->addException($e, __("Error in reading category rules"));
            return;
        }

        if (!is_array($conditions) || count($conditions) == 0) {
            $this->_messageManager->addError(__("There was no category rules to apply"));
            return;
        }
        $postData = $this->request->getPostValue();
		if(count($postData) != 0) {
			$id = $rules->getCategoryId();
			$rules = $this->rulesFactory->create() 
					->addFieldToSelect('*')
					->addFieldToFilter('is_active', array('eq' => 1))
					->addFieldToFilter('category_id', array('eq' => $id))
					->getFirstItem();

			//Save is smart category state (or clear it)
			if (!empty($rules->getCategoryId())) {
			$categoryModel = $this->categorySaveModelFactory->create();
			$reportdata = $categoryModel->getCollection()
						  ->addFieldToFilter('cron_status', 0)
						  ->addFieldToFilter('category_id', $id)->getFirstItem();

			if(!empty($reportdata->getData('entity_id'))) {
				
				$reportId = $reportdata->getData('entity_id');
				$categoryModel->load($reportId);
				$categoryModel->setCronStatus(0);
				$saveData = $categoryModel->save();
				
			} else {
				$categoryModel->addData([
					"category_id" => $id,
					"category_name" => $postData['name'],
					"cron_status" => 0
				]);
				$saveData = $categoryModel->save();
			}
			
			if($saveData){
				$this->_messageManager->addSuccess(__("Category rules applied product will be updated on scheduled"));
			} else {
				$this->_messageManager->addNotice(__("You saved the category. but scheduled data not saved"));
			}
            return;
       
			}
		}
        
        $this->applyConditions($category, $collection, $conditions);

        if (!empty($this->notices)) {
            foreach ($this->notices as $notice) {
                $this->_messageManager->addNotice($notice);
            }
        }

        if ($this->_messageManager->hasMessages()) {
            return;
        }

        $this->_messageManager->addSuccess(__("Category rules applied"));
    }

    
}
