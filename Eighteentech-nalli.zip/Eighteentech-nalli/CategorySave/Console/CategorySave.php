<?php

namespace Eighteentech\CategorySave\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Helper\ProgressBarFactory;

class CategorySave extends Command
{

	const NAME = 'name';
	const CATID = 'catid';
	const CATNAME = 'catname';
	
	private $logger;
	/**
     * @var ProgressBarFactory
     */
    private $progressBarFactory;
	
	public function __construct(
	 \Magento\Catalog\Model\CategoryFactory $CategoryFactory,
	 \Magento\Catalog\Api\CategoryRepositoryInterface $repository,
	 \Magento\Framework\App\State $State,
	 \Magento\Store\Model\App\Emulation $Emulation,
	 \Eighteentech\CategorySave\Logger\Logger $logger,
	 ProgressBarFactory $progressBarFactory,
	 \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
	 \Magento\VisualMerchandiser\Model\ResourceModel\Rules\CollectionFactory $rulesFactory
	){
	 $this->categoryFactory = $CategoryFactory;
	 $this->logger = $logger;
	 $this->_repository = $repository;
	 $this->state = $State;
	 $this->emulation = $Emulation;
	 $this->progressBarFactory = $progressBarFactory;
	 $this->_dateFactory = $dateFactory; 
	 $this->rulesFactory = $rulesFactory;
	 parent::__construct();
	}
	
	protected function configure()
	{
		$options = [
			new InputOption(
				self::CATID,
				null,
				InputOption::VALUE_REQUIRED,
				'Catid'
			)
		];
		$this->setName('save:category:rules')
			->setDescription('save category command line')
			->setDefinition($options);

		parent::configure();
	}

	protected function execute(InputInterface $input, OutputInterface $output)
	{
		$storeId = 0;
		$date = $this->_dateFactory->create()->gmtDate();
		$this->state->setAreaCode(\Magento\Framework\App\Area::AREA_ADMINHTML);
		$this->emulation->startEnvironmentEmulation($storeId, \Magento\Framework\App\Area::AREA_ADMINHTML, true);
		$output->writeln('<info>Process starts.</info>');
		
		if ($catidPass = $input->getOption(self::CATID)) {
			 try {
			    $catId =  $catidPass;
				$category = $this->getcategorybyId($catidPass);
				$category->setUpdatedAt($date);
				$category->setStoreId(0);
				$this->_repository->save($category);
				
				/** @var ProgressBar $progress */
			 $progressBar = $this->progressBarFactory->create(
				[
					'output' => $output,
					'max' => 1,
				]
			 );	
			 $progressBar->setFormat(
             	'%current%/%max% [%bar%] %percent:3s%% %elapsed% %memory:6s%'
        	 );
			 $progressBar->start();
				
				$output->write(PHP_EOL);
			 	$output->writeln("Category ID ".$catId." save");
				 
				 $output->write(PHP_EOL);
			 	 $output->writeln("Category Name ".$category->getName()." save"); 
				 	
			 
	 		 $this->emulation->stopEnvironmentEmulation();
			 $progressBar->finish();
			 $output->write(PHP_EOL);
			 $output->writeln('<info>Process finished.</info>');
			} catch (\Exception $e) {
       		 $this->logger->critical($e->getMessage());
			 $output->writeln("Something went wrong pls check log");
    		}	
		} else {
			try {
			 $rules = $this->rulesFactory->create() 
				->addFieldToSelect('*') 
				->addFieldToFilter('is_active', array('eq' => 1));
			 
			 /** @var ProgressBar $progress */
			 $progressBar = $this->progressBarFactory->create(
				[
					'output' => $output,
					'max' => count($rules),
				]
			 );	
			 $progressBar->setFormat(
             	'%current%/%max% [%bar%] %percent:3s%% %elapsed% %memory:6s%'
        	 );
			 $progressBar->start();
			  foreach ($rules as $rule){
				 //$output->writeln("Category ID ".$rule->getCategoryId()." save");
				 $catId = $rule->getCategoryId();
				 //if($catidPass == $catId){
					 $category = $this->getcategorybyId($catId);  
					 $category->setUpdatedAt($date);
					 $category->setStoreId(0);
					 $this->_repository->save($category);
				 
				 
				 $output->write(PHP_EOL);
			 	 $output->writeln("Category ID ".$catId." save");
				 
				 $output->write(PHP_EOL);
			 	 $output->writeln("Category Name ".$category->getName()." save"); 
			  //}	
			 }	
	 		 $this->emulation->stopEnvironmentEmulation();
			 $progressBar->finish();
			 $output->write(PHP_EOL);
			 $output->writeln('<info>Process finished.</info>');
			} catch (\Exception $e) {
       		 $this->logger->critical($e->getMessage());
			 $output->writeln("Something went wrong pls check log");
    		}
		}
		return $this;
	}

	public function getcategorybyId  ($id){
		$category=NULL;
		try {
        $category = $this->categoryFactory->create()->load($id);	
		/* Some logic that could throw an Exception */
		} catch (\Exception $e) {
			$this->logger->critical($e->getMessage());
		}
		return $category;
	}	
}
