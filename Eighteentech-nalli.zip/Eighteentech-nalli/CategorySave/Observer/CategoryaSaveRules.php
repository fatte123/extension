<?php
namespace Eighteentech\CategorySave\Observer;

class CategoryaSaveRules implements \Magento\Framework\Event\ObserverInterface
{
    private $category = null;
    
    public $categorySaveModelFactory;
    
    public function __construct(
		\Eighteentech\CategorySave\Model\CategorySaveFactory $categorySaveModelFactory
    ){
		$this->categorySaveModelFactory = $categorySaveModelFactory;
	}
    
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
         //$this->category = $observer->getEvent()->getCategory();
         $category = $observer->getEvent()->getData('category');
        //echo "<pre>"; print_r($category->getData());die;
        if($category->getIsSmartCategory()==1) {
			//$categoryModel = $this->categorySaveModelFactory->create();
			//echo $id = $category->getId();die;
		}
    }
}
