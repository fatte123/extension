<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Eighteentech\CategorySave\Cron;

use Magento\Framework\Controller\ResultFactory;

class SaveCategory
{


    /**
     * @var logger
     */
    protected $logger;
	/**
     * @var ProgressBarFactory
     */
    private $progressBarFactory;
	
	public function __construct(
	 \Magento\Catalog\Model\CategoryFactory $CategoryFactory,
	 \Magento\Catalog\Api\CategoryRepositoryInterface $repository,
	 \Eighteentech\CategorySave\Logger\Logger $logger,
	 \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
	 \Magento\Store\Model\App\Emulation $Emulation,
	 \Magento\Framework\App\State $State,
	 \Magento\VisualMerchandiser\Model\ResourceModel\Rules\CollectionFactory $rulesFactory
	){
	 $this->categoryFactory = $CategoryFactory;
	 $this->logger = $logger;
	 $this->_repository = $repository;
	 $this->rulesFactory = $rulesFactory;
	 $this->emulation = $Emulation;
	 $this->_dateFactory = $dateFactory; 
	 $this->state = $State;
	}
	
    /**
     * @return string
     */
    public function execute()
    {
		$storeId = 0;
		$date = $this->_dateFactory->create()->gmtDate();
		//$this->state->setAreaCode(\Magento\Framework\App\Area::AREA_ADMINHTML);
		//$this->emulation->startEnvironmentEmulation($storeId, \Magento\Framework\App\Area::AREA_ADMINHTML, true);
		
			 try {
			 	$rules = $this->rulesFactory->create() 
				->addFieldToSelect('*')->addFieldToFilter('is_active', array('eq' => 1));
				$this->logger->info('Total category found in Rules = '.count($rules));
				foreach ($rules as $rule){
					$catId = $rule->getCategoryId();
					$category = $this->getcategorybyId($catId); 
					if($category){
					 $category->setUpdatedAt($date);
					 $category->setStoreId(0);
					 $this->_repository->save($category);
					 $this->logger->info('category  = '.$category->getName() .'('.$catId .') saved');
					}
				}
				
 			 } catch (\Exception $e) {
       		 $this->logger->critical($e->getMessage()); 
    		}
    		
        $this->logger->info("SaveCategory Rule function run");
    }
    
    public function getcategorybyId  ($id) {
		$category=NULL;
		try {
        $category = $this->categoryFactory->create()->load($id);	
		/* Some logic that could throw an Exception */
		} catch (\Exception $e) {
			$this->logger->critical($e->getMessage());
		}
		return $category;
	}
}
