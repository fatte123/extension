<?php
/**
 * Erpsynch Module
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Nalli_Erpsync
 */
namespace Eighteentech\CategorySave\Cron;

use Magento\Framework\Controller\ResultFactory;

class SaveCategoryScheduled
{


    /**
     * @var logger
     */
    protected $logger;

	
	public function __construct(
	 \Magento\Catalog\Model\CategoryFactory $CategoryFactory,
	 \Magento\Catalog\Api\CategoryRepositoryInterface $repository,
	 \Eighteentech\CategorySave\Logger\Logger $logger,
	 \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
	 \Magento\Store\Model\App\Emulation $Emulation,
	 \Magento\Framework\App\State $State,
	 \Magento\VisualMerchandiser\Model\ResourceModel\Rules\CollectionFactory $rulesFactory,
	 \Eighteentech\CategorySave\Model\CategorySaveFactory $categorySaveModelFactory
	){
	 $this->categoryFactory = $CategoryFactory;
	 $this->logger = $logger;
	 $this->_repository = $repository;
	 $this->rulesFactory = $rulesFactory;
	 $this->emulation = $Emulation;
	 $this->_dateFactory = $dateFactory; 
	 $this->state = $State;
	 $this->categorySaveModelFactory = $categorySaveModelFactory;
	}
	
    /**
     * @return string
     */
    public function execute()
    {
		$storeId = 0;
		$date = $this->_dateFactory->create()->gmtDate();
			try {
			 	$categoryModel = $this->categorySaveModelFactory->create();
				$reportdata = $categoryModel->getCollection()->addFieldToFilter('cron_status', 0);
				foreach ($reportdata as $rule){
					$catId = $rule->getCategoryId();
					$category = $this->getcategorybyId($catId); 
					if($category) {
						try {	
						 $category->setUpdatedAt($date);
						 $category->setStoreId(0);
						 $this->_repository->save($category);
						 $this->logger->info('category  = '.$category->getName() .'('.$catId .') saved');
						 } catch (\Exception $e) {
							$this->logger->info('32166
							'.$e->getMessage()); 
						 }
					}
					if(!empty($rule->getData('entity_id'))) { 
						try {
							$reportId = $rule->getData('entity_id');
							$categoryModel->load($reportId);
							$categoryModel->setCronStatus(1);
							$saveData = $categoryModel->save();
						} catch (\Exception $e) {
							$this->logger->info($e->getMessage()); 
						}	
					}
				}
				
 			 } catch (\Exception $e) {
       		 $this->logger->info($e->getMessage()); 
    		}
    		
        $this->logger->info("SaveCategory Rule function run");
    }
    
    public function getcategorybyId  ($id) {
		$category=NULL;
		try {
        $category = $this->categoryFactory->create()->load($id);	
		/* Some logic that could throw an Exception */
		} catch (\Exception $e) {
			$this->logger->info($e->getMessage());
		}
		return $category;
	}
}
