# Eighteentech_CategoryWidget

This module creates Custom Widget for add category with its product (Catalog Category with Product Grid)


## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable RetailInsights_CustomerCart
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage


