<?php
/**
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Eighteentech_CategoryWidget
 */

namespace Eighteentech\CategoryWidget\Block\Category\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

/**
 * Grid of Category component
 */
class CategoryList extends Template implements \Magento\Widget\Block\BlockInterface
{
    const PAGE_SIZE = 1;
    const PRODUCT_SIZE = 10;

    protected $_categoryFactory;
     /**
      * @var File
      */
    private $file;

    /*
     *@var \Magento\Catalog\Helper\Output $Output
     */
    public $Output;

    /*
     *@var \Eighteentech\AjaxWishlist\Helper\Data $ajaxhelper
     */
    public $ajaxhelper;

    /*
     *@var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     */
    protected $_productCollectionFactory;

	protected $scopeConfig;

	/**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface CookieManagerInterface
     */
    private $cookieManager;

    /*
     *@param \Magento\Framework\View\Element\Template\Context $context
     *@param \Magento\Catalog\Helper\Category $category
     *@param \Magento\Catalog\Model\CategoryRepository $categoryRepository
     *@param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     *@param \Magento\Widget\Helper\Conditions $conditionsHelper
     *@param \Magento\Framework\View\Asset\Repository $assetRepos
     *@param \Magento\Catalog\Helper\ImageFactory $helperImageFactory
     *@param \Magento\Framework\Image\AdapterFactory $imageFactory
     *@param \Magento\Framework\Filesystem $filesystem
     *@param \Magento\Catalog\Helper\Output $Output
     *@param \Eighteentech\AjaxWishlist\Helper\Data $ajaxhelpe
     *@param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     *@param File $file
	 *@param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	 *@param \Magento\Framework\Stdlib\CookieManagerInterface CookieManagerInterface
     */

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\Helper\Category $category,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Widget\Helper\Conditions $conditionsHelper,
        \Magento\Framework\View\Asset\Repository $assetRepos,
        \Magento\Catalog\Helper\ImageFactory $helperImageFactory,
        \Magento\Framework\Image\AdapterFactory $imageFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Catalog\Helper\Output $Output,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Eighteentech\AjaxWishlist\Helper\Data $ajaxhelper,
        File $file,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        array $data = []
    ) {
        $this->storeManager = $context->getStoreManager();
        $this->category = $category;
        $this->categoryRepository = $categoryRepository;
        $this->_categoryFactory      = $categoryFactory;
        $this->conditionsHelper = $conditionsHelper;
        $this->assetRepos = $assetRepos;
        $this->helperImageFactory = $helperImageFactory;
        $this->imageFactory = $imageFactory;
        $this->_filesystem = $filesystem;
        $this->file = $file;
        $this->output = $Output;
        $this->ajaxhelper = $ajaxhelper;
        $this->_directory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->_productCollectionFactory = $productCollectionFactory;
		$this->scopeConfig = $scopeConfig;
		$this->cookieManager = $cookieManager;
        parent::__construct(
            $context,
            $data
        );
    }

    /**
     * Get small place holder image
     *
     * @return string
     */
    public function getPlaceHolderImage()
    {
        /** @var \Magento\Catalog\Helper\Image $helper */
        $imagePlaceholder = $this->helperImageFactory->create();
        return $this->assetRepos->getUrl($imagePlaceholder->getPlaceholder('small_image'));
    }

    /**
     * @param array $categoryIds
     * @return \Magento\Framework\Data\Collection
     */
    public function getCategoryById($categoryId)
    {
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);
        return $category;
    }

    /**
     * @param array $categoryIds
     * @return \Magento\Framework\Data\Collection
     */
    public function getCategory()
    {
        $categoryIds = $this->getCategoryIds();
        if (!empty($categoryIds)) {
            $ids = array_slice(explode(',', $categoryIds), 0, $this->getCategoryToDisplay());
            $category = [];
            foreach ($ids as $id) {
                $category[] = $this->getCategoryById($id);
            }
            return $category;
        }
        return '';
    }

    public function getCategoryProducts($categoryId, $limit)
    {
        $products = $this->getCategoryById($categoryId)->getProductCollection();

        //$products->addFieldToFilter('visibility', ['eq' => 4]);
        $products->addAttributeToSelect(['url_key','small_image','thumbnail','name','price','sku',
        'article_type','category_name','image'])->setPageSize($limit)->getSelect()->orderRand();
        $products->getSelect()->joinLeft(
            'cataloginventory_stock_item',
            'e.entity_id = cataloginventory_stock_item.product_id',
            'cataloginventory_stock_item.is_in_stock'

        )->where('cataloginventory_stock_item.is_in_stock', ['eq' => 1]);
        return $products;
    }

    /**
     * @param $imageName string imagename only
     * @param $width
     * @param $height
     */
    public function getResize($imageName, $width = 316, $height = 475)
    {
        $realPath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)
        ->getAbsolutePath('catalog/category/'.$imageName);
        if (!$this->_directory->isFile($realPath) || !$this->_directory->isExist($realPath)) {
            return false;
        }
        $targetDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)
        ->getAbsolutePath('resized/'.$width.'x'.$height);
        $pathTargetDir = $this->_directory->getRelativePath($targetDir);
        if (!$this->_directory->isExist($pathTargetDir)) {
            $this->_directory->create($pathTargetDir);
        }
        if (!$this->_directory->isExist($pathTargetDir)) {
            return false;
        }

        $image = $this->imageFactory->create();
        $image->open($realPath);
        $image->keepAspectRatio(true);
        $image->resize($width, $height);
        $pathInfo = $this->file->getPathInfo($realPath);
        $dest = $targetDir . '/' . $pathInfo;
        $image->save($dest);
        if ($this->_directory->isFile($this->_directory->getRelativePath($dest))) {
            return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA)
            .'resized/'.$width.'x'.$height.'/'.$imageName;
        }
        return false;
    }

    /**
     * Retrieve how many category should be displayed
     *
     * @return int
     */
    public function getCategoryToDisplay()
    {
        if (!$this->hasData('page_size')) {
            $this->setData('page_size', self::PAGE_SIZE);
        }
        return $this->getData('page_size');
    }

    /**
     * Retrieve how many category should be displayed
     *
     * @return int
     */
    public function getProductToDisplay()
    {
        if (!$this->hasData('product_size')) {
            $this->setData('product_size', self::PRODUCT_SIZE);
        }
        return $this->getData('product_size');
    }

    /**
     * Retrieve category ids from widget
     *
     * @return string
     */
    public function getCategoryIds()
    {
        $conditions = $this->getData('conditions')
            ? $this->getData('conditions')
            : $this->getData('conditions_encoded');

        if ($conditions) {
            $conditions = $this->conditionsHelper->decode($conditions);
        }

        foreach ($conditions as $key => $condition) {
            if (!empty($condition['attribute']) && $condition['attribute'] == 'category_ids') {
                return $condition['value'];
            }
        }
        return '';
    }

    /*
     *return \Magento\Catalog\Helper\Output $Output
     */
    public function getOutputHelper()
    {
        return $this->output;
    }

     /*
      *@return \Eighteentech\AjaxWishlist\Helper\Data $ajaxhelper
      */
    public function getAjaxHelper()
    {
        return $this->ajaxhelper;
    }

	public function getCategoryProductsSkuForRecommended($categoryId, $limit)
    {
        $products = $this->getCategoryById($categoryId)->getProductCollection();
        $products->addAttributeToSelect(['sku'])->setPageSize($limit)->getSelect()->orderRand();
        return $products;
    }

	public function getConfig($configPath)
    {
        return $this->scopeConfig->getValue(
            $configPath,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

	/*
	 *@return get category id from Sysem.xml
	 */
	public function getcategoryId(){
        return $this->getConfig('categorywidget/category_product/cat_id');
    }

	/*
	 *@return get status from Sysem.xml
	 */
	public function getStatus(){
        return $this->getConfig('categorywidget/category_product/status');
    }

	/*
	 * Get Custom Cookie using
	 */
    public function getCustomCookiedata()
    {
        return $this->cookieManager->getCookie(
            'sytepro'
        );
    }
}
