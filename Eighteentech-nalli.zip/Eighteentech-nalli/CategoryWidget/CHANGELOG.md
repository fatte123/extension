# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0]
### Added
- This module adds a new table named customer_cart_mctr in database.

## [1.2.0]
### Added
- This module alters field customerquoteids from varchar to longtext.

## [1.2.1]
### Added
- This module make use of db_schema instead of schema for table creation.

