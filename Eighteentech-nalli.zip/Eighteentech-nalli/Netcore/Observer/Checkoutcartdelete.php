<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Eighteentech\Netcore\Logger\Logger;

class Checkoutcartdelete implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registry;

    /**
     * @var CheckoutSession
     */
    protected $_checkoutSession;

    /**
     * @var Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Eighteentech\Netcore\Logger\Logger
     */
    private $logger;

    /**
     * Checkoutcartdelete constructor.
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param Config $config
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Catalog\Model\Session $catalogSession,
        Config $config,
        Logger $logger
    ) {
        $this->_layout         = $layout;
        $this->_registry       = $registry;
        $this->_storeManager   = $storeManager;
        $this->_request        = $request;
        $this->_eventManager   = $eventManager;
        $this->config          = $config;
        $this->_catalogSession = $catalogSession;
        $this->helper          = $helper;
        $this->logger          = $logger;
    }

    /**
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        try {
            $itemId = $this->_request->getParam('id');
            if ($itemId) {
                // Handled for remove cart delete item thorugh redirection
                $this->_catalogSession->setCartRemove('remove');
                $qty = $this->helper->getQuoteItemQty($itemId);
                $this->_catalogSession->setCartRemoveQty($qty);
            }
        } catch (\Exception $e) {
            $this->logger->info("Something went wrong checkout cart delete please check " . $e->getMessage());
        }
    }
}
