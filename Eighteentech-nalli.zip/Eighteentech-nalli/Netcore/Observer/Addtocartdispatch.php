<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use \Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Catalog\Model\Session as CatalogSession;

class Addtocartdispatch implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var\ Magento\Framework\Stdlib\CookieManagerInterfac
     */
    protected $_cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    protected $_cookieMetadataFactory;

    /**
     * @var Magento\Framework\Session\SessionManagerInterface
     */
    protected $_sessionManager;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registry;

    /**
     * The affiliate cookie name
     */
    const COOKIE_NAME = "Addcartflag";

    /**
     * @var CheckoutSession
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $catalogSession;

    /**
     * Addtocartdispatch constructor.
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     * @param CheckoutSession $checkoutSession
     * @param Config $config
     * @param CatalogSession $catalogSession
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        CheckoutSession $checkoutSession,
        Config $config,
        CatalogSession $catalogSession
    ) {
        $this->_layout        = $layout;
        $this->_registry      = $registry;
        $this->_storeManager  = $storeManager;
        $this->_request       = $request;
        $this->_eventManager  = $eventManager;
        $this->config         = $config;
        $this->_cookieManager = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager        = $sessionManager;
        $this->_checkoutSession       = $checkoutSession;
        $this->catalogSession = $catalogSession;
    }

    /**
     * Add to cart dispatch event called both for ajax call as well as page redirection call set
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        $product = $observer->getEvent()->getProduct();
        // echo "get executeAddToCartJs from OB" . $product;
        if ($product->getData() != '') {
            $this->catalogSession->setSmacProd($product->getId());
            $this->catalogSession->setSmacQty((int)($this->_request->getParam('qty') !== null ? $this->_request->getParam('qty') :  1));
            // Handled for ajax add to cart success thorugh custom js
            $cartAction = 'addcartsuccess';
            if ($cartAction) {
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                $this->_cookieManager->setPublicCookie(
                    self::COOKIE_NAME,
                    $cartAction,
                    $publicCookieMetadata
                );
            }
        }
    }
}
