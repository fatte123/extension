<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use \Magento\Wishlist\Model\Item as WishlistItem;
use Eighteentech\Netcore\Logger\Logger;

class Wishlisttocart implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    protected $_queryFactory;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    protected $_cookieManager;

    /**
     * @var Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    protected $_cookieMetadataFactory;

    /**
     * @var WishlistItem
     */
    protected $wishlistItem;

    /**
     * @var \Eighteentech\Netcore\Logger\Logger
     */
    private $logger;


    /**
     * Wishlisttocart constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Search\Model\QueryFactory $queryFactory
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     * @param Config $config
     * @param WishlistItem $wishlistItem
     * @param Logger $logger
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Search\Model\QueryFactory $queryFactory,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        Config $config,
        WishlistItem $wishlistItem,
        Logger $logger
    ) {
        $this->_layout                = $layout;
        $this->_storeManager          = $storeManager;
        $this->_request               = $request;
        $this->_eventManager          = $eventManager;
        $this->_queryFactory          = $queryFactory;
        $this->_catalogSession        = $catalogSession;
        $this->_cookieManager         = $cookieManager;
        $this->_sessionManager        = $sessionManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->config                 = $config;
        $this->wishlistItem           = $wishlistItem;
        $this->logger                 = $logger;
    }

    /**
     *  Event handled for move product from wishlist to cart,
     *  thus addition of product to cart and removal from wishlist
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        $item = (int) $this->_request->getParam('item');
        $qty  = $this->_request->getParam('qty');
        if ($item) {
            try {
                $itemData = $this->wishlistItem->load($item);
                if (!empty($itemData) && $itemData->getData() != '') {
                    $productId = $itemData->getProductId();
                    if ($productId) {
                        $this->_catalogSession->setSmWRemoveProd($productId);
                        $this->_catalogSession->setSmacProd($productId);
                        if ($qty >= 1) {
                            $this->_catalogSession->setSmWRemoveQty($qty);
                            $this->_catalogSession->setSmacQty($qty);
                        }
                        // cookie set to dispatch the add to crat event
                        $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                            ->setDuration(259200)->setPath($this->_sessionManager->getCookiePath())
                            ->setDomain($this->_sessionManager->getCookieDomain())->setHttpOnly(false);

                        $this->_cookieManager->setPublicCookie(
                            'Addcartflag',
                            'addcartsuccess',
                            $publicCookieMetadata
                        );
                    }
                }
            } catch (\Exception $e) {
                $this->logger->info('Something went wrong when Wishlist to cart' . $e->getMessage());
            }
        }
    }
}
