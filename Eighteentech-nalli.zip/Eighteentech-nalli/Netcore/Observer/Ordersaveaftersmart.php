<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Eighteentech\Netcore\Helper\Data;
use Eighteentech\Netcore\Logger\Logger;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Ordersaveaftersmart implements \Magento\Framework\Event\ObserverInterface
{

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    private $resourceConnection;
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;
    /**
     * @var \Magento\Catalog\Model\Product
     */
    private $product;
    /**
     * @var \Magento\Catalog\Helper\Image
     */
    private $image;
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;

    /**
     * Ordersaveafterwe constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Catalog\Model\Product $product
     * @param \Magento\Catalog\Helper\Image $image
     * @param Status $helper
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Catalog\Model\Product $product,
        \Magento\Catalog\Helper\Image $image,
        \Magento\Customer\Model\Session $customerSession,
        Data $helper,
		Logger $logger,
		ScopeConfigInterface $scopeConfig
		)
    {
        $this->helper = $helper;
        $this->storeManager = $storeManager;
        $this->resourceConnection = $resourceConnection;
        $this->request = $request;
        $this->product = $product;
        $this->image = $image;
        $this->customerSession = $customerSession;
		$this->logger = $logger;
		$this->scopeConfig = $scopeConfig;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
		$statuscode = $order->getStatus();
        $incrementId = $order->getIncrementId();
		$this->logger->info('Smarttech - Order '.$incrementId.' Status '.$order->getStatus());

		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        $idc_region = $this->scopeConfig->getValue("smartech/general/idc_region", $storeScope);
        $siteId     = $this->scopeConfig->getValue("smartech/general/site_tracking_id", $storeScope);
        $userKey    = $this->scopeConfig->getValue("smartech/general/web_tracking_id", $storeScope);
        $api_key    = $this->scopeConfig->getValue("smartech/general/api_key", $storeScope);

        $postUrl    = sprintf($this->helper::NETCORE_PRODUCT_PURCHASE_SYNC_URL_IN, $incrementId, 'checkout', $siteId, $userKey);

        
		
		if($statuscode=='shipped'){
			$this->logger->info('Smarttech - Order Shipped event started ');
        $shippingAddress = array();
        if (!empty($order->getShippingAddress())) {
            $shippingAddress = (object)$order->getShippingAddress()->getData();
        }


        $billingAddress = (object)$order->getBillingAddress()->getData();

        if (empty($shippingAddress)) {
            $shippingAddress = $billingAddress;
        }
        $customerEmail = $billingAddress->email;
        $customerSession = $this->customerSession;
        if ($customerSession->isLoggedIn()) {
            $customerEmail = $customerSession->getCustomer()->getEmail();
        }
		
		$tracking_number = ''; 
		/*if(is_object($order->getTracksCollection()->fetchItem())){
				$tracking_number = $order->getTracksCollection()->fetchItem()->getTrackNumber();
			}*/
        $productinformation = array();
        foreach ($order->getAllItems() as $item) {
            $product = $this->product->load($item->getProductId());
            $imageHelper = $this->image;
            $productImageUrl = $imageHelper->init($product, 'product_page_image_large')->getUrl();
            $OrgPrice = (float)$product->getPrice();
            $productinformation[] = array(
                'productid' => $item->getProductId(),
                'productname' => $product->getName(),
                'productdescription' => $product->getDescription(),
                'productshortdescription' => $product->getShortDescription(),
                'productsku' => $product->getSku(),
                'producturl' => $product->getProductUrl(),
                'productimage' => $product->getData('image'),
                'productoriginalprice' => $OrgPrice,
                'productqty' => (float)$item->getQtyOrdered(),
                'ordered_qty' => (float)$item->getQtyOrdered()
            );
        }

        $shippingRegionName = $shippingAddress->region;

        /*$prepareShippingAddress = array(
            'customerFirstName' => $shippingAddress->firstname,
            'customerMiddleName' => trim($shippingAddress->middlename) != '' ? $shippingAddress->middlename : null,
            'customerLastName' => $shippingAddress->lastname,
            'customerStreet' => $shippingAddress->street,
            'customerTelephone' => $shippingAddress->telephone,
			'customerCity' => $shippingAddress->city,
            'customerPostCode' => $shippingAddress->postcode,
            'customerEmail' => $customerEmail,
            'customerRegionName' => $shippingRegionName,
            'customerRegion' => $shippingAddress->region,
            'customerCountry' => $shippingAddress->country_id,
        );*/

        $prepareJson = array(
                'customer_user_id' => $customerEmail,
                'currency' => $order->getOrderCurrencyCode(),
                'eventData' => "",
                'order_date' => $order->getCreatedAt(),
                'order_id' => $incrementId,
                'tracking' => "",
                'additional' => "",
                'customerregionname' => $shippingRegionName,
                'customerregion' => $shippingAddress->region,
                'customercity' => $shippingAddress->city,
                'customerstreet' => $shippingAddress->street,
                'customercountry' => $shippingAddress->country_id,
                'customerfirstname' => $shippingAddress->firstname,
                'customerlastname' => $shippingAddress->lastname,
                'customertelephone' => $shippingAddress->telephone,
                'customerpostcode' => $shippingAddress->postcode,
                'customeremail' => $customerEmail,
                'items' => $productinformation
        );
         /*       $prepareJson = array(
                'customer_user_id' => $customerEmail,
                'currency' => $order->getOrderCurrencyCode(),
                'items' => array(
                    'orderID' => $incrementId,
					'TrackingID' => $tracking_number,
                    'orderProductInformation' => $productinformation,
                    'customerShippingInformation' => $prepareShippingAddress,
                )
        );*/
        
        $params['data'] = json_encode([[
            'asset_id' => $siteId,
            'activity_name' => 'custom_order_shipped_nalli',
            "timestamp" => date("Y-m-d\TH:i:s.000\Z"),
            "activity_source" => "web",
            "identity" => $customerEmail,
            "activity_params" => $prepareJson
        ]]);
        $params['request_type'] = "orderUpdate";

		$this->logger->info(print_r($params['data'], true));
		$this->logger->info('postUrl=>'. $postUrl.'====api_key=>'. $api_key);

        /*Calling NetcoreSmartech API*/
        $result = $this->helper->makeRequest('POST', $postUrl, $params,$api_key);
        $this->logger->info(print_r(json_decode($result, true)));

        /*Calling NetcoreSmartech API*/
		$this->logger->info('Smarttech - Order Shipped event triggered '.$statuscode);
		}
		
		if($statuscode == 'complete'){
			$this->logger->info('Smarttech - Order complete event started ');
        $shippingAddress = array();
        if (!empty($order->getShippingAddress())) {
            $shippingAddress = (object)$order->getShippingAddress()->getData();
        }
		
		$billingAddress = (object)$order->getBillingAddress()->getData();

        if (empty($shippingAddress)) {
            $shippingAddress = $billingAddress;
        }

        $customerEmail = $billingAddress->email;

        $incrementId = $order->getIncrementId();
        $couponCode = "";
        if ($order->getCouponCode() && $order->getCouponCode() != '') {
            $couponCode = $order->getCouponCode();
        }

        $productinformation = array();
		$baseUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
		$orderfeedbackBaseUrl = $baseUrl.'sales/order/view/order_id/'.$order->getEntityId();
		$feedbackBaseUrl = $baseUrl.'orderfeedback/index/index/id';
		$total_ordered_qty = 0;       
        foreach ($order->getAllItems() as $item) {
            $product = $this->product->load($item->getProductId());
            $imageHelper = $this->image;
            $productImageUrl = $imageHelper->init($product, 'product_page_image_large')->getUrl();
            $OrgPrice = (float)$product->getPrice();
            $total_ordered_qty = $total_ordered_qty + (int) $item->getQtyOrdered();
            $productinformation[] = array(
                'productid' => $item->getProductId(),
                'productname' => $product->getName(),
                'productdescription' => $product->getDescription(),
                'productshortdescription' => $product->getShortDescription(),
                'productsku' => $product->getSku(),
                'producturl' => $product->getProductUrl(),
                'productimage' => $product->getData('image'),
                'productoriginalprice' => $OrgPrice,
                'productqty' => (string)$item->getQtyOrdered(),
                'productqty_1' => (int)$item->getQtyOrdered(),
                'ordered_qty' => (string)$item->getQtyOrdered(),
                'ordered_qty_1' => (int) $item->getQtyOrdered(),                
                'total_ordered_qty' => (int) $order->getTotalQtyOrdered(),                
                'feedbackurl' => $feedbackBaseUrl.'/'.$item->getItemId()
            );
        }
        
        $productItemData = [];
		foreach ($productinformation as $iteminformation) {
			$iteminformation['total_ordered_qty'] = $total_ordered_qty;
			$this->logger->info('Smarttech - iteminformation --total_ordered_qty-> '.$iteminformation['total_ordered_qty']);
			$productItemData[] = $iteminformation;
		}
		$productinformation = $productItemData;
        $shippingRegionName = $shippingAddress->region;

		$this->logger->info('Smarttech - total_ordered_qty-> '.$total_ordered_qty);
        /*$prepareShippingAddress = array(
            'customerFirstName' => $shippingAddress->firstname,
            'customerMiddleName' => trim($shippingAddress->middlename) != '' ? $shippingAddress->middlename : null,
            'customerLastName' => $shippingAddress->lastname,
            'customerStreet' => $shippingAddress->street,
            'customerTelephone' => $shippingAddress->telephone,
			'customerCity' => $shippingAddress->city,
            'customerPostCode' => $shippingAddress->postcode,
            'customerEmail' => $customerEmail,
            'customerRegionName' => $shippingRegionName,
            'customerRegion' => $shippingAddress->region,
            'customerCountry' => $shippingAddress->country_id,
        );*/

        $prepareJson = array(
                'customer_user_id' => $customerEmail,
                'currency' => $order->getOrderCurrencyCode(),
                'eventData' => "",
                'order_date' => $order->getCreatedAt(),
                'order_id' => $incrementId,
                'feedback_url' => $orderfeedbackBaseUrl,
                'additional' => "",
                'customerregionname' => $shippingRegionName,
                'customerregion' => $shippingAddress->region,
                'customercity' => $shippingAddress->city,
                'customerstreet' => $shippingAddress->street,
                'customercountry' => $shippingAddress->country_id,
                'customerfirstname' => $shippingAddress->firstname,
                'customerlastname' => $shippingAddress->lastname,
                'customertelephone' => $shippingAddress->telephone,
                'customerpostcode' => $shippingAddress->postcode,
                'customeremail' => $customerEmail,
                'items' => $productinformation

        );
        $params['data'] = json_encode([[
            'asset_id' => $siteId,
            'activity_name' => 'custom_order_delivered_nalli',
            "timestamp" => date("Y-m-d\TH:i:s.000\Z"),
            "activity_source" => "web",
            "identity" => $customerEmail,
            "activity_params" => $prepareJson
        ]]);
        $params['request_type'] = "orderUpdate";
        /*Calling NetcoreSmartech API*/
        $this->logger->info(print_r($params['data'], true));
       $result =  $this->helper->makeRequest('POST', $postUrl, $params,$api_key);
       $this->logger->info(print_r(json_decode($result, true)));
       
        /*Calling NetcoreSmartech API*/
		$this->logger->info('Smarttech - Order complete event triggered '.$statuscode);
		}


		if($statuscode == 'canceled' || $statuscode == 'payment_review'){
			$this->logger->info('Smarttech - Order complete event started ');
		$billingAddress = (object)$order->getBillingAddress()->getData();

        if (empty($shippingAddress)) {
            $shippingAddress = $billingAddress;
        }

        $customerEmail = $billingAddress->email;
        $prepareJson = array('paymentstatus' => $statuscode);
        $params['data'] = json_encode([[
            'asset_id' => $siteId,
            'activity_name' => 'purchase_failed_nalli',
            "timestamp" => date("Y-m-d\TH:i:s.000\Z"),
            "activity_source" => "web",
            "identity" => $customerEmail,
            "activity_params" => $prepareJson
        ]]);
        $params['request_type'] = "orderUpdate";
        /*Calling NetcoreSmartech API*/
        $this->logger->info(print_r($params['data'], true));
       $result =  $this->helper->makeRequest('POST', $postUrl, $params,$api_key);
       $this->logger->info(print_r(json_decode($result, true)));
       
        /*Calling NetcoreSmartech API*/
		$this->logger->info('Smarttech - Order complete event triggered '.$statuscode);
		}
				
		
    }

}
 
