<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Eighteentech\Netcore\Logger\Logger;

class Cartremovewishlistdispatch implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    protected $_queryFactory;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var QuoteItem
     */
    protected $quoteItem;

    /**
     * @var \Eighteentech\Netcore\Logger\Logger
     */
    private $logger;

    /**
     * Cartremovewishlistdispatch constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Search\Model\QueryFactory $queryFactory
     * @param Config $config
     * @param QuoteItem $quoteItem
     * @param Logger $logger
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Search\Model\QueryFactory $queryFactory,
        Config $config,
        QuoteItem $quoteItem,
        Logger $logger
    ) {
        $this->_layout         = $layout;
        $this->_storeManager   = $storeManager;
        $this->_request        = $request;
        $this->_catalogSession = $catalogSession;
        $this->_eventManager   = $eventManager;
        $this->_queryFactory   = $queryFactory;
        $this->config          = $config;
        $this->quoteItem       = $quoteItem;
        $this->logger          = $logger;
    }

    /**
     * Remove item from cart and move to wishlist
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        try {
            $productId = '';
            $item      = $this->_request->getParam('item');
            if ($item) {
                $itemData      = $this->quoteItem->load($item);
                $productId     = $itemData->getProductId();
                $qty           = $itemData->getQty();
                if ($productId) {
                    $this->_catalogSession->setSmWAddQty($qty);
                    $this->_catalogSession->setCartRemove('remove');
                    $this->_catalogSession->setDeleteProd($productId);
                    $this->_catalogSession->setSmWAddProd($productId);
                    $this->_catalogSession->setCartRemoveQty($qty);
                }
            }
        } catch (\Exception $e) {
            $this->logger->info('Something went wrong when item move from cart to wishlist ' . $e->getMessage());
        }
    }
}
