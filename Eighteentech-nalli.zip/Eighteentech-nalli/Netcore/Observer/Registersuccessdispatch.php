<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Eighteentech\Netcore\Logger\Logger;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Registersuccessdispatch implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $customerRepository;
    protected $_layout;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var \Eighteentech\Netcore\Logger\Logger
     */
    private $logger;

    /**
     * Registersuccessdispatch constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param Config $config
     * @param CustomerSession $customerSession
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param Logger $logger
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        Config $config,
        CustomerSession $customerSession,
        \Eighteentech\Netcore\Helper\Data $helper,
        Logger $logger,
        CustomerRepositoryInterface $customerRepository
    ) {
        $this->_layout       = $layout;
        $this->_storeManager = $storeManager;
        $this->_request      = $request;
        $this->_eventManager = $eventManager;
        $this->config        = $config;
        $this->customerSession = $customerSession;
        $this->helper          = $helper;
        $this->logger          = $logger;
        $this->customerRepository = $customerRepository;
    }

    /**
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        try {
            $email = $observer->getEvent()->getCustomer()->getEmail();
            if ($email) {
                $this->customerSession->setEmail($email);
                $jsonEvent = $this->helper->getCustomerJson($email);
                // $this->helper->log("Singup mobile log", "jsScriptJSON = " . $jsonEvent);
                $strEvent  = $this->helper->getCustomerTrack($jsonEvent);
                // $this->helper->log("Singup-payload", "jsScriptJSON = " . $strEvent);
                // Customer custom attributeResource save the mobile filed singup to customer model megento
                $customer = $observer->getEvent()->getCustomer();
                // print_r(get_class_methods($customer));
                // print_r($customer->getCustomAttribute('mobile_attribute'));
                // $customer_mob = $customer->getCustomAttribute('mobile_attribute');
                // $customer->setData('telephone', $customer_mob);
                // $customer->setTelphone($customer_mob);
                $this->customerRepository->save($customer);
                // $customer->setMobile($customer->getMobileAttribute());
                // $this->customerRepository->save($customer);
                // $customer->setMobile($customer->getMobileAttribute());
                // $this->customerRepository->save($customer);
                //end Customer custom attributeResource 
                return sprintf($strEvent);
            }
        } catch (\Exception $e) {
            $this->logger->info("Something went wrong with Register success dispatch event " . $e->getMessage());
        }
    }
}
