<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class Layouthandle implements ObserverInterface
{

    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    protected $_cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    protected $_cookieMetadataFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    protected $_queryFactory;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * Layouthandle constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Search\Model\QueryFactory $queryFactory
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     * @param Config $config
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Search\Model\QueryFactory $queryFactory,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        Config $config
    ) {
        $this->_layout                = $layout;
        $this->_storeManager          = $storeManager;
        $this->_request               = $request;
        $this->_eventManager          = $eventManager;
        $this->_queryFactory          = $queryFactory;
        $this->_catalogSession        = $catalogSession;
        $this->_checkoutSession       = $checkoutSession;
        $this->_customerSession       = $customerSession;
        $this->_cookieManager         = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager        = $sessionManager;
        $this->helper                 = $helper;
        $this->config                 = $config;
    }

    public function _prepareLayout()
    {
        //return parent::_prepareLayout();
    }

    /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }

    /**
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * Event handled here for delete cart item & add cart item ajax call
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        // cookies for js guest check out
        $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
        ->setDuration(259200)
        ->setPath($this->_sessionManager->getCookiePath())
        ->setDomain($this->_sessionManager->getCookieDomain())
        ->setHttpOnly(false);
        $json_pk = $this->helper->getSmartechCustomerIdentityKey();
        $this->_cookieManager->setPublicCookie(
            'smart_pk',
            urldecode($json_pk),
            $publicCookieMetadata
        );
        // on page load set user identity 
        $email = $this->getCustomerSession()->getCustomer()->getEmail();
        if ($email) {
            //echo "Email" . $email;
            $pk_str  = $this->helper->getContactTrack_pk($email);            
            // $this->helper->log("Register", "customer  primary Key main layout = " . __LINE__ .$pk_str);
            $str  = $this->helper->getContactTrack_setpk($pk_str);
            // $this->_cookieManager->setPublicCookie(
            //     'mag_ck_value',
            //     urldecode($str),
            //     $publicCookieMetadata
            // );
            // $this->getCustomerSession()->unsEmail();
            //return sprintf($str);
        } 

        // end of user identity 

        if ($this->_request->getFullActionName() == 'checkout_cart_add') {
            $prod = $this->getCatalogSession()->getSmacProd();
            $qty = $this->getCatalogSession()->getSmacQty();
            $getCookie = $this->_cookieManager->getCookie('Addcartflag');
            if ($prod) {
                $json = $this->helper->getCartJson($prod, '', $qty);
                // Handled for ajax add to cart success thorugh custom js
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                                 
                $this->_cookieManager->setPublicCookie(
                    'SmCartJson',
                    $json,
                    $publicCookieMetadata
                );
                
                $this->getCatalogSession()->unsSmacProd();
            }
        }
        
        if ($this->_request->getFullActionName() == 'customer_account_edit') {
			$email = $this->getCustomerSession()->getCustomer()->getEmail();
			$name = $this->getCustomerSession()->getSmName();
			
            $getCookie = $this->_cookieManager->getCookie('customerEdit');
            if ($name && $name!='') {
                $json = $this->helper->getCustomerEditJson($email);
                // Handled for ajax add to cart success thorugh custom js
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                                 
                $this->_cookieManager->setPublicCookie(
                    'SmCustomerEditJson',
                    $json,
                    $publicCookieMetadata
                );
                
                $this->getCustomerSession()->unsSmName();
            }
        }
			$email = $this->getCustomerSession()->getSmSubscriberEmail();
            $getCookie = $this->_cookieManager->getCookie('customerSubscribed');
            if ($email && $email!='') {                
                // Handled for ajax add to cart success thorugh custom js
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                                 
                $this->_cookieManager->setPublicCookie(
                    'SmCustomerSubscribedJson',
                    $email,
                    $publicCookieMetadata
                );
                
                $this->getCustomerSession()->unsSmSubscriberEmail();
            }
           
    }
}
