<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;


class CustomereditPost implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var\ Magento\Framework\Stdlib\CookieManagerInterfac
     */
    protected $_cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    protected $_cookieMetadataFactory;
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registry;

    /**
     * The affiliate cookie name
     */
    const COOKIE_NAME = "Customeredit";

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * Addtocartdispatch constructor.
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     * @param CheckoutSession $checkoutSession
     * @param Config $config
     * @param CatalogSession $catalogSession
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        Config $config,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->_layout        = $layout;
        $this->_registry      = $registry;
        $this->_storeManager  = $storeManager;
        $this->_request       = $request;
        $this->_eventManager  = $eventManager;
        $this->config         = $config;
        $this->_cookieManager = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager        = $sessionManager;
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->customerSession = $customerSession;
    }

    /**
     * Add to cart dispatch event called both for ajax call as well as page redirection call set
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
		$event = $observer->getEvent();
		$customer = $observer->getCustomerDataObject();
		$customerId = $customer->getId();
		//echo 'ghgfhfghdfgd'; exit; 
        if ($customerId!= '') {
            // Handled for ajax add to cart success thorugh custom js
            $customerEdit = 'customerEdit';
            if ($customerEdit) {
				$this->customerSession->setSmName($customer->getFirstname());
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                $this->_cookieManager->setPublicCookie(
                    self::COOKIE_NAME,
                    $customerEdit,
                    $publicCookieMetadata
                );
            }
        }
    }
}
