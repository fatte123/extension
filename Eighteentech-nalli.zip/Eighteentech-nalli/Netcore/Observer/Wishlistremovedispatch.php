<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Observer;

use Magento\Framework\View\Page\Config;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Catalog\Model\Session as CatalogSession;
use Eighteentech\Netcore\Logger\Logger;
use \Magento\Wishlist\Model\Item as WishlistItem;

class Wishlistremovedispatch implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    protected $_queryFactory;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $catalogSession;

    /**
     * @var \Eighteentech\Netcore\Logger\Logger
     */
    private $logger;

    /**
     * @var WishlistItem
     */
    protected $wishlistItem;

    /**
     * Wishlistremovedispatch constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Search\Model\QueryFactory $queryFactory
     * @param Config $config
     * @param CatalogSession $catalogSession
     * @param Logger $logger
     * @param WishlistItem $wishlistItem
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Search\Model\QueryFactory $queryFactory,
        Config $config,
        CatalogSession $catalogSession,
        Logger $logger,
        WishlistItem $wishlistItem
    ) {
        $this->_layout       = $layout;
        $this->_storeManager = $storeManager;
        $this->_request      = $request;
        $this->_eventManager = $eventManager;
        $this->_queryFactory = $queryFactory;
        $this->config        = $config;
        $this->catalogSession = $catalogSession;
        $this->logger = $logger;
        $this->wishlistItem = $wishlistItem;
    }

    /**
     * Remove wishlist item
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        try {
            $productId = '';
            $item      = $this->_request->getParam('item');
            if ($item) {
                //Load product from wishlist item list
                $itemData      = $this->wishlistItem->load($item);
                $qty           = (int) $itemData->getQty();
                $productId     = $itemData->getProductId();
                if ($productId) {
                    $this->catalogSession->setSmWRemoveProd($productId);
                    $this->catalogSession->setSmWRemoveQty($qty);
                }
            }
        } catch (\Exception $e) {
            $this->logger->info('Something went wrong when remove wishist item ' . $e->getMessage());
        }
    }
}
