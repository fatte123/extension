var config = {
    "map": {
        "*": {
            "smartechCustom": "Eighteentech_Netcore/js/smartechCustom"
        } 
    }
};
