/**
 * Copyright © Netxore, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
require(
    ['jquery', 'jquery/jquery.cookie', 'domReady!'],
    function ($) {
        $(document).ajaxSuccess(
            function (event, xhr, settings) {
                var str        = settings.url;
                var cart       = str.includes('/cart/add');
                var minicart   = str.includes('customer/section/load');
                var removeItem = str.includes('/sidebar/removeItem');
                if (settings.type === 'GET' && minicart) {
                    if ($.cookie('Addcartflag') !== null 
                     && $.cookie('Addcartflag') === 'addcartsuccess' 
                     && $.cookie('SmCartJson') !== null) {                
                        var myJsonString;// = $.cookie('SmCartJson') || '{}';
                        const name = "SmCartJson=" ;
                        const cDecoded = decodeURIComponent(document.cookie); //to be careful
                        const cArr = cDecoded.split('; ');
                        let res;
                        cArr.forEach(val => {
                          if (val.indexOf(name) === 0) myJsonString = val.substring(name.length);
                        })
                        if (typeof myJsonString === 'string') {
                            myJsonString = JSON.parse(myJsonString);
                        }

                        myJsonString.prid = parseInt(myJsonString.prid); //change product id from string to int
                        myJsonString.prqt = parseInt(myJsonString.prqt); //change product quantity from string to int
                        myJsonString.final_price = parseFloat(myJsonString.final_price); //change final price to float and put it back in final price
                        myJsonString.price = parseFloat(myJsonString.price); //change price to float and put it back in final price

                        smartech('dispatch', 'add to cart', myJsonString);
                        delete_cookie('Addcartflag');
                        delete_cookie('SmCartJson');
                        $.cookie("Addcartflag", null);
                        $.cookie("SmCartJson", null);
                    }
                }

                if (settings.type === 'POST' && settings.processData && removeItem) {
                    if ($.cookie('Removecartflag') === 'removetItemSidebar') {
                        var myJsonRemoveCart = $.cookie('SmRemoveCartJson');
                        if (typeof myJsonRemoveCart === 'string') {
                            myJsonRemoveCart = JSON.parse(myJsonRemoveCart);
                        }

                        myJsonRemoveCart.prid = parseInt(myJsonRemoveCart.prid); //change product id from string to int
                        myJsonRemoveCart.prqt = parseInt(myJsonRemoveCart.prqt); //change product quantity from string to int
                        myJsonRemoveCart.final_price = parseFloat(myJsonRemoveCart.final_price); //change final price to float and put it back in final price
                        myJsonRemoveCart.price = parseFloat(myJsonRemoveCart.price); //change price to float and put it back in final price

                        smartech('dispatch', 'remove from cart', myJsonRemoveCart);
                        delete_cookie('SmRemoveCartJson');
                        delete_cookie('Removecartflag');
                        $.cookie("SmRemoveCartJson", null);
                        $.cookie("Removecartflag", null);
                    }
                    
                }

                if (settings.type === 'GET') {
                    if ($.cookie('Customeredit') == 'customerEdit') {
                        var SmCustomerEditJson = $.cookie('SmCustomerEditJson');
                        //console.log('SmCustomerEditJson'+SmCustomerEditJson);
                        //var mySmCustomerEditJson = '';
                        //if (typeof SmCustomerEditJson === 'string') {
                            mySmCustomerEditJson = $.parseJSON(SmCustomerEditJson);
                        //}
                        if(mySmCustomerEditJson.email.length>0){
                        var today = new Date().getFullYear()+'-'+("0"+(new Date().getMonth()+1)).slice(-2)+'-'+("0"+new Date().getDate()).slice(-2);
						smartech('contact', '1', {
								'pk^email': mySmCustomerEditJson.email,
								'email': mySmCustomerEditJson.email,
								'mobile': mySmCustomerEditJson.mobile,
								'NAME': mySmCustomerEditJson.name, 
								},function() {
								smartech('identify',mySmCustomerEditJson.email);
								smartech('dispatch', 'user_profile_update',{"updatedate":today,"firstname":mySmCustomerEditJson.name,"lastname":mySmCustomerEditJson.lastname,"email":mySmCustomerEditJson.email,"mobile":mySmCustomerEditJson.mobile,"dob":""});
						});                      
                        
                        delete_cookie('SmCustomerEditJson');
                        delete_cookie('Customeredit');
                        $.cookie("SmCustomerEditJson", null);
                        $.cookie("Customeredit", null);
                       }
                    }
                    if ($.cookie('Customersubscribed') == 'customerSubscribed') {
                        var SmCustomerSubscribedJson = $.cookie('SmCustomerSubscribedJson');                        
						smartech('contact', '1', {
								'pk^email': SmCustomerSubscribedJson, 
								},function() {
								smartech('identify',SmCustomerSubscribedJson);
								smartech('dispatch', 'Newsletter Subscription', {"usertype": 'customer'});
						});                      
                        
                        delete_cookie('Customersubscribed');
                        delete_cookie('Customeredit');
                        $.cookie("SmCustomerSubscribedJson", null);
                        $.cookie("Customersubscribed", null);
                    } 
                    
                                       
                    
                }
                                
            }
        );

        function delete_cookie(name)
        {
            document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            //document.cookie = cookieValue;
        }
    }
);
