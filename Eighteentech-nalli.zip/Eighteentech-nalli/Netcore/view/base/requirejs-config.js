var config = {
    'config': {
        'mixins': {
            'Magento_Checkout/js/action/set-shipping-information': {
                'Eighteentech_Netcore/js/hook': true
            }
        }
    }
};
