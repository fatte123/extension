define([
    'jquery'
], function ($) {
    'use strict';
    console.log("Called this Hook.");

    $(document).ready(function () {
        // $(document).on('change', "[name='country_id']", function () {
        //     alert("Hi");
        // });
        let isShipingForm = false;
        if(window.location.href.indexOf("checkout") >-1)
        {

                $("body").click(function(e) {
                    if(isShipingForm === false && $("#shipping-method-buttons-container"))
                    {
                        isShipingForm = true;
                            // Event
                            // $( "#co-shipping-method-form>div>button" ).click(function() {
                               
                            $("#co-shipping-method-form").submit(function() {
                                console.log("next click ");
                                $("body").unbind("click");

                                //code called
     
    let firstname =   $("input[name=firstname]").val();
    let lastname =   $("input[name=lastname]").val(); 
    let company =   $("input[name=company]").val();
    let username =   $("input[name=username]").val();
    let email = $("input[id=customer-email]").val();
    let city =   $("input[name=city]").val();
    let postcode =   $("input[name=postcode]").val(); 
    let telephone =   $("input[name=telephone]").val();
    if ($.cookie('smart_pk') !== null && $.cookie('smart_pk') != "customer_id" )
    {
        const today = new Date();
        const yyyy = today.getFullYear();
        let mm = today.getMonth() + 1; 
        let dd = today.getDate();
        if (dd < 10) dd = '0' + dd;
        if (mm < 10) mm = '0' + mm;

        const todays = dd + '/' + mm + '/' + yyyy; 
        let listId = 5;
       
    
        // smartech('contact',  " + listId + ", " . $json . "); 
        var pk_meta = 'pk^' +$.cookie('smart_pk');
       
        let pkk_key =  $.cookie('smart_pk');
        let pkk_value = "";
        switch(pkk_key) {
            case "email":
                pkk_value = email;
            break;
            case "mobile":
                pkk_value = telephone;
            break;
            default:
            // code block
        }

        let data_payload = {
                [pk_meta] : pkk_value ,
                'email': email ,
                'mobile': telephone ,
                'FIRST_NAME': firstname ,
                'LAST_NAME':  lastname,
                'COMPANY_NAME':  company ,
                'CITY':city ,
                'SIGNUPDATE':todays,
                
                }
                Object.keys(data_payload).forEach(k => !data_payload[k] && delete data_payload[k]);
        
        
        smartech('contact',  listId ,data_payload );
        smartech('identify', pkk_value);
    }

                               

                            });
                        
                    }
                 
                });
              
        }
 
        
    });

    return function (targetModule) {
        targetModule.crazyPropertyAddedHere = 'yes';
        return targetModule;
    };
});