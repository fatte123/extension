<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Helper;

use Magento\Store\Model\App\Emulation;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Image as ProductImageHelper;
use Psr\Log\LoggerInterface;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\Data\StockItemInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class Product extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Store\Model\App\Emulation
     */
    protected $appEmulation;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $productImageHelper;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var SubscriberFactory
     */
    protected $subscriberFactory;

    /**
     * @var StockRegistryInterface|null
     */
    protected $stockRegistry;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * Product constructor.
     * @param Emulation $appEmulation
     * @param StoreManagerInterface $storeManager
     * @param ProductRepositoryInterface $productRepository
     * @param Image $imageHelper
     * @param LoggerInterface $logger
     * @param CategoryRepositoryInterface $categoryRepository
     * @param SubscriberFactory $subscriberFactory
     * @param StockRegistryInterface $stockRegistry
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        Emulation $appEmulation,
        StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository,
        ProductImageHelper $productImageHelper,
        LoggerInterface $logger,
        CategoryRepositoryInterface $categoryRepository,
        SubscriberFactory $subscriberFactory,
        StockRegistryInterface $stockRegistry,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection
    ) {
        $this->appEmulation          = $appEmulation;
        $this->storeManager          = $storeManager;
        $this->productRepository     = $productRepository;
        $this->productImageHelper    = $productImageHelper;
        $this->logger                = $logger;
        $this->categoryRepository    = $categoryRepository;
        $this->subscriberFactory     = $subscriberFactory;
        $this->stockRegistry         = $stockRegistry;
        $this->customerRepository = $customerRepository;
        $this->categoryCollection = $categoryCollection;
    }

    /**
     * To get image url from the product sku
     * @param $sku
     * @return mixed
     */
    public function getProductImageUrl($sku)
    {
        try {
            $storeId = $this->storeManager->getStore()->getId();
            $product = $this->productRepository->get($sku);
            
            if ($product && $product->getImage() && $product->getImage() != 'no_selection') {
                $baseurl = $this->storeManager->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'catalog/product';
                $imageUrl = $baseurl.$product->getData('thumbnail'); 
                return $imageUrl;
                
            } else {
                $this->appEmulation->startEnvironmentEmulation($storeId, \Magento\Framework\App\Area::AREA_FRONTEND, true);
                if ($product) {
                    $imageUrl = $this->productImageHelper->init($product, 'product_thumbnail_image')->getUrl();
                    $this->appEmulation->stopEnvironmentEmulation();
                    return $imageUrl;
                }
            }
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check getProductImageUrl ' . $sku .' '. $exception->getMessage());
        }
    }

    /**
     * To get product data from the productId
     * @param $productId
     * @return mixed     *
     */
    public function getProductData($productId)
    {
        try {
            $product = $this->productRepository->getById($productId);
            return $product;
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check the product getProductData ' . $productId. ' '. $exception->getMessage());
        }
    }

    /**
     * To get product data from the sku
     * @param $sku
     * @return mixed
     */
    public function getProductDataFromSku($sku)
    {
        try {
            $product = $this->productRepository->get($sku);
            return $product;
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check the getProductDataFromSku ' .$sku . ' '.$exception->getMessage());
        }
    }

    /**
     * @param $categoryIds
     * @return array
     */
    public function getCategoryNames($categoryIds) {
        // Get IDs and check if categories are present
        if (!$categoryIds) {
            return "";
        }

        // Fetch collection
        $categoryCollection = $this->categoryCollection->create()
            ->addAttributeToSelect('*')
            ->addAttributeToFilter('entity_id', $categoryIds)
            ->addIsActiveFilter();

        // Prepare string
        $categories = array();
        foreach ($categoryCollection as $category) {
            array_push($categories, $category->getName());
        }

        return $categories;
    }

    /**
     * @param int $customerId
     * @return bool
     */
    public function isCustomerSubscribeById($customerId)
    {
        try {
            $status = $this->subscriberFactory->create()->loadByCustomerId((int)$customerId)->isSubscribed();
            return (bool)$status;
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check isCustomerSubscribeById '. $exception->getMessage());
        }
    }


    /**
     * @param string $email
     * @return bool
     */
    public function isCustomerSubscribeByEmail($email)
    {
        try {
            $status = $this->subscriberFactory->create()->loadByEmail($email)->isSubscribed();
            return (bool)$status;
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check isCustomerSubscribeByEmail '. $exception->getMessage());
        }
    }

    /**
     * get stock status
     * @param int $productId
     * @return bool
     */
    public function getStockStatus($productId)
    {
        try {
            /** @var StockItemInterface $stockItem */
            $stockItem = $this->stockRegistry->getStockItem($productId);
            $isInStock = $stockItem ? $stockItem->getIsInStock() : false;
            return $isInStock;
        } catch (\Exception $exception) {
            $this->logger->error('Something went wrong please check getStockStatus '. $exception->getMessage());
        }
    }

    /**
     * get customer by email
     * @param $customerEmail
     * @return \Magento\Customer\Api\Data\CustomerInterface|null
     */
    public function getCustomerByEmail($customerEmail)
    {
        $customer = null;
        try {
            $customer = $this->customerRepository->get($customerEmail);
        } catch (NoSuchEntityException $noSuchEntityException) {
            $this->logger->info('No customer record found with this email '.$customerEmail);
        }
        return $customer;
    }
}
