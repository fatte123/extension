<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Helper;

use Eighteentech\Netcore\Model\Customer;
use Eighteentech\Netcore\Model\QuoteItems;
use Eighteentech\Netcore\Model\OrderItems;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Eighteentech\Netcore\Helper\Product as productHelper;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Checkout\Model\Session as checkoutSession;
use Magento\Quote\Model\Cart\CartTotalRepository;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Framework\HTTP\Client\Curl;

use function GuzzleHttp\json_decode;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    const NETCORE_CATALOG_SYNC_URL_IN = "https://upload.boxx.ai/product/";
    const NETCORE_CUSTOMER_SYNC_URL_IN = "https://api.netcoresmartech.com/apiv2?activity=jsonupload&type=contact&primarykey=%s&notifyemail=%s&apikey=%s";
    const NETCORE_PRODUCT_PURCHASE_SYNC_URL_IN = "https://api2.netcoresmartech.com/v1/activity/upload";
    const NETCORE_ABANDONED_CART_SYNC_URL_IN = "https://api2.netcoresmartech.com/v1/activity/upload";
    const NETCORE_JS_SCRIPT_IN = "https://cdnt.netcoresmartech.com/smartechclient.js";
    const NETCORE_JS_SERVICE_WORKER_IN = "//cdnt.netcoresmartech.com/swv4.js";
    
    //US region
    const NETCORE_PURCHASE_PRODUCT_HOOK_ENDPOINT_US = "https://twa.netcoresmartech.com/dispatchngn_webhook_magento";
    const NETCORE_CHECKOUT_HOOK_ENDPOINT_US = "https://twa.netcoresmartech.com/dispatchngn_webhook_magento";
    const NETCORE_JS_SERVICE_WORKER_US = "//cdnt.netcoresmartech.com/swv4.js";    
    
    /**
     * The segregation of all the endpoints needs to be managed per IDC. Right now all IDC's pointing to US IDC
     * @blockStart US-IDC
     * @author anup kale <anup.kale@netcorecloud.com>
     * @created 21/09/2021
     * @todo Needs to be finalized with discussion with Vinit
     */
    const NETCORE_CATALOG_SYNC_URL_US = "https://upload.boxx.ai/product/";
    const NETCORE_CUSTOMER_SYNC_URL_US = "https://api.netcoresmartech.com/apiv2?activity=jsonupload&type=contact&primarykey=%s&notifyemail=%s&apikey=%s";
    const NETCORE_PRODUCT_PURCHASE_SYNC_URL_US = "https://api2.netcoresmartech.com/v1/activity/upload";
    const NETCORE_ABANDONED_CART_SYNC_URL_US = "https://api2.netcoresmartech.com/v1/activity/upload";
    const NETCORE_JS_SCRIPT_US = "https://cdnt.netcoresmartech.com/smartechclient.js"; 
    /**
     * @blockEnd US-IDC
     */
             
    /**
     * @blockEnd IN-IDC
     */
    /**
     * @todo @Rana, Can you please make the script location IDC specific as well?
     */

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Eighteentech\Netcore\Model\QuoteItems
     */
    protected $_quoteItems;

    /**
     * @var \Eighteentech\Netcore\Model\OrderItems
     */
    protected $_orderItems;

    /**
     * @var \Eighteentech\Netcore\Model\Customer
     */
    protected $_customer;

    /**
     * @var \Eighteentech\Netcore\Helper\Product
     */
    protected $productHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $date;

    /**
     * @var checkoutSession
     */
    protected $checkoutSession;

    /**
     * @var CartTotalRepository
     */
    protected $cartTotalRepository;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var QuoteItem
     */
    protected $quoteItem;

    /**
     * @var Curl
     */
    protected $curl;

    /**
     * Data constructor.
     * @param Customer $customer
     * @param QuoteItems $quoteItems
     * @param OrderItems $orderItems
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param Product $productHelper
     * @param DateTime $date
     * @param checkoutSession $checkoutSession
     * @param CartTotalRepository $cartTotalRepository
     * @param CustomerSession $customerSession
     * @param QuoteItem $quoteItem
     * @param Curl $curl
     */
    public function __construct(
        Customer $customer,
        QuoteItems $quoteItems,
        OrderItems $orderItems,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        productHelper $productHelper,
        DateTime $date,
        checkoutSession $checkoutSession,
        CartTotalRepository $cartTotalRepository,
        CustomerSession $customerSession,
        QuoteItem $quoteItem,
        Curl $curl
    ) {
        $this->_quoteItems = $quoteItems;
        $this->_orderItems = $orderItems;
        $this->_scopeConfig = $scopeConfig;
        $this->_customer = $customer;
        $this->_storeManager = $storeManager;
        $this->productHelper = $productHelper;
        $this->date = $date;
        $this->checkoutSession = $checkoutSession;
        $this->cartTotalRepository = $cartTotalRepository;
        $this->customerSession = $customerSession;
        $this->quoteItem = $quoteItem;
        $this->curl = $curl;
    }

    /* Get the web tracking id enabled */

    /**
     * @return mixed
     */
    public function getWebTrackEnable()
    {
        $isEnable = $this->_scopeConfig->getValue(
            'smartech/general/enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $isEnable;
    }

    /* Get the assigned web tracking id value from config assigned field */

    /**
     * @return mixed
     */
    public function getWebId()
    {
        $webId = $this->_scopeConfig->getValue(
            'smartech/general/web_tracking_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $webId;
    }

    /* Get the assigned site tracking id value from config assigned field */

    /**
     * @return mixed
     */
    public function getSiteId()
    {
        $siteId = $this->_scopeConfig->getValue(
            'smartech/general/site_tracking_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $siteId;
    }

    /* Get Registration primary field  */

    /**
     * @return string
     */
    public function getRegisterionId()
    {
        $siteId = $this->_scopeConfig->getValue(
            'smartech/general/registration_primary_field',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return strtolower($siteId);
    }

    /* Get bpn notification flag */

    /**
     * @return mixed
     */
    public function getBpnTrackEnable()
    {
        $bpnIsEnable = $this->_scopeConfig->getValue(
            'smartech/push_notification/bpn_enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $bpnIsEnable;
    }

    /* Get bpn sender id */

    /**
     * @return mixed
     */
    public function getBpnSenderId()
    {
        $bpnSenderId = $this->_scopeConfig->getValue(
            'smartech/push_notification/bpn_sender_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $bpnSenderId;
    }

    /* Get bpn app id */

    /**
     * @return mixed
     */
    public function getBpnAppId()
    {
        $bpnSenderId = $this->_scopeConfig->getValue(
            'smartech/push_notification/bpn_app_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $bpnSenderId;
    }

    /* Get bpn project id */

    /**
     * @return mixed
     */
    public function getBpnProjectId()
    {
        $bpnSenderId = $this->_scopeConfig->getValue(
            'smartech/push_notification/bpn_project_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $bpnSenderId;
    }

    /* Get bpn api key */

    /**
     * @return mixed
     */
    public function getBpnApiKey()
    {
        $bpnApiKey = $this->_scopeConfig->getValue(
            'smartech/push_notification/bpn_api_key',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $bpnApiKey;
    }

    /**
     * Get tracker script to include
     * @return string
     */
    public function getTrackingScript()
    {
        $this->_scriptLocation     = self::NETCORE_JS_SCRIPT_IN;

        $str = '';
        $webTrackinId = $this->getWebId();
        $getSiteId = $this->getSiteId();
        // Get customer key identity
        $str = '<script src="' . $this->_scriptLocation . '"></script>
				<script>smartech("create","' . $webTrackinId . '");
				smartech("register","' . $getSiteId . '");
                </script>';
        return $str;
    }

    /**
     * Page Browse
     * @param $track
     * @return string
     */
    public function getScriptPageBrowse($track)
    {
        unset($track['is_enable']);
        $str = '';
        $identity = $this->getCustomerIdentity();
        $json = json_encode($track);
        $str = "<script>"
            . "smartech('identify', '" . $identity . "');"
            . "smartech('dispatch', 'page browse' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Add to cart
     * @param $json
     * @return string
     */
    public function getScriptAddToCart($json)
    {
        
        $json = $this->dataTypeConversion($json);
        
        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'add to cart' , " . $json . ");"
            . "</script>";
            
        return $str;
    }
     /**
      * Update  to cart
      * @param $json
      * @return string
      */
    public function getScriptUpdateToCart($json)
    {

        $json = $this->dataTypeConversion($json);
        
        $str = '';
        $str = "<script>" 
            . "smartech('dispatch', 'add to cart' , " . $json . ");"
            . "</script>";
            // echo $str;
        return $str;
    }


    /**
     * Remove from cart
     * @param $json
     * @return string
     */
    public function getScriptRemoveFromCart($json)
    {
        $json = $this->dataTypeConversion($json);

        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'remove from cart' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Checkout
     * @param $json
     * @return string
     */
    public function getScriptCheckout($json)
    {

        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'checkout' , " . $json . ", 'smartechMagento');"
            . "</script>";
        return $str;
    }

    /**
     * Product purchase
     * @param $json
     * @return string
     */
    public function getScriptPurchase($json)
    {
        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'product purchase' , " . $json . ", 'smartechMagento');"
            . "</script>";
        return $str;
    }

    /**
     * Add to wishlist
     * @param $json
     * @return string
     */
    public function getScriptWishlistAdd($json)
    {
        $json = $this->dataTypeConversion($json);

        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'add to wishlist' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Add to wishlist
     * @param $json
     * @return string
     */
    public function getScriptCatalogData($json)
    {

        $json = $this->dataTypeConversion($json);

        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'product view' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Remove from wishlist
     * @param $json
     * @return string
     */
    public function getScriptWishlistRemove($json)
    {
        $json = $this->dataTypeConversion($json);

        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'remove from wishlist' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Product search
     * @param $json
     * @return string
     */
    public function getScriptSearch($json)
    {
        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'product search' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * Contact
     * @param $json
     * @return string
     */
    public function getContactTrack($json,$pk_str)
    {
        $str = '';
        $listId = 5;
        $str = "<script>"
            . "smartech('identify', '". $pk_str ."');"
            . "smartech('contact', " . $listId . " , " . $json . ");"
            . "</script>";
        return $str;
    }
      /**
     * Customer  set identity when user login
     * @param $json
     * @return string
     */
    public function getContactTrack_setpk($pk_str)
    {
        $str = '';
        $listId = 5;
        $str = "<script>"
            . "smartech('identify', '". $pk_str ."');"
            . "</script>";
        return $str;
    }

    /**
     * Customer
     * @param $json
     * @return string
     */
    public function getCustomerTrack($json)
    {
        $str = '';
        $str = "<script>" 
            . "smartech('dispatch', 'signup' , " . $json . ");"
            . "</script>";
        return $str;
    }

    /**
     * @param $search
     * @return false|string
     */
    public function getSearchJson($search, $products)
    {
        $data['type'] = 'Search';
        $data['key'] = $search;
        $data['product_ids'] = $products;
        $json = json_encode($data);
        return $json;
    }

    /**
     * Build customer registration json data
     * @param $email
     * @return false|string
     */
    public function getRegisterJson($email)
    {
        $json = '';
        // Get customer's smartech identity key set
        $key = $this->getSmartechCustomerIdentityKey();
        $customerData = $this->_customer->getCustomer($email);
        // print_r(  $customerData->getData());
        // $customer = $this->customer->create()->setWebsiteId($websiteID)->loadByEmail($email);
        $billingID =  $customerData->getDefaultBilling();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $address = $objectManager->create('Magento\Customer\Model\Address')->load($billingID);
        $primaryKey = 'pk^' . $key;
        // $addressRepository = $objectManager->create("Magento\Customer\Api\AddressRepositoryInterface");
        // $address = $addressRepository->getById($customerId);
        
        // $data[$primaryKey] = $customerData->getData($key);
        switch ($key) {
            case "email":
                $data[$primaryKey] = $customerData->getEmail();
                break;
            case "mobile":
                $data[$primaryKey] = $customerData->getTelephone() ? $customerData->getTelephone() : $address->getTelephone() ;
                break;
            case "customer_id":
                 $primaryKey = 'pk^' . "customer_id";
                $data[$primaryKey] = $customerData->getId() ? $customerData->getId() : '';
                break;

            case "id":
                 $primaryKey = 'pk^' . "customer_id";
                $data[$primaryKey] = $customerData->getId() ? $customerData->getId() : '';
                break;
            default:
        }
        
        /*$data['FIRST_NAME'] = $customerData->getFirstname();
        $data['LAST_NAME'] = $customerData->getLastname();
        $data['DOB'] = $customerData->getDob();
        // $data['MOBILE'] = $customerData->getMobileAttribute() . $customerData->getCustomAttribute('mobile_attribute');
        $data['mobile'] = $customerData->getTelephone() ? $customerData->getTelephone() : $address->getTelephone() ;
        $data['email'] = $customerData->getEmail() ? $customerData->getEmail() : '';
        $data['CITY'] = $address->getCity() ? $address->getCity(): '';
        $data['CUSTOMER_GROUP_ID'] = $customerData->getGroupId();
        $data['CUSTOMER_ID'] = $customerData->getId() ? $customerData->getId() : '';
        $data['NEWSLETTER_SUBSCRIBER_STATUS'] = $this->productHelper->isCustomerSubscribeByEmail($customerData->getEmail());
        $data['WEBSITE_ID'] = $customerData->getWebsiteId();
        $created_at = date($customerData->getCreatedAt());
        $data['SIGNUPDATE'] = date('d-m-Y', strtotime($created_at));*/

        $json = json_encode($data);
        return $json;
    }

    /**
     * Build customer registration json data
     * @param $email
     * @return false|string
     */
    public function getCustomerJson($email)
    {
        $json = '';
        $customerData = $this->_customer->getCustomer($email);
        $billingID =  $customerData->getDefaultBilling();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $address = $objectManager->create('Magento\Customer\Model\Address')->load($billingID);

        $data['FIRSTNAME'] = $customerData->getFirstname();
        $data['LASTNAME'] = $customerData->getLastname();
        $data['DOB'] = $customerData->getDob();
        $data['mobile'] = $customerData->getTelephone();
        $data['email'] = $customerData->getEmail();
        $data['CITY'] = $address->getCity() ? $address->getCity() : '';
        $created_at = date($customerData->getCreatedAt());
        $data['SIGNUPDATE'] = date('d-m-Y', strtotime($created_at));
        $json = json_encode($data);
        return $json;
    }


    /**
     * Build cart product json data
     * @param $prodId
     * @param string $type
     * @param int $qty
     * @return false|string
     */
    public function getCartJson($prodId, $type = '', $qty = 1)
    {

        $json = '';
        $product = $this->productHelper->getProductData($prodId);
        $data['prid'] = $prodId;
        $data['name'] = $product->getName();
        $data['brand'] = 'Nalli';
        $data['variant'] = 'No';
        $data['is_in_stock'] = 'Yes';
        $data['category'] = count($product->getCategoryIds()) > 0 ?
            $this->productHelper->getCategoryNames($product->getCategoryIds()) : "";
        $data['price'] = (float)number_format((float)$product->getPrice(), 2, '.', '');
        $data['final_price'] = (float)number_format((float)$product->getFinalPrice(), 2, '.', '');
        $data['prqt'] = $type . $qty;
        $data['currency'] = $this->getStoreCurrency();
        $data['image_url'] = $this->productHelper->getProductImageUrl($product->getSku());
        $data['product_type'] = $product->getTypeId();
        $data['product_url'] = $product->getProductUrl();
        $data['activity_date'] = $this->date->gmtTimeStamp();
        $data['sku'] = $product->getSku();
        $json = json_encode($data);
        return $json;
    }


    /**
     * Build cart product json data
     * @param $prodId
     * @param string $type
     * @param int $qty
     * @return false|string
     */
    public function getCartJsonnew($prodId, $type = '', $qty = 1)
    {

        $json = '';
        $product = $this->productHelper->getProductData($prodId);
        $data['prid'] = $prodId;
        $data['name'] = $product->getName();
        $data['brand'] = 'Nalli';
        $data['variant'] = 'No';
        $data['is_in_stock'] = 'Yes';
        $data['category'] = count($product->getCategoryIds()) > 0 ?
            $this->productHelper->getCategoryNames($product->getCategoryIds()) : "";
        $data['price'] = (float)number_format((float)$product->getPrice(), 2, '.', '');
        $data['final_price'] = (float)number_format((float)$product->getFinalPrice(), 2, '.', '');
        $data['prqt'] = $type . $qty;
        $data['currency'] = $this->getStoreCurrency();
        $data['image_url'] = $this->productHelper->getProductImageUrl($product->getSku());
        $data['product_type'] = $product->getTypeId();
        $data['product_url'] = $product->getProductUrl();
        $data['activity_date'] = $this->date->gmtTimeStamp();
        $data['sku'] = $product->getSku();
        // print_r($data); exit();
        // $json = json_encode($data);
        $identity = 'email';
        // return ['data' => $data, 'identity' => "email"];
        // return $json;
        $newdata = ['data' => $data, 'identity' => "email"];
        // print_r($newdata);
        return json_encode($newdata);
    }
    

    /**
     * To get product id from item id
     * @param $id
     * @return mixed
     */
    public function getProductFromItem($id)
    {
        $itemData = $this->quoteItem->load($id);
        $product = $itemData->getData();
        return $product['product_id'];
    }

    /**
     * To get quote item qty
     * @param $id
     * @return int
     */
    public function getQuoteItemQty($id)
    {
        $itemData = $this->quoteItem->load($id);
        $qty = (int) $itemData->getQty();
        return $qty;
    }

    /**
     * Get store currency
     * @return mixed
     */
    public function getStoreCurrency()
    {
        return $this->_storeManager->getStore()->getCurrentCurrency()->getCode();
    }

    /**
     * To check if customer logged in
     * @return string
     */
    public function isCustomerLoggedIn()
    {
        // $this->log("Register", "customer  is login  fuction = "  .json_encode($this->customerSession->isLoggedIn()));
        if ($this->customerSession->isLoggedIn()) {
            return $this->customerSession->getCustomer();
        }
        return '';
    }

    /**
     * To fetch customer's identity field
     * @return string
     */
    public function getCustomerIdentity()
    {
        $identity = ''; // The blank value is not considered
        $customer = $this->isCustomerLoggedIn();
        
        if ($customer) {
            // $this->log("Register", "customer  is login = "  .json_encode($customer));
            $key = $this->getSmartechCustomerIdentityKey();
            // $this->log("Register", "Key = " .json_encode($key));
            $identity = $customer->getData($key);
            // $this->log("Register", "Key value of method = " .json_encode(get_class_methods($customer)));
            // $this->log("Register", "Key value = " .json_encode($identity));

        }
        return $identity;
    }

    /**
     * get Customer identity key
     * @return string
     */
    public function getSmartechCustomerIdentityKey()
    {
        $isprimarykey = $this->_scopeConfig->getValue(
            'smartech/general/registration_primary_field',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $key = $isprimarykey;
        return strtolower($key);
    }


    /**
     * Create log file when sync fails
     * @return boolen
     */
    public function log(
        $file_name,
        $data = ''
    ) {
        //path to log
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/Netcore' . $file_name . '.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        //write data
        $logger->info(print_r($data, 1));
        return 1;
    }

    /**
     * Convert price from string to float
     */
    public function dataTypeConversion($json)
    {
        $decodedJson = json_decode($json);

        $decodedJson->prid = (int) $decodedJson->prid; //convert product id to int
        $decodedJson->prqt = (int) $decodedJson->prqt; //convert product quantity to int
        $decodedJson->final_price = (float) $decodedJson->final_price; //convert final price to float
        $decodedJson->price = (float) $decodedJson->price; //convert price to float

        $json = json_encode($decodedJson);
        return $json;
    }
    
    /**
     * @param $quoteId
     * @return false|string
     */
    public function getCheckoutJson($quoteId)
    {
        $json                   = '';
        $quote                  = $this->_quoteItems->getQuote($quoteId);
        $data['total_items']     = (int) $this->checkoutSession->getQuote()->getItemsCount();
        $data['totalamount']    = (float)number_format((float)$this->checkoutSession->getQuote()->getGrandTotal(), 2, '.', '');
        $data['subtotal']    = (float)number_format((float)$this->checkoutSession->getQuote()->getBaseSubtotal(), 2, '.', '');
        $data['currency']    = $quote->getQuoteCurrencyCode();
        $data['discount']    = (float)number_format((float)$this->checkoutSession->getQuote()->getDiscountAmount(), 2, '.', '');
        $data['cart_id']    = $quoteId;
		$itemArray = [];
        foreach ($quote->getItems() as $item) {
            $product = $this->productHelper->getProductData($item->getProductId());
            $itemArray[] = [
                'prid'          => (int)$item->getProductId(),
                'name'          => $item->getName(),
                'price'         => (float)number_format((float)$item->getPrice(), 2, '.', ''),
                'prqt'           => (int) $item->getQty(),
                'image'         => $this->productHelper->getProductImageUrl($item->getSku()),
                'producturl'   => $product->getProductUrl(),
                'product_type'  => $item->getProductType(),
                'currency'      => $this->getStoreCurrency(),
                'sku'           => $item->getSku(),
                'variant'       => 'No',
                'brand'       => 'Nalli',
                'is_in_stock'       => 'Yes',
                'final_price'   => (float)number_format((float)$product->getFinalPrice(), 2, '.', '')
            ];
        }

        $data['items'] = $itemArray;
        if (empty($data)) {
            return "";
        }
        $key = $this->getSmartechCustomerIdentityKey();
        $customerData = $this->_customer->getCustomer($quote->getCustomer()->getEmail());
        $identity = $customerData->getData($key);
        return ['data' => $data, 'identity' => ($identity ?: "")];
    }
    
    public function makeRequest(
        $method,
        $url,
        $data = [],
        $api_key = ''
    ) {
        

        //create log file
        $idc_region = $this->_scopeConfig->getValue("smartech/general/idc_region", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        if (isset($data['request_type'])) {
            //cron type
            $request_type = strtok($data['request_type'], ' ');
        } else {
            //cron type for customer
            $request_type = 'customer';
        }

        //create log file only if the idc_region is POD2
        if (strcasecmp($idc_region, 'POD2') === 0) {
            //write data
            $this->log($request_type . '_sync_' . time(), $data);
        }

        try {

            $authHeader = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $api_key
            ];

            $this->curl->setOption(CURLOPT_HTTPHEADER, $authHeader);
            $this->curl->setOption(CURLOPT_SSL_VERIFYHOST, false);
            $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);

            if ($method == "GET") {
                // method method
                $this->curl->get($url);
            } else {
                // post methodgetProductId
                try {
					$this->curl->post($url, $data['data']);
                }catch (\Exception $e) {
					$result = '';
					//write to log
					$this->log($request_type . '_error_' . time(), $e);
				}
            }

            // output of curl request
            $result = $this->curl->getBody();
            // $this->log($request_type . '_response_' . time(), $result);
            if (strcasecmp($idc_region, 'POD2') === 0) {
                //write data
                $this->log($request_type . '_response_' . time(), $result);
            }
        }
     catch (\Exception $e) {
            $result = '';
            //write to log
            $this->log($request_type . '_error_' . time(), $e);
        }

        return $result;
    }
    public function getPurchaseOrderJson($orderId, $forHook = 0)
    {
        $json = '';
        $order = $this->_orderItems->getOrder($orderId);
        $getAllItems = $this->_orderItems->getOrderItems($orderId);
        $orderData['total_item_count'] = (int) $order->getTotalItemCount();
        $orderData['order_number'] = $order->getIncrementId();
        $orderData['totalamount'] = (float)number_format((float)$order->getBaseGrandTotal(), 2, '.', '');
        $orderData['dateofpurchase'] = date("Y-m-d H:i:s");
        $orderData['activity_date'] = strtotime($order->getCreatedAt());
        $orderData['order_id'] = $orderId;
        foreach ($getAllItems as $key => $item) {
            $product = $this->productHelper->getProductData($item->getProductId());
            $productData[] = [
                'prid'              => (int)$product->getId(),
                'name'              => $product->getName(),
                'price'             => (float)number_format($item->getPrice(), 2, '.', ''),
                'qty'               => (int) $item->getQtyOrdered(),
                'image_url'         => $this->productHelper->getProductImageUrl($item->getSku()),
                'product_url'       => $product->getProductUrl(),
                'product_type'      => $item->getProductType(),
                'currency'          => $order->getOrderCurrencyCode(),
                'sku'               => $item->getSku(),
                'is_in_stock'       => 'Yes',
                'variant'           => $product->getResource()->getAttribute('color')->getFrontend()->getValue($product),
                'final_price'       => (float)number_format((float)$product->getFinalPrice(), 2, '.', '')
            ];
        }
        $orderData['total_qty_ordered'] = (int) $order->getTotalQtyOrdered();
        $orderData['subtotal'] = (float) $order->getBaseSubtotal();
        $orderData['shipping_description'] =  $order->getShippingDescription();
        $orderData['shipping_city'] = $order->getShippingAddress() ? $order->getShippingAddress()->getCity() : '';
        $orderData['shipping_region'] = $order->getShippingAddress() ? $order->getShippingAddress()->getRegion() : '';
        $orderData['shipping_country_id'] = $order->getShippingAddress() ? $order->getShippingAddress()->getCountryId() : '';
        $orderData['shipping_address'] = $order->getShippingAddress() ? $order->getShippingAddress()->getData()['street'] : '';
        $orderData['billing_address'] = $order->getBillingAddress() ? $order->getBillingAddress()->getData()['street'] : '';
        $orderData['payment_method'] = $order->getPayment()->getMethodInstance()->getTitle();
        $orderData['shipping_method'] = $order->getShippingMethod();
        $orderData['shippingfee'] = number_format($order->getShippingAmount(),2,'.','');
        $orderData['coupon_code'] = $order->getCouponCode();
        $orderData['discount'] = number_format($order->getDiscountAmount(),2,'.','');
        $orderData['customer_email'] = $order->getCustomerEmail();
        $orderData['items'] = $productData;

        if (empty($orderData)) {
            return "";
        }
        $key = $this->getSmartechCustomerIdentityKey();
        $customerData = $this->_customer->getCustomer($order->getCustomerEmail());
        $identity = $customerData->getData($key);
        return ['data' => $orderData, 'identity' => ($identity ?: "")];
    }
       /**
     * Build customer registration primary key data
     * @param $email
     * @return false|string
     */
    public function getContactTrack_pk($email)
    {
        $json = '';
         
        $key = $this->getSmartechCustomerIdentityKey();
        $customerData = $this->_customer->getCustomer($email); 
        $billingID =  $customerData->getDefaultBilling();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $address = $objectManager->create('Magento\Customer\Model\Address')->load($billingID);
            
        
        $primaryKey = 'pk^' . $key;
        $this->log("Register", "customer  primaryKey  = " . __LINE__ .$primaryKey);
        
        // $data[$primaryKey] = $customerData->getData($key);
        switch ($key) {
            case "email":
                $data[$primaryKey] = $customerData->getEmail();
                break;
            case "mobile":
                $data[$primaryKey] = $customerData->getMobile() ? $customerData->getTelephone() : $address->getTelephone();
                // $this->log("Register", "customer Mob primaryKey  = " . __LINE__ . "User email = ".$customerData->getEmail(). "PK mob = ". $address->getTelephone());
                break;
            case "customer_id":
                 $primaryKey = 'pk^' . "customer_id";
                // $this->log("Register", "customer  primaryKey  = ". __LINE__ ."PK =".$primaryKey. "ID ".$customerData->getId());
                $data[$primaryKey] = $customerData->getId() ? $customerData->getId() : $customerData->getEmail();
                break;
            case "id":
                 $primaryKey = 'pk^' . "customer_id";
                    // $this->log("Register", "customer  primaryKey  = " . __LINE__ ."PK =".$primaryKey. "ID ".$customerData->getId());
                    $data[$primaryKey] = $customerData->getId() ? $customerData->getId() : $customerData->getEmail();
                    break;
            default:
        }  
        return $data[$primaryKey];
    }    
    /**
     * Category Viewed
     * @param $categoryName
     * @return string
     */
    public function getScriptCategoryData($categoryName)
    {
		$arr = ['categoryname'=>$categoryName];
		$json = json_encode($arr);
        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'Category Viewed' , " . $json . ");"
            . "</script>";
        return $str;
    } 
    
    public function getCustomerEditJson($email)
    {
        $json = '';
        $customerData = $this->_customer->getCustomer($email);
        $billingID =  $customerData->getDefaultBilling();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $address = $objectManager->create('Magento\Customer\Model\Address')->load($billingID);

        $data['name'] = $customerData->getFirstname();
        $data['lastname'] = $customerData->getLastname();
        $data['mobile'] = $customerData->getMobile();
        $data['email'] = $customerData->getEmail();
        $json = json_encode($data);
        return $json;
    } 
    
    public function getScriptViewCart($json)
    {
        $str = '';
        $str = "<script>"
            . "smartech('dispatch', 'Cart View' , " . $json . ");"
            . "</script>";
        return $str;
    }
                  
}
