<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Model;

class OrderItems
{
    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $_orderRepository;

    /**
     * @var \Magento\Sales\Api\OrderItemRepositoryInterface
     */
    protected $_itemRepository;

    /**
     * OrderItems constructor.
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     * @param \Magento\Sales\Api\OrderItemRepositoryInterface $itemRepository
     */
    public function __construct(
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Api\OrderItemRepositoryInterface $itemRepository
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_itemRepository = $itemRepository;
    }

    /**
     * Get Order data
     * @param $orderId
     * @return array
     */
    public function getOrder($orderId)
    {
        try {
            $order = $this->_orderRepository->get($orderId);
            return $order;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $responce = [];
            return $responce;
        }
    }

    /* Get Order Items */

    public function getOrderItems($orderId)
    {
        try {
            $order = $this->_orderRepository->get($orderId);
            $items = $order->getAllVisibleItems();
            return $items;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $responce = [];
            return $responce;
        }
    }

    /**
     * Get Item data through id
     * @param $itemId
     * @return array
     */
    public function getOrderItemData($itemId)
    {
        try {
            $item = $this->_itemRepository->get($itemId);
            return $item;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $responce = [];
            return $responce;
        }
    }
}
