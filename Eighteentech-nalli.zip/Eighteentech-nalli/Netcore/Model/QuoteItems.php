<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Model;

class QuoteItems
{
    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $_quoteRepository;

    /**
     * QuoteItems constructor.
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepository
     */
    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository
    ) {
        $this->_quoteRepository = $quoteRepository;
    }

    /**
     * @param $quoteId
     * @return array
     */
    public function getQuote($quoteId)
    {
        try {
            $quote = $this->_quoteRepository->get($quoteId);
            return $quote;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return [];
        }
    }

    /**
     * @param $quoteId
     * @return array
     */
    public function getQuoteItems($quoteId)
    {
        try {
            $quote = $this->_quoteRepository->get($quoteId);
            $items = $quote->getAllItems();
            return $items;
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            return [];
        }
    }
}
