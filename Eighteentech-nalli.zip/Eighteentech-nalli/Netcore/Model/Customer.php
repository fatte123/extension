<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Model;

use Magento\Customer\Model\CustomerFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

class Customer
{
    /**
     * @var CustomerFactory
     */
    protected $customerFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * Customer constructor.
     * @param CustomerFactory $customerFactory
     * @param StoreManagerInterface $storeManager
     * @param LoggerInterface $logger
     */
    public function __construct(
        CustomerFactory $customerFactory,
        StoreManagerInterface $storeManager,
        LoggerInterface $logger
    ) {
        $this->customerFactory = $customerFactory;
        $this->storeManager = $storeManager;
        $this->logger = $logger;
    }

    /**
     * @param $email
     * @return mixed
     */
    public function getCustomer($email)
    {
        try {
            $websiteId = $this->storeManager->getStore()->getWebsiteId();
            $customer = $this->customerFactory->create();
            $customer->setWebsiteId($websiteId);
            $customer->loadByEmail($email);
            return $customer;
        } catch (\Exception $e) {
            $this->logger->error('Something went wrong with customer' . $e->getMessage());
        }
    }
}
