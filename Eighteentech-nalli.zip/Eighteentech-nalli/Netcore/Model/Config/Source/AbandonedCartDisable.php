<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */
 
 
namespace Eighteentech\Netcore\Model\Config\Source;

use Magento\Framework\Data\Form\Element\AbstractElement;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\View\Helper\SecureHtmlRenderer;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;

class AbandonedCartDisable extends \Magento\Config\Block\System\Config\Form\Field
{

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param Context $context
     * @param array $data
     * @param SecureHtmlRenderer|null $secureRenderer
     * @param ScopeConfigInterface $scopeConfig
     */

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        array $data = [],
        ?SecureHtmlRenderer $secureRenderer = null
    ) {
        parent::__construct($context, $data);
        $this->secureRenderer = $secureRenderer ?? ObjectManager::getInstance()->get(SecureHtmlRenderer::class);
        $this->scopeConfig          = $scopeConfig;
    }

    protected function _getElementHtml(AbstractElement $element)
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $sync =  $this->scopeConfig->getValue("smartech/history_sync/abandoned_cart", $storeScope, 1);

        if ($sync) {
            $element->setDisabled('disabled');
            return $element->getElementHtml();
        } else {
            return $element->getElementHtml();
        }
    }
}
