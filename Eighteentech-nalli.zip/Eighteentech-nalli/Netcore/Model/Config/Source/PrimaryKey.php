<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */
 
namespace Eighteentech\Netcore\Model\Config\Source;

class PrimaryKey implements \Magento\Framework\Data\OptionSourceInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => 'email', 'label' => __('Email')],
            ['value' => 'mobile', 'label' => __('Mobile')],
            ['value' => 'id', 'label' => __('Customer_Id')]
        ];
    }
}
