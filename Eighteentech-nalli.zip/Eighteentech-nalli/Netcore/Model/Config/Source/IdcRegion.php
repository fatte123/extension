<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */
 
namespace Eighteentech\Netcore\Model\Config\Source;

class IdcRegion implements \Magento\Framework\Data\OptionSourceInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => '', 'label' => __('Please Select')],
            ['value' => 'IN', 'label' => __('IN')],
            ['value' => 'US', 'label' => __('US')],
            ['value' => 'EU', 'label' => __('EU')]
        ];
    }
}
