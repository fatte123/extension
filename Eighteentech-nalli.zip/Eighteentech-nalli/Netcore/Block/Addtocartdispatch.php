<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Block;

class Addtocartdispatch extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlInterface;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;


    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    private $cookieManager;

    /**
     * Addtocartdispatch constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Title $pageTitle
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Title $pageTitle,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        array $data = []
    ) {
        $this->helper           = $helper;
        $this->_request         = $request;
        $this->_pageTitle       = $pageTitle;
        $this->_urlInterface    = $urlInterface;
        $this->_catalogSession  = $catalogSession;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->cookieManager    = $cookieManager;
        $this->addData(['cache_lifetime' => false]);
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }

    /**
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * @return string
     */
    public function executeAddToCartJs()
    {
        $prod = $getCookie = $json = '';
        $qty  = 1;
        $prod = $this->getCatalogSession()->getSmacProd();
        if ($this->getCatalogSession()->getSmacQty()) {
            $qty = $this->getCatalogSession()->getSmacQty();
        }
        // echo "from executeAddToCartJs Block" . $prod;
        $getCookie = $this->cookieManager->getCookie('Addcartflag');
        if ($prod && $this->_request->getFullActionName() == 'checkout_cart_add') {
            $json = $this->helper->getCartJson($prod, '', $qty);
            // Call handled for add to cart page redirect success event
            /*if ($getCookie == 'addcartsuccess') {
                $this->getCatalogSession()->unsSmacProd();
                $this->getCatalogSession()->unsSmacQty();
                $this->cookieManager->deleteCookie('SmCartJson');
                $this->cookieManager->deleteCookie('Addcartflag');
                $str = $this->helper->getScriptAddToCart($json);
                return sprintf($str);
            }*/
        }        
    }
}
