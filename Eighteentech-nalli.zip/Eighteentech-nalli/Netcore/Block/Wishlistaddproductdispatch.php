<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Block;

class Wishlistaddproductdispatch extends \Magento\Framework\View\Element\Template
{

    protected $_urlInterface;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * Wishlistaddproductdispatch constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Title $pageTitle
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Title $pageTitle,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    ) {
        $this->helper           = $helper;
        $this->_request         = $request;
        $this->_pageTitle       = $pageTitle;
        $this->_urlInterface    = $urlInterface;
        $this->_catalogSession  = $catalogSession;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->addData(['cache_lifetime' => false]);
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }

    /**
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * @return string
     */
    public function executeWishlistAddJs()
    {
        $prod = '';
        $qty  = 1;
        $prod = $this->getCatalogSession()->getSmWAddProd();
        if ($prod) {
            if ($this->getCatalogSession()->getSmacQty() >= 1) {
                $qty = $this->getCatalogSession()->getSmacQty();
            } elseif ($this->getCatalogSession()->getSmWAddQty() >= 1) {
                // move cart items to wishlist
                $qty = $this->getCatalogSession()->getSmWAddQty();
            }
            $json = $this->helper->getCartJson($prod, '', $qty);
            $str  = $this->helper->getScriptWishlistAdd($json);
            $this->getCatalogSession()->unsSmWAddProd();
            $this->getCatalogSession()->unsSmacQty();
            $this->getCatalogSession()->unsSmWAddQty();
            return sprintf($str);
        }
    }
}
