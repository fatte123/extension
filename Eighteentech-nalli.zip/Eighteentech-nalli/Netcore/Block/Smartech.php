<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Block;

use Exception;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Smartech extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlInterface;

    /**
     * Name of cookie that holds private content version
     */
    const BPN_SENDER  = '';
    const BPN_API_KEY = '';
    const SM_WEB_ID   = '';
    const SM_SITE_ID  = '';

    /**
     * CookieManager
     *
     * @var CookieManagerInterface
     */
    private $cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @var SessionManagerInterface
     */
    private $sessionManager;

      /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Smartech constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Title $pageTitle
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param CookieManagerInterface $cookieManager
     * @param CookieMetadataFactory $cookieMetadataFactory
     * @param SessionManagerInterface $sessionManager
     * @param \Magento\Framework\Module\Dir\Reader $moduleReader
     * @param \Magento\Framework\Filesystem\DirectoryList $dir
     * @param \Magento\Framework\Filesystem\Io\File $file
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Title $pageTitle,
        \Magento\Framework\UrlInterface $urlInterface,
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        SessionManagerInterface $sessionManager,
        \Magento\Framework\Module\Dir\Reader $moduleReader,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\Framework\Filesystem\Io\File $file,        
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->_request = $request;
        $this->_pageTitle = $pageTitle;
        $this->_urlInterface = $urlInterface;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->sessionManager        = $sessionManager;
        
        $this->_catalogSession        = $catalogSession;
        $this->_checkoutSession       = $checkoutSession;
        $this->_customerSession       = $customerSession;
        $this->_cookieManager         = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager        = $sessionManager;
        $this->helper                 = $helper;
        $this->_dir  = $dir->getRoot() . "/pub/media";
        $this->_file = $file;
        $this->scopeConfig      = $scopeConfig;
        $this->addData(['cache_lifetime' => false]);
        parent::__construct($context, $data);
    }
      /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }

    /**
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * @return mixed
     */
    public function get()
    {
        return $this->cookieManager->getCookie(self::COOKIE_NAME);
    }

    /**
     * @param $cookieName
     * @param $value
     * @param int $duration
     */
    public function set($cookieName, $value, $duration = 86400)
    {
        $metadata = $this->cookieMetadataFactory
            ->createPublicCookieMetadata()
            ->setDuration($duration)
            ->setPath($this->sessionManager->getCookiePath())
            ->setDomain($this->sessionManager->getCookieDomain());
        $this->cookieManager->setPublicCookie($cookieName, $value, $metadata);
    }

    /**
     * General smartech function cal
     * @return string
     */
    public function getSmartechTxt()
    {
        return 'Smartech cal!';
    }

     /**
     *  smartech function call for set user identity
     * @return string
     */
    public function getSmartechuser()
    {

         // on page laod set user identity 
         $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
         ->setDuration(259200)
         ->setPath($this->_sessionManager->getCookiePath())
         ->setDomain($this->_sessionManager->getCookieDomain())
         ->setHttpOnly(false);
         
         $email = $this->getCustomerSession()->getCustomer()->getEmail();
         if ($email) {
             
             $pk_str  = $this->helper->getContactTrack_pk($email);            
            //  $this->helper->log("Register", "customer  primary Key main layout = " . __LINE__ .$pk_str);
             $str  = $this->helper->getContactTrack_setpk($pk_str);
             return sprintf($str);
         } 
         return "";
         // on page load set user identity 
        $email = $this->_customerSession()->getCustomer()->getEmail();
        if ($email) {
            
            $pk_str  = $this->helper->getContactTrack_pk($email);            
            // $this->helper->log("Register", "customer  primary Key main layout = " . __LINE__ .$pk_str);
            $str  = $this->helper->getContactTrack_setpk($pk_str);
            $this->_cookieManager->setPublicCookie(
                'smart_ck',
                urldecode($str),
                $publicCookieMetadata
            );
            // $this->getCustomerSession()->unsEmail();
            //return sprintf($str);
        } 

        // end of user identity 
         
         // end of user identity 
         
    }

    /**
     * @description - fetch smartech track details for page browse event
     * @return mixed
     */
    public function getTrackDetails()
    {
        $data['is_enable'] = $this->helper->getWebTrackEnable();
        $data['title']     = $this->_pageTitle->getShort();
        $data['url']       = $this->_urlInterface->getCurrentUrl();
        if ($this->helper->getBpnTrackEnable() && $this->helper->getWebTrackEnable()) {
            $this->writeFile('sw.js', $this->_dir);
        }
        return $data;
    }

    /**
     * BPN data fetch code from backend
     * @return mixed
     */
    public function addBpnPushJs()
    {
        $track = $this->getTrackDetails();
        if ($this->helper->getBpnTrackEnable()) {
            $data['bpn_sender_id'] = $this->helper->getBpnSenderId();
            $data['bpn_api_key']   = $this->helper->getBpnApiKey();
            return $data;
        }
    }

    /**
     * @description - Handle created to generate file
     * @param $fileName
     * @param $dir
     */
    public function writeFile($fileName, $dir)
    {
        if ($this->helper->getBpnTrackEnable() && $this->helper->getWebTrackEnable()) {
            $content  = $this->geterateBpnScriptFile();
            $filePath = "/".$fileName;
            /*if (file_exists($dir.'/'.$fileName)) {
                unlink($dir.$filePath);
            }*/
            $ioAdapter = $this->_file;
            try {
                $ioAdapter->open(['path' => $dir]);
                $ioAdapter->write($fileName, $content, 0644);
            } catch (Exception $e) {
                $this->helper->log("sw_write_error", print_r($e, 1));
            }
            return;
        }
    }

    /**
     * @description - function added to get generate the push notification script in the root
     * @return string
     */
    function geterateBpnScriptFile()
    {
        $bpnData['bpn_apiKey']    = $this->helper->getBpnApiKey();
        $bpnData['bpn_sender_id'] = $this->helper->getBpnSenderId();
        $bpnData['sm_web_id']     = $this->helper->getWebId();
        $bpnData['sm_site_id']    = $this->helper->getSiteId();
        $bpnData['app_id']        = $this->helper->getBpnAppId();
        $bpnData['project_id']    = $this->helper->getBpnProjectId();

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $idc_region = $this->scopeConfig->getValue("smartech/general/idc_region", $storeScope);
            
        switch ($idc_region) {
            case 'IN':
                $swURl    = $this->helper::NETCORE_JS_SERVICE_WORKER_IN;
                break;
            case 'US':
                $swURl    = $this->helper::NETCORE_JS_SERVICE_WORKER_US;
                break;
            case 'EU':
                $swURl    = $this->helper::NETCORE_JS_SERVICE_WORKER_EU;
                break;
            default:
                $swURl    = $this->helper::NETCORE_JS_SERVICE_WORKER_POD2;
        }

        /**
         * @todo need to change the SW endpoint per IDC.
         * CONST is defined as NETCORE_JS_SERVICE_WORKER_<<IDC>>
         *
         */
        $bpnData['includeScript'] = "importScripts('" . $swURl ."');";
        $script = "var config = {
            apiKey: '".$bpnData['bpn_apiKey']."',
            messagingSenderId: '".$bpnData['bpn_sender_id']."',
            appID: '". $bpnData['app_id'] ."',
            projectId: '". $bpnData['project_id'] ."',
            user_key: '".$bpnData['sm_web_id']."',
            siteid: '".$bpnData['sm_site_id']."',
        };".PHP_EOL.$bpnData['includeScript'];
        return $script;
    }
}
