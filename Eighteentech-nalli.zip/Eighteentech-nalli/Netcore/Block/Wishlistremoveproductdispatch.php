<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */

namespace Eighteentech\Netcore\Block;

class Wishlistremoveproductdispatch extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Catalog\Model\_urlInterface
     */
    protected $_urlInterface;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Csutomer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * Wishlistremoveproductdispatch constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Title $pageTitle
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Title $pageTitle,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    ) {
        $this->helper           = $helper;
        $this->_request         = $request;
        $this->_pageTitle       = $pageTitle;
        $this->_urlInterface    = $urlInterface;
        $this->_catalogSession  = $catalogSession;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->addData(['cache_lifetime' => false]);
        parent::__construct($context, $data);
    }
    /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Csutomer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }
    /**
     * @return \Magento\Checkout\Model\Session get chekout session for all
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * @return string when block call
     */
    public function executeWishlistRemoveJs()
    {
        $prod = '';
        $qty  = 1;
        $prod = $this->getCatalogSession()->getSmWRemoveProd();
        if ($prod) {
            if ($this->getCatalogSession()->getSmWRemoveQty()) {
                $qty = $this->getCatalogSession()->getSmWRemoveQty();
            }
            if ($this->getCatalogSession()->getSmWAddQty() >= 1) {
                // move cart items to wishlist
                $qty = $this->getCatalogSession()->getSmWAddQty();
            }
            $json = $this->helper->getCartJson($prod, '-', $qty);
            $str  = $this->helper->getScriptWishlistRemove($json);
            $this->getCatalogSession()->unsSmWRemoveProd();
            $this->getCatalogSession()->unsSmWRemoveQty();
            return sprintf($str);
        }
    }
}
