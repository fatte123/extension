<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Netcore 
 *
 */


namespace Eighteentech\Netcore\Block;

use Magento\Framework\App\Config\ScopeConfigInterface;

class Checkout extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlInterface;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    protected $_catalogSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;


    /**
     * Checkout constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Eighteentech\Netcore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\View\Page\Title $pageTitle
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\Netcore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\View\Page\Title $pageTitle,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        ScopeConfigInterface $scopeConfig,       
        array $data = []
    ) {
        $this->helper           = $helper;
        $this->_request         = $request;
        $this->_pageTitle       = $pageTitle;
        $this->_urlInterface    = $urlInterface;
        $this->_catalogSession  = $catalogSession;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->scopeConfig      = $scopeConfig;        
        $this->addData(['cache_lifetime' => false]);
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * @return \Magento\Catalog\Model\Session
     */
    public function getCatalogSession()
    {
        return $this->_catalogSession;
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }

    /**
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    /**
     * @return string
     */
    public function executeCheckoutJs()
    {
        // $this->helper->log("checkout", "checkout started");
        $quoteId = $this->getCheckoutSession()->getQuoteId();
        $data    = $this->helper->getCheckoutJson($quoteId);
        // $this->helper->log("checkout", "data = " . print_r($data, 1));
        //create json string for Javascript
        $jsScriptJSON     = $this->helper->getScriptCheckout(json_encode($data['data']));
        // $this->helper->log("checkout", "jsScriptJSON = " . $jsScriptJSON);

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        $idc_region = $this->scopeConfig->getValue("smartech/general/idc_region", $storeScope);
        $siteId     = $this->scopeConfig->getValue("smartech/general/site_tracking_id", $storeScope);
        $userKey    = $this->scopeConfig->getValue("smartech/general/web_tracking_id", $storeScope);

        $params['data'] = json_encode([[
            'asset_id' => $siteId,
            'activity_name' => 'checkout',
            "timestamp" => date("Y-m-d\TH:i:s.000\Z"),
            "activity_source" => "web",
            "identity" => $data['identity'],
            "activity_params" => $data['data']
        ]]);
        $params['request_type'] = "checkoutHook";

        // $this->helper->log("checkout", "params = " . print_r($params, 1));

        switch ($idc_region) {
            case 'IN':
                $postUrl    = sprintf($this->helper::NETCORE_CHECKOUT_HOOK_ENDPOINT_IN, $quoteId, 'checkout', $siteId, $userKey);
                break;
            case 'US':
                $postUrl    = sprintf($this->helper::NETCORE_CHECKOUT_HOOK_ENDPOINT_US, $quoteId, 'checkout', $siteId, $userKey);
                break;
            case 'EU':
                $postUrl    = sprintf($this->helper::NETCORE_CHECKOUT_HOOK_ENDPOINT_EU, $quoteId, 'checkout', $siteId, $userKey);
                break;
            default:
                $postUrl    = sprintf($this->helper::NETCORE_CHECKOUT_HOOK_ENDPOINT_POD2, $quoteId, 'checkout', $siteId, $userKey);
        }
        //Send data to netcore via web hook
        //$this->helper->log("checkout", "postUrl = " . $postUrl);
        //$this->helper->makeRequest('POST', $postUrl, $params);

        return sprintf($jsScriptJSON);
    }
    
    public function executePayNow()
    {
		$data = [];
		$data['totalamount']    = (float)number_format((float)$this->getCheckoutSession()->getQuote()->getGrandTotal(), 2, '.', '');
		$data['subtotal']    = (float)number_format((float)$this->getCheckoutSession()->getQuote()->getSubtotal(), 2, '.', '');
		$data['currency'] =  $this->helper->getStoreCurrency();
		return $data; 
	} 
	
    public function executeCartJs()
    {
        $quoteId ='';
        $quoteId = $this->getCheckoutSession()->getQuoteId();        
        if($quoteId){        
			$data = $this->helper->getCheckoutJson($quoteId);
			$jsScriptJSON     = $this->helper->getScriptViewCart(json_encode($data['data']));
			return sprintf($jsScriptJSON);
		}
		return true;       
        
    }
    	   
}
