# Magento 2 MultipleCartDelete  custom extension

This Extension is used forDelete Multiple Cart Itme's & Remove Custom options functionality on cart page.

## Features:

### Frontend
- show con caheckout/cart page
- Added to product attribute on etc/catalog_attributes.xml (color,material)


## Introduction installation:

### Install Magento 2 Hide Price Not Login
- Download file
- Unzip the file
- Create a folder [root]/app/code/Eighteentech/MultipleCartDelete
- Copy to folder

### Enable Extension

```
php bin/magento module:enable Eighteentech_MultipleCartDelete
php bin/magento setup:upgrade
php bin/magento cache:clean
php bin/magento setup:static-content:deploy
```


