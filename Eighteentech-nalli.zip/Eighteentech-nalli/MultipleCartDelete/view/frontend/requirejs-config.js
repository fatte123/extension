var config = {
    "map": {
        "*": {
            "MultipleCartDelete": "Eighteentech_MultipleCartDelete/js/MultipleCartDelete",
            CustomOptionsDelete: "Eighteentech_MultipleCartDelete/js/CustomOptionsDelete"
        } 
    }
};