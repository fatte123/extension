/**
 * CustomOptionsDelete JS
 *
 * @author 18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_MultipleCartDelete
 */
 define([
    'jquery','CustomOptionsDelete','Magento_Ui/js/modal/confirm'
], function ($, CustomOptionsDelete, confirmation) {
    'use strict';

    function main(config, element) {
        var $element = $(element);
        var AjaxUrl = config.AjaxUrl;
        $(document).ready(function(){
            $('.remove-custom-options').click(function() {
            var optionid = $(this).attr('data-optioid');
            var cartid = $(this).attr('data-item-id');
            confirmation({
                title: $.mage.__('Confirm'),
                content: $.mage.__('Are you sure, you want to delete this?'),
                actions: {
                    confirm: function() {
                        $.ajax({
                            type: "POST",
                            url: AjaxUrl,
                            data: {
                                'option_id': optionid,
                                'cartid': cartid
                            },
                            showLoader: true,
                            success: function(data) {
                                // alert("tetsttt" + data);
                                // $(".form-cart").submit();
                                if (data == '1') {
                                    setTimeout(function() {
                                        $('form#form-validate').submit();
                                        // $(".form-cart").submit();
                                    }, 3000);
                                }
                            },
                            error: function(data) {
                                $(".option-msg").html(data);
                            },
                        });
                    },
                    cancel: function() {
                        return false;
                    }
                }
            });
        });
        });
 
 
    };
    return main;
});