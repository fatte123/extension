<?php
/**
 * Cart UpdatePost Controller
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_MultipleCartDelete
 */
namespace Eighteentech\MultipleCartDelete\Controller\Cart;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\SerializerInterface;

class DeleteOption extends \Magento\Framework\App\Action\Action
{

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * [__construct]
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory,
     * @param \Magento\Framework\Registry $coreRegistry,
     * @param \Nalli\Countermaster\Helper\Data $countermasterHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        SerializerInterface $serializer = null,
        \Magento\Checkout\Model\Cart $cartItem,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        $this->_pageFactory = $pageFactory;
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(SerializerInterface::class);
        $this->cartItem = $cartItem;
        $this->messageManager = $messageManager;
        $this->resultJsonFactory = $resultJsonFactory;
        return parent::__construct($context);
    }
    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        $data = $this->getRequest()->getPost();
        $post_options = $data['option_id'];
        $cart = $this->cartItem;
        if (!empty($data['cartid']) && !empty($post_options)) {
            $item = $cart->getQuote()->getItemById($data['cartid']);
            $buyreqoptId = $this->serializer->unserialize($item->getOptionByCode('info_buyRequest')->getValue());
            $product = $item->getProduct();
            $option = $product->getOptionById($data['option_id']);
            $optionsName = $option->getTitle();
            if ($buyreqoptId && $post_options) {
                $buyreqoptId['options'][$post_options] = '';
                $option_Ids = explode(",", $item->getOptionByCode('option_ids')->getValue());
                if (($key = array_search($post_options, $option_Ids)) !== false) {
                    unset($option_Ids[$key]);
                }
                $optidnew = implode(",", $option_Ids);
                $item->getOptionByCode('info_buyRequest')->setValue($this->serializer->serialize($buyreqoptId));
                if ($optidnew) {
                    $item->getOptionByCode('option_ids')->setValue($optidnew);
                } else {
                    $item->removeOption('option_ids');
                }
                $item->removeOption('option_' .$post_options);
                $item->saveItemOptions();
                $cart->getQuote()->setTriggerRecollect(1);
                $cart->getQuote()->collectTotals();
                $cart->getQuote()->save();
                $this->messageManager->addSuccess($optionsName.' Option is deleted');
            // echo $message = __($optionsName.' Option is deleted');
                $data = 1;
                return $result->setData($data);
            } else {
                $this->messageManager->addError('Somehing went wrong');
                $data = 0;
                return $result->setData($data);
            }
        } else {
            $this->messageManager->addError('Somehing went wrong');
            $this->getResponse()->setRedirect("/checkout/cart/");
            $data = 0;
            return $result->setData($data);
        }
    }
}
