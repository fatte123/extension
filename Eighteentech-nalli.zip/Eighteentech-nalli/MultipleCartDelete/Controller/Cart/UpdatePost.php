<?php
/**
 * Cart UpdatePost Controller
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_MultipleCartDelete
 */
namespace Eighteentech\MultipleCartDelete\Controller\Cart;

use Magento\Checkout\Model\Cart\RequestQuantityProcessor;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;

class UpdatePost extends \Magento\Checkout\Controller\Cart\UpdatePost
{
	
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Checkout\Model\Cart $cart,
        RequestQuantityProcessor $quantityProcessor = null,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Quote\Model\Quote\Item $quoteItem,
        ProductRepositoryInterface $productRepository,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager        
    ) {
		$this->_catalogSession = $catalogSession;
		$this->quoteItem = $quoteItem;
		$this->productRepository     = $productRepository;
        $this->_cookieManager         = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager        = $sessionManager;		
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart,
            $quantityProcessor
        );
    }	

    /**
     * Update shopping cart data action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
         
        $updateAction = (string)$this->getRequest()->getParam('update_cart_action');        
        switch ($updateAction) {
			
             case 'delete_items':
                $multiDelete = $this->getRequest()->getParam('select_product');
				
                if (is_array($multiDelete)) {
                    if (count($multiDelete)) {
                        $cartProductIds = $this->cart->getQuoteProductIds();
                        /*if (count($cartProductIds) == count($multiDelete)) {
                            $this->_emptyShoppingCart();
                        } elseif (!empty($multiDelete)) {*/
                            $this->_removeCartItems($multiDelete);
							
                        //}
                    }
                }
                break; 
			case 'empty_cart':
                $this->_emptyShoppingCart();
                break;
			case 'update_qty':
                $this->_updateShoppingCart();
                break;	
            default:
               $this->_updateShoppingCart();
        }

        return $this->_goBack();
    }

    /**
     * @param $multiDelete
     */
    private function _removeCartItems($multiDelete)
    {
        try {
			$arrRemoveItem = [];
            foreach ($multiDelete as $_itemQuoteId) {
                if (!empty($_itemQuoteId)) {
					$this->getQuoteItemCatalogSession($_itemQuoteId);
                    $this->cart->removeItem($_itemQuoteId);
                    $this->cart->save();                   
                    
                }
            }
            
            $this->cart->getQuote()->setTriggerRecollect(1);
            $this->cart->getQuote()->collectTotals();
            $this->cart->getQuote()->save();
                    
        } catch (\Magento\Framework\Exception\LocalizedException $exception) {
            $this->messageManager->addError($exception->getMessage());
            $this->messageManager->addException($exception, __('We can\'t delete the shopping cart.'));
        }
    }
    
    public function getQuoteItemCatalogSession($id)
    {
        $itemData = $this->quoteItem->load($id);
        $this->_catalogSession->setCartRemove('remove');
        $qty = (int) $itemData->getQty();
        $this->_catalogSession->setCartRemoveQty($qty); 
        
        $qty = (int) $itemData->getQty();
        $productId     = $itemData->getProductId();
        $product = $this->getProductData($productId);
        if ($product->getData() != '') {
            $this->_catalogSession->setDeleteProd($product->getId());
            // Handled for ajax add to cart success thorugh custom js
            $cartAction = 'removetItemSidebar';
            if ($cartAction) {
                $publicCookieMetadata = $this->_cookieMetadataFactory->createPublicCookieMetadata()
                    ->setDuration(259200)
                    ->setPath($this->_sessionManager->getCookiePath())
                    ->setDomain($this->_sessionManager->getCookieDomain())
                    ->setHttpOnly(false);
                $json = $this->getCartJson($product->getId(), '-', $qty);
                $this->_cookieManager->setPublicCookie(
                    'SmRemoveCartJson',
                    $json,
                    $publicCookieMetadata
                );
                $this->_cookieManager->setPublicCookie(
                    'Addcartflag',
                    '',
                    $publicCookieMetadata
                );
                $this->_cookieManager->setPublicCookie(
                    'Removecartflag',
                    $cartAction,
                    $publicCookieMetadata
                );
            }
        }

    }
    
    public function getProductData($productId)
    {
        try {
            $product = $this->productRepository->getById($productId);
            return $product;
        } catch (\Exception $exception) {
            //echo $exception->getMessage(); exit;
            
        }
    }
     
	public function getCartJson($prodId, $type = '', $qty = 1)
    {
        $json = '';
        $product = $this->getProductData($prodId);
        $data['prid'] = $prodId;
        $data['name'] = $product->getName();
        $data['brand'] = '';
        $data['variant'] = '';
       
        $data['price'] = (float)number_format((float)$product->getPrice(), 2, '.', '');
        $data['final_price'] = (float)number_format((float)$product->getFinalPrice(), 2, '.', '');
        $data['prqt'] = $type . $qty;
        $data['sku'] = $product->getSku();
        $json = json_encode($data);
        return $json;
    }    
           
}
