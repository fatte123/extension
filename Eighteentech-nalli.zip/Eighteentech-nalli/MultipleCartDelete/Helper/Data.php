<?php
/**
 * Currency Block File
 *
 * @author 18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_MultipleCartDelete
 */
 
namespace Eighteentech\MultipleCartDelete\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /**
     * @var \Magento\Directory\Model\CurrencyFactory
     */
    protected $currencyFactory;
	
	/**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $StoreManagerInterface;
    
    /**
     * @param  \Magento\Directory\Model\CurrencyFactory
     */
    public function __construct(
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
		\Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
    ) {
        $this->currencyFactory = $currencyFactory;
		$this->storeManagerInterface = $StoreManagerInterface;
    }
    
    /*
     *@return currency symbol
     */
    public function getSymbol()
    {
		$currentCurrencyCode = $this->getCurrencyCode();
        $currency = $this->currencyFactory->create()->load($currentCurrencyCode);
        return $currencySymbol = $currency->getCurrencySymbol();
    }
    
    /*
     *@return currency code
     */
    public function getCurrencyCode()
    {
      $currencyCode = $this->storeManagerInterface->getStore()->getCurrentCurrency();
	  return$currencyCode->getCurrencyCode(); 
    }
}
