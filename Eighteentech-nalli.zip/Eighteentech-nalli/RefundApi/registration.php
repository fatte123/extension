<?php
/**
 * Module registration file
 *
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_RefundApi
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Eighteentech_RefundApi',
    __DIR__
);
