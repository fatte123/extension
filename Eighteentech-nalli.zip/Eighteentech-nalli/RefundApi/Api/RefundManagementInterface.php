<?php
/**
 * Module Interface file
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <info@18thdigitech.com>
 * @package Eighteentech_RefundApi
 */
namespace Eighteentech\RefundApi\Api;

interface RefundManagementInterface
{
    /**
     * GET for Post api
     * @param array $data
     * @return rest/V1/orderRefundApi/ output
     */
    public function getRefundback();
}
