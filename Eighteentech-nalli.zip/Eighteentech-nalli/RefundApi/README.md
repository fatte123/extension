# Eighteentech_RefundApi

This module creates credit memo for orders using api.

## INSTALLATION
In magento root directory, execute:

```bash
php bin/magento module:enable Eighteentech_RefundApi
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Usage

Api Url - Base url/rest/V1/orderRefundApi
Method - POST
Data required example - 
{
    "orders": [
        {
            "order_id": "2000xxxx",
            "refund_shipping": 20,
            "adjustment_positive": 10,
            "adjustment_negative": 5,
            "send_email": true,
            "comment": "test2 comment from API 2000xxxx",
            "returnItems": [
                {
                    "sku": "NS34xxxxx",
                    "qty_requested": "1",
                    "return_to_stock": true
                }
            ]
        }
    ]
}
