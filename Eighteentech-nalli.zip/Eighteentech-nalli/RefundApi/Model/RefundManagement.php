<?php
/**
 * Model file
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <info@18thdigitech.com>
 * @package Eighteentech_RefundApi
 */
namespace Eighteentech\RefundApi\Model;

use Eighteentech\RefundApi\Api\RefundManagementInterface;
use Magento\Sales\Api\CreditmemoManagementInterface;

/**
 * Model class RefundManagement
 */
class RefundManagement implements RefundManagementInterface
{
    /**
     * @var Psr\Log\LoggerInterface
     */
    protected $logger;
    
    /**
     * @var \Magento\Framework\Webapi\Rest\Request
     */
    protected $request;

    /**
     * @var  \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender
     */
    protected $creditmemoSender;
    
    /**
     * @var  \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader
     */
    protected $creditmemoLoader;
    
    /**
     * @var  \Magento\Sales\Api\Data\OrderInterface
     */
    protected $orderRepository;
   
    /**
     * @var \Magento\Framework\Registry|null
     */
    protected $registry = null;

    /**
     * Constructor
     *
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Webapi\Rest\Request $request
     * @param \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender $creditmemoSender
     * @param \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader $creditmemoLoader
     * @param \Magento\Sales\Api\Data\OrderInterface $orderRepository
     * @param \Magento\Framework\Registry $registry
     * @param creditmemoManagement $creditmemoManagement
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Webapi\Rest\Request $request,
        \Magento\Sales\Model\Order\Email\Sender\CreditmemoSender $creditmemoSender,
        \Magento\Sales\Controller\Adminhtml\Order\CreditmemoLoader $creditmemoLoader,
        \Magento\Sales\Api\Data\OrderInterface $orderRepository,
        \Magento\Framework\Registry $registry,
        CreditmemoManagementInterface $creditmemoManagement
    ) {
        $this->logger= $logger;
        $this->request = $request;
        $this->_objectManager = $objectManager;
        $this->creditmemoSender = $creditmemoSender;
        $this->creditmemoLoader = $creditmemoLoader;
        $this->orderRepository = $orderRepository;
        $this->registry = $registry;
        $this->creditmemoManagement  = $creditmemoManagement;
    }

    /**
     * Get order Details and itme details for credit memo
     */
    public function getRefundback()
    {
        $data = $this->request->getBodyParams();
       
       /*
        *$response set arrya for Api response
       */
        $response = [];
       
       /*
       *@$data Associative array
       */
        foreach ($data['orders'] as $orders) {
            /*
             *@$orderId for json data
            */
            $orderId = $orders['order_id'];
           
            /*
             *@$orderComment for json data
            */
            $orderComment = $orders['comment'];
           
            /*
             *@$ordergetting order detail using increment id
            */
            $order = $this->orderRepository->loadByIncrementId($orderId);
                   
            /*
             *@$refund_shipping shipping detail from json string
            */
            if (isset($orders['refund_shipping'])) {
                 $shippingAmount = $orders['refund_shipping'];
            } else {
                $shippingAmount = 0;
            }
            
            /*
             *@$adjustment_positive shipping detail from json string
            */
            if (isset($orders['adjustment_positive'])) {
                $positiveAmount = $orders['adjustment_positive'];
            } else {
                $positiveAmount = 0;
            }
            
            /*
             *@$adjustment_negative shipping detail from json string
            */
            if (isset($orders['adjustment_negative'])) {
                 $negativeAmount = $orders['adjustment_negative'];
            } else {
                $negativeAmount = 0;
            }
            
            /*
             *@$send_email Check  true false value
            */
            if (isset($orders['send_email'])) {
                $sendEmail = 1;
            } else {
                $sendEmail = 0;
            }
            
            /*
             *$creditMemoData =array() store credit memo data
            */
            $creditMemoData = [];
            $creditMemoData['do_offline'] = 1;
            $creditMemoData['shipping_amount'] = $shippingAmount;
            $creditMemoData['adjustment_positive'] = $positiveAmount;
            $creditMemoData['adjustment_negative'] = $negativeAmount;
            $creditMemoData['comment_text'] = $orderComment;
            $creditMemoData['send_email'] = $sendEmail;
           
            try {
                 //check order is not empty
                if (!empty($order->getData())) {
          
                  //check invoice is created or not
                    if ($order->hasInvoices()) {
          
                         //check can credit memo
                        if ($order->canCreditmemo()) {
                    
                            /*
                            *@items sku for returnItems json
                            */
                            $item = [];
                            foreach ($orders['returnItems'] as $returnItem) {
                                $item[] = $returnItem['sku'];
                                $itmeqty[$returnItem['sku']] = $returnItem['qty_requested'];
                                 $itemReturnToStock[$returnItem['sku']] = $returnItem['return_to_stock'];
                            }
                 
                         /*
                         *@item sku from ordered item
                         */
                            $item_data = [];
                            foreach ($order->getAllVisibleItems() as $items) {
                                 $item_data[] = $items->getSku();
                            }
                 
                         /*
                         *@array_intersect handles duplicate items in arrays differently
                         */
                            $result = array_intersect($item_data, $item);
                            $count=0;
                            foreach ($order->getAllVisibleItems() as $items) {
                               /*
                               *@getting ordered item id from sku
                               */
                                if (in_array($items->getSku(), $result)) {
                                     ++$count;
                                    
                                      /*
                                       *@get qty from  returnItems json
                                       */
                                      $qty = $itmeqty[$items->getSku()];
                                      $qtyitemReturnToStock = $itemReturnToStock[$items->getSku()];
                                      $orderItemId = $items->getItemId();
                                       /*
                                       *check return_to_stock form returnItems
                                       */
                                    if ($qtyitemReturnToStock) {
                                        $itemToCredit[$orderItemId] = ['qty'=>$qty,'back_to_stock'=>1];
                                    } else {
                                        $itemToCredit[$orderItemId] = ['qty'=>$qty];
                                    }
                                    $creditMemoData['items'] = $itemToCredit;
                                }//if end
                                
                            }// foreach loop end

                            //check product count
                            if ($count!=0) {
                                $this->creditmemoLoader->setOrderId($order->getId()); //pass order id
                                $this->creditmemoLoader->setCreditmemo($creditMemoData);
                                $creditmemo = $this->creditmemoLoader->load();
                                if ($creditmemo) {
                                    if (!$creditmemo->isValidGrandTotal()) {
                                        throw new \Magento\Framework\Exception\LocalizedException(
                                            __('The credit memo\'s total must be positive.')
                                        );
                                    }
                                    if (!empty($creditMemoData['comment_text'])) {
                                         $creditmemo->addComment(
                                             $creditMemoData['comment_text'],
                                             isset($creditMemoData['comment_customer_notify']),
                                             isset($creditMemoData['is_visible_on_front'])
                                         );
                                         $creditmemo->setCustomerNote($creditMemoData['comment_text']);
                                         $creditmemo->setCustomerNoteNotify(isset(
                                             $creditMemoData['comment_customer_notify']
                                         ));
                                    }
                                     $creditmemoManagement = $this->creditmemoManagement;
                                    $creditmemo->getOrder()->setCustomerNoteNotify(!empty(
                                        $creditMemoData['send_email']
                                    ));
                                    $creditmemoManagement->refund($creditmemo, (bool)$creditMemoData['do_offline']);
                                    if (!empty($creditMemoData['send_email'])) {
                                             $this->creditmemoSender->send($creditmemo);
                                    }
                                     $currentCreditMemo = $this->registry->registry('current_creditmemo');
                                     $response[] = ['success'=>true,
                                         'message'=> "Credit memo created successfully",
                                         'order_id'=> $orderId,
                                         'credit_memo_id'=> $currentCreditMemo->getIncrementId()
                                      ];
                                    /*
                                      *unset the current_creditmemo registry
                                     */
                                     if ($this->registry->registry('current_creditmemo')) {
                                         $this->registry->unregister('current_creditmemo');
                                     }
                                   //if credit memo not created
                                } else {
                                    $response[] = [
                                       'success'=> false,
                                       'message'=>__("Failed to create credit memo"),
                                       'order_id'=>$orderId
                                    ];
                                }
                  
                                /*
                              *check product count
                             */
                            } else {
                                $response[] = [
                                    'success' => false,
                                    'message' =>__("No product sku match"),
                                    'order_id'=> $orderId
                                ];
                            }
                          /*
                           *check credit memo created or not
                           */
                        } else {
                            $response [] = [
                               'success' => false,
                               'message' =>__('Credit memo already created'),
                               'order_id'=> $orderId
                            ];
                        }
                    /*
                     *check invoice created or not
                     */
                    } else {
                        $response [] = [
                          'success' => false,
                          'message' =>__('Invoice not created'),
                          'order_id'=> $orderId
                        ];
                    }
                    //check order is is valid
                } else {
                    $response [] = [
                        'success' => false,
                        'message' =>__('Invalid order id'),
                        'order_id'=> $orderId
                    ];
                }
            
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $response[] = [
                  'success' => false,
                  'message' =>__("Failed to create credit memo ".$e->getMessage()),
                  'order_id'=> $orderId
                ];
                $this->logger->info('Error message', ['exception'=>$e->getMessage()]);
           
            } catch (\Exception $e) {
                $response[] = [
                    'success' => false,
                    'message' => $e->getMessage(),
                    'order_id'=> $orderId
                ];
                $this->logger->critical('Error message', ['exception' =>__(
                    "Failed to create creditmemo ".$e->getMessage()
                )]);
            }
        }
        
        return $response;
    }
}
