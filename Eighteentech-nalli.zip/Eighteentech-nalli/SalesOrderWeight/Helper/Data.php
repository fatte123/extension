<?php
/**
 * SalesOrderWeight
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author: <mailto:info@18thdigitech.com>
 * @package Eighteentech_SalesOrderWeight
 */

namespace Eighteentech\SalesOrderWeight\Helper;

use \Magento\Framework\App\Helper\AbstractHelper as AbstractHelper;

class Data extends AbstractHelper
{
    /*
	 *@var \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
	 */    
    private $productRepository;
	
	/*
	 *@var \Psr\Log\LoggerInterface $logger
	 */
	private $logger;

    public function __construct(
       \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
	   \Psr\Log\LoggerInterface $logger
    ) {
	   $this->productRepository = $productRepository;
	   $this->logger = $logger;
    }

    public function loadMyProduct($sku)
    {
	  $product = NULL;
	  try {
      $product =  $this->productRepository->get($sku);
	  } catch (\Exception $e) {
       $this->logger->critical($e->getMessage());
   	  }
	 return $product;
    }
}
