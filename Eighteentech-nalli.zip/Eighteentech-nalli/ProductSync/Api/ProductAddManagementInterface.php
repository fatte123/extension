<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_ProductSync
 * @author     https://www.18thdigitech.com/
 */

namespace Eighteentech\ProductSync\Api;

interface ProductAddManagementInterface
{
    /**
     * Updates the specified products in item array.
     *
     * @api
     * @param mixed $data
     * @return boolean
     */
    public function addProduct();
}
