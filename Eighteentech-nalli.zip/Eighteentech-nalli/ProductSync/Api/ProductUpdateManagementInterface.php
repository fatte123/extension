<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_ProductSync
 * @author     https://www.18thdigitech.com/
 */

namespace Eighteentech\ProductSync\Api;

interface ProductUpdateManagementInterface
{
    /**
     * Updates the specified products in item array.
     *
     * @api
     * @param mixed $data
     * @return boolean
     */
    public function updateProduct();
}
