<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_ProductSync
 * @author     https://www.18thdigitech.com/
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Eighteentech_ProductSync',
    __DIR__
);
