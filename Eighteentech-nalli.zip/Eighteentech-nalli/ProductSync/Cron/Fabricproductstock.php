<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_ProductSync
 */

namespace Eighteentech\ProductSync\Cron;

use Exception;
use Psr\Log\LoggerInterface;

class Fabricproductstock
{
	protected $_pageFactory;
    protected $_productRepository;
    protected $_searchCriteriaBuilder;
    protected $_logger;

	public function __construct(
        LoggerInterface $logger,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\Api\Search\FilterGroupBuilder $filterGroupBuilder,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry)
	{   
        $this->logger = $logger;
        $this->_productRepository = $productRepository;
        $this->_searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->stockRegistry = $stockRegistry;
	}

	public function execute()
	{
        try {
            $filter_1 = $this->filterBuilder
                ->setField('category_name')
                ->setConditionType('eq')
                ->setValue('Fabric')
                ->create();

            $filter_2 = $this->filterBuilder
                ->setField('category_name')
                ->setConditionType('eq')
                ->setValue(strtolower("Fabric"))
                ->create();

            $filter_group = $this->filterGroupBuilder
                ->addFilter($filter_1)
                ->addFilter($filter_2)
                ->create();
            $searchCriteria = $this->_searchCriteriaBuilder->setFilterGroups([$filter_group])->create();
            $searchResults = $this->_productRepository->getList($searchCriteria);
            $products = $searchResults->getItems();
            foreach($products as $product) {
                $productId = $product->getId();
                if($productId){
                    $stockItem = $this->stockRegistry->getStockItem($productId);
                    $IsInStock = $stockItem ? $stockItem->getIsInStock() : false;
                    if($IsInStock){
                        $stockQty = $stockItem->getQty();
                        if($stockQty < (float)1.5){
                            $stockItem->setData('is_in_stock',false);
                            $stockItem->save();
                            $this->logger->info($productId." Stock updated !");
                        }
                    }
                }
            }
        }
        catch (Exception $e) {
            $this->logger->critical($e);
        }
        
        return $this;
	}
}