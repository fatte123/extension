<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_ProductSync
 * @author     https://www.18thdigitech.com/
 */

namespace Eighteentech\ProductSync\Model;

use Eighteentech\ProductSync\Api\ProductAddManagementInterface as ProductApiInterface;
use Magento\ImportExport\Model\Import;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

class ProductAddManagement implements ProductApiInterface
{
   /**
    * Column product category.
    */
    const COL_CATEGORY = 'categories';
    
   /**
    * Column ATTR_DEFAULT
    */
    const ATTR_DEFAULT = [
        'sku',
        'status',
        'categories',
        'qty',
        'is_in_stock',
        'price',
        'store_view_code',
        'attribute_set_code',
        'product_type',
        'product_websites',
        'weight',
        'name',
        'visibility',
        'tax_class_name',
        'product_online',
        'custom_layout_update',
        'config_attributes',
        'meter'
    ];
    
    /**
     * Column ATTR_IMAGE
     */
    const ATTR_IMAGE = [
        'image',
        'small_image',
        'thumbnail',
        'pleats_pallu',
        'blouse_closeup',
        'pallu_body',
        'crumbled_shot',
        'border_shot',
        'dhoti_image_1',
        'dhoti_image_2',
        'dhoti_image_3'
    ];

    /**
     * @var Product\CategoryProcessor
     */
    protected $categoryProcessor;
    
     /**
      * @var Magento\Catalog\Api\CategoryLinkManagementInterface
      */
    protected $CategoryLinkManagementInterface;
    
    /**
     * @var Magento\Catalog\Model\CategoryLinkRepository
     */
    protected $CategoryLinkRepository;
    
    /**
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $stockState;
    
    /**
     * @var Magento\Catalog\Model\ResourceModel\Product\Action
     */
    protected $Action;
    
    /**
     * @var Magento\Store\Model\StoreManagerInterface
     */
    protected $StoreManagerInterface;
    
     /**
      * @var \Magento\Eav\Model\AttributeRepository
      */
    protected $attributeRepository;
    
    /**
     * @var \Magento\Eav\Api\AttributeOptionManagementInterface
     */
    protected $attributeOptionManagement;
    
    /**
     * @var \Magento\Eav\Api\Data\AttributeOptionLabelInterface
     */
    protected $attributeOptionLabel;
    
    /**
     * @var \Magento\Eav\Api\Data\AttributeOptionInterface
     */
    protected $option;
    
    /**
     * @var \Magento\Framework\Webapi\Rest\Request
     */
     protected $request;
     
    /**
     * @var \Magento\Catalog\Api\ProductMediaAttributeManagementInterface
     */
     protected $ProductMediaAttributeManagementInterface;
     
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeCode
     */
     protected $attributeCode;
    
    /**
     * @var ResourceConnection
     */
     protected $resourceConnection;
     
    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $_productloader;
    
    /**
     * @var Magento\Framework\Filesystem\DirectoryList;
     */
     protected $_dir;

    /**
     * @var Magento\Framework\Filesystem\Io\File;
     */
     private $file;
    /**
     * @param Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param Product\CategoryProcessor $categoryProcessor
     * @param Magento\Catalog\Api\CategoryLinkManagementInterface
     * @param Magento\Catalog\Model\CategoryLinkRepository
     * @param Magento\CatalogInventory\Api\StockStateInterface $stockState
     * @param Magento\Catalog\Model\ResourceModel\Product\Action $Action
     * @param Magento\Store\Model\StoreManagerInterface $StoreManagerInterface
     * @param Magento\Eav\Model\AttributeRepository $attributeRepository
     * @param Magento\Eav\Api\AttributeOptionManagementInterface $attributeOptionManagement
     * @param Magento\Eav\Api\Data\AttributeOptionLabelInterface $attributeOptionLabel
     * @param Magento\Eav\Api\Data\AttributeOptionInterface $option
     * @param Magento\Framework\Webapi\Rest\Request $request
     * @param Magento\Catalog\Api\ProductMediaAttributeManagementInterface $ProductMediaAttributeManagementInterface
     * @param Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeCode
     * @param Magento\Catalog\Model\Product $Product
     * @param ResourceConnection $resourceConnection
     * @param Psr\Log\LoggerInterface
     */
     
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        Product\CategoryProcessor $categoryProcessor,
        \Magento\Catalog\Api\CategoryLinkManagementInterface $CategoryLinkManagementInterface,
        \Magento\Catalog\Model\CategoryLinkRepository $CategoryLinkRepository,
        \Magento\CatalogInventory\Api\StockStateInterface $stockState,
        \Magento\Catalog\Model\ResourceModel\Product\Action $Action,
        \Magento\Store\Model\StoreManagerInterface $StoreManagerInterface,
        \Magento\Eav\Model\AttributeRepository $attributeRepository,
        \Magento\Eav\Api\AttributeOptionManagementInterface $attributeOptionManagement,
        \Magento\Eav\Api\Data\AttributeOptionLabelInterface $attributeOptionLabel,
        \Magento\Eav\Api\Data\AttributeOptionInterface $option,
        \Magento\Framework\Webapi\Rest\Request $request,
        \Magento\Catalog\Api\ProductMediaAttributeManagementInterface $ProductMediaAttributeManagementInterface,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\CollectionFactory $attrOptionCollectionFactory,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\Catalog\Model\Product $Product,
        ResourceConnection $resourceConnection,
        DirectoryList $dir,
        File $file,
        \Eighteentech\ProductSync\Logger\Logger $logger
    ) {
        $this->productRepository = $productRepository;
        $this->categoryProcessor = $categoryProcessor;
        $this->CategoryLinkManagementInterface = $CategoryLinkManagementInterface;
        $this->CategoryLinkRepository = $CategoryLinkRepository;
        $this->stockState = $stockState;
        $this->action = $Action;
        $this->storeManagerInterface = $StoreManagerInterface;
        $this->attributeRepository = $attributeRepository;
        $this->attributeOptionManagement = $attributeOptionManagement;
        $this->attributeOptionLabel = $attributeOptionLabel;
        $this->option = $option;
        $this->mediaAttribute = $ProductMediaAttributeManagementInterface;
        $this->request = $request;
        $this->eavConfig = $eavConfig;
        $this->attrOptionCollectionFactory = $attrOptionCollectionFactory;
        $this->_productloader  = $_productloader;
        $this->_product = $Product;
        $this->_product = $Product;
        $this->resourceConnection = $resourceConnection;
        $this->_dir = $dir;
        $this->file = $file;
        $this->logger = $logger;
    }

    /**
     * Updates the specified product from the request payload.
     *
     * @api
     * @param mixed $products
     * @return boolean
     */
     
    public function addProduct()
    {
        $products = $this->request->getBodyParams();
       /*
        *$response set arrya for Api response
        */
        $response = [];
        $storeId = 0;
        if (!empty($products)) {
            foreach ($products as $product) {
                $sku = trim($product['sku']);
                $this->logger->info($sku.' -- Synchronize  Start-- ');
                $productObject = $this->getProduct($sku);
                if ($productObject) {
                    $response[] = [
                            'success' => false,
                            'message' => "Sku already exists",
                            'sku' => $product['sku'],
                            'id' => $productObject->getId()
                        ];
                
                } else {
                
                    $productId = $this->saveDefaultAttribute($product);
                    if ($productId) {
                            
                        $this->logger->info($sku.' -- Synchronize  End-- ');
                        $this->addProductAttribute($product, $productId);
                        /*
                         *Update image attribute
                         */
                        $data = $this->productImageUpload($product, $productId);
                        //$response[] =['data' => $data];
                        $response[] = [
                                'success' => true,
                                "message" => "product created successfully",
                                'sku' => $sku,
                                'id' => $productId
                            ];
                    } else {
                        $response[] = [
                               'success' =>false,
                               "message" => "something went wrong",
                               "sku" => $sku
                            ];
                    }
                }
            } //foreach ends
            
        } else {
            $response[] = [
                            'success' =>false,
                              "message" => "empty value not allowed"
                          ];
        }
        return $response;
    }
    
    public function saveDefaultAttribute($product)
    {
            
        try {
            $_productObj = $this->_productloader->create();
            $productId =null;
            $productInsert = null;
            $productObject = null;
            /* set current store global */
            $storeId = 0;
            $store = $this->storeManagerInterface->getStore($storeId);
            $this->storeManagerInterface->setCurrentStore($store->getCode());
                        
            $sku = trim($product['sku']);
            $name = trim($product['name']);
            $visibility = trim($product['visibility']);
            $weight = trim($product['weight']);
            $product_online = trim($product['product_online']);
            $price = trim($product['price']);
            
            $_productObj->setName($name);
            $_productObj->setAttributeSetId(4);
            $_productObj->setSku($sku);
            $_productObj->setTypeId('simple');
            // type of product (simple/virtual/downloadable/configurable)
            $visibilityId = $this->addvisibility($visibility);
            $_productObj->setVisibility($visibilityId);
            // visibilty of product (catalog / search / catalog, search / Not visible individually)
            $_productObj->setWeight($weight);
            if (($product_online==1)) {
                $code = 1;
            } else {
                $code = 0;
            }
            $_productObj->setStatus($code);  //Status on product enabled/ disabled 1/0
            $_productObj->setPrice($price);
            $url_key = isset($product['url_key']) ? trim($product['url_key']) : "";
            $url = trim($url_key);
            if (!empty($url)) {
                $_productObj->setUrlKey($url);
            } else {
                $physical_store_code = isset($product['physical_store_code'])
                ? trim($product['physical_store_code'])
                : "";
                $physicalStoreCode = trim($physical_store_code);
                if (!empty($physicalStoreCode)) {
                    $product_url_key = strtolower($name.'-'.$sku.'-'.$physicalStoreCode);
                } else {
                    $product_url_key = strtolower($name.'-'.$sku);
                }
                $product_url_key = $this->createSlug($product_url_key);
                $_productObj->setUrlKey($product_url_key);
            }
            $_productObj->setTaxClassId(0);
            $_productObj->setStockData([
                            'manage_stock' => 1,
                            'is_in_stock' => 1,
                            'qty' => $product['qty']
                        ]);
            $_productObj->setStoreId(0);
            $_productObj->setWebsiteIds([1]);
            $productInsert = $_productObj->save();
            $productId = $_productObj->getId();
            
            $this->logger->info($sku.' -- Product-id='.$productId.' -- created');
            
            foreach ($product as $key => $_product) {
                $attributeCode = trim($key);
                $attributeValue = trim($_product);
                if ($attributeCode == 'categories' && ($attributeValue!="")) {
                    $this->addCategory($product);
                }
            }
            return $productId;
           /*return  $this->getProduct($sku);*/
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage().' -- Getting error on saveDefaultAttribute-- ');
            return false;
        }
    }
    
    public function productImageUpload($product, $productId)
    {
            $_productObj = $this->getProductsByid($productId);
            $sku = trim($product['sku']);
            $image = isset($product['image']) ? trim($product['image']) : "";
            $small_image = isset($product['small_image']) ? trim($product['small_image']) : "";
            $thumbnail = isset($product['thumbnail']) ? trim($product['thumbnail']) : "";
            $pleats_pallu = isset($product['pleats_pallu']) ? trim($product['pleats_pallu']) : "";
            $blouse_closeup = isset($product['blouse_closeup']) ? trim($product['blouse_closeup']) : "";
            $pallu_body = isset($product['pallu_body']) ? trim($product['pallu_body']) : "";
            $crumbled_shot = isset($product['crumbled_shot']) ? trim($product['crumbled_shot']) : "";
            $border_shot = isset($product['border_shot']) ? trim($product['border_shot']) : "";
            $dhoti_image_1 = isset($product['dhoti_image_1']) ? trim($product['dhoti_image_1']) : "";
            $dhoti_image_2 = isset($product['dhoti_image_2']) ? trim($product['dhoti_image_2']) : "";
            $dhoti_image_3 = isset($product['dhoti_image_3']) ? trim($product['dhoti_image_3']) : "";
            $array = [
                        'image' => $image,
                        'small_image' => $small_image,
                        'thumbnail' => $thumbnail,
                        'pleats_pallu' => $pleats_pallu,
                        'blouse_closeup' => $blouse_closeup,
                        'pallu_body' => $pallu_body,
                        'crumbled_shot' => $crumbled_shot,
                        'border_shot' => $border_shot,
                        'dhoti_image_1' => $dhoti_image_1,
                        'dhoti_image_2' => $dhoti_image_2,
                        'dhoti_image_3' => $dhoti_image_3
                      ];
            $ptr = array_unique(array_values(array_filter($array)));
            try {
                foreach ($ptr as $row) {
                    $imageKey = array_keys($array, $row);
                    $attributeValue = $array[$imageKey[0]];
                    $checkImage = $this->getImportImageFilepath($attributeValue);
                    
                    if ($this->file->fileExists($checkImage)) {
                        /** @var string $tmpDir */
                    
                        $tmpDir = $this->getMediaDirTmpDir();
                        /** create folder if it is not exists */
                        $this->file->checkAndCreateFolder($tmpDir);
                        /** @var string $newFileName */
                        $basename = $this->getBaseName($checkImage);
                         $newFileName = $tmpDir .'/'. $basename;
                        
                        /** read file from URL and copy it to the new destination */
                        $result = $this->file->read($checkImage, $newFileName);
                        $uploadImage = $this->uploadImage($_productObj, $imageKey, $attributeValue, $checkImage);
                        if ($uploadImage['imagePath']!="") {
                            try {
                                if ($result) {
                                    $_productObj->addImageToMediaGallery($newFileName, $imageKey, false, false);
                                    $_productObj->save();
                                    $this->logger->info('-- Image Added on '.$_productObj->getSku().'--');
                                }
                            } catch (\Exception $e) {
                                $this->logger->info(
                                    $e->getMessage().' -- Getting error on addImageToMediaGallery '.
                                    $_productObj->getSku().'--'
                                );
                            }
                        }
                    } else {
                        $this->logger->info($sku.' image -- '.$attributeValue.'-- not exits');
                    }
                }//foreach end
            } catch (\Exception $e) {
                $this->logger->info($e->getMessage().' -- Getting error on productImageUpload-- ');
            }
    }
   
    public function addProductAttribute($product, $productId)
    {
        $storeId = 0;
        try {
            $sku = trim($product['sku']);
            foreach ($product as $key => $_product) {
                $attributeCode = trim($key);
                $attributeValue = trim($_product);
                if ((!in_array($attributeCode, self::ATTR_DEFAULT)) && (!in_array($attributeCode, self::ATTR_IMAGE))) {
                    $attributeDetail = $this->getAttributeDetail($attributeCode);
                 /*
                 *update all default attributes
                  */
                    if (!empty($attributeDetail)) {
                        if ($attributeDetail['is_user_defined']==0) {
                            if ($attributeDetail['frontend_input']==='text') {
                                $updateAttributes[$attributeCode] = $attributeValue;
                            }
                            if ($attributeDetail['frontend_input']==='textarea') {
                                $updateAttributes[$attributeCode] = $attributeValue;
                            }
                            /*for boolean*/
                            if ($attributeDetail['frontend_input']==='boolean') {
                                if ($attributeValue=='Yes') {
                                    $code = 1;
                                } else {
                                    $code = 0;
                                }
                                $updateAttributes[$attributeCode]=$code;
                            }
                        }
                        /*
                     * update all custom attributes
                      */
                        if ($attributeDetail['is_user_defined']==1) {
                         /*for multiselect*/
                            if (($attributeDetail['frontend_input']==='multiselect') && ($attributeValue!="")) {
                                $value=[];
                                $attributeValue = explode("|", $attributeValue);
                                foreach ($attributeValue as $attribute) {
                                    $Data = $this->getOrCreateAttributeOption($sku, $attributeCode, $attribute);
                                    if (isset($Data['option_obj']) && !empty($Data['option_obj'])) {
                                          $value[] = $Data['option_obj']->getValue();
                                    }
                                }
                                   //convert array to string ex:4,6,8
                                   $multiValue = implode(",", $value);
                                if (!empty($multiValue)) {
                                    $updateAttributes[$attributeCode] = $multiValue;
                                }
                            }
                            /*for boolean*/
                            if (($attributeDetail['frontend_input']==='boolean') && ($attributeValue!="")) {
                            
                                if ($attributeValue=='Yes') {
                                    $code = 1;
                                } else {
                                    $code = 0;
                                }
                                $updateAttributes[$attributeCode]=$code;
                                //for internation update code
                                if (($attributeCode=='international') && ($attributeValue!="")) {
                                    $this->updateInternational([$productId], $attributeValue, $storeId);
                                }
                                if (($attributeCode=='has_physicalstorecode') && ($attributeValue!="")) {
                                    if ($attributeValue == 1 || $attributeValue == 'Yes') {
                                        $code = 1;
                                    } else {
                                        $code = 0;
                                    }
                                    $updateAttributes[$attributeCode]=$attributeValue;
                                }
                            }
                            /*for select*/
                            if (($attributeDetail['frontend_input']==='select')
                            && ($attributeValue!="")) {
                                if ($attributeCode == 'color') {
                                    $primarycolor1 = $product['primarycolor1'];
                                    $Data = $this->getOrCreateColorAttributeOption(
                                        $sku,
                                        $attributeCode,
                                        $attributeValue,
                                        $primarycolor1
                                    );
                                } else {
                                    $Data = $this->getOrCreateAttributeOption($sku, $attributeCode, $attributeValue);
                                }
                                if (isset($Data['option_obj']) && !empty($Data['option_obj'])) {
                                    $value = $Data['option_obj']->getValue();
                                    if (!empty($value)) {
                                        if ($attributeCode == 'blouse') {
                                            if ($product['category_name'] == 'Saree') {
                                                $updateAttributes[$attributeCode] = $value;
                                            }
                                        }
                                        if ($attributeCode == 'angavastram_matching') {
                                            if ($product['category_name'] == 'Dhoti') {
                                                $updateAttributes[$attributeCode] = $value;
                                            }
                                        }
                                        if ($attributeCode == 'blouse_lenth') {
                                            if ($product['category_name'] == 'Saree') {
                                                $updateAttributes[$attributeCode] = $value;
                                            }
                                        } else {
                                            $updateAttributes[$attributeCode] = $value;
                                        }
                                    }
                                }
                            }
                            /*for textarea*/
                            if (($attributeDetail['frontend_input']==='textarea') && ($attributeValue!="")) {
                                $updateAttributes[$attributeCode] = $attributeValue;
                            }
                                /*for text*/
                            if (($attributeDetail['frontend_input']==='text') && ($attributeValue!="")) {
                                if ($attributeCode == 'blouse_color') {
                                    if ($product['category_name'] == 'Saree') {
                                        $updateAttributes[$attributeCode] = $attributeValue;
                                    }
                                }
                                if ($attributeCode == 'angavastram_length') {
                                    if ($product['category_name'] == 'Dhoti') {
                                        $updateAttributes[$attributeCode] = $attributeValue;
                                    }
                                }
                                if ($attributeCode == 'angavastram_color') {
                                    if ($product['category_name'] == 'Dhoti') {
                                        $updateAttributes[$attributeCode] = $attributeValue;
                                    }
                                }
                                if ($attributeCode == 'dhoti_length') {
                                    if ($product['category_name'] == 'Dhoti') {
                                        $updateAttributes[$attributeCode] = $attributeValue;
                                    }
                                } else {
                                       $updateAttributes[$attributeCode] = $attributeValue;
                                }
                            }
                        }
                    }
                }
            }
            //adding options_container
            $updateAttributes['options_container'] = "container2";
            if (!empty($updateAttributes)) {
                $this->action->updateAttributes([$productId], $updateAttributes, $storeId);
                $this->logger->info($sku.'-- addProductAttribute run successfully -- ');
            }
            
        } catch (\Exception $e) {
             $this->logger->info($e->getMessage().' -- Getting error on addProductAttribute (SKU='.$sku.')-- ');
        }
    }
    
    /**
     * Media directory name for the temporary file storage
     * pub/media/tmp
     *
     * @return string
     */
    protected function getMediaDirTmpDir()
    {
        return $this->_dir->getPath(DirectoryList::MEDIA) . DIRECTORY_SEPARATOR . 'tmp';
    }
    
    public function getProductsByid($id)
    {
        $product=null;
        try {
            $product = $this->_product->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($id.' --dont exits-- ');
        }
        return $product;
    }
    
    /*
     *returns product object
     */
    public function getProductById($id)
    {
        return $this->productRepository->getById($id);
    }
    
    /*
     *
     */
    public function getProduct($sku)
    {
        $product=null;
        try {
            $product = $this->productRepository->get($sku);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            $this->logger->info($e->getMessage().'Sku not exits'. $sku);
        }
        return $product;
    }
    
    /*
     * update the layout if International is yes
      */
    public function updateInternational($productId, $attributeValue, $storeId)
    {
        if ($attributeValue=='Yes') {
            $attributeCode = "custom_layout_update";
            $value = '<body><attribute name="class" value="product-international"/></body>
	 				  <referenceContainer name="product.price.final" remove="true"/>';
            $this->action->updateAttributes($productId, [$attributeCode => $value ], $storeId);
        } else {
            return null;
        }
    }
    
    /*
     * check attribute exit or not
     */
     
    public function loadattribute($attributeCode)
    {
        try {
            $attributeData = $this->attributeRepository->get('catalog_product', $attributeCode);
            if ($attributeData->getData()) {
                return true;
            }
        } catch (\Exception $e) {
              $this->logger->critical($attributeCode.' -- Not Found-- '.$e->getMessage());
            return false;
        }
    }
    
    /*
     * return image path
     */
     
    public function getImportImageFilepath($image)
    {
        return $this->_dir->getPath('var').'/import'.$image;
    }
     
    public function uploadImage($_product, $attributeCode, $attributeValue, $imagePath)
    {
        try {
            foreach ($attributeCode as $imageCode) {
             /*Add Images To The Product*/
                $existingMediaGalleryEntries = $_product->getMediaGalleryEntries();
                foreach ($existingMediaGalleryEntries as $key => $entry) {
                    foreach ($entry->getTypes() as $keys => $imagekey) {
                        unset($existingMediaGalleryEntries[$key]);
                    }
                }
                $_product->setMediaGalleryEntries($existingMediaGalleryEntries);
            }
            return  $data = [
                        'imagePath' => $imagePath,
                        'attributeCode' => $attributeCode
                    ];
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
            return null;
        }
    }
     
     /**
      * get  Attribute frontend_input
      */
    public function getAttributeDetail($attributeCode)
    {
        if ($this->loadattribute($attributeCode)) {
            $attributeData = $this->attributeRepository->get('catalog_product', $attributeCode);
            $frontendInput = $attributeData->getFrontendInput();
            $is_user_defined = $attributeData->getIsUserDefined();
              return $data = [
                    'frontend_input' => $frontendInput,
                    'is_user_defined' => $is_user_defined
                ];
        } else {
            return null;
        }
    }
    
    public function getImagesAttribute()
    {
        $attributeSet = 'default'; //attribute set name
        $mediaAttributeList = $this->mediaAttribute->getList($attributeSet);
        return $mediaAttributeList;
    }
    
   /**
    * Add Update Color Attribute options
    */
    public function getOrCreateColorAttributeOption($sku, $attributeCode, $label, $primaryColor)
    {
    
        $data = null;
        try {
            if ($this->loadattribute($attributeCode)) {
                     $attributeData = $this->attributeRepository->get('catalog_product', $attributeCode);
                     $attributeId = $attributeData->getAttributeId();
                if ($attributeId) {
                    $options = $this->attributeOptionManagement->getItems('catalog_product', $attributeId);
                    array_shift($options);
                    if ($options) {
                        foreach ($options as $option) {
                            if (trim(strtolower($option->getLabel())) === trim(strtolower($label))) {
                                $optionObj = $option;
                                break;
                            }
                        }
                    }
                    if (empty($optionObj)) {
                          $attribute = $this->eavConfig->getAttribute('catalog_product', $attributeCode);
                        if (!$attribute) {
                            return;
                        }
                        $this->attributeOptionLabel->setStoreId(0);
                        $this->attributeOptionLabel->setLabel($label);
                        $this->attributeOptionLabel->setValue($label);
                        $this->option->setLabel($label);
                        $this->option->setValue($label);
                        $this->option->setSortOrder(0);
                        $this->option->setIsDefault(false);
                        $optionId = $this->attributeOptionManagement->add(
                            'catalog_product',
                            $attributeCode,
                            $this->option
                        );
                        if ($primaryColor!="") {
                            $colorCode = $primaryColor;
                        } else {
                            $colorCode = "#808080";
                        }
                        $optionId = substr($optionId, 3);
                        $connection  = $this->resourceConnection->getConnection();
                        $tableName = "eav_attribute_option_swatch";
                         $tableName = $connection->getTableName($tableName);
                        $data = [
                          'option_id' => $optionId,
                          'store_id' => 0,
                          'type' => 1,
                          'value' => $colorCode,
                          ];
                         $connection->insert($tableName, $data);
                        
                        if ($optionId) {
                            return $this->getOrCreateColorAttributeOption($sku, $attributeCode, $label);
                        }
                    }
                    $frontendInput = $attributeData->getFrontendInput();
                    $data = [
                    'option_obj' => $optionObj,
                    'attribute_id' => $attributeId,
                    'frontend_input' => $frontendInput
                    ];
                }
            } else {
                $data=null;
            }
            
            return $data;
        } catch (\Exception $e) {
            $this->logger->info(
                'Exception: attributeCode'. $attributeCode. ' || getOrCreateColorAttributeOption: '. $e->getMessage()
            );
        }
        return $data;
    }
    
     /**
      * Add Update Attribute options
      *
      * @param int $sku
      * @param int $attributeCode
      * @param int $label
      */
    public function getOrCreateAttributeOption($sku, $attributeCode, $label)
    {
        $data = null;
        try {
            if ($this->loadattribute($attributeCode)) {
                     $attributeData = $this->attributeRepository->get('catalog_product', $attributeCode);
                     $attributeId = $attributeData->getAttributeId();
                if ($attributeId) {
                    $options = $this->attributeOptionManagement->getItems('catalog_product', $attributeId);
                    array_shift($options);
                    if ($options) {
                        foreach ($options as $option) {
                            if (trim(strtolower($option->getLabel())) === trim(strtolower($label))) {
                                $optionObj = $option;
                                break;
                            }
                        }
                    }
                    if (empty($optionObj)) {
                          $this->attributeOptionLabel->setStoreId(0);
                        $this->attributeOptionLabel->setLabel($label);
                        $this->attributeOptionLabel->setValue($label);
                        $this->option->setLabel($label);
                        $this->option->setValue($label);
                        $this->option->setSortOrder(0);
                        $this->option->setIsDefault(false);
                        $optionId = $this->attributeOptionManagement->add(
                            'catalog_product',
                            $attributeCode,
                            $this->option
                        );
                    
                        if ($optionId) {
                            return $this->getOrCreateAttributeOption($sku, $attributeCode, $label);
                        }
                    }
                     $frontendInput = $attributeData->getFrontendInput();
                    $data = [
                        'option_obj' => $optionObj,
                        'attribute_id' => $attributeId,
                        'frontend_input' => $frontendInput
                    ];
                }
            } else {
                $data=null;
            }
            
            return $data;
        } catch (\Exception $e) {
            $this->logger->info('AttributeCode'. $attributeCode. ' || getOrCreateAttributeOption: '. $e->getMessage());
        }
        return $data;
    }
 
   /**
    * log for an API
    */
    public function writeLog($log)
    {
        $this->logger->info($log);
    }
    
    /**
     * Retrieve stock qty whether product
     *
     * @param int $productId
     * @param int $websiteId
     * @return float
     */
    public function getStockQty($productId, $websiteId = null)
    {
        return $this->stockState->getStockQty($productId, $websiteId);
    }
    
    /**
     * Delete valid category ids from provided row data.
     *
     * @return boolen value
     */
    protected function deleteCategory($product)
    {
        $sku = $product->getSku();
        try {
            /*get category id from product*/
            $categoryId = $product->getCategoryIds();
            foreach ($categoryId as $id) {
               /*Delete all previous category id*/
                $this->CategoryLinkRepository->deleteByIds($id, $sku);
            }
            return true;
        
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
        }
        return false;
    }

   /**
    * INsert valid category ids from provided row data.
    *
    * @return boolen value
    */
    protected function addCategory($product)
    {
        $sku = $product['sku'];
        try {
           /**
            * returns processRowCategories category id
            */
            $categoryIds = $this->processRowCategories($product);
            /*Add New category id*/
            $this->CategoryLinkManagementInterface->assignProductToCategories($sku, $categoryIds);
            return true;
        
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
        }
        return false;
    }
    
    /**
     * Resolve valid category ids from provided row data.
     *
     * @param array $rowData
     * @return array
     */
    protected function processRowCategories($rowData)
    {
        $categoriesString = empty($rowData[self::COL_CATEGORY]) ? '' : $rowData[self::COL_CATEGORY];
        $categoryIds = [];
        if (!empty($categoriesString)) {
            $categoryIds = $this->categoryProcessor->upsertCategories(
                $categoriesString,
                $this->getMultipleValueSeparator()
            );
            foreach ($this->categoryProcessor->getFailedCategories() as $error) {
                $this->errorAggregator->addError(
                    AbstractEntity::ERROR_CODE_CATEGORY_NOT_VALID,
                    ProcessingError::ERROR_LEVEL_NOT_CRITICAL,
                    $rowData['rowNum'],
                    self::COL_CATEGORY,
                    __('Category "%1" has not been created.', $error['category'])
                    . ' ' . $error['exception']->getMessage()
                );
            }
        } else {
            $product = $this->retrieveProductBySku($rowData['sku']);
            if ($product) {
                $categoryIds = $product->getCategoryIds();
            }
        }
        return $categoryIds;
    }
    
     /**
      * Retrieve Category Processor
      *
      * @return \Magento\CatalogImportExport\Model\Import\Product\CategoryProcessor
      */
    public function getCategoryProcessor()
    {
        return $this->categoryProcessor;
    }
    
     /**
      * Retrieve product by sku.
      *
      * @param string $sku
      * @return \Magento\Catalog\Api\Data\ProductInterface|null
      */
      
    private function retrieveProductBySku($sku)
    {
        try {
            $product = $this->productRepository->get($sku);
        } catch (NoSuchEntityException $e) {
            return null;
        }
        return $product;
    }
    
    /**
     * Multiple value separator getter.
     *
     * @return string
     */
     
    public function getMultipleValueSeparator()
    {
        if (!empty($this->_parameters[Import::FIELD_FIELD_MULTIPLE_VALUE_SEPARATOR])) {
            return $this->_parameters[Import::FIELD_FIELD_MULTIPLE_VALUE_SEPARATOR];
        }
        return Import::DEFAULT_GLOBAL_MULTI_VALUE_SEPARATOR;
    }
    
    /**
     * check product exist by sku
     */
    public function checkProductExistBySku($sku)
    {
        try {
            $product = $this->productRepository->get($sku, true);
            return $product;
        } catch (\Exception $e) {
            $product = null;
        }
        return $product;
    }
    
     /**
      * Parse values from multiple attributes fields
      *
      * @param string $labelRow
      * @return array
      */
      
    private function parseMultipleValues($labelRow)
    {
        return $this->parseMultiselectValues(
            $labelRow,
            $this->getMultipleValueSeparator()
        );
    }
    
     /**
      * check product visibility and returns its id
      */
      
    public function addvisibility($visibility)
    {
        if ($visibility==='Not Visible Individually') {
            return 1;
        }
        if ($visibility==='Catalog') {
            return 2;
        }
        if ($visibility==='Search') {
            return 3;
        }
        if ($visibility==='Catalog, Search') {
            return 4;
        }
    }
    
    /**
     * Generate url key from string
     */
    public function createSlug($string)
    {
        $slug=preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
        return $slug;
    }

    public function getBaseName($path)
    {
        $fileInfo = $this->file->getPathInfo($path);
        $basename = $fileInfo['basename'];
        return $basename;
    }
}
