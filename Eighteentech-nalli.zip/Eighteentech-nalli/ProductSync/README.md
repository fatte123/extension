# Magento 2 Product Sync

This Extension is used for addinga a new product or updating an existing product. 

## Features:

### Frontend
- Allows to add new product or update existing using API.


## Introduction installation:

### Install in Magento 2
- Download file
- Unzip the file
- Create a folder [root]/app/code/Eighteentech/ProductSync
- Copy to folder

### Enable Extension

```
php bin/magento module:enable Eighteentech_ProductSync
php bin/magento setup:upgrade
php bin/magento cache:clean
php bin/magento setup:static-content:deploy
```


