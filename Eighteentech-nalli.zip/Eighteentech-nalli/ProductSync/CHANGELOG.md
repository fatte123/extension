# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2022-1-13
### Added
- This module allows to add new product or update existing using API.
- API to add new product is rest/V1/productsync/addProduct.
- API to update a  product is rest/V1/productsync/updateProduct.
