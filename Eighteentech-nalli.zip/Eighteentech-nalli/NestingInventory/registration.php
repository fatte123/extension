<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_NestingInventory
 * @author     https://www.18thdigitech.com/
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Eighteentech_NestingInventory',
    __DIR__
);
