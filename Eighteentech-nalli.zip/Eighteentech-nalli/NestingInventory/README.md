## Eighteentech

/**
 * @category   Eighteentech
 * @package    Eighteentech_NestingInventorySales
 * @author     https://www.18thdigitech.com/
 */
 
 Managing point's
 1.get the Inventory Sales using \Eighteentech\NestingInventory\Helper\Data;
 	function name getProductSalableQty();
 	
 2.get the Current Quote using \Eighteentech\NestingInventory\Helper\Quotehelp;
 	function name getCurrentQuote();
	
 3.All the function are using in addtocart.phtml 
 //app/design/frontend/venderName/ModuleName/Magento_Catalog/templates/product/view/addtocart.phtml
 	