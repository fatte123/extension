<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_NestingInventory
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\NestingInventory\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku;

class Data extends AbstractHelper
{
    
    /**
     * @var \Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku;
     */
   private $getSalableQuantityDataBySku;
      
    public function __construct(
		
		\Magento\CatalogInventory\Api\StockStateInterface $stockState
	)
    {
		$this->stockState = $stockState;
       
    }
    /*
     *get product salable quantity in Magento 2.
    */
    public function getProductSalableQty($sku)
    {
        $salable = $this->getSalableQuantityDataBySku->execute($sku);
        return $salable[0]['qty'];
    }
	
	/**
     * Retrieve stock qty whether product
     *
     * @param int $productId
     * @param int $websiteId
     * @return float
     */
    public function getStockQty($productId, $websiteId = null)
    {
        return $this->stockState->getStockQty($productId, $websiteId);
    }
}
