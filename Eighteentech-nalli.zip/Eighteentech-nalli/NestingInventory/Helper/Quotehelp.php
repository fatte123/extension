<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_NestingInventory
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\NestingInventory\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Quotehelp extends AbstractHelper
{
     
     /**
      * @var \Magento\Checkout\Model\Cart;
      */
    protected $cart;
     
    public function __construct(
        \Magento\Checkout\Model\Cart $cart
    ) {
        $this->cart             = $cart;
    }
     /**
      * @getCurrentQuote function  rerurns current Quote items
      */
    public function getCurrentQuote()
    {
        $itemsVisible = $this->cart->getQuote()->getAllVisibleItems();
        foreach ($itemsVisible as $item) {
            $cartitems[] = $item->getProductId();
        }
            return $cartitems;
    }
}
