<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_NestingInventory
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\NestingInventory\Observer;

use Magento\Framework\Event\ObserverInterface;

class QuantityValidatorObserver implements ObserverInterface
{
    /**
     * @var \Eighteentech\NestingInventory\Model\QuantityValidator $quantityValidator
     */
    protected $quantityValidator;

    /**
     * @param \Eighteentech\NestingInventory\Model\QuantityValidator $quantityValidator
     */
    public function __construct(
        \Eighteentech\NestingInventory\Model\QuantityValidator $quantityValidator
    ) {
        $this->quantityValidator = $quantityValidator;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->quantityValidator->validate($observer);
    }
}

