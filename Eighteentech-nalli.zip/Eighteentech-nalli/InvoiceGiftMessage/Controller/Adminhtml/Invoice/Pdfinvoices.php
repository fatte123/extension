<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Eighteentech\InvoiceGiftMessage\Controller\Adminhtml\Invoice;

class Pdfinvoices extends \Eighteentech\InvoiceGiftMessage\Controller\Adminhtml\Invoice\AbstractInvoice\Pdfinvoices
{
}
