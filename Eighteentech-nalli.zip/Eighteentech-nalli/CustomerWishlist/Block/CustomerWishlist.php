<?php
/**
 * Block File
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_CustomerWishlist
 */
 
namespace Eighteentech\CustomerWishlist\Block;

class CustomerWishlist extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Framework\View\Element\Template\Context $context
     */
    public $context;
    
    /*
     *@var \Eighteentech\CustomerWishlist\Helper\Data $Helper
     */
    public $Helper;
    
    /*
     *@var \Magento\Wishlist\Model\WishlistFactory $wishlistFactory
     */
    public $wishlistFactory;
    
    /*
     *@var \Magento\Customer\Model\Session $customerSession
     */
    protected $customerSession;
    
    /*
     *@param \Magento\Framework\View\Element\Template\Context $context
     *@param \Eighteentech\CustomerWishlist\Helper\Data $Helper
     *@parma \Magento\Wishlist\Model\WishlistFactory $wishlistFactory
     *@param \Magento\Customer\Model\Session $customerSession
     */
     
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Eighteentech\CustomerWishlist\Helper\Data $Helper,
        \Magento\Wishlist\Model\WishlistFactory $wishlistFactory,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->helper = $Helper;
        $this->_wishlistfactory = $wishlistFactory;
        $this->customerSession = $customerSession;
        parent::__construct($context);
    }
    
    /**
     * @return all helper function
     */
    public function getHelper()
    {
        return $this->helper;
    }
    
    /**
     * @param int $customerId
     * @return customer wishlist collection
     */
    public function getWishlistByCustomerId()
    {
        $customerId = $this->getCustomerId();
        $limit = $this->getHelper()->getCartLimit();
        $this->_wishlistfactory = $this->_wishlistfactory->create();
        $this->_productCollection = $this->_wishlistfactory->loadByCustomerId($customerId)
        ->getItemCollection()->setPageSize($limit)->setCurPage(1);
        $this->_productCollection->setOrder('position', 'DESC');
        return $this->_productCollection;
    }
    
    /*
     *@return logedin customer id
     */
    public function getCustomerId()
    {
        return $this->customerSession->getCustomer()->getId();
    }
}
