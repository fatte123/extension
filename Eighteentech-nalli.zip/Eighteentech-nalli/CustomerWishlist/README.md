# Magento 2 CustomerWishlist 

This Extension is used for show Customer Wishlist on cart page

## Features:

### Frontend
- show Customer Wishlist on cart page

### Backend
- Set status, phone number and message function under menu Stores >> Configuration >> Nalli - CustomerWishlist

## Introduction installation:

### Install Magento 2 Hide Price Not Login
- Download file
- Unzip the file
- Create a folder [root]/app/code/Eighteentech/CustomerWishlist
- Copy to folder

### Enable Extension

```
php bin/magento module:enable Eighteentech_CustomerWishlist
php bin/magento setup:upgrade
php bin/magento cache:clean
php bin/magento setup:static-content:deploy
```


