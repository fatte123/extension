<?php
/**
 * Data Helper File
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_CustomerWishlist
 */

namespace Eighteentech\CustomerWishlist\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const STATUS = 'customerwishlist/customer_wishlist/status';
    const CART_LIMIT = 'customerwishlist/customer_wishlist/cart_limit';
    
    /**
     * Return status
     *
     * @return string
     */

    public function getStatus()
    {
        return $this->scopeConfig->getValue(
            self::STATUS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return phone
     *
     * @return string
     */

    public function getCartLimit()
    {
        return $this->scopeConfig->getValue(
            self::CART_LIMIT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
