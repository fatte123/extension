/**
 * MultipleCartDelete JS
 *
 * @author 18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_CustomerWishlist
 */
 define([
    'jquery',
	'Nalli_Core/js/slick'
], function($,slickSlider){
   "use strict";
    $(document).ready(function () {
	
	if($(".wishlist-product-carousel-essentials").length > 0){
			$('.wishlist-product-carousel-essentials').slick({  
				dots: false,
				arrows: true,
				infinite: false,
				autoplay: true,
				speed: 300,
				slidesToShow: 5,
				slidesToScroll: 1,
				responsive: [
					{
						breakpoint: 1080,
						settings: {
							slidesToShow: 4,
						},
					},
					
					{
						breakpoint: 1008,
						settings: {
							slidesToShow: 3,
						},
					},

					{
						breakpoint: 767,
						settings: {
							slidesToShow: 2,
						},
					},
				],
				 
			}); 
		 }	
	}); /* ----------------Document Ready End---------------- */
});