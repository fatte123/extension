var config = {
    map: {
        '*': {
            CustomerWishlist: 'Eighteentech_CustomerWishlist/js/CustomerWishlist',
        }
    }
};
