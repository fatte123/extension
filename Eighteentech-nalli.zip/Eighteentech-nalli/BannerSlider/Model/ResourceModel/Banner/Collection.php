<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Model\ResourceModel\Banner;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * /@package Eighteentech\BannerSlider\Model\ResourceModel\Banner
 *
 * @SuppressWarnings(PHPMD)
 */
class Collection extends AbstractCollection
{
    /**
     * ID Field Name
     *
     * @var string
     */
    protected $_idFieldName = 'banner_id';

    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'eighteentech_bannerslider_banner_collection';

    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'banner_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Eighteentech\BannerSlider\Model\Banner::class,
            \Eighteentech\BannerSlider\Model\ResourceModel\Banner::class
        );
    }

    /**
     * Get SQL for get record count.
     * Extra GROUP BY strip added.
     *
     * @return \Magento\Framework\DB\Select
     */
    public function getSelectCountSql()
    {
        $countSelect = parent::getSelectCountSql();
        $countSelect->reset(\Zend_Db_Select::GROUP);

        return $countSelect;
    }

    /**
     * @param array|string $field
     * @param null $condition
     *
     * @return AbstractCollection
     */
    public function addFieldToFilter($field, $condition = null)
    {
        if ($field == 'banner_id') {
            $field = 'main_table.banner_id';
        }

        if ($field == 'type' && is_array($condition) || isset($condition['like'])) {
            $condition['like'] = str_replace("'%", '', $condition['like']);
            $condition['like'] = str_replace("%'", '', $condition['like']);
            if (stristr('Video', $condition['like'])) {
                $condition = 1;
            }
            if (stristr('Image', $condition['like'])) {
                $condition = 0;
            }
            if (stristr('Advanced', $condition['like'])) {
                $condition = 2;
            }
        }

        if ($field == 'status' && is_array($condition) || isset($condition['like'])) {
            $condition['like'] = str_replace("'%", '', $condition['like']);
            $condition['like'] = str_replace("%'", '', $condition['like']);
            if (stristr('Enable', $condition['like'])) {
                $condition = 1;
            }
            if (stristr('Disable', $condition['like'])) {
                $condition = 0;
            }
        }

        return parent::addFieldToFilter($field, $condition);
    }
}
