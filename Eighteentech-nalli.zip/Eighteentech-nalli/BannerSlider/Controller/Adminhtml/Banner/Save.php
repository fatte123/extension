<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action\Context;
use Magento\Backend\Helper\Js;
use Magento\Framework\Registry;
use Eighteentech\BannerSlider\Controller\Adminhtml\Banner;
use Eighteentech\BannerSlider\Helper\Image;
use Eighteentech\BannerSlider\Model\BannerFactory;

/**
 * Class Save
 * /@package Eighteentech\BannerSlider\Controller\Adminhtml\Banner
 */
class Save extends Banner
{
    /**
     * Image Helper
     *
     * @var \Eighteentech\BannerSlider\Helper\Image
     */
    protected $imageHelper;

    /**
     * JS helper
     *
     * @var \Magento\Backend\Helper\Js
     */
    public $jsHelper;

    /**
     * Save constructor.
     * @param Image $imageHelper
     * @param BannerFactory $bannerFactory
     * @param Registry $registry
     * @param Js $jsHelper
     * @param Context $context
     */
    public function __construct(
        Image $imageHelper,
        BannerFactory $bannerFactory,
        Registry $registry,
        Js $jsHelper,
        Context $context
    ) {
        $this->imageHelper = $imageHelper;
        $this->jsHelper    = $jsHelper;

        parent::__construct($bannerFactory, $registry, $context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data = $this->getRequest()->getPost('banner')) {
            $banner = $this->initBanner();

            $this->imageHelper->uploadImage($data, 'image', Image::TEMPLATE_MEDIA_TYPE_BANNER, $banner->getImage());
            $this->imageHelper->
            uploadImage($data, 'mobile_image', Image::TEMPLATE_MEDIA_TYPE_BANNER, $banner->getImage());
            $data['sliders_ids'] = (isset($data['sliders_ids']) &&
                $data['sliders_ids']) ? explode(',', $data['sliders_ids']) : [];
            if ($sliders = $this->getRequest()->getPost('sliders', false)) {
                $banner->setTagsData(
                    $this->jsHelper->decodeGridSerializedInput($sliders)
                );
            }

            $banner->addData($data);

            $this->_eventManager->dispatch(
                'eighteentechbannerslider_banner_prepare_save',
                [
                    'banner'  => $banner,
                    'request' => $this->getRequest()
                ]
            );
            try {
                $banner->save();
                $this->messageManager->addSuccess(__('The Banner has been saved.'));
                $this->_session->setEighteentechBannerSliderBannerData(false);
                if ($this->getRequest()->getParam('back')) {
                    $resultRedirect->setPath(
                        'eighteentechbannerslider/*/edit',
                        [
                            'banner_id' => $banner->getId(),
                            '_current'  => true
                        ]
                    );

                    return $resultRedirect;
                }
                $resultRedirect->setPath('eighteentechbannerslider/*/');

                return $resultRedirect;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Banner.'));
            }

            $this->_getSession()->setData('eighteentech_bannerSlider_banner_data', $data);
            $resultRedirect->setPath(
                'eighteentechbannerslider/*/edit',
                [
                    'banner_id' => $banner->getId(),
                    '_current'  => true
                ]
            );

            return $resultRedirect;
        }

        $resultRedirect->setPath('eighteentechbannerslider/*/');

        return $resultRedirect;
    }
}
