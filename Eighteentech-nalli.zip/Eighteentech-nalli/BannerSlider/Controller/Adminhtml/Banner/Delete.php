<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Controller\Adminhtml\Banner;

use Eighteentech\BannerSlider\Controller\Adminhtml\Banner;

/**
 * Class Delete
 * /@package Eighteentech\BannerSlider\Controller\Adminhtml\Banner
 */
class Delete extends Banner
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $this->bannerFactory->create()
                ->load($this->getRequest()->getParam('banner_id'))
                ->delete();
            $this->messageManager->addSuccess(__('The Banner has been deleted.'));
        } catch (\Exception $e) {
            // display error message
            $this->messageManager->addErrorMessage($e->getMessage());
            // go back to edit form
            $resultRedirect->
            setPath('eighteentechbannerslider/*/edit', ['banner_id' => $this->getRequest()->getParam('banner_id')]);

            return $resultRedirect;
        }

        $resultRedirect->setPath('eighteentechbannerslider/*/');

        return $resultRedirect;
    }
}
