<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Controller\Adminhtml\Slider;

use Eighteentech\BannerSlider\Controller\Adminhtml\Slider;

/**
 * Class Delete
 * /@package Eighteentech\BannerSlider\Controller\Adminhtml\Slider
 */
class Delete extends Slider
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            /** @var \Eighteentech\BannerSlider\Model\Banner $banner */
            $this->sliderFactory->create()
                ->load($this->getRequest()->getParam('slider_id'))
                ->delete();
            $this->messageManager->addSuccess(__('The slider has been deleted.'));
        } catch (\Exception $e) {
            // display error message
            $this->messageManager->addErrorMessage($e->getMessage());
            // go back to edit form
            $resultRedirect->
            setPath('eighteentechbannerslider/*/edit', ['slider_id' => $this->getRequest()->getParam('slider_id')]);

            return $resultRedirect;
        }

        $resultRedirect->setPath('eighteentechbannerslider/*/');

        return $resultRedirect;
    }
}
