<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Controller\Adminhtml\Slider;

/**
 * Class BannersGrid
 * /@package Eighteentech\BannerSlider\Controller\Adminhtml\Slider
 */
class BannersGrid extends Banners
{
}
