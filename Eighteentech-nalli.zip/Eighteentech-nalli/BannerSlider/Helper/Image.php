<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Helper;

use Eighteentech\BannerSlider\Helper\Media;

/**
 * Class Image
 * /@package Eighteentech\Blog\Helper
 */
class Image extends Media
{
    const TEMPLATE_MEDIA_PATH        = 'eighteentech/bannerslider';
    const TEMPLATE_MEDIA_TYPE_BANNER = 'banner/image';
    const TEMPLATE_MEDIA_TYPE_SLIDER = 'slider/image';
}
