<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Store\Model\StoreManagerInterface;
use Eighteentech\BannerSlider\Model\BannerFactory;
use Eighteentech\BannerSlider\Model\SliderFactory;
use Eighteentech\BannerSlider\Helper\AbstractData;

/**
 * Class Data
 * /@package Eighteentech\BannerSlider\Helper
 *
 * @SuppressWarnings(PHPMD)
 */
class Data extends AbstractData
{
    const CONFIG_MODULE_PATH = 'eighteentechbannerslider';
    const CONFIG_STATUS = 'eighteentechbannerslider/general/enabled';
    const CONFIG_RESPONSIVE = 'eighteentechbannerslider/eighteentechbannerslider_design/responsive';
    const CONFIG_ITEM_SLIDER = 'eighteentechbannerslider/eighteentechbannerslider_design/item_slider';
    const CONFIG_AUTOWIDTH = 'eighteentechbannerslider/eighteentechbannerslider_design/autoWidth';
    const CONFIG_AUTOHEIGHT = 'eighteentechbannerslider/eighteentechbannerslider_design/autoHeight';
    const CONFIG_LOOP = 'eighteentechbannerslider/eighteentechbannerslider_design/loop';
    const CONFIG_NAV = 'eighteentechbannerslider/eighteentechbannerslider_design/nav';
    const CONFIG_DOTS = 'eighteentechbannerslider/eighteentechbannerslider_design/dots';
    const CONFIG_LAZYLOAD = 'eighteentechbannerslider/eighteentechbannerslider_design/lazyLoad';
    const CONFIG_AUTOPLAY = 'eighteentechbannerslider/eighteentechbannerslider_design/autoplay';
    const CONFIG_AUTOPLAY_TIMEOUT = 'eighteentechbannerslider/eighteentechbannerslider_design/autoplayTimeout';
    const CONFIG_RANDOM = 'eighteentechbannerslider/eighteentechbannerslider_design/random';
    

    /**
     * @var DateTime
     */
    protected $date;

    /**
     * @var HttpContext
     */
    protected $httpContext;

    /**
     * @var BannerFactory
     */
    public $bannerFactory;

    /**
     * @var SliderFactory
     */
    public $sliderFactory;
    
    /**
     * @var scopeConfig
     */
    protected $scopeConfig;

    /**
     * Data constructor.
     *
     * @param DateTime $date
     * @param Context $context
     * @param HttpContext $httpContext
     * @param BannerFactory $bannerFactory
     * @param SliderFactory $sliderFactory
     * @param StoreManagerInterface $storeManager
     * @param ObjectManagerInterface $objectManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        DateTime $date,
        Context $context,
        HttpContext $httpContext,
        BannerFactory $bannerFactory,
        SliderFactory $sliderFactory,
        StoreManagerInterface $storeManager,
        ObjectManagerInterface $objectManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->date          = $date;
        $this->httpContext   = $httpContext;
        $this->bannerFactory = $bannerFactory;
        $this->sliderFactory = $sliderFactory;
		$this->scopeConfig = $scopeConfig;
        parent::__construct($context, $objectManager, $storeManager);
    }

    /**
     * @param null $slider
     *
     * @return false|string
     */
    public function getBannerOptions($slider = null)
    {
        if ($slider && $slider->getDesign() === "1") { //not use Config
            $config = $slider->getData();
        } else {
            $config = $this->getModuleConfig('eighteentechbannerslider_design');
        }

        $defaultOpt    = $this->getDefaultConfig($config);
        $responsiveOpt = $this->getResponsiveConfig($slider);
        $effectOpt     = $this->getEffectConfig($slider);

        $sliderOptions = array_merge($defaultOpt, $responsiveOpt, $effectOpt);

        return self::jsonEncode($sliderOptions);
    }

    /**
     * @param $configs
     *
     * @return array
     */
    public function getDefaultConfig($configs)
    {
        $basicConfig = [];
        foreach ($configs as $key => $value) {
            if (in_array($key, ['autoWidth', 'autoHeight', 'loop',
                'nav', 'dots', 'lazyLoad', 'autoplay', 'autoplayTimeout'])) {
                $basicConfig[$key] = (int)$value;
            }
        }

        return $basicConfig;
    }

    /**
     * @param null $slider
     *
     * @return array
     */
    public function getResponsiveConfig($slider = null)
    {
        if (isset($slider)) {
            $isResponsive = $this->getModuleConfig('eighteentechbannerslider_design/responsive') == 1;
            try {
                $responsiveItems = $this->unserialize($this->getModuleConfig('eighteentechbannerslider_design/item_slider'));
            } catch (\Exception $e) {
                $responsiveItems = [];
            }
        } else {
            $isResponsive = $slider->getIsResponsive();
            try {
                $responsiveItems = $this->unserialize($slider->getResponsiveItems());
            } catch (\Exception $e) {
                $responsiveItems = [];
            }
        }
        if (!$isResponsive || !$responsiveItems) {
            return ["items" => 1];
        }

        $result = [];
        foreach ($responsiveItems as $config) {
            $size          = $config['size'] ?: 0;
            $items         = $config['items'] ?: 0;
            $result[$size] = ["items" => $items];
        }

        return ['responsive' => $result];
    }

    /**
     * @param $slider
     *
     * @return array
     */
    public function getEffectConfig($slider)
    {
        if (!$slider) {
            return [];
        }

        return ['animateOut' => $slider->getEffect()];
    }

    /**
     * @param null $id
     *
     * @return \Eighteentech\BannerSlider\Model\ResourceModel\Banner\Collection
     */
    public function getBannerCollection($id = null)
    {
        $collection = $this->bannerFactory->create()->getCollection();

        $collection->join(
            ['banner_slider' => $collection->getTable('eighteentech_bannerslider_banner_slider')],
            'main_table.banner_id=banner_slider.banner_id AND banner_slider.slider_id=' . $id,
            ['position']
        );

        $collection->addOrder('position', 'ASC');

        return $collection;
    }

    /**
     * @return Collection
     */
    public function getActiveSliders()
    {
        /** @var Collection $collection */
        $collection = $this->sliderFactory->create()
            ->getCollection()
            ->addFieldToFilter('status', 1)
            ->addOrder('priority');

        $collection->getSelect()
            ->where('FIND_IN_SET(0, store_ids) OR FIND_IN_SET(?, store_ids)', $this->storeManager->getStore()->getId())
            ->where('from_date is null OR from_date <= ?', $this->date->date())
            ->where('to_date is null OR to_date >= ?', $this->date->date());

        return $collection;
    }
    
    /**
     * @returm mobule config status
     */
    public function getStatus()
    {
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_STATUS, $storeScope);
	}
	
	/**
     * @returm Responsive status
     */
	public function getResponsive() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_RESPONSIVE, $storeScope);
	}
	
	/**
     * @returm ItemSlider status
     */
	public function getItemSlider() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_ITEM_SLIDER, $storeScope);
	}
	
	/**
     * @returm ItemSlider status
     */
	public function getautoWidth() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_AUTOWIDTH, $storeScope);
	}
	
	/**
     * @returm AUTOHEIGHT status
     */
	public function getAutoHeight() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_AUTOHEIGHT, $storeScope);
	}
	
	/**
     * @returm loop status
     */
	public function getLoop() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_LOOP, $storeScope);
	}
	
	/**
     * @returm nav status
     */
	public function getNav() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_NAV, $storeScope);
	}
	
	/**
     * @returm dots status
     */
	public function getDots() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_DOTS, $storeScope);
	}
	
	/**
     * @returm lazyLoad status
     */
	public function getLazyLoad() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_LAZYLOAD, $storeScope);
	}
	
	/**
     * @returm autoplay status
     */
	public function getAutoPlay() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_AUTOPLAY, $storeScope);
	}
	
	/**
     * @returm autoplayTimeout status
     */
	public function getAutoPlayTimeout() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_AUTOPLAY_TIMEOUT, $storeScope);
	}
	
	/**
     * @returm random status
     */
	public function getRandom() 
	{
	  $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
	  return $this->scopeConfig->getValue(self::CONFIG_RANDOM, $storeScope);
	}
	
	
}
