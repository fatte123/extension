<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Block;

/**
 * Class Widget
 * /@package Eighteentech\BannerSlider\Block
 */
class Widget extends Slider
{
    /**
     * @return array|bool|\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getBannerCollection()
    {
        $sliderId = $this->getData('slider_id');
        if (!$this->helperData->isEnabled() || !$sliderId) {
            return false;
        }

        $sliderCollection = $this->helperData->getActiveSliders();
        $slider           = $sliderCollection->addFieldToFilter('slider_id', $sliderId)->getFirstItem();
        $this->setSlider($slider);

        return parent::getBannerCollection();
    }
}
