<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Block\Adminhtml;

/**
 * Class Slider
 * /@package Eighteentech\BannerSlider\Block\Adminhtml
 *
 * @SuppressWarnings(PHPMD)
 */
class Slider extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller     = 'adminhtml_slider';
        $this->_blockGroup     = 'Eighteentech_BannerSlider';
        $this->_headerText     = __('Sliders');
        $this->_addButtonLabel = __('Create New Slider');

        parent::_construct();
    }
}
