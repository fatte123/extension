<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Block\Adminhtml\Slider\Edit\Tab\Renderer;

use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class Snippet
 * /@package Eighteentech\BannerSlider\Block\Adminhtml\Slider\Edit\Tab\Renderer
 */
class Snippet extends AbstractElement
{

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * public constructor
     * @param \Magento\Framework\Data\Form\Element\Factory $factoryElement
     * @param \Magento\Framework\Data\Form\Element\CollectionFactory $factoryCollection
     * @param \Magento\Framework\Escaper $escaper
     * @param \Magento\Framework\App\RequestInterface $request
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Data\Form\Element\Factory $factoryElement,
        \Magento\Framework\Data\Form\Element\CollectionFactory $factoryCollection,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\App\RequestInterface $request,
        $data = []
    ) {
        parent::__construct($factoryElement, $factoryCollection, $escaper, $data);
        $this->request = $request;
    }

    /**
     * @return string
     */
    public function getElementHtml()
    {
        $sliderId = $this->request->getParam('slider_id', '1');
        $html     = '<ul class="banner-location-display"><li><span>';
        $html     .= __('Add Widget with name "Banner Slider widget" and set "Slider Id" for it.');
        $html     .= '</span></li><li><span>';
        $html     .= __('CMS Page/Static Block');
        $html     .= '</span><code>{{block class="Eighteentech\BannerSlider\Block\Widget" 
        slider_id="' . $sliderId . '"}}</code><p>';
        $html     .= __('You can paste the above block of snippet into any page in Magento 2 and set SliderId for it.');
        $html     .= '</p></li><li><span>';
        $html     .= __('Template .phtml file');
        $html     .= '</span><code>' .
        $this->_escaper->escapeHtml('<?php echo $block->getLayout()
            ->createBlock("Eighteentech\BannerSlider\Block\Widget::class")
            ->setSliderId(' . $sliderId . ')->toHtml();?>') . '</code><p>';
        $html     .= __('Open a .phtml file and insert where you want to display Banner Slider.');
        $html     .= '</p></li></ul>';

        return $html;
    }
}
