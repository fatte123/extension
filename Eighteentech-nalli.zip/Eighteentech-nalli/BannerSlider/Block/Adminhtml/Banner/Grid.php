<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Block\Adminhtml\Banner;

/**
 * Class Grid
 * /@package Eighteentech\BannerSlider\Block\Adminhtml\Banner
 */
class Grid extends \Magento\Backend\Block\Widget\Grid
{
}
