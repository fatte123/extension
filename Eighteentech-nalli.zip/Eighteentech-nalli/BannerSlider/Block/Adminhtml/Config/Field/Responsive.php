<?php
/**
 * @author 18th DigiTech Team
 * @copyright Copyright (c) 2020 18th DigiTech (https://www.18thdigitech.com)
 * @package Eighteentech_BannerSlider
 */
namespace Eighteentech\BannerSlider\Block\Adminhtml\Config\Field;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;

/**
 * Class Responsive
 * /@package Eighteentech\BannerSlider\Block\Adminhtml\Config\Field
 *
 * @SuppressWarnings(PHPMD)
 */
class Responsive extends AbstractFieldArray
{
    /**
     * @inheritdoc
     */
    protected function _prepareToRender()
    {
        $this->addColumn('size', ['label' => __('Screen size from'), 'renderer' => false]);
        $this->addColumn('items', ['label' => __('Number of items'), 'renderer' => false]);

        $this->_addAfter       = false;
        $this->_addButtonLabel = __('Add');
    }
}
