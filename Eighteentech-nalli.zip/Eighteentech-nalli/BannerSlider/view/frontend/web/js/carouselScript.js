define([
        "jquery",
        'owlcarousel',
        'picturefill'
    ], function($){
        "use strict";
      $.widget('mage.carouselScript', {
	  options: {
			   id:'',
			   autoWidths:'',
			   autoHeights:'',
			   loops:'',
			   navs:'',
			   dotss:'',
			   lazyLoads:'',
			   autoplays:'',
			   autoplayTimeouts:'',
			   randoms:'',
			},
		/**
         * Creates widget
         * @private
         */
        _create: function () {
            var self = this;
             $(document).ready(function() {
				 self.bannerSlider();
				 setTimeout(function() {
                     $(".owl-dots").insertAfter(".owl-nav .owl-prev");
                    }, 1500);
                setTimeout(function() {    
                    $('figure a').each(function() {
                    	var linktype = $('figure a').attr("data-element");
                    	if (linktype === 'link') {
                    	  $(this).closest('figure a').addClass('pagewidget-item');
                    	}
                    });
                  $( "a.pagebuilder-button-primary" ).each(function( index ) {
					var title = $(this).find( "span" ).text();
					$(this).attr('title', 'Shop by Price|'+title);
				  });   
                  
                    
                }, 5000);
                setTimeout(function() {    
                                        
                   $(document).find('a.pagebuilder-button-primary').addClass('pagewidget-item');
                    
                }, 10000);
            });
            
         },	
		 initializeWidget: function () {
			var options = this.options;
		 },
		 bannerSlider:function() {
		 
		 var id = this.options.id;
		 var autoWidths = this.options.autoWidths;
		 var autoHeights = this.options.autoHeights; 
		 var loops = this.options.loops;
		 var navs = this.options.navs;
		 var dotss = this.options.dotss;
		 var lazyLoads = this.options.lazyLoads;
		 var autoplays = this.options.autoplays;
		 var autoplayTimeouts = this.options.autoplayTimeouts;
		 var randoms = this.options.randoms;
		 	 
		 var owl = $(id);
		  owl.owlCarousel({
			autoWidth:autoWidths,
			autoHeight:autoHeights,
			lazyLoad:lazyLoads,
			autoplay:autoplays,
			autoplayTimeout:autoplayTimeouts,
			nav:navs,
			dots:dotss,
			loop:loops,
			items:1,
			onInitialize : function(element){
			if(randoms ===1) {	
				owl.children().sort(function(){
					return Math.round(Math.random()) - 0.5;
				}).each(function(){
					$(this).appendTo(owl);
				});
			 }
			}
		 
		  });
		 },
		 
        
	  });  
	  return $.mage.carouselScript;
	  
 });
