<?php
/**
 * Currency Block File
 *
 * @author 18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_CurrencySymbol
 */
 
namespace Eighteentech\CurrencySymbol\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /**
     * @var \Magento\Directory\Model\CurrencyFactory
     */
    protected $currencyFactory;
    
    /**
     * @param  \Magento\Directory\Model\CurrencyFactory
     */
    public function __construct(
        \Magento\Directory\Model\CurrencyFactory $currencyFactory
    ) {
        $this->currencyFactory = $currencyFactory;
    }
    
    /*
     *@return currency symbol
     */
    public function getSymbol($currentCurrencyCode)
    {
        $currency = $this->currencyFactory->create()->load($currentCurrencyCode);
        return $currencySymbol = $currency->getCurrencySymbol();
    }
    
    /*
     *@return currency symbol
     */
    public function getSwitcherSymbol($currentCurrencyCode)
    {
        $currency = $this->currencyFactory->create()->load($currentCurrencyCode);
        return $currencySymbol = $currency->getCurrencySymbol();
    }
}
