# Eighteentech_CurrencySymbol Module

How to Install the module 
-------------------------
copy and paste the downloaded folder & file to app/code/Eighteen/CurrencySymbol

Run the following commands in terminal-
-----------------------------
php bin/magento setup:upgrade

now module is properly installed

Use of this module
------------------
This Module Display Currency Symbol in header Currency Dropdown instead of Currency Code+ Currency Complete Name.


Dependencies
------------------
Magento_Directory

