<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Model\Data;

use Eighteentech\CustomApi\Api\Data\ErrorMessageDetailsInterface;

class ErrorMessageDetails implements ErrorMessageDetailsInterface
{

    protected $sizeOutOfStockMessage;
    protected $qtyNotAvailableMessage;
    protected $maxAllowedQtyExceededMessage;
    protected $productOutOfStockMessage;

    /**
     * @inheritDoc
     */
    public function getProductOutOfStockMessage()
    {
        return $this->productOutOfStockMessage;
    }

    /**
     * @inheritDoc
     */
    public function setProductOutOfStockMessage($productOutOfStockMessage)
    {
        $this->productOutOfStockMessage = $productOutOfStockMessage;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getSizeOutOfStockMessage()
    {
        return $this->sizeOutOfStockMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function setSizeOutOfStockMessage($sizeOutOfStockMessage)
    {
        $this->sizeOutOfStockMessage = $sizeOutOfStockMessage;
        return $sizeOutOfStockMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function getQtyNotAvailableMessage()
    {
        return $this->qtyNotAvailableMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function setQtyNotAvailableMessage($qtyNotAvailableMessage)
    {
        $this->qtyNotAvailableMessage = $qtyNotAvailableMessage;
        return $qtyNotAvailableMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxAllowedQtyExceededMessage()
    {
        return $this->maxAllowedQtyExceededMessage;
    }

    /**
     * {@inheritdoc}
     */
    public function setMaxAllowedQtyExceededMessage($maxAllowedQtyExceededMessage)
    {
        $this->maxAllowedQtyExceededMessage = $maxAllowedQtyExceededMessage;
        return $maxAllowedQtyExceededMessage;
    }
}
