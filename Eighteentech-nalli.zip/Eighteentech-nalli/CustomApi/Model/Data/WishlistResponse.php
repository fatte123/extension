<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Model\Data;

use Eighteentech\CustomApi\Api\Data\WishlistResponseInterface;

class WishlistResponse implements WishlistResponseInterface
{
    protected $wishlistCount;
    protected $wishlistItemDetails;
    protected $sku;

    /**
     * @inheritDoc
     */
    public function getWishlistCount()
    {
        return $this->wishlistCount;
    }

    /**
     * @inheritDoc
     */
    public function setWishlistCount($wishlistCount)
    {
        $this->wishlistCount = $wishlistCount;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getWishlistItems()
    {
        return $this->wishlistItemDetails;
    }

    /**
     * @inheritDoc
     */
    public function setWishlistItems($wishlistItemDetails)
    {
        $this->wishlistItemDetails = $wishlistItemDetails;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getSku()
    {
        return $this->sku;
    }

    /**
     * @inheritDoc
     */
    public function setSku($sku)
    {
        $this->sku = $sku;
        return $this;
    }
}
