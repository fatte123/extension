<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Model\Data;

use Eighteentech\CustomApi\Api\Data\ItemsDetailsInterface;
use Magento\Framework\Model\AbstractExtensibleModel;

class ItemsDetails extends AbstractExtensibleModel implements ItemsDetailsInterface
{
    protected $itemID;
    protected $productID;
    protected $sku;
    protected $qty;
    protected $maxSaleQty;
    protected $name;
    protected $imageUrl;
    protected $configuration;
    protected $unitPrice;
    protected $unitMrp;
    protected $rowPrice;
    protected $rowMrp;
    protected $priceSavedInPercent;
    protected $errorInfos;
    protected $qtyOrdered;
    protected $qtyCancelled;
    protected $option;
    protected $extensionAttributes;
    protected $wishlistItemId;
    protected $inStock;

    /**
     * {@inheritdoc}
     */
    public function getItemId()
    {
        return $this->itemID;
    }

    /**
     * {@inheritdoc}
     */
    public function getProductId()
    {
        return $this->productID;
    }

    /**
     * {@inheritdoc}
     */
    public function getSku()
    {
        return $this->sku;
    }

    /**
     * {@inheritdoc}
     */
    public function getQty()
    {
        return $this->qty;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxSaleQty()
    {
        return $this->maxSaleQty;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * {@inheritdoc}
     */
    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    /**
     * {@inheritdoc}
     */
    public function getConfiguration()
    {
        return $this->configuration;
    }

    /**
     * {@inheritdoc}
     */
    public function getUnitPrice()
    {
        return $this->unitPrice;
    }

    /**
     * {@inheritdoc}
     */
    public function getUnitMrp()
    {
        return $this->unitMrp;
    }

    /**
     * {@inheritdoc}
     */
    public function getRowPrice()
    {
        return $this->rowPrice;
    }

    /**
     * {@inheritdoc}
     */
    public function getRowMrp()
    {
        return $this->rowMrp;
    }

    /**
     * {@inheritdoc}
     */
    public function getPriceSavedInPercent()
    {
        return $this->priceSavedInPercent;
    }

    /**
     * {@inheritdoc}
     */
    public function getInStock()
    {
        return $this->inStock;
    }

    /**
     * {@inheritdoc}
     */
    public function getIsFree()
    {
        return $this->isFree;
    }

    /**
     * {@inheritdoc}
     */
    public function getErrorInfos()
    {
        return $this->errorInfos;
    }

    /**
     * {@inheritdoc}
     */
    public function setItemId($itemID)
    {
        $this->itemID = $itemID;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setProductId($productID)
    {
        $this->productID = $productID;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setSku($sku)
    {
        $this->sku = $sku;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setQty($qty)
    {
        $this->qty = $qty;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setMaxSaleQty($maxSaleQty)
    {
        $this->maxSaleQty = $maxSaleQty;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setConfiguration($configuration)
    {
        $this->configuration = $configuration;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setUnitPrice($unitPrice)
    {
        $this->unitPrice = $unitPrice;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setUnitMrp($unitMrp)
    {
        $this->unitMrp = $unitMrp;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setRowPrice($rowPrice)
    {
        $this->rowPrice = $rowPrice;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setRowMrp($rowMrp)
    {
        $this->rowMrp = $rowMrp;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setPriceSavedInPercent($priceSavedInPercent)
    {
        $this->priceSavedInPercent = $priceSavedInPercent;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setInStock($inStock)
    {
        $this->inStock = $inStock;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setIsFree($isFree)
    {
        $this->isFree = $isFree;
        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setErrorInfos($errorInfos)
    {
        $this->errorInfos = $errorInfos;
        return $errorInfos;
    }

    /**
     * {@inheritdoc}
     *
     * @return \Eighteentech\CustomApi\Api\Data\ItemsDetailsExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * {@inheritdoc}
     *
     * @param \Eighteentech\CustomApi\Api\Data\ItemsDetailsExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(\Eighteentech\CustomApi\Api\Data\ItemsDetailsExtensionInterface $extensionAttributes)
    {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * @inheritDoc
     */
    public function getQtyOrdered()
    {
        return $this->qtyOrdered;
    }

    /**
     * @inheritDoc
     */
    public function getQtyCancelled()
    {
        return $this->qtyCancelled;
    }

    /**
     * @inheritDoc
     */
    public function getOption()
    {
        return $this->option;
    }

    /**
     * @inheritDoc
     */
    public function setQtyOrdered($qtyOrdered)
    {
        $this->qtyOrdered = $qtyOrdered;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function setQtyCancelled($qtyCancelled)
    {
        $this->qtyCancelled = $qtyCancelled;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function setOption($option)
    {
        $this->option = $option;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getWishlistItemId()
    {
        return $this->wishlistItemId;
    }

    /**
     * @inheritDoc
     */
    public function setWishlistItemId($wishlistItemId)
    {
        $this->wishlistItemId = $wishlistItemId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getPostData()
    {
        return $this->postData;
    }

    /**
     * @inheritDoc
     */
    public function setPostData($postData)
    {
        $this->postData = $postData;
        return $this;
    }
}
