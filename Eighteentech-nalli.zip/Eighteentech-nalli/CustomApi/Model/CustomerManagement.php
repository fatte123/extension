<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category CustomerManagement
 * @package  CustomerManagement_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Model;

use Eighteentech\CustomApi\Api\CustomerManagementInterface;
use Magento\Wishlist\Model\WishlistFactory;
use Eighteentech\CustomApi\Api\Data\WishlistDetailsInterfaceFactory;
use Eighteentech\CustomApi\Api\Data\WishlistResponseInterfaceFactory;
use Eighteentech\CustomApi\Api\Data\ItemsDetailsInterfaceFactory;
use Eighteentech\CustomApi\Helper\Product;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Eighteentech\CustomApi\Api\Data\ErrorMessageDetailsInterfaceFactory;

class CustomerManagement implements CustomerManagementInterface
{
    
    protected $_wishlist;
    protected $_wishlistDetails;
    protected $_wishlistResponse;
    protected $_itemsDetails;
    protected $_productHelper;
    protected $_productRepository;
    protected $_messageDetails;

    public function __construct(
        WishlistFactory $wishlist,
        WishlistDetailsInterfaceFactory $wishlistDetails,
        WishlistResponseInterfaceFactory $wishlistResponse,
        ItemsDetailsInterfaceFactory $itemsDetails,
        Product $productHelper,
        ProductRepositoryInterface $productRepository,
        ErrorMessageDetailsInterfaceFactory $messageDetails
    ) {
        $this->_wishlist = $wishlist;
        $this->_wishlistDetails = $wishlistDetails;
        $this->_wishlistResponse = $wishlistResponse;
        $this->_itemsDetails = $itemsDetails;
        $this->_productHelper = $productHelper;
        $this->_productRepository = $productRepository;
        $this->_messageDetails = $messageDetails;
    }

    public function getWishlistItems($customerId)
    {
        $result = $this->_wishlistDetails->create();
        $result->setStatus(false);
        try {
            $response = $this->_wishlistResponse->create();
            $wishlistItemDetails = [];
            try {
                $wishlistCollection = $this->_wishlist->create()->loadByCustomerId($customerId, true)
                ->getItemCollection();
                $response->setWishlistCount(0);
                if (count($wishlistCollection) > 0) {
                    $response->setWishlistCount(count($wishlistCollection));
                    foreach ($wishlistCollection as $item) {
                        $product = $this->_productRepository->getById($item->getProduct()->getId());
                        $finalPrice = $product->getPriceInfo()->getPrice('final_price')->getAmount()->getValue();
                        $originalPrice = $product->getPriceInfo()->getPrice('regular_price')->getAmount()->getValue();

                        $itemDetails = $this->_itemsDetails->create();
                        $itemDetails->setWishlistItemId($item->getId());
                        $itemDetails->setProductId($item->getProduct()->getId());
                        $itemDetails->setSku($item->getProduct()->getSku());
                        $itemDetails->setName($item->getProduct()->getName());
                        $itemDetails->setImageUrl($this->_productHelper->getImageUrl($item->getProduct()->getImage()));
                        $itemDetails->setUnitPrice($finalPrice);
                        $itemDetails->setUnitMrp($originalPrice);
                        $itemDetails->setPostData('test');
                        $itemDetails->setIsFree(false);

                        $itemDetails->setPriceSavedInPercent(0);
                        if ($finalPrice < $originalPrice) {
                            $priceSavedInPercent = 100 - round(($finalPrice / $originalPrice) * 100);
                            $itemDetails->setPriceSavedInPercent($priceSavedInPercent);
                        }
                        $itemDetails->setInStock(true);
                        if (!$product->isSaleable()) {
                            $itemDetails->setInStock(false);
                            $errorInfos = [];
                            $errorInfo = $this->_messageDetails->create();
                            $errorInfo->setProductOutOfStockMessage(__('This product is out of stock.'));
                            $errorInfos[] = $errorInfo;
                            $itemDetails->setErrorInfos($errorInfos);
                        }
                        $wishlistItemDetails[] = $itemDetails;
                    }
                }
                $response->setWishlistItems($wishlistItemDetails);
            } catch (\Exception $e) {
                $result->setMessage(__($e->getMessage()));
                return $result;
            }
            $result->setStatus(true);
            $result->setResponse($response);
            return $result;
        } catch (\Exception $e) {
            $result->setMessage(__($e->getMessage()));
            return $result;
        }
    }

    public function removeWishlistItem($customerId, $itemId)
    {
        $result = $this->_wishlistDetails->create();
        $result->setStatus(false);
        try {
            $wishlist = $this->_wishlist->create()->loadByCustomerId($customerId, true);
            $wishlistItem = $wishlist->getItem($itemId);
            
            if (!$wishlistItem) {
                $result->setMessage(__("Invalid item ID given."));
                return $result;
            }
            $sku = $wishlistItem->getProduct()->getSku();

            $wishlistItem->delete();
            $wishlist->save();
            $result->setStatus(true);
            $result->setMessage(__("Wishlist item removed successfully."));
            $response = $this->_wishlistResponse->create();
            $response->setSku($sku);
            $result->setResponse($response);
            return $result;
        } catch (\Exception $e) {
            $result->setMessage(__($e->getMessage()));
            return $result;
        }
    }
}
