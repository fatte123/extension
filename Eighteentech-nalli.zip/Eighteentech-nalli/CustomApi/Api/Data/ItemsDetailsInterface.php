<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */

namespace Eighteentech\CustomApi\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface ItemsDetailsInterface extends ExtensibleDataInterface
{

    /**
     * Get item ID
     *
     * @return int|null
     */
    public function getItemId();

    /**
     * Get wishlist item ID
     *
     * @return int|null
     */
    public function getWishlistItemId();

    /**
     * Get product ID
     *
     * @return int|null
     */
    public function getProductId();

    /**
     * Returns the product SKU.
     *
     * @return string|null Product SKU.
     */
    public function getSku();

    /**
     * Returns the post data.
     *
     * @return string|null post data.
     */
    public function getPostData();

    /**
     * Returns the product quantity.
     *
     * @return float|null Product quantity.
     */
    public function getQty();

    /**
     * Returns the product maximum sale quantity.
     *
     * @return float|null Product maximum sale quantity.
     */
    public function getMaxSaleQty();

    /**
     * Returns the product name.
     *
     * @return string|null Product name
     */
    public function getName();

    /**
     * Returns the image URL.
     *
     * @return string|null image URL
     */
    public function getImageUrl();

    /**
     * Returns the configuration.
     *
     * @return \Eighteentech\CustomApi\Api\Data\ConfigurableAttributeInterface[]|null configuration
     */
    public function getConfiguration();

    /**
     * Returns the product unit price.
     *
     * @return float|null Product unit price.
     */
    public function getUnitPrice();

    /**
     * Returns the product unit MRP.
     *
     * @return float|null Product unit MRP.
     */
    public function getUnitMrp();

    /**
     * Returns the row price.
     *
     * @return float|null row price.
     */
    public function getRowPrice();

    /**
     * Returns the row MRP.
     *
     * @return float|null row MRP.
     */
    public function getRowMrp();

    /**
     * Returns the price saved in percent
     *
     * @return int|null price saved in percent.
     */
    public function getPriceSavedInPercent();

    /**
     * Get in stock
     *
     * @return boolean|null
     */
    public function getInStock();

    /**
     * Get is free
     *
     * @return boolean|null
     */
    public function getIsFree();

    /**
     * Return the error info
     *
     * @return \Eighteentech\CustomApi\Api\Data\ErrorMessageDetailsInterface[]|null error info.
     */
    public function getErrorInfos();

    /**
     * Get quantity ordered
     *
     * @return int|null
     */
    public function getQtyOrdered();

    /**
     * Get quantity cancelled
     *
     * @return int|null
     */
    public function getQtyCancelled();

    /**
     * Get option
     *
     * @return string|null
     */
    public function getOption();

    /**
     * Returns the extension attributes
     *
     * @return \Eighteentech\CustomApi\Api\Data\ItemsDetailsExtensionInterface|null extension attributes.
     */
    public function getExtensionAttributes();

    /**
     * Set item ID
     *
     * @param int|null $itemID
     * @return $this
     */
    public function setItemId($itemID);

    /**
     * Set wishlist item ID
     *
     * @return $this
     */
    public function setWishlistItemId($wishlistItemId);

    /**
     * Set product ID
     *
     * @param int|null $productID
     * @return $this
     */
    public function setProductId($productID);

    /**
     * Sets the product SKU.
     *
     * @param string|null $sku
     * @return $this
     */
    public function setSku($sku);

    /**
     * Sets the product SKU.
     *
     * @param string|null $sku
     * @return $this
     */
    public function setPostData($postData);

    /**
     * Sets the product quantity.
     *
     * @param float|null $qty
     * @return $this
     */
    public function setQty($qty);

    /**
     * Sets the product maximum sale quantity.
     *
     * @param float|null $maxSaleQty
     * @return $this
     */
    public function setMaxSaleQty($maxSaleQty);

    /**
     * Sets the product name.
     *
     * @param string|null $name
     * @return $this
     */
    public function setName($name);

    /**
     * Sets the product image URL.
     *
     * @param string|null $imageUrl
     * @return $this
     */
    public function setImageUrl($imageUrl);

    /**
     * Sets the configuration.
     *
     * @param \Eighteentech\CustomApi\Api\Data\ConfigurableAttributeInterface[]|null $configuration
     * @return $this
     */
    public function setConfiguration($configuration);

    /**
     * Sets the product unit price.
     *
     * @param float|null $unitPrice
     * @return $this
     */
    public function setUnitPrice($unitPrice);

    /**
     * Sets the product unit MRP.
     *
     * @param float|null $unitMrp
     * @return $this
     */
    public function setUnitMrp($unitMrp);

    /**
     * Sets the row price.
     *
     * @param float|null $rowPrice
     * @return $this
     */
    public function setRowPrice($rowPrice);

    /**
     * Sets the row MRP.
     *
     * @param float|null $rowMrp
     * @return $this
     */
    public function setRowMrp($rowMrp);

    /**
     * Sets the price saved in percent.
     *
     * @param int|null $priceSavedInPercent
     * @return $this
     */
    public function setPriceSavedInPercent($priceSavedInPercent);

    /**
     * Set in stock
     *
     * @return $this
     */
    public function setInStock($inStock);

    /**
     * Set is free
     *
     * @return $this
     */
    public function setIsFree($isFree);

    /**
     * Sets the error info.
     *
     * @param \Eighteentech\CustomApi\Api\Data\ErrorMessageDetailsInterface[]|null $errorInfos
     * @return $this
     */
    public function setErrorInfos($errorInfos);

    /**
     * Set quantity ordered
     *
     * @return $this
     */
    public function setQtyOrdered($qtyOrdered);

    /**
     * Set quantity cancelled
     *
     * @return $this
     */
    public function setQtyCancelled($qtyCancelled);

    /**
     * Set option
     *
     * @return $this
     */
    public function setOption($option);

    /**
     * Sets the extension attributes
     *
     * @param \Eighteentech\CustomApi\Api\Data\ItemsDetailsExtensionInterface
     * @return $this
     */
    public function setExtensionAttributes(ItemsDetailsExtensionInterface $extensionAttributes);
}
