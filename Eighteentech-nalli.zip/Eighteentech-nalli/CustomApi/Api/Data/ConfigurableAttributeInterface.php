<?php

namespace Eighteentech\CustomApi\Api\Data;

interface ConfigurableAttributeInterface
{
    /**
     * Get attribute ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set attribute ID
     *
     * @param int|null $id
     * @return $this
     */
    public function setId($id);

    /**
     * Get attribute code
     *
     * @return string
     */
    public function getCode();

    /**
     * Set attribute code
     *
     * @param string|null $code
     * @return $this
     */
    public function setCode($code);

    /**
     * Get attribute label
     *
     * @return string
     */
    public function getLabel();

    /**
     * Set attribute label
     *
     * @param string|null $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * Get in stock options
     *
     * @return \Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterface[]|null
     */
    public function getInStockOptions();

    /**
     * Set in stock options
     *
     * @param \Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterface[]|null $inStockOptions
     * @return $this
     */
    public function setInStockOptions($inStockOptions);

    /**
     * Get out of stock options
     *
     * @return \Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterface[]|null
     */
    public function getOutOfStockOptions();

    /**
     * Set out of stock options
     *
     * @param \Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterface[]|null $outOfStockOptions
     * @return $this
     */
    public function setOutOfStockOptions($outOfStockOptions);

    /**
     * Get an array of in stock configurable options for cart items
     *
     * @return \Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterface[]|null
     */
    public function getOptions();

    /**
     * Set in stock options for cart items
     *
     * @return $this
     */
    public function setOptions($options);
}
