<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api\Data\Product;

interface ImageInterface
{

    const IMAGE_URL = 'url';
    const HEIGHT = 'height';
    const WIDTH = 'width';

    /**
     * Get URL
     *
     * @return string|null
     */
    public function getUrl();

    /**
     * Set URL
     *
     * @param string $url
     * @return $this
     */
    public function setUrl($url);

    /**
     * Retrieve image height
     *
     * @return float
     */
    public function getHeight();

    /**
     * Set original image height in px
     *
     * @param string $height
     * @return float
     */
    public function setHeight($height);

    /**
     * Get original image width
     *
     * @return float
     * @since 101.1.0
     */
    public function getWidth();

    /**
     * Set image width in px
     *
     * @param string $width
     * @return float
     */
    public function setWidth($width);
}
