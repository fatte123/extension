<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api\Data;

interface ErrorMessageDetailsInterface
{

    /**
     * Return the product out of stock error message
     *
     * @return string|null out of stock error message.
     */
    public function getProductOutOfStockMessage();

    /**
     * Sets the product out of stock error message
     *
     * @param string|null $productOutOfStockMessage
     * @return $productOutOfStockMessage
     */
    public function setProductOutOfStockMessage($productOutOfStockMessage);

    /**
     * Return the size out of stock error message
     *
     * @return string|null out of stock error message.
     */
    public function getSizeOutOfStockMessage();

    /**
     * Sets the size out of stock error message
     *
     * @param string|null $sizeOutOfStockMessage
     * @return $sizeOutOfStockMessage
     */
    public function setSizeOutOfStockMessage($sizeOutOfStockMessage);

    /**
     * Return the quantity not available error message
     *
     * @return string|null  quantity not available error message.
     */
    public function getQtyNotAvailableMessage();

    /**
     * Sets the quantity not available error message
     *
     * @param string|null $qtyNotAvailableMessage
     * @return $qtyNotAvailableMessage
     */
    public function setQtyNotAvailableMessage($qtyNotAvailableMessage);

    /**
     * Return the max allowed quantity exceeded error message
     *
     * @return string|null max allowed quantity exceeded error message.
     */
    public function getMaxAllowedQtyExceededMessage();

    /**
     * Sets the max allowed quantity exceeded error message
     *
     * @param string|null $maxAllowedQtyExceededMessage
     * @return $maxAllowedQtyExceededMessage
     */
    public function setMaxAllowedQtyExceededMessage($maxAllowedQtyExceededMessage);
}
