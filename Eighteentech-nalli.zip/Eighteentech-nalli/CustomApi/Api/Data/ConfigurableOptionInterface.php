<?php


namespace Eighteentech\CustomApi\Api\Data;

interface ConfigurableOptionInterface
{
    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set ID
     *
     * @param int|null $id
     * @return $this
     */
    public function setId($id);

    /**
     * Get label
     *
     * @return string
     */
    public function getLabel();

    /**
     * Set label
     *
     * @param string|null $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * Get selected option status
     *
     * @return boolean|null
     */
    public function getIsSelectedOption();

    /**
     * Set selected option status
     *
     * @param boolean|null $status
     * @return $this
     */
    public function setIsSelectedOption($status);

    /**
     * Get max sale qty
     *
     * @return int|null
     */
    public function getMaxSaleQty();

    /**
     * Set max sale qty
     *
     * @param int|null $maxSaleQty
     * @return $this
     */
    public function setMaxSaleQty($maxSaleQty);
}
