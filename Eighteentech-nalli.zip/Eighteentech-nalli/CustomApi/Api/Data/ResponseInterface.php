<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */

namespace Eighteentech\CustomApi\Api\Data;

interface ResponseInterface
{

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus();

    /**
     * Get message
     *
     * @return string|null
     */
    public function getMessage();

    /**
     * Set status
     *
     * @param boolean $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Set message
     *
     * @param string|null $message
     * @return $this
     */
    public function setMessage($message);

    /**
     * Get response
     *
     * @return \Eighteentech\CustomApi\Api\Data\ResultInterface|null
     */
    public function getResponse();

    /**
     * Set response
     *
     * @param \Eighteentech\CustomApi\Api\Data\ResultInterface|null $response
     * @return $this
     */
    public function setResponse($response);
}
