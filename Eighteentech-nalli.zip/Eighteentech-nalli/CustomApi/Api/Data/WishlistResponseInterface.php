<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api\Data;

interface WishlistResponseInterface
{
    /**
     * Get wishlist count
     *
     * @return int|null
     */
    public function getWishlistCount();

    /**
     * Set wishlist count
     *
     * @return $this
     */
    public function setWishlistCount($wishlistCount);

    /**
     * Get wishlist items details
     *
     * @return \Eighteentech\CustomApi\Api\Data\ItemsDetailsInterface[]|null
     */
    public function getWishlistItems();

    /**
     * Set wishlist items details
     *
     * @return $this
     */
    public function setWishlistItems($wishlistItemDetails);

    /**
     * Get Sku
     *
     * @return string|null
     */
    public function getSku();

    /**
     * Set Sku
     * @param string $sku
     * @return $this
     *
     */
    public function setSku($sku);
}
