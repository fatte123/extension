<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api\Data;

interface WishlistDetailsInterface
{
    /**
     * Get status
     *
     * @return boolean|null
     */
    public function getStatus();

    /**
     * Set status
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get message
     *
     * @return string|null
     */
    public function getMessage();

    /**
     * Set message
     *
     * @return $this
     */
    public function setMessage($message);

    /**
     * Get response
     *
     * @return \Eighteentech\CustomApi\Api\Data\WishlistResponseInterface|null
     */
    public function getResponse();

    /**
     * Set response
     *
     * @return $this
     */
    public function setResponse($response);
}
