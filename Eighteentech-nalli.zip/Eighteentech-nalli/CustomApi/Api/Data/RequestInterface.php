<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api\Data;

interface RequestInterface
{

    /**
     *  Get URL Key
     *
     * @return string
     */
    public function getUrlKey();

    /**
     * Set URL Key
     *
     * @api
     * @param string $urlKey
     */
    public function setUrlKey($urlKey);
    
    /**
     * Get Sort Information
     *
     * @return string|null
     */
    public function getSortBy();

    /**
     * Set Sort Information
     *
     * @api
     * @param string|null $sortBy
     */
    public function setSortBy($sortBy);
    
     /**
      * Get Sort by direction
      *
      * @return string|null
      */
    public function getSortDirection();

    /**
     * Set Sort by direction
     *
     * @api
     * @param string|null $direction
     */
    public function setSortDirection($direction);

    /**
     * Get Product limit
     *
     * @return int|null
     */
    public function getLimit();

    /**
     * Set Product limit
     *
     * @api
     * @param int|null $limit
     */
    public function setLimit($limit);

    /**
     * Get Product pagination
     *
     * @return int|null
     */
    public function getPage();

    /**
     * Set Product pagination
     *
     * @api
     * @param int|null $page
     */
    public function setPage($page);

    /**
     *  Get Search Parameter
     *
     * @return string|null
     */
    public function getSearchQuery();

    /**
     * Set Search Parameter
     *
     * @api
     * @param string|null $searchParam
     */
    public function setSearchQuery($searchParam);
    
     /**
      *  Get Store Id
      *
      * @return int|null
      */
    public function getStoreId();

    /**
     * Set Store Id
     *
     * @api
     * @param int|null $storeId
     */
    public function setStoreId($storeId);
    
    /**
     *  Get API Calling Source
     *
     * @return string|null
     */
    public function getSource();

    /**
     * Set API Calling Source
     *
     * @api
     * @param string|null $source
     */
    public function setSource($source);
    
    /**
     * Get SKU for Sorting
     *
     * @return string|null
     */
    public function getSku();

    /**
     * Set SKU for Sorting
     *
     * @api
     * @param string|null $sku
     */
    public function setSku($sku);
    
    /**
     * Get Customer Id
     *
     * @return int|null
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @api
     * @param int|null $customerId
     */
    public function setCustomerId($customerId);
    
     /**
      * Get Image size
      *
      * @return mixed|null
      */
    public function getImageSize();

    /**
     * Set Image size
     *
     * @api
     * @param mixed|null $imageSize
     */
    public function setImageSize($imageSize);
}
