<?php

namespace Eighteentech\CustomApi\Api;

interface ConfigurableProductManagementInterface
{

    /**
     * Get options of an Configurable product
     *
     * @api
     *
     * @param int $productId
     * @param int|null $includeOutOfStockOptions
     * @return \Eighteentech\CustomApi\Api\Data\ConfigurableOptionsDetailsInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\InputException
     */
    public function getAvailableOptions($productId, $includeOutOfStockOptions = null);
}
