<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api;

interface CustomerManagementInterface
{
    /**
     * Get no of items in wishlist
     *
     * @api
     * @param int $customerId
     * @return \Eighteentech\CustomApi\Api\Data\WishlistDetailsInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\InputException
     */
    public function getWishlistItems($customerId);

    /**
     * Remove wishlist item
     *
     * @api
     * @param int $customerId
     * @param int $itemId
     * @return \Eighteentech\CustomApi\Api\Data\WishlistDetailsInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\InputException
     */
    public function removeWishlistItem($customerId, $itemId);
}
