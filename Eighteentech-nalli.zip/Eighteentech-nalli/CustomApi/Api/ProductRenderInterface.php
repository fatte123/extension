<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Api;

/**
 * Interface which provides Product information and Layered Navigation
 * @api
 * @since 101.1.0
 */
interface ProductRenderInterface
{

    /**
     * To Fetch product Information
     *
     * @api
     * @param \Eighteentech\CustomApi\Api\Data\RequestInterface $request
     * @param int|null $customerId
     * @return \Eighteentech\CustomApi\Api\Data\ResponseInterface
     */
    public function getList(\Eighteentech\CustomApi\Api\Data\RequestInterface $request, $customerId = null);

    /**
     * To Fetch Layered Navigation Information
     *
     * @api
     * @param \Eighteentech\CustomApi\Api\Data\RequestInterface $request
     * @return \Eighteentech\CustomApi\Api\Data\ResponseInterface
     */
    public function getFilterItems(\Eighteentech\CustomApi\Api\Data\RequestInterface $request);
}
