<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */
 
namespace Eighteentech\CustomApi\Helper;

use Magento\Framework\App\Helper;
use Magento\Review\Model\ReviewFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Data\Form\FormKey;
use Magento\Catalog\Helper\ImageFactory;
use Eighteentech\CustomApi\Api\Data\Product\ImageInterfaceFactory;
use Magento\Checkout\Helper\Cart;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\App\State;
use Magento\Framework\View\DesignInterface;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Model\Product\Url;
use Magento\Store\Model\ScopeInterface;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Filesystem\DirectoryList;
use \Magento\Framework\Filesystem\Driver\File;
use Magento\Eav\Model\ResourceModel\Entity\Attribute as EavAttribute;

class Product extends Helper\AbstractHelper
{
    const DEFAULT_PAGE = 1;

    private $formKey;
    private $reviewFactory;
    private $imageFactory;
    private $CustomApiFactory;
    private $cartHelper;
    private $priceCurrency;
    private $storeManager;
    private $interval = [];
    private $state;
    private $design;
    private $attributeSet;
    private $productUrlModel;
    
    private $productCollectionFactory;
    protected $quoteRepository;
    protected $quoteIdMaskFactory;
    protected $_wishlist;
    private $_productRepository;
    private $_directory;
    protected $fileDriver;
    private $_eavAttribute;

    const XML_PATH_ONE_PRICE_INTERVAL = 'catalog/layered_navigation/one_price_interval';
    const XML_PATH_PRODUCT_LIMIT_ON_GRID = 'catalog/frontend/grid_per_page';

    public function __construct(
        Helper\Context $context,
        FormKey $formKey,
        ReviewFactory $reviewFactory,
        ImageFactory $imageFactory,
        ImageInterfaceFactory $CustomApi,
        Cart $cartHelper,
        PriceCurrencyInterface $priceCurrency,
        StoreManagerInterface $storeManager,
        State $state,
        DesignInterface $design,
        AttributeSetRepositoryInterface $attributeSet,
        Url $productUrlModel,
        CollectionFactory $productCollection,
        CartRepositoryInterface $quoteRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        WishlistFactory $wishlist,
        ProductRepository $productRepository,
        DirectoryList $directory,
        File $fileDriver,
        EavAttribute $eavAttribute
    ) {
        $this->formKey = $formKey;
        $this->reviewFactory = $reviewFactory;
        $this->imageFactory = $imageFactory;
        $this->CustomApiFactory = $CustomApi;
        $this->cartHelper = $cartHelper;
        $this->priceCurrency = $priceCurrency;
        $this->storeManager = $storeManager;
        $this->state = $state;
        $this->design = $design;
        $this->attributeSet = $attributeSet;
        $this->productUrlModel = $productUrlModel;
        $this->productCollectionFactory = $productCollection;
        $this->quoteRepository = $quoteRepository;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->_wishlist = $wishlist;
        $this->_productRepository = $productRepository;
        $this->_directory = $directory;
        $this->fileDriver = $fileDriver;
        $this->_eavAttribute = $eavAttribute;
        
        parent::__construct($context);
    }

    public function getProductUrl($product)
    {
        return $this->productUrlModel->getUrl($product, ['_ignore_category' => true]);
    }

    public function getReviewSummary($product)
    {
        $this->reviewFactory->create()->getEntitySummary($product);
        return $product->getRatingSummary();
    }

    public function getCurrencyCode()
    {
        return $this->storeManager->getStore()->getCurrentCurrency()->getCode();
    }

    public function getAddToCartUrl($product)
    {
        return $this->cartHelper->getAddUrl($product);
    }

    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

 /*   public function getOfferImage($optionId)
    {
       $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $imageUrl = null;
        $imageName = $this->optionImageHelper->getAttrImageName($optionId);
        if ($imageName <> '') {
            $imageUrl = $mediaUrl.'attribute/'.$imageName;
        }
        return $imageUrl;
    }

    public function getOfferColorCode($optionId)
    {
        $color = '';
        $colorCode = $this->optionImageHelper->getAttrDescriptionName($optionId);
        if ($colorCode <> '') {
            $color = $colorCode;
        }
        return $color;
    }*/

   

    public function getImageUrl($image)
    {
        if ($image == 'no_selection') {
            return $this->imageFactory->create()->getDefaultPlaceholderUrl('image');
        }
        $store = $this->storeManager->getStore();
        $imageUrl = $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $image;
        return $imageUrl;
    }

    public function getAttributeSetName($product)
    {
        $attributeSet = $this->attributeSet->get($product->getAttributeSetId());
        return $attributeSet->getAttributeSetName();
    }

    public function renderRangeLabel($fromPrice, $toPrice)
    {
        $fromPrice = empty($fromPrice) ? 0 : $fromPrice * $this->getCurrencyRate();
        $toPrice = empty($toPrice) ? $toPrice : $toPrice * $this->getCurrencyRate();

        $formattedFromPrice = $this->priceCurrency->format($fromPrice, false);
        if ($toPrice === '') {
            return __('%1 and above', $formattedFromPrice);
        } elseif ($fromPrice == $toPrice && $this->getOnePriceIntervalValue()) {
            return $formattedFromPrice;
        } else {
            return __('%1 - %2', $formattedFromPrice, $this->priceCurrency->format($toPrice, false));
        }
    }

    public function emulateImageCreating(ProductInterface $product, $imageCode, $image, $designId = null)
    {
        if (isset($designId)) {
            $this->design->setDesignTheme($designId);
        } else {
            $this->design->setDefaultDesignTheme();
        }

        $imageHelper = $this->imageFactory->create();
        $imageHelper->init($product, $imageCode);
        $image->setUrl($imageHelper->getUrl());
        return $imageHelper;
    }

    public function canUseCanonicalTag()
    {
        return $this->scopeConfig->getValue(
            \Magento\Catalog\Helper\Category::XML_PATH_USE_CATEGORY_CANONICAL_TAG,
            ScopeInterface::SCOPE_STORE
        );
    }

    private function getOnePriceIntervalValue()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_ONE_PRICE_INTERVAL,
            ScopeInterface::SCOPE_STORE
        );
    }

    public function getProductLimit($limitFromRequest)
    {
        $limit = $this->scopeConfig->getValue(self::XML_PATH_PRODUCT_LIMIT_ON_GRID, ScopeInterface::SCOPE_STORE);
        if (isset($limitFromRequest) && ($limitFromRequest >= 1)) {
            $limit = (int)$limitFromRequest;
        }
        return $limit;
    }

    public function getPageSize($pageSize)
    {
        $page = self::DEFAULT_PAGE;
        if (isset($pageSize) && ($pageSize >= 1)) {
            $page = (int)$pageSize;
        }
        return $page;
    }

    public function getCurrencyRate()
    {
        $rate = $this->storeManager->getStore($this->storeManager->getStore()->getId())
            ->getCurrentCurrencyRate();
        if (!$rate) {
            $rate = 1;
        }
        return $rate;
    }

    public function getSortField($sort, $direction, $isSearchApplied)
    {
        $data = [];
        if (empty($sort)) {
            $sort = $isSearchApplied ? 'relevance' : $this->scopeConfig->getValue(
                \Magento\Catalog\Model\Config::XML_PATH_LIST_DEFAULT_SORT_BY,
                ScopeInterface::SCOPE_STORE
            );
        }
        if (empty($direction)) {
            $direction = $isSearchApplied ? 'desc' : 'asc';
        }
        $data['sort'] = $sort;
        $data['dir'] = $direction;
        return $data;
    }

    public function setInterval($interval)
    {
        $this->interval = $interval;
    }

    public function prepareData($key, $count, $filteredValues)
    {
        $values = [];
        if (isset($filteredValues['price'])) {
            $values = $filteredValues['price'];
        }
        list($from, $toInterval) = explode('_', $key);
        if ($from == '*') {
            $from = $this->getFrom($toInterval, '-' . $toInterval);
        }
        if ($toInterval == '*') {
            $toInterval = $this->getTo($toInterval, $from . '-');
        }

        $label = $this->renderRangeLabel($from, $toInterval);
        $value = $from . '-' . $toInterval;

        $canShow = false;
        if (in_array($value, $values)) {
            $canShow = true;
        }
        $data = [
            'label' => $label,
            'value' => $value,
            'count' => $count,
            'show' => $canShow
        ];
        return $data;
    }

    private function getFrom($from, $key)
    {
        $toInterval = '';
        $appliedInterval = $this->interval;
        if (array_key_exists($key, $appliedInterval)) {
            $interval = $appliedInterval[$key];
            if ($interval && is_numeric($interval[0]) && $interval[0] < $from) {
                $toInterval = $interval[0];
            }
        }
        return $toInterval;
    }

    private function getTo($from, $key)
    {
        $toInterval = '';
        $appliedInterval = $this->interval;
        if (array_key_exists($key, $appliedInterval)) {
            $interval = $appliedInterval[$key];
            if ($interval && is_numeric($interval[1]) && $interval[1] > $from) {
                $toInterval = $interval[1];
            }
        }
        return $toInterval;
    }

    public function getProductCollection($category)
    {
        return $this->productCollectionFactory->create()
            ->addCategoryFilter($category)
            ->addAttributeToFilter('status', Status::STATUS_ENABLED)
            ->addAttributeToSelect('*');
    }

    public function generateImageUrl($product, $imageCode, $storeId)
    {
        $this->storeManager->setCurrentStore($storeId);
        $this->design->setDefaultDesignTheme();

        $imageHelper = $this->imageFactory->create();
        $imageHelper->init($product, $imageCode);
        return $imageHelper;
    }

    public function getBaseUrl()
    {
        $store = $this->storeManager->getStore();
        return $store->getBaseUrl();
    }

    public function getQuoteFromMaskedId($quoteMaskedId)
    {
        $quoteIdMask = $this->quoteIdMaskFactory->create()->load($quoteMaskedId, 'masked_id');

        if ($quoteIdMask->getId()) {
            $quote = $this->quoteRepository->get($quoteIdMask->getQuoteId());
            return $quote;
        }

        return null;
    }

    public function getWishlistItemId($customerId, $productId)
    {
        $wishlistCollection = $this->_wishlist->create()->loadByCustomerId($customerId, true)->getItemCollection();

        if ($wishlistCollection) {
            foreach ($wishlistCollection as $item) {
                if ($item->getProduct()->getId() == $productId) {
                    return $item->getId();
                }
            }
        }

        return null;
    }

    public function getProductDetailsById($productId)
    {
        $product = $this->_productRepository->getById($productId);

        if ($product) {
            $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
            $placeholderPath = 'catalog/placeholder/image_placeholder';
            $productGalleryImages = [];

            $id = $product->getId();
            $name = $product->getName();
            $sku = $product->getSku();
            $shortDescription = $product->getShortDescription();
            $isSalable = $product->getIsSalable();
            $typeId = $product->getTypeId();

            $params['_ignore_category'] = true;
            $productUrl = $this->productUrlModel->getUrl($product, $params);

            // product images
            $imageHelper = $this->state->emulateAreaCode(
                'frontend',
                [$this, 'generateImageUrl'],
                [$product, 'upsell_products_list', 1]
            );
            $imageUrl = $imageHelper->getUrl();
            $productImage = ['url' => $imageUrl,
                            'width' => $imageHelper->getWidth(),
                            'height' => $imageHelper->getHeight()
                            ];

            foreach ($product->getMediaGalleryImages() as $galleryImage) {
                $image = $galleryImage->getFile();
                $checkImage = $this->_directory->getPath('media') . '/catalog/product' . $image;
                if ($this->fileDriver->isExists($fileName)) {
                    $productGalleryImages[] = $this->getImageUrl($image);
                } else {
                    $config = $this->storeManager->getStore()->getConfig($placeholderPath);
                    $productGalleryImages[] = $mediaUrl . 'catalog/product/placeholder' . $config;
                }
            }

            // price
            $priceSavedInPercent = 0;
            $finalPrice = $product->getPriceInfo()->getPrice('final_price')->getAmount()->getValue();
            $regularPrice = $product->getPriceInfo()->getPrice('regular_price')->getAmount()->getValue();
            if ($finalPrice < $regularPrice) {
                $priceSavedInPercent = 100 - round(($finalPrice / $regularPrice) * 100);
            }

            /* Set Product Label Section */
            $offerImageUrl = null;
            $optionLabel = null;
            $attributeSetName = $this->getAttributeSetName($product);
            $attributeSetName = str_replace(" ", "", $attributeSetName);
            $productAttributeCode = strtolower($attributeSetName) . "_" . 'offers';
            $attributeId = $this->_eavAttribute->getIdByCode(
                \Magento\Catalog\Model\Product::ENTITY,
                $productAttributeCode
            );

            if (!empty($attributeId)) {
                $attributeOptionlabel = $product->getAttributeText($productAttributeCode);
                if (!empty($attributeOptionlabel)) {
                    $attributeOptionText = strtolower($attributeOptionlabel);
                    $optionLabel = str_replace(" ", "-", $attributeOptionText);
                    $baseUrl = $this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
                    $offerImageUrl = $baseUrl . 'attribute/options/' . $optionLabel . '.png';
                }
            }
            /* Product Label Section end */

            $this->reviewFactory->create()->getEntitySummary($product, $this->storeManager->getStore()->getId());
            $ratingSummary = $product->getRatingSummary()->getRatingSummary();

            $result = [
                'id' => $id,
                'name' => $name,
                'sku' => $sku,
                'short_description' => $shortDescription,
                'is_salable' => $isSalable,
                'type_id' => $typeId,
                'url' => $productUrl,
                'image' => $productImage,
                'gallery_images' => $productGalleryImages,
                'regular_price' => $regularPrice,
                'final_price' => $finalPrice,
                'price_saved_in_percent' => $priceSavedInPercent,
                'offer_image_url' => $offerImageUrl,
                'offer_details' => ['offer_image_url' => $offerImageUrl, 'option_label' => $optionLabel],
                'rating' => $ratingSummary
            ];

            return $result;
        }

        return null;
    }
}
