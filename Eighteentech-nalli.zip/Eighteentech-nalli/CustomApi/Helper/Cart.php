<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_CustomApi
 *
 */

namespace Eighteentech\CustomApi\Helper;

use Magento\Framework\App\Helper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Url\Helper\Data;
use Magento\Authorization\Model\UserContextInterface;
use Magento\Quote\Api\GuestCartRepositoryInterfaceFactory;
use Magento\Catalog\Api\ProductRepositoryInterfaceFactory;
use Eighteentech\CustomApi\Api\Data\ConfigurableAttributeInterfaceFactory;
use Eighteentech\CustomApi\Api\Data\ConfigurableOptionInterfaceFactory;
use Eighteentech\CustomerLogin\Model\OtpFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteRepository\SaveHandler;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Model\ResourceModel\Quote\QuoteIdMask as QuoteIdMaskResource;
use Magento\Customer\Api\CustomerRepositoryInterfaceFactory;

class Cart extends Helper\AbstractHelper
{
    protected $_userContext;
    protected $_guestCartRepository;
    protected $_productRepository;
    protected $_configurableAttribute;
    protected $_configurableOption;
    protected $_otp;
    protected $quoteRepository;
    protected $quoteIdMaskFactory;
    protected $saveHandler;
    protected $quoteIdMaskResource;
    protected $customerRepository;
    protected $dataHelper;

    public function __construct(
        Context $context,
        UserContextInterface $userContext,
        GuestCartRepositoryInterfaceFactory $guestCartRepository,
        ProductRepositoryInterfaceFactory $productRepository,
        ConfigurableAttributeInterfaceFactory $configurableAttribute,
        ConfigurableOptionInterfaceFactory $configurableOption,
        OtpFactory $otp,
        CartRepositoryInterface $quoteRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        SaveHandler $saveHandler,
        QuoteIdMaskResource $quoteIdMaskResource,
        CustomerRepositoryInterfaceFactory $customerRepositoryFactory,
        Data $dataHelper
    ) {
        $this->_userContext = $userContext;
        $this->_guestCartRepository = $guestCartRepository;
        $this->_productRepository = $productRepository;
        $this->_configurableAttribute = $configurableAttribute;
        $this->_configurableOption = $configurableOption;
        $this->_otp = $otp;
        $this->dataHelper = $dataHelper;
        $this->quoteRepository = $quoteRepository;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->saveHandler = $saveHandler;
        $this->quoteIdMaskResource = $quoteIdMaskResource;
        $this->customerRepository = $customerRepositoryFactory->create();
        parent::__construct($context);
    }

    public function isAllowed($cartId)
    {
        $quote = $this->_guestCartRepository->create()->get($cartId);
        if ($quote->getCustomerId()) {
            return ($quote->getCustomerId() == $this->_userContext->getUserId()) ? true : false;
        }
        return true;
    }

    public function getDeleteUrl()
    {
        return $this->_getUrl('checkout/cart/delete');
    }

    public function getCurrentBase64Url()
    {
        return $this->dataHelper->getCurrentBase64Url();
    }

    public function getUsedProductOptions($product)
    {
        $productOptions = $product->getTypeInstance(true)->getOrderOptions($product);

        foreach ($product->getTypeInstance()->getConfigurableAttributes($product) as $attribute) {
            $configurationAttributeDetails = $this->_configurableAttribute->create();
            $productAttribute = $attribute->getProductAttribute();
            $attributeCode = $productAttribute->getAttributeCode();

            foreach ($product->getTypeInstance()->getUsedProducts($product, null) as $childProduct) {
                $childProduct = $this->_productRepository->create()->getById($childProduct->getId());

                $configurationAttributeDetails->setId($productAttribute->getId());
                $configurationAttributeDetails->setCode($attributeCode);
                $configurationAttributeDetails->setLabel($productAttribute->getStoreLabel($product->getStoreId()));

                if (!empty($productOptions['attributes_info'])) {
                    foreach ($productOptions['attributes_info'] as $option) {
                        $configurationOptionDetails = $this->getConfigurableOptionDetails(
                            $childProduct,
                            $attributeCode
                        );

                        if ($option['option_value'] == $childProduct->getData($attributeCode)) {
                            $configurationOptionDetails->setIsSelectedOption(true);
                        }

                        $options[] = $configurationOptionDetails;

                        if (($option['option_value'] != $childProduct->getData($attributeCode))
                        && ($childProduct->isSaleable() != 1)) {
                            array_pop($options);
                        }
                    }
                } else {
                    $options[] = $this->getConfigurableOptionDetails($childProduct, $attributeCode);

                    if ($childProduct->isSaleable() != 1) {
                        array_pop($options);
                    }
                }
                $configurationAttributeDetails->setOptions($options);
            }
            $configurationDetails[] = $configurationAttributeDetails;
        }
        return $configurationDetails;
    }

    private function getConfigurableOptionDetails($childProduct, $attributeCode)
    {
        $configurationOptionDetails = $this->_configurableOption->create();
        $configurationOptionDetails->setLabel($childProduct->getAttributeText($attributeCode));
        $configurationOptionDetails->setId($childProduct->getData($attributeCode));
        $configurationOptionDetails->setIsSelectedOption(false);
        return $configurationOptionDetails;
    }

    public function isMobileVerified($cartId, $mobile)
    {
        $oxOtpDetails = $this->_otp->create()->getCollection()->addFieldToFilter('otp_type', 'cod')
        ->addFieldToFilter('quote_id', $cartId)->addFieldToFilter('username', $mobile)
        ->addFieldToFilter('is_verified', 1);
        if (count($oxOtpDetails) > 0) {
            return true;
        }
        return false;
    }

    public function mergeCart($guestQuoteId, $customerId)
    {
        try {
            $guestQuoteIdMask = $this->quoteIdMaskFactory->create()->load($guestQuoteId, 'masked_id');
            $guestQuote = $this->quoteRepository->get($guestQuoteIdMask->getQuoteId());
            $userQuoteId = null;
            $maskQuoteId = null;

            if ($guestQuote) {
                try {
                    $customerQuote = $this->quoteRepository->getForCustomer($customerId);
                    $customerQuote->setStoreId(1);
                    $customerQuote->merge($guestQuote)->collectTotals();
                    $this->saveHandler->save($customerQuote);
                    $this->quoteRepository->delete($guestQuote);
                    $userQuoteId = $customerQuote->getId();
                } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
                    $guestQuote->setCustomer($this->customerRepository->getById($customerId));
                    $this->saveHandler->save($guestQuote);
                    $userQuoteId = $guestQuote->getId();
                }

                $quoteIdMask = $this->quoteIdMaskFactory->create();
                $maskQuoteDetails = $quoteIdMask->load($userQuoteId, 'quote_id');
                $maskQuoteId = $maskQuoteDetails->getMaskedId();

                if (empty($maskQuoteId)) {
                    $quoteIdMask->setQuoteId($userQuoteId)->save();
                    $maskQuoteId = $quoteIdMask->getMaskedId();
                }
                return $maskQuoteId;
            }
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {

            $customerQuote = $this->quoteRepository->getForCustomer($customerId);
            $customerQuoteId = $customerQuote->getId();

            $quoteIdMask = $this->quoteIdMaskFactory->create();
            $maskQuoteDetails = $quoteIdMask->load($customerQuoteId, 'quote_id');
            $maskQuoteId = $maskQuoteDetails->getMaskedId();

            if (empty($maskQuoteId)) { // for new quote
                $quoteIdMask->setQuoteId($customerQuoteId)->save();
                $maskQuoteId = $quoteIdMask->getMaskedId();
            }
            return $maskQuoteId;
        }
    }
}
