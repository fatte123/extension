<?php
namespace Eighteentech\Core\Controller\Index;

class Home extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	
	protected $resultJsonFactory;
	
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
		)
	{
		$this->_resultPageFactory = $pageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
		return parent::__construct($context);
	}
	
	public function execute()
	{
		$resultPage = $this->_resultPageFactory->create();
        $result = $this->_resultJsonFactory->create();
        $datainfo = $resultPage->getLayout()
                        ->createBlock(\Magento\Framework\View\Element\Template::class)
                         ->setTemplate('Magento_Cms::ajax_home.phtml')
                        ->toHtml();
                        
        $result->setData(['content' => $datainfo]);
         return $result;
	}
}
?>
