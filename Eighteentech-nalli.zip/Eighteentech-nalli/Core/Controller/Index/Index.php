<?php
namespace Eighteentech\Core\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	
	/**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface CookieManagerInterface
     */
    private $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory CookieMetadataFactory
     */
    private $cookieMetadataFactory;
	
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
 		\Magento\Store\Model\StoreManagerInterface $storeManager
	) {
		$this->_pageFactory = $pageFactory;
		$this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
		$this->scopeConfig = $scopeConfig;
 		$this->storeManager = $storeManager;
		return parent::__construct($context);
	}

	public function execute()
	{
		if($this->getConfigValue()) {
		   /* '.nalli.com',*/
		$domains = [
			'.www.nalli.com',
			'.mcstaging.nalli.com',
			'mcstaging.nalli.com',
			'.mcprod.nalli.com',
			'mcprod.nalli.com'
		];
		if(!empty($domains)){
			foreach($domains as $domain){
				setcookie(
		            'PHPSESSID',
		            'expire',
		            [
		                'expires' => 1,
		                'path' => '/',
		                'domain' => $domain,
		                'secure' => true,
		                'httponly' => true,
		                'samesite' => 'Lax'
		            ]
		        );
			}
		}
			die("done");
		} else {
			die("nalli.com");
		}
       
		
	}
	public function getConfigValue() {
		
	 return $this->scopeConfig->getValue("core_config/general/enable_phpsession",\Magento\Store\Model\ScopeInterface::SCOPE_STORE,$this->storeManager->getStore()->getStoreId());
	 
	}
}
