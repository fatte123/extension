<?php

namespace Eighteentech\Core\Plugin\Helper;


use Magento\CatalogInventory\Model\ResourceModel\Stock\StatusFactory;
class Stock
{    
private $logger;
protected $_registry;
protected $request;
protected $stockStatusResource;
protected $stockStatusFactory;
public function __construct(
    \Psr\Log\LoggerInterface $logger,
    \Magento\Framework\Registry $registry,
    \Magento\Framework\App\Request\Http $request,
    StatusFactory $stockStatusFactory
) {
    $this->logger = $logger;
    $this->_registry = $registry;
    $this->request = $request;
    $this->stockStatusFactory  = $stockStatusFactory;
}
public function aroundAddIsInStockFilterToCollection(\Magento\CatalogInventory\Helper\Stock $subject, \Closure $proceed, $collection)
{
    try{
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/customlog.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);        		     
		$logger->info('text message');		
		
        $category = $this->_registry->registry('current_category');//get current category
       
        $currentPage = $this->request->getFullActionName(); //catalogsearch_result_index
         
        $logger->info('$currentPage->'.$currentPage);
        if(!is_null($category) && $currentPage!= 'catalogsearch_result_index')
        {
            $stockFlag = 'has_stock_status_filter';
          $categoryId = $category->getId();
        $parentCategoryId =  $category->getParentCategory()->getId();                     
              
            	             
            if($categoryId == 825 || $parentCategoryId == 825)
            {
            $resource = $this->getStockStatusResource();                
                $resource->addStockDataToCollection(
                        $collection,
                        false
                ); 
            }
            $collection->setFlag($stockFlag, true);
        } 
        return $this;
    }catch(\Exception $e){
        return $e->getMessage();
        $this->logger->info('--exception--'.$e->getMessage());
    }
}

public function getStockStatusResource(){
    if (empty($this->stockStatusResource)) {
        $this->stockStatusResource = $this->stockStatusFactory->create();
    }
    return $this->stockStatusResource;
   }
}
