<?php

namespace Eighteentech\Core\Plugin;


use Magento\Catalog\Model\Layer as CatalogLayer;
use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollection;

class CatalogInventoryLayer {
	
	protected $_logger;
	public function __construct( 
		\Psr\Log\LoggerInterface $logger
		){
			$this->_logger = $logger;
		}
	public function aroundPrepareProductCollection(CatalogLayer $subject, \Closure $proceed, $collection)
	{
  
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/customlog.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        		     
		$categoryId = $subject->getCurrentCategory()->getId();
		$logger->info('text message');
		
		$proceed($collection);
		if ($categoryId == 825){
			$collection->getSelect()->joinLeft(
					 ['_inventory_table' => 'cataloginventory_stock_item'], 
					 "_inventory_table.product_id = e.entity_id", ['is_in_stock']
			);
			$collection->addFieldToFilter('is_in_stock',array('eq'=>'0'));
			$logger->info('fdgfdg-$categoryId->'.$categoryId);    
		}       

		return $this;
    }
}
