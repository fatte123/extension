<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_Core
 *
 */
 
namespace Eighteentech\Core\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Customer\Helper\View as CustomerViewHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\ConfigInterface;
use Magento\CustomerBalance\Model\BalanceFactory;
use Magento\Framework\Pricing\Helper\Data as pricingHelper;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\Product as ProductModel;
use Magento\Catalog\Model\Product\Option;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const STORE_PHONE_NUMBER = 'general/store_information/phone';
    protected $_customerSession;
    protected $httpContext;
    protected $objectManager;
    protected $wishlist;
    protected $_customerViewHelper;
    protected $_scopeConfig;
    protected $timezone;
	protected $Option;
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product
     */
    protected $resourceProduct;
    /**
     * @var \Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable
     */
    protected $resourceConfigurable;
    protected $_productRepository;
    protected $_balanceFactory;
    protected $_pricingHelper;
    protected $_currentCustomer;
    protected $storeManager;
    protected $productModel;
   
    public function __construct(
        Context $context,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Wishlist\Model\Wishlist $wishlist,
        CustomerViewHelper $customerViewHelper,
        ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        ConfigInterface $salesConfig,
        \Magento\GiftCardAccount\Helper\Data $giftCardAccountData,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Catalog\Model\ResourceModel\Product $resourceProduct,
        \Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable $resourceConfigurable,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        BalanceFactory $balanceFactory,
        pricingHelper $pricingHelper,
        CurrentCustomer $currentCustomer,
        StoreManagerInterface $storeManager,
        ProductModel $productModel,
		Option $option
    ) {
        $this->_customerSession = $customerSession;
        $this->httpContext = $httpContext;
        $this->_objectManager = $objectManager;
        $this->wishlist = $wishlist;
        $this->_customerViewHelper = $customerViewHelper;
        $this->_scopeConfig = $scopeConfig;
        $this->_checkoutSession = $checkoutSession;
        $this->_salesConfig = $salesConfig;
        $this->_giftCardAccountData = $giftCardAccountData;
        $this->timezone = $timezone;
        $this->resourceProduct = $resourceProduct;
        $this->resourceConfigurable = $resourceConfigurable;
        $this->_productRepository = $productRepository;
        $this->_balanceFactory = $balanceFactory;
        $this->_pricingHelper = $pricingHelper;
        $this->_currentCustomer = $currentCustomer;
        $this->storeManager = $storeManager;
        $this->productModel = $productModel;
        $this->option = $option;
        parent::__construct($context);
    }

    public function getLogedinUserName()
    {
        $customerSession = $this->_objectManager->create(\Magento\Customer\Model\Session::class);
        return $customerSession->getCustomer()->getName();
    }

    public function getLoggedInCustomer()
    {
        return $this->_customerSession->getCustomer();
    }

    public function isCustomerLoggedIn()
    {
        return $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
    }
    
    public function loadWishList($id)
    {
        return $this->wishlist->loadByCustomerId($id);
    }
	
	public function getCustomoption($_product) {
		return $this->option->getProductOptionCollection($_product);
	}
    
    public function getUserName()
    {
        $customerSession = $this->_objectManager->create(\Magento\Customer\Model\Session::class);
        if (!$this->isCustomerLoggedIn()) {
            return '';
        }
       
        return $customerSession->getCustomer()->getName();
    }

    /**
     * Get user email
     *
     * @return string
     */
    public function getUserEmail()
    {
        $customerSession = $this->_objectManager->create(\Magento\Customer\Model\Session::class);
        if (!$this->isCustomerLoggedIn()) {
            return '';
        }
        return $customerSession->getCustomer()->getEmail();
    }
    
    public function getStorePhoneNumber()
    {
        return $this->_scopeConfig->getValue(self::STORE_PHONE_NUMBER, ScopeInterface::SCOPE_STORE);
    }
    
    /**
     * Get sales quote
     *
     * @return \Magento\Quote\Model\Quote
     */
    public function getQuote()
    {
        return $this->_checkoutSession->getQuote();
    }

    /**
     * Get gift card list from quote
     *
     * @return mixed
     */
    public function getQuoteGiftCards()
    {
        return $this->_giftCardAccountData->getCards($this->getQuote());
    }
    
    /**
     * Get CMS page Identifier
     *
     * @return string
     */
    public function getCmsPageIdentifier()
    {
         $cmsPage = $this->_objectManager->get(\Magento\Cms\Model\Page ::class);
        return $cmsPage->getIdentifier();
    }
    
    public function getFormatDate($yourdate, $dateformat = 'Y/m/d H:i:s')
    {
        return $dateTimeZone = $this->timezone->date(new \DateTime($yourdate))->format($dateformat);
    }
    
    public function getParentId($childSku)
    {
        $parentIds=[];
        $childId = $this->resourceProduct->getIdBySku($childSku);
        if ($childId) {
            $parentIds = $this->resourceConfigurable->getParentIdsByChild($childId);
            if (isset($parentIds[0])) {
                return $product = $this->_productRepository->getById($parentIds[0]);
                
            }
    
        }
    }
    
    public function getCustomerBalance()
    {
        $customerId = $this->_currentCustomer->getCustomerId();
        if (!$customerId) {
            $balanceAmount = 0;
            $originalBalanceAmount = 0;
        } else {
            $balance = $this->_balanceFactory->create()->setCustomerId($customerId)->loadByCustomer();
            $balanceAmount = $this->_pricingHelper->currency(round($balance->getAmount()));
            $originalBalanceAmount = round($balance->getAmount());
        }
       
        return $originalBalanceAmount;
    }
    
    public function getCustomerBalanceReturn()
    {
        $htmlstring='';
        if ($this->getCustomerBalance()) {
            $balanceAmount = $this->_pricingHelper->currency($this->getCustomerBalance());
            $htmlstring .= '<a href="'.$this->getStoreManagerData().'storecredit/info/index" class="storecredit-icon">';
            $htmlstring .=     $balanceAmount;
            $htmlstring .= '</a>';
            return $htmlstring;
        } else {
            return $htmlstring = '<a href="'.$this->getStoreManagerData().
            'storecredit/info/index" class="storecredit-icon"><span class="price">0</span></a>';
        }
    }
    
    public function getCustomerBalanceMobile()
    {
        $htmlstring='';
        if ($this->getCustomerBalance()) {
            $balanceAmount = $this->_pricingHelper->currency($this->getCustomerBalance());
            $htmlstring .= '<a href="'.$this->getStoreManagerData().
            'storecredit/info/index" class="store-credit-icon-with-balance storecredit-icon">';
            $htmlstring .=     $balanceAmount;
            $htmlstring .= '</a>';
            return $htmlstring;
        } else {
            return $htmlstring = '<a href="'.$this->getStoreManagerData().
            'storecredit/info/index" class="store-credit-icon-with-balance storecredit-icon">
			<span class="price">0</span></a>';
        }
    }
    
    public function getStoreManagerData()
    {
        return $storeUrl = $this->storeManager->getStore()->getBaseUrl();
    }
    
    public function getLoadProductDetail($productId)
    {
        return $this->productModel->load($productId);
    }
}
