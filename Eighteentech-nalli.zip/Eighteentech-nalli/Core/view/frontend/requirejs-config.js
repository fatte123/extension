var config = {
	
	map: {
       '*': {          
           message: 'Eighteentech_Core/js/message'
       }
   },
	deps: [       
       "Eighteentech_Core/js/custom-validator"
    ]
};

