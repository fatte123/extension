define([
    "jquery",
], function ($) {
    'use strict';
    var self;
    $.widget('eighteentech.message', {
        options: {
            timeToHide: 4000,
            messageType: 'success',
            messageText: '',
            timeout: '',
            timeout1: '',
            timeout2: '',
            messageElement: '<div class="notification-view"><div class="notify-message text-center"></div></div>',
            method: 'show',            
            notifyContentElement: '.notify-message',
            notifyElement: '.notification-view'
        },
        _init: function () {
            self = this;
            self.displayNotification();
        },

        clearTimeOuts: function () {
            clearTimeout(self.options.timeout1);
            clearTimeout(self.options.timeout);
            clearTimeout(self.options.timeout2);
        },

        displayNotification: function () {
            if ($('.notification-view').length != 0) {                
                $('.notify-message').removeClass('active');
                setTimeout(function () {
                    $('.notification-view').remove();                    
                    self.showHideMessage();
                }, 500)
            } else {
                self.showHideMessage();
            }
        },

        showHideMessage: function () {
            self.clearTimeOuts();
            self.setContentOnElement();
            self.removeActiveFromElement('.notify-message');
            self.removeElementFromDOM('.notification-view');
        },

        removeElementFromDOM: function (divElementToBeRemoved) {
            self.options.timeout2 = setTimeout(function () {
                $(divElementToBeRemoved).remove();
            }, self.options.timeToHide + 1000);
        },

        removeActiveFromElement: function (divElement) {
            self.options.timeout = setTimeout(function () {
                $(divElement).removeClass('active');
            }, self.options.timeToHide);
        },

        setContentOnElement: function () {
            $(self.options.messageElement).insertBefore('.messages');
            self.options.timeout1 = setTimeout(function () {
                $('.notify-message').text(self.options.messageText);
                $('.notify-message').addClass("active " + self.options.messageType);
            }, 500);
        }
    });
    return $.eighteentech.message;
});
