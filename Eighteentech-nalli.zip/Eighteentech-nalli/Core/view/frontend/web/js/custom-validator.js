define([
        "jquery",
        "jquery/ui",
        'jquery/validate',
        'mage/mage',
        'mage/translate'
    ],
    function ($) {
        "use strict";

        /* Mobile number validations*/
        //  Avoid character typing
        $(".validate-mobile-number,.mobile-number-optional,.validate-numbers-only").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
        });
        
        // Show error message if mobile number not started with 6, 7, 8, 9
        $.validator.addMethod('validate-mobile-number', function (v, element) {
            var isNumValid = /^[6789]/.test(v);
            var elem = $(element);
            var mobileNumber = $.trim(v);
            var formid = elem.closest('form').attr('id');
            var targetElement = '#' + formid;
            var mobLength = mobileNumber.length;

            addMobileCodeSpan(elem, isNumValid, targetElement, mobLength);
            if (isNumValid && mobLength <= 10) {
                var result = mobLength < 10;
                return !result;
            }
        }, $.mage.__('Enter a valid mobile number.'));


        // Validation for OTP
        $('body').on('keydown', '.input-otp', function (e) {
            if (e.ctrlKey && e.which == 86) {
                return;
            }
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57) && (e.keyCode < 96 || e.keyCode > 105)) {
                return false;
            }
        });

        //  Check if nemeric
        $.validator.addMethod('required-otp', function (v) {
            if (!$.mage.isEmpty(v)) {
                return !$.mage.isEmpty(v);
            }
        }, $.mage.__('Please enter a valid OTP.'));

        //  Check if nemeric
        $.validator.addMethod('required-change-password-otp', function (v) {
            if (!$.mage.isEmpty(v)) {
                return !$.mage.isEmpty(v);
            }
        }, $.mage.__('Please enter a valid OTP.'));

        /* Email or mobile validation*/
        $.validator.addMethod('required-email-mobile', function (v) {
            if (!$.mage.isEmpty(v)) {
                //If field contains number
                var isnum = /^\d+$/.test(v);
                if (isnum) {
                    //validate phone number
                    var expr = /^[6789]\d{9}$/;
                    return (expr.test(v));
                } else {
                    //validate email
                    return $.mage.isEmptyNoTrim(v) || /^([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*@([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*\.(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]){2,})$/i.test(v);
                }
                return;
            }

        }, $.mage.__('Please enter a valid Email/Mobile number'));

        //Only Email Verification
        $.validator.addMethod('validate-email-id', function (v) {
            if (!$.mage.isEmpty(v)) {
                return $.mage.isEmptyNoTrim(v) || /^([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*@([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*\.(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]){2,})$/i.test(v); //eslint-disable-line max-len
            }
        }, $.mage.__('Please enter a valid email address.'));

        //login password
        $.validator.addMethod('required-password', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Password is a required field.'));

        // validate register password
        $.validator.addMethod('validate-custom-pwd', function (v, elm) {
            var passwordMinLength = $(elm).data('password-min-length');
            this.pwdLength = passwordMinLength;
            if (!$.mage.isEmpty(v)) {

                var pass = $.trim(v);
                var result = pass.length >= passwordMinLength;
                return result;
            }
        }, function () {
            var message = $.mage.__('Password length should be minimum %s.');
            return message.replace('%s', this.pwdLength);
        });

        //Forget Password
        $.validator.addMethod('validate-forget-password', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Password is a required field'));


        //  Check if numeric
        $.validator.addMethod('required-change-password-otp', function (v) {
            if (!$.mage.isEmpty(v)) {
                return !$.mage.isEmpty(v);
            }
        }, $.mage.__('Please enter a valid OTP.'));


        //newsletter
        // Mobile number optional
        $.validator.addMethod('mobile-number-optional', function (v, element) {
            var elem = $(element);
            var formid = elem.closest('form').attr('id');
            var targetElement = '#' + formid;
            if ($.mage.isEmpty(v)) {
                $(targetElement).find('.mobile-control-text').remove();
                $(targetElement).find('.mobile-control input').removeClass("mobile-padding");
                return true;
            } else {
                var isNumValid = /^[6789]/.test(v);
                var mobileNumber = $.trim(v);
                var mobLength = mobileNumber.length;

                addMobileCodeSpan(elem, isNumValid, targetElement, mobLength);
                if (isNumValid && mobLength <= 10) {
                    var result = mobLength < 10;
                    return !result;
                }
            }
        }, $.mage.__('Please enter a valid mobile number.'));

        //validate Name
        $.validator.addMethod('required-name', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter your name.'));
        
        // Customer Profile Picture Validation
        $.validator.addMethod(
            'validate-image-format', function (v, elm) {
                if (elm.value != '') {
                    var extension = elm.value.split('.').pop().toLowerCase();
                    if ($.inArray(extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                        return false;
                    }
                }
                return true;
            }, $.mage.__('The profile picture is not a valid image.'));

        $.validator.addMethod(
            'validate-image-size', function (v, elm) {
                if (elm.value != '') {
                    if (elm.files[0].size > 512000) {
                        return false;
                    }
                }
                return true;
            }, $.mage.__('The size of the image is too large.'));

        $.validator.addMethod(
            'validate-image-filename', function (v, elm) {
                if (elm.value != '') {
                    if ((/\s/.test(elm.files[0].name))) {
                        return false;
                    }
                }
                return true;
            }, $.mage.__('Filename should not contain spaces.'));

        $.validator.addMethod(
            'validate-filename-length', function (v, elm) {
                if (elm.value != '') {
                    var name = elm.files[0].name;
                    var filename = name.substring(0, name.indexOf("."));
                    if (filename.length <= 1) {
                        return false;
                    }
                }
                return true;
            }, $.mage.__('Filename is not valid.'));

        $.validator.addMethod(
            'validate-filename-characters', function (v, elm) {
                var specialCharacters = /[*|\":,!~<>[\]{}`\\()';@&$]/;
                if (elm.value != '') {
                    if (specialCharacters.test(elm.files[0].name)) {
                        return false;
                    }
                }
                return true;
            }, $.mage.__('Filename contains special characters.'));
            
        function addMobileCodeSpan(elem, isNumValid, targetElement, mobLength) {
            //  alert('span'+mobLength);
            if (isNumValid && mobLength <= 10) {
                if ($(targetElement).find('.mobile-control-text').length == 0) {
                    elem.after('<span class="mobile-control-text">+91</span>');
                }
                $(targetElement).find('.mobile-control input').addClass("mobile-padding");
            } else {
                $(targetElement).find('.mobile-control-text').remove();
                $(targetElement).find('.mobile-control input').removeClass("mobile-padding");

            }
        }

        // Name field validation
        $('body').on('keyup','input[name="firstname"]',function(){
            var current = $(this);
            current.val(current.val().replace(/(\s{2,})|[^a-zA-Z']/g, ' '));
            current.val(current.val().replace(/^\s*/, ''));
            //current.val($.trim(current.val()));
        });

        $('body').on('keyup','input[name="password"]',function(){
            var current = $(this);
            current.val(current.val().replace(/\s+/g, ''));
        });

        $('body').on('blur','input[name="firstname"]',function(){
            var name = $(this).val();
            $(this).val($.trim(name));
        });
        
        $('body').on('keyup','input[name="mobilenumber"]',function(){
			var current = $(this);
            current.val(current.val().replace(/[a-z]/g, ""));
            //current.val(current.val().replace(/[A-Z]/g, " "); 
		});	
        
        $('body').on('blur','input[name="mobilenumber"]',function(){
            var mobilenumber = $(this).val();
            $(this).val($.trim(mobilenumber));
        });
        
        
        $('body').on('keyup','input[name="mobile"]',function(){
			var current = $(this);
            current.val(current.val().replace(/[a-z]/g, ""));
        });
		
		$('body').on('blur','input[name="mobile"]',function(){
            var mobilenumber = $(this).val();
            $(this).val($.trim(mobilenumber));
        });	
		

            //Feedback
        //Validate-comment
        $.validator.addMethod('required-comment', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter your comment.'));

        //Validate dropdown
        $.validator.addMethod('required-select', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please select.'));
        //validate-email-id
        //required-name
        $('body').on('focus', '.login-register-tab .login-register-tab, .form .input-text', function () {
            $(this).closest(".field").addClass("focused");
        });
        $('body').on('blur', '.login-register-tab .login-register-tab, .form .input-text', function () {
            var inputValue = $(this).val();
            if (inputValue) {
                $(this).closest(".field").addClass("focused");
            } else {
                $(this).closest(".field").removeClass("focused");
            }
        });

        $('.form .input-text').each(function () {
            var inputValue = this.value;
            if (inputValue) {
                $(this).closest(".field").addClass("focused");
            } else {
                $(this).closest(".field").removeClass("focused");
            }
        });

          //Size calculator validation
        $.validator.addMethod('required-band', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter a valid band size.'));

        $.validator.addMethod('required-bust', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter a valid bust size.'));
        $.validator.addMethod('required-hipsize', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter a valid hip size.'));


        //Review - textarea
        $.validator.addMethod('required-review', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please add your review.'));


        //validate pincode
        $.validator.addMethod('validate-pincode', function (v, elm) {
            if (!$.mage.isEmpty(v)) {

                var pincodeMaxLength = $(elm).data('max-length');
                var pin = $.trim(v);
                var result = pin.length < pincodeMaxLength || pin.length > pincodeMaxLength;
                return !result;
            }
        }, $.mage.__('Please enter a valid pincode.'));

		    $(".validate-pincode").keypress(function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
        });
        $.validator.addMethod('required-address', function (v) {
            return !$.mage.isEmpty(v);
        }, $.mage.__('Please enter your address.'));
        $.validator.addMethod('alternate-phone', function (v) {
            if ($.mage.isEmpty(v)) {
                return true;
            } else {
                var isNumValid = /^[- +()]*[0-9][- +()0-9]*$/.test(v);
                return isNumValid
            }
        }, $.mage.__('Please enter a valid number.'));
        
        //Check out form validation
        $('body').on('keypress', '#co-shipping-form .postcode, #co-shipping-form .telephone', function (e) {
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
        });

        $('body').on('keyup', '#co-shipping-form .telephone', function (e) {
            var elem = $(e.currentTarget);
            var formid = elem.closest('form').attr('id');
            var mobileNumber = elem.val();
            elem.closest('div').addClass('mobile-control');

            var isNumValid = /^[6789]/.test(mobileNumber);
            var targetElement = '#' + formid;
            var mobLength = mobileNumber.length;

            addMobileCodeSpan(elem, isNumValid, targetElement, mobLength);
        });
    }
);
