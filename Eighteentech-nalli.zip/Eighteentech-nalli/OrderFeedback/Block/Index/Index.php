<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */
namespace Eighteentech\OrderFeedback\Block\Index;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;


class Index extends \Magento\Framework\View\Element\Template {
	protected $request;
    public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Api\OrderItemRepositoryInterface $orderItemRepository,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Request\Http $request,
        StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository,
        array $data = []    
    ) {
		$this->orderRepository = $orderRepository;
		$this->orderItemRepository = $orderItemRepository;
		$this->request = $request;	
		$this->storeManager          = $storeManager;
        $this->productRepository     = $productRepository;
		$this->customerSession = $customerSession;
        parent::__construct($context, $data);

    }
/* get order Item collection */
    public function getOrderItemData()
    {
		
		$arrData = [];
		$this->request->getParams();
        $itemId = $this->request->getParam('id');
        $itemCollection = $this->orderItemRepository->get($itemId);
        $orderCollection = $this->orderRepository->get($itemCollection->getOrderId());
        $sessionCustomerId = $this->customerSession->getId();
        $orderCustomerId = $orderCollection->getCustomerId();
        if($orderCustomerId == $sessionCustomerId){
			$arrData['customer_email'] = $orderCollection->getCustomerEmail();		 
			$arrData['customer_name'] = $orderCollection->getCustomerFirstname();
			$arrData['increment_id'] = $orderCollection->getIncrementId();
			$arrData['order_id'] = $itemCollection->getOrderId();
			$arrData['updated_at'] = $orderCollection->getUpdatedAt();
			$arrData['sku'] = $itemCollection->getSku();
			$arrData['product_name'] = $itemCollection->getName();
			$arrData['item_id'] = $itemId;
            $product = $this->productRepository->get($itemCollection->getSku());
			$baseurl = $this->storeManager->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'catalog/product';
            $imageUrl = $baseurl.$product->getData('thumbnail'); 
            $arrData['product_image'] = $imageUrl;
            $arrData['is_order_feedback'] = $itemCollection->getIsOrderFeedback();				
			
			
        
		} 
        return $arrData;
    }

    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

}				
