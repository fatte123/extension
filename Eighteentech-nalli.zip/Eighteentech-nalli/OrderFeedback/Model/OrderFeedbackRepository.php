<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Model;

use Eighteentech\OrderFeedback\Api\OrderFeedbackRepositoryInterface;
use Eighteentech\OrderFeedback\Api\Data\OrderFeedbackDetailsInterfaceFactory;
use Eighteentech\OrderFeedback\Model\FeedbackFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Sales\Model\Order;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\Io\File as FileIo;

class OrderFeedbackRepository implements OrderFeedbackRepositoryInterface
{

    const STATUS = 1;


    /**
     * @var FeedbackFactory
     */
    protected $feedbackFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;


    public function __construct(
        OrderFeedbackDetailsInterfaceFactory $orderFeedbackDetailsInterfaceFactory,
        FeedbackFactory $feedbackFactory,
        StoreManagerInterface $storeManager,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Api\OrderItemRepositoryInterface $orderItemRepository
    ) {
        $this->orderFeedbackDetailsInterfaceFactory = $orderFeedbackDetailsInterfaceFactory;
        $this->feedbackFactory = $feedbackFactory;
        $this->storeManager = $storeManager;
        $this->orderRepository = $orderRepository;
		$this->orderItemRepository = $orderItemRepository;
    }


    /**
     * {@inheritdoc}
     */
    public function saveFeedback($itemId, $rating, $feedbacks, $comment)
    {
        $result = $this->orderFeedbackDetailsInterfaceFactory->create();
        $result->setStatus(false);
        try {
			$itemCollection = $this->orderItemRepository->get($itemId);
			$orderCollection = $this->orderRepository->get($itemCollection->getOrderId());
            $email = $orderCollection->getCustomerEmail();

            $feedbackModel = $this->feedbackFactory->create();
            $arrData['customer_email'] = $orderCollection->getCustomerEmail();		 
			$arrData['customer_name'] = $orderCollection->getCustomerFirstName().' '.$orderCollection->getCustomerLastName();
			$arrData['order_id'] = $itemCollection->getOrderId();
			$arrData['increment_id'] = $orderCollection->getIncrementId();
			$arrData['updated_at'] = $orderCollection->getUpdatedAt();
			$arrData['sku'] = $itemCollection->getSku();
			$arrData['rating'] = $rating;
			$arrData['feedbacks'] = $feedbacks;
			$arrData['comment'] = $comment;
            $feedbackModel->setData($arrData);
            $itemCollection->setIsOrderFeedback(1);
            $itemCollection->save();
            $feedbackModel->save();

            $result->setStatus(true);
            $result->setMessage(__("Feedback saved successfully."));
            return $result;
        } catch (\Exception $e) {
            $result->setMessage($e->getMessage());
            return $result;
        }
    }
}
