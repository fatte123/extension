<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Model\ResourceModel\Feedback;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_eventPrefix = 'order_feedback_grid_collection';
    protected $_eventObject = 'feedback_grid_collection';

    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            \Eighteentech\OrderFeedback\Model\Feedback::class,
            \Eighteentech\OrderFeedback\Model\ResourceModel\Feedback::class
        );
    }
}
