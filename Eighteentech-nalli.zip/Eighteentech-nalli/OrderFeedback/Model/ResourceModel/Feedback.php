<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Feedback extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('eighteentech_order_feedback', 'id');
    }
}
