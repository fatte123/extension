<?php

namespace Eighteentech\OrderFeedback\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	
/**
     * Soldproducts constructor.
     * @param \Magento\Backend\App\Action\Context $context     
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,        
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->customerSession = $customerSession;
        $this->redirect = $redirect;
        $this->request = $request;
        $this->urlInterface = $url;
        return parent::__construct($context);
    }	
    public function execute()
    {
        $customerSession = $this->customerSession;
        if (!$customerSession->isLoggedIn()) {
			$login_url = $this->urlInterface->getUrl('customer/account/login');
			return $this->resultRedirectFactory->create()->setPath($login_url);		

        }
        $params = $this->request->getParams();
        if((!isset($params['id']) || $params['id']=='')){
			$order_url = $this->urlInterface->getUrl('sales/order/history/');
			return $this->resultRedirectFactory->create()->setPath($order_url);	
		}        
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
    
}
