<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Controller\Adminhtml\Feedback;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action;

class Index extends Action
{
    protected $resultPage;
    protected $resultPageFactory = false;

    public function __construct(Context $context, PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        //Call page factory to render layout and page content
        $resultPage = $this->resultPageFactory->create();
        /**
         * Set active menu item
         */
        $resultPage->setActiveMenu('Eighteentech_OrderFeedback::feedback');
        $resultPage->getConfig()->getTitle()->prepend((__('Manage Feedback')));
        //Add bread crumb
        $resultPage->addBreadcrumb(__('Nalli'), __('Nalli'));
        $resultPage->addBreadcrumb(__('OrderFeedback'), __('OrderFeedback'));
        return $resultPage;
    }

    /*
     * Check permission via ACL resource
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eighteentech_OrderFeedback::feedback');
    }
}
