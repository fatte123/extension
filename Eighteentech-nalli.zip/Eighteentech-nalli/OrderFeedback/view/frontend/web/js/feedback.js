define(['jquery',
], function ($, message) {
    "use strict";
    $.widget('order.feedback', {
        options: {
            messagesPopup: '.messages',
            messagep:'Let us know what part of your last purchase was good.',
            messagen:'Let us know what part of your last purchase could have been better.',
            feedbackOption: [
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Colour not as expected', 'Product is damaged/stained','Website can improve','Shipment arrived late','Packaging was not upto the mark','Unhappy interaction with customer care','Other (Please specify)'],
								['Product colour was beautiful', 'Product fabric quality was very good','Shipping was prompt','Packaging was well done','Website was easy to use','Customer care gave great service','Other (Please specify)'],
								['Product colour was beautiful', 'Product fabric quality was very good','Shipping was prompt','Packaging was well done','Website was easy to use','Customer care gave great service','Other (Please specify)'],
								['Product colour was beautiful', 'Product fabric quality was very good','Shipping was prompt','Packaging was well done','Website was easy to use','Customer care gave great service','Other (Please specify)'],
								['Product colour was beautiful', 'Product fabric quality was very good','Shipping was prompt','Packaging was well done','Website was easy to use','Customer care gave great service','Other (Please specify)'],
								
							]            
        },
        _create: function () {
            var self = this;
            //Ajax Call
            $('#submit-feedback').on("click" , function (event) {
                event.preventDefault();
                if($("#order-feedback-form").find('input[name="star_rating"]:checked').length>0){                
					$("#order-feedback-form").find('#feedback-options-error').text('');
                
                }else{
					 $("#order-feedback-form").find('#feedback-options-error').text('Please select your rating.');
						$('html, body').animate({
							scrollTop: $("#order-feedback-form").offset().top
						}, 500);					 
						return false;
				}
                if ($("#order-feedback-form").valid()) {					
                    self.ajaxSubmit();
                }
            });

            // onclick rating event
            $('body').on('click', '.review-field-rating .radio', self.onClickRating.bind(this));
            self.updateSuggation(0);
			//this.resetForm();
            $("input[name='feedback-options']").on('change', function () {
                if ($('input[name="feedback-options"]:checked').length > 0) {
                    $('button#submit-success-feedback').removeClass('disabled');
                }
            });
        },

		onClickRating: function (e){
			var self = this;
			var rating = parseInt($("#order-feedback-form").find('input[name="star_rating"]:checked').val());
			$("#order-feedback-form").find('#feedback-options-error').text('');
			$("#order-feedback-form").find('input[name="star_rating"]').removeClass('active');
			$("#order-feedback-form").find('input[name="star_rating"]').each(function(){
                var val1 = parseInt($(this).val());
                if (val1 <= rating) {
                   $(this).addClass('active');
                }
            });
            if(rating>6){
				$("#order-feedback-form").find('.text-let-us p').html(self.options.messagep);
			}else{
				$("#order-feedback-form").find('.text-let-us p').html(self.options.messagen);
			}
			
			self.updateSuggation(rating-1);
			

		},
		updateSuggation: function(option1){
		 var self = this;
		 $("#order-feedback-form").find('#suggationOptions').html('');
		 $.each(self.options.feedbackOption[option1], function(i)
			{
								
				var container = $('#suggationOptions'); 
				var li = $('<li/>')
					.addClass('ui-menu-item')
					.appendTo(container);
				var span = $('<span/>')
					.addClass('ui-menu-item')
					.appendTo(li);
				
				
				
				var input = $('<input/>')
					.addClass('ui-all')
					.attr('type', 'checkbox')
					.attr('name', 'suggation[]')
					.attr('id', 'suggation'+i)
					.attr('value', self.options.feedbackOption[option1][i])
					.appendTo(span);

			   var label = $('<label/>')
					.addClass('ui-all')
					.attr('for', 'suggation'+i)
					.text(self.options.feedbackOption[option1][i])
					.appendTo(span);
			});
					
		},
        resetForm: function () {
            //reset form
            $('#order-feedback-popup-modal input[type="radio"]').prop('checked', false);
            $(".validate-option").hide();
            $('button#submit-success-feedback').addClass('disabled');
        },

        ajaxSubmit: function () {
            var self = this, payload, feedbacks = '';
            $('input[name="suggation[]"]:checked').each(function() {
			   if(feedbacks==''){
					feedbacks = this.value;
			   }else{
				    feedbacks = feedbacks+', '+this.value;
			   }
			});
            payload = {
                'itemId': parseInt($("#order-feedback-form").find('input[name="item_id"]').val()),
                'rating': parseInt($("#order-feedback-form").find('input[name="star_rating"]:checked').val()),              
                'feedbacks': feedbacks,
                'comment': $("#order-feedback-form").find('textarea[name="comment"]').val()
            };

            $.ajax({
                url: BASE_URL + "rest/default/V1/saveFeedback/",
                type: "POST",
                data: JSON.stringify(payload),
                datatype: 'json',
                contentType: 'application/json',
                showLoader: true,
                success: function (response) {
                    if (response.status) {
                        $(self.options.messagesPopup).message({
                            timeToHide: 4000,
                            messageType: 'success',
                            messageText: response.message,
                            method:'show'
                        }); 
                        //$('#order-feedback-form').reset();
                        setTimeout(function() {
							//window.location.reload();
							var href = $("#order-feedback-form").find('.back-bitton').attr('href');
							window.location.href = href;
						}, 3000);
                    } else {
                        $(self.options.messagesPopup).message({
                            timeToHide: 4000,
                            messageType: 'error',
                            messageText: response.message,
                            method: 'show'
                        });
                       
						setTimeout(function() {
							window.location.reload();
						}, 3000);
                    }
                },
                error: function (response) {
                    $(self.options.messagesPopup).message({
                        timeToHide: 4000,
                        messageType: 'error',
                        messageText: response.message,
                        method:'show'
                    });
                }
            });
            return false;
        }
    });
    return $.order.feedback;
});
