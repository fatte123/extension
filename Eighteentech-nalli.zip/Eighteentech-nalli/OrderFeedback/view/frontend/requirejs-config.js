var config = {
    map: {
        '*': {
           feedback: 'Eighteentech_OrderFeedback/js/feedback'
        }
    }
};
