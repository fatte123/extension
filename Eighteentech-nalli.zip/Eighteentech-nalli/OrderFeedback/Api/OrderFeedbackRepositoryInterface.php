<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Api;

interface OrderFeedbackRepositoryInterface
{
    /**
     * Save feedback
     *
     * @api
     * @param int $itemId
     * @param int $rating
     * @param string $feedbacks
     * @param string $comment
     * @return \Eighteentech\OrderFeedback\Api\Data\OrderFeedbackDetailsInterface
     */
    public function saveFeedback($itemId, $rating, $feedbacks, $comment);
}
