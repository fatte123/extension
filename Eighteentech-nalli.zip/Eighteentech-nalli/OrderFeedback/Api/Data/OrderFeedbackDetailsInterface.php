<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_OrderFeedback
 *
 */

namespace Eighteentech\OrderFeedback\Api\Data;

interface OrderFeedbackDetailsInterface
{
    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus();

    /**
     * Set status
     *
     * @param boolean $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get message
     *
     * @return string|null
     */
    public function getMessage();

    /**
     * Set message
     *
     * @param string|null $message
     * @return $this
     */
    public function setMessage($message);

}
