<?php

namespace Eighteentech\GA4\Block\DataLayer;

use Eighteentech\GA4\Block\DataLayer;

class Checkout extends DataLayer
{
    /**
     * Prepare checkout data for datalayer
     *
     * @return string
     */
    public function prepareCheckoutData()
    {
        $quote = $this->getCurrentQuote();
        $items = $this->getQuoteItems();

        $result = [
            'currency' => $quote->getStore()->getCurrentCurrencyCode(),
            'value' => number_format($quote->getSubtotal(), 2),
            'coupon' => $quote->getCouponCode(),
            'items' => $items
        ];

        return json_encode($result);
    }

    /**
     * Return quote items in json
     *
     * @return string
     */
    public function getItemsInJson()
    {
        return json_encode($this->getQuoteItems());
    }

    /**
     * Prepare quote data for datalayer
     *
     * @return array
     */
    public function prepareQuoteData()
    {
        $quote = $this->getCurrentQuote();

        $result = [
            'currency' => $quote->getStore()->getCurrentCurrencyCode(),
            'value' => number_format($quote->getSubtotal(), 2),
            'coupon' => $quote->getCouponCode()
        ];

        return $result;
    }
}
