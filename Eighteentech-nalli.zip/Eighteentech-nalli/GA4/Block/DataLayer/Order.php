<?php

namespace Eighteentech\GA4\Block\DataLayer;

use Eighteentech\GA4\Block\DataLayer;

class Order extends DataLayer
{
    /**
     * Prepare order data for datalayer
     *
     * @return string
     */
    public function prepareOrderData()
    {
        $order = $this->getLastOrder();
        $items = [];

        foreach ($order->getAllVisibleItems() as $item) {
            $product = $item->getProduct();
            $category = $this->dataLayerHelper->getProductCategories($product);

            $items[] = [
                "item_id" => $item->getSku(),
                "item_name" => $item->getName(),
                "price" => number_format($item->getRowTotal(), 2),
                "quantity" => number_format($item->getQtyOrdered(), 2),
                "item_brand" => $product->getBrand() ?? $this->dataLayerHelper->getStoreName(),
                "coupon" => $order->getCouponCode(),
                "discount" => number_format($item->getDiscountAmount(), 2),
                "item_category" => $category['name'] ?? '',
                "item_list_id" => $category['url_key'] ?? '',
                "item_list_name" => $category['name'] ?? ''
            ];
        }

        $result = [
            "transaction_id" => $order->getIncrementId(),
            "value" => number_format($order->getSubtotal(), 2),
            "tax" => number_format($order->getTaxAmount(), 2),
            "shipping" => number_format($order->getShippingAmount(), 2),
            "currency" => $order->getOrderCurrencyCode(),
            "coupon" => $order->getCouponCode(),
            "items" => $items
        ];

        return json_encode($result);
    }
}
