<?php

namespace Eighteentech\GA4\Block\DataLayer;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;

class RemoveCartItem extends Template
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "removeCartDatalayer";

    /**
     * @var CookieManagerInterface
     */
    private $cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @var SessionManagerInterface
     */
    private $sessionManager;

    /**
     * @param CookieManagerInterface $cookieManager
     * @param CookieMetadataFactory $cookieMetadataFactory
     * @param SessionManagerInterface $sessionManager
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        SessionManagerInterface $sessionManager,
        Context $context,
        array $data = []
    ) {
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->sessionManager = $sessionManager;
        parent::__construct($context, $data);
    }

    /**
     * Get remove item data
     *
     * @return string
     */
    public function getRemoveItemData()
    {
        $dataLayerJson = '';

        $removeCartItemCookie = $this->cookieManager->getCookie(self::COOKIE_NAME);
        
        if (!empty($removeCartItemCookie)) {
            $dataLayerJson = $removeCartItemCookie;

            $publicCookieMetadata = $this->cookieMetadataFactory
                ->createPublicCookieMetadata()
                ->setPath($this->sessionManager->getCookiePath())
                ->setDomain($this->sessionManager->getCookieDomain());

            $this->cookieManager->deleteCookie(self::COOKIE_NAME, $publicCookieMetadata);
        }

        return $dataLayerJson;
    }
}
