<?php

namespace Eighteentech\GA4\Block\DataLayer;

use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class WishlisttoCart extends Template
{
    /**
     * @var CatalogSession
     */
    private $catalogSession;

    /**
     * @param CatalogSession $catalogSession
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        CatalogSession $catalogSession,
        Context $context,
        array $data = []
    ) {
        $this->catalogSession = $catalogSession;
        parent::__construct($context, $data);
    }

    /**
     * Get cart item data
     *
     * @return string
     */
    public function getWishlistCartItemData()
    {
        $dataLayerJson = '';

        if (!empty($this->catalogSession->getWishlistToCart())) {
            $dataLayerJson = $this->catalogSession->getWishlistToCart();
            $this->catalogSession->unsWishlistToCart();
        }

        return $dataLayerJson;
    }
}
