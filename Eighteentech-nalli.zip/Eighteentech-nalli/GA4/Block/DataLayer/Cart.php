<?php

namespace Eighteentech\GA4\Block\DataLayer;

use Eighteentech\GA4\Block\DataLayer;

class Cart extends DataLayer
{
    /**
     * Prepare cart data for datalayer
     *
     * @return string
     */
    public function prepareCartData()
    {
        $quote = $this->getCurrentQuote();
        $items = $this->getQuoteItems();

        if (!empty($items)) {
            $result = [
                'currency' => $quote->getStore()->getCurrentCurrencyCode(),
                'value' => $quote->getSubtotal(),
                'items' => $items
            ];
        }

        return !empty($result) ? json_encode($result) : '';
    }
}
