<?php

namespace Eighteentech\GA4\Block;

use Eighteentech\GA4\Helper\Data;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class GTMScript extends Template
{
    /**
     * @var string
     */
    public const HEAD_SCRIPT_TEXT = 'eighteentech_ga4/general/header_script';

    /**
     * @var string
     */
    public const BODY_SCRIPT_TEXT = 'eighteentech_ga4/general/body_script';

    /**
     * @var Data
     */
    protected $dataHelper;

    /**
     * Constructor
     *
     * @param Data $dataHelper
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Data $dataHelper,
        Context $context,
        array $data = []
    ) {
        $this->dataHelper = $dataHelper;
        parent::__construct($context, $data);
    }

    /**
     * Get header GTM script
     *
     * @return string
     */
    public function getHeaderText()
    {
        return $this->dataHelper->getConfigValue(self::HEAD_SCRIPT_TEXT);
    }

    /**
     * Get body GTM script
     *
     * @return string
     */
    public function getBodyText()
    {
        return $this->dataHelper->getConfigValue(self::BODY_SCRIPT_TEXT);
    }
}
