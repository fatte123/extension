<?php

namespace Eighteentech\GA4\Block;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Quote\Model\Quote;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Model\Order;

class DataLayer extends Template
{
    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayerHelper;

    /**
     * @param CheckoutSession $checkoutSession
     * @param DataLayerHelper $dataLayerHelper
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        CheckoutSession $checkoutSession,
        DataLayerHelper $dataLayerHelper,
        Context $context,
        array $data = []
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->dataLayerHelper = $dataLayerHelper;
        parent::__construct($context, $data);
    }

    /**
     * Get current quote
     *
     * @return Quote
     */
    public function getCurrentQuote()
    {
        return $this->checkoutSession->getQuote();
    }

    /**
     * Get last order
     *
     * @return Order
     */
    public function getLastOrder()
    {
        return $this->checkoutSession->getLastRealOrder();
    }

    /**
     * Get Quote items
     *
     * @return array
     */
    public function getQuoteItems()
    {
        $quote = $this->getCurrentQuote();

        $items = [];
        foreach ($quote->getAllVisibleItems() as $item) {
            $product = $item->getProduct();
            $category = $this->dataLayerHelper->getProductCategories($product);

            $items[] = [
                "item_id" => $item->getSku(),
                "item_name" => $item->getName(),
                "price" => number_format($item->getRowTotal(), 2),
                "quantity" => number_format($item->getQty(), 2),
                "item_brand" => $product->getBrand() ?? $this->dataLayerHelper->getStoreName(),
                "coupon" => $quote->getCouponCode(),
                "discount" => number_format($item->getDiscountAmount(), 2),
                "item_category" => $category['name'] ?? '',
                "item_list_id" => $category['url_key'] ?? '',
                "item_list_name" => $category['name'] ?? ''
            ];
        }

        return $items;
    }
}
