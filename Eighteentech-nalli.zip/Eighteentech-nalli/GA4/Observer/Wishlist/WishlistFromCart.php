<?php

declare(strict_types=1);

namespace Eighteentech\GA4\Observer\Wishlist;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Quote\Model\ResourceModel\Quote\Item as QuoteItem;

class WishlistFromCart implements ObserverInterface
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "addToWishlistDatalayer";

    /**
     * @var CatalogSession
     */
    protected $catalogSession;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayer;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @param CatalogSession $catalogSession
     * @param DataLayerHelper $dataLayer
     * @param RequestInterface $request
     * @param CheckoutSession $checkoutSession
     */
    public function __construct(
        CatalogSession $catalogSession,
        DataLayerHelper $dataLayer,
        RequestInterface $request,
        CheckoutSession $checkoutSession
    ) {
        $this->catalogSession = $catalogSession;
        $this->dataLayer = $dataLayer;
        $this->request = $request;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * Provide json data to add_to_wishlist datalayer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $itemId = $this->request->getParam('item');

        if (!empty($itemId)) {
            $quote = $this->checkoutSession->getQuote();
            $item = $quote->getItemById($itemId);
            $product = $item->getProduct();
            $qty = $item->getQty();

            $dataLayerJson = [
                'currency' => $this->dataLayer->getCurrencyCode(),
                'value' => $product->getFinalPrice(),
                'items' => [$this->dataLayer->prepareProductData($product, $qty)]
            ];

            $this->catalogSession->setWishlistFromCart(json_encode($dataLayerJson));
        }
    }
}
