<?php

declare(strict_types=1);

namespace Eighteentech\GA4\Observer\Wishlist;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Wishlist\Model\ItemFactory as WishlistItemFactory;

class WishlistToCart implements ObserverInterface
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "WishlistToCartDatalayer";

    /**
     * @var CatalogSession
     */
    protected $catalogSession;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayer;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var WishlistItemFactory
     */
    protected $wishlistItemFactory;

    /**
     * @param CatalogSession $catalogSession
     * @param DataLayerHelper $dataLayer
     * @param RequestInterface $request
     * @param WishlistItemFactory $wishlistItemFactory
     */
    public function __construct(
        CatalogSession $catalogSession,
        DataLayerHelper $dataLayer,
        RequestInterface $request,
        WishlistItemFactory $wishlistItemFactory
    ) {
        $this->catalogSession = $catalogSession;
        $this->dataLayer = $dataLayer;
        $this->request = $request;
        $this->wishlistItemFactory = $wishlistItemFactory;
    }

    /**
     * Provide json data to add_to_wishlist datalayer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        
        $itemId = $this->request->getParam('item');
        $qty = $this->request->getParam('qty');


        if (!empty($itemId)) {
            $item = $this->wishlistItemFactory->create()->load($itemId);
            $product = $item->getProduct();

            $dataLayerJson = [
                'currency' => $this->dataLayer->getCurrencyCode(),
                'value' => $product->getFinalPrice(),
                'items' => [$this->dataLayer->prepareProductData($product, $qty)]
            ];
            $this->catalogSession->setWishlistToCart(json_encode($dataLayerJson));
        }
    }
}
