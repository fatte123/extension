<?php

declare(strict_types=1);

namespace Eighteentech\GA4\Observer\Wishlist;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Wishlist\Model\Wishlist;

class AllWishlistToCart implements ObserverInterface
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "WishlistToCartDatalayer";

    /**
     * @var CatalogSession
     */
    protected $catalogSession;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayer;

    /**
     * @var Wishlist
     */
    protected $wishlist;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @param CatalogSession $catalogSession
     * @param DataLayerHelper $dataLayer
     * @param Wishlist $wishlist
     * @param CustomerSession $customerSession
     */
    public function __construct(
        CatalogSession $catalogSession,
        DataLayerHelper $dataLayer,
        Wishlist $wishlist,
        CustomerSession $customerSession
    ) {
        $this->catalogSession = $catalogSession;
        $this->dataLayer = $dataLayer;
        $this->wishlist = $wishlist;
        $this->customerSession = $customerSession;
    }

    /**
     * Provide json data to add_to_wishlist datalayer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $customerId = $this->customerSession->getCustomerId();
        $wishlistCollection = $this->wishlist->loadByCustomerId($customerId)->getItemCollection();

        $items = [];
        foreach ($wishlistCollection as $wishlist) {
            $product = $wishlist->getProduct();
            $qty = $wishlist->getBuyRequest()['qty'];
            $items[] = $this->dataLayer->prepareProductData($product, $qty);
        }

        $dataLayerJson = [
            'currency' => $this->dataLayer->getCurrencyCode(),
            'value' => $product->getFinalPrice(),
            'items' => $items
        ];

        $this->catalogSession->setWishlistToCart(json_encode($dataLayerJson));
    }
}
