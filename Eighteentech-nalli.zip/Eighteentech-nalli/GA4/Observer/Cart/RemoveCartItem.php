<?php

declare(strict_types=1);

namespace Eighteentech\GA4\Observer\Cart;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Catalog\Model\Session as CatalogSession;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;

class RemoveCartItem implements ObserverInterface
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "removeCartDatalayer";

    /**
     * @var CatalogSession
     */
    protected $catalogSession;

    /**
     * @var CookieManagerInterface
     */
    protected $cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    protected $cookieMetadataFactory;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var SessionManagerInterface
     */
    protected $sessionManager;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayer;

    /**
     * @param CatalogSession $catalogSession
     * @param CookieManagerInterface $cookieManager
     * @param CookieMetadataFactory $cookieMetadataFactory
     * @param RequestInterface $request
     * @param SessionManagerInterface $sessionManager
     * @param DataLayerHelper $dataLayer
     */
    public function __construct(
        CatalogSession $catalogSession,
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        RequestInterface $request,
        SessionManagerInterface $sessionManager,
        DataLayerHelper $dataLayer
    ) {
        $this->catalogSession = $catalogSession;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->request = $request;
        $this->sessionManager = $sessionManager;
        $this->dataLayer = $dataLayer;
    }

    /**
     * Provide json data to remove_from_cart datalayer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $item = $observer->getEvent()->getQuoteItem();
        $store = $item->getQuote()->getStore();
        $product = $item->getProduct();
        $qty = $item->getQty();

        if (!empty($product)) {
            $dataLayerJson = [
                'currency' => $store->getCurrentCurrencyCode(),
                'value' => $product->getFinalPrice(),
                'items' => [$this->dataLayer->prepareProductData($product, $qty)]
            ];

            $this->catalogSession->setDeleteProduct(json_encode($dataLayerJson));
            
            $publicCookieMetadata = $this->cookieMetadataFactory->createPublicCookieMetadata()
                ->setDuration(259200)
                ->setPath($this->sessionManager->getCookiePath())
                ->setDomain($this->sessionManager->getCookieDomain())
                ->setHttpOnly(false);

            $this->cookieManager->setPublicCookie(
                self::COOKIE_NAME,
                json_encode($dataLayerJson),
                $publicCookieMetadata
            );
        }
    }
}
