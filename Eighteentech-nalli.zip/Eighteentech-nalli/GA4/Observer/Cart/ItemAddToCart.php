<?php

declare(strict_types=1);

namespace Eighteentech\GA4\Observer\Cart;

use Eighteentech\GA4\Helper\DataLayer as DataLayerHelper;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;

class ItemAddToCart implements ObserverInterface
{
    /**
     * @var string
     */
    public const COOKIE_NAME = "addToCartDatalayer";

    /**
     * @var CookieManagerInterface
     */
    protected $cookieManager;

    /**
     * @var CookieMetadataFactory
     */
    protected $cookieMetadataFactory;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var SessionManagerInterface
     */
    protected $sessionManager;

    /**
     * @var DataLayerHelper
     */
    protected $dataLayer;

    /**
     * @param CookieManagerInterface $cookieManager
     * @param CookieMetadataFactory $cookieMetadataFactory
     * @param RequestInterface $request
     * @param SessionManagerInterface $sessionManager
     * @param DataLayerHelper $dataLayer
     */
    public function __construct(
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        RequestInterface $request,
        SessionManagerInterface $sessionManager,
        DataLayerHelper $dataLayer
    ) {
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->request = $request;
        $this->sessionManager = $sessionManager;
        $this->dataLayer = $dataLayer;
    }

    /**
     * Provide json data to add_to_cart datalayer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $product = $observer->getEvent()->getProduct();
        $qty = $this->request->getParam('qty') ?? 1;

        if (!empty($product)) {
            $dataLayerJson = [
                'currency' => $this->dataLayer->getCurrencyCode(),
                'value' => $product->getFinalPrice(),
                'items' => [$this->dataLayer->prepareProductData($product, $qty)]
            ];
            
            $publicCookieMetadata = $this->cookieMetadataFactory->createPublicCookieMetadata()
                ->setDuration(259200)
                ->setPath($this->sessionManager->getCookiePath())
                ->setDomain($this->sessionManager->getCookieDomain())
                ->setHttpOnly(false);

            $this->cookieManager->setPublicCookie(
                self::COOKIE_NAME,
                json_encode($dataLayerJson),
                $publicCookieMetadata
            );
        }
    }
}
