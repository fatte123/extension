<?php

namespace Eighteentech\GA4\Helper;

use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Model\Product;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;

class DataLayer extends AbstractHelper
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var CollectionFactory
     */
    protected $categoryCollection;
    
    /**
     * @param StoreManagerInterface $storeManager
     * @param CollectionFactory $categoryCollection
     * @param Context $context
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        CollectionFactory $categoryCollection,
        Context $context
    ) {
        $this->storeManager = $storeManager;
        $this->categoryCollection = $categoryCollection;
        parent::__construct($context);
    }

    /**
     * Get product categories
     *
     * @param Product $product
     * @return string
     */
    public function getProductCategories($product)
    {
        $categoryIds = $product->getCategoryIds();
        $categories = [];

        if (!empty($categoryIds)) {
            // Fetch collection
            $categoryCollection = $this->categoryCollection->create()
                ->addAttributeToSelect('*')
                ->addAttributeToFilter('entity_id', $categoryIds)
                ->addIsActiveFilter();

            // Prepare string
            foreach ($categoryCollection as $category) {
                $categories['name'][] = $category->getName();
                $categories['url_key'][] = $category->getUrlkey();
            }
        }

        return $categories;
    }

    /**
     * Prepare Item data for datalayer
     *
     * @param Product $product
     * @param integer $qty
     * @return array
     */
    public function prepareProductData($product, $qty = 1)
    {
        $category = $this->getProductCategories($product);

        return [
            'item_id' => $product->getSku(),
            'item_name' => $product->getName(),
            'price' => $product->getFinalPrice(),
            'qty' => $qty,
            'item_brand' => $product->getBrand() ?? $this->getStoreName(),
            'item_category' => $category['name'] ?? '',
            'item_list_id' => $category['url_key'] ?? '',
            'item_list_name' => $category['name'] ?? ''
        ];
    }

    /**
     * Get store name
     *
     * @return string
     */
    public function getStoreName()
    {
        return $this->storeManager->getStore()->getName();
    }

    /**
     * Get current store currency code
     *
     * @return string
     */
    public function getCurrencyCode()
    {
        return $this->storeManager->getStore()->getCurrentCurrencyCode();
    }
}
