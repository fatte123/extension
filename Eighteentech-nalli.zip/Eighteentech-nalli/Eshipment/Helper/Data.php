<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_Eshipment
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\Eshipment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_STATUS = 'eship/eshipment/status';
    const XML_PATH_DYNAMIC = 'eship/eshipment/dynamic';
    const XML_PATH_ENCRYPTION = 'eship/eshipment/encryption';
    const XML_PATH_ORDER_ID = 'eship/eshipment/order_id';
    const XML_PATH_URL = 'eship/eshipment/url';
    
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function getGeneralConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_HELLOWORLD .'general/'. $code, $storeId);
    }
    
    public function getStatus($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_STATUS, $storeId);
    }
    
    public function getOrderId($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_ORDER_ID, $storeId);
    }
    
    public function getEncryption($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_ENCRYPTION, $storeId);
    }
    
    public function isDynamic($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_DYNAMIC, $storeId);
    }
    
    public function getApiUrl($storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_URL, $storeId);
    }
}
