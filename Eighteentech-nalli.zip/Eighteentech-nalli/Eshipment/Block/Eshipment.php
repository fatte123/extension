<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_Eshipment
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\Eshipment\Block;

class Eshipment extends \Magento\Framework\View\Element\Template
{
    /*
     *@var \Magento\Framework\View\Element\Template\Context $context
     */
    public $context;
    
    /*
     *@var \Magento\Framework\App\Request\Http $request
     */
    public $request;
     
    /*
     *@var \Magento\Sales\Api\Data\OrderInterface $order
     */
    public $order;
      
    /*
     *@var \Magento\Customer\Model\Session $Session
     */
    public $Session;
    
    /*
     *@var \Magento\Catalog\Model\ProductFactory $_productloader
     */
    public $_productloader;
    
    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $curl;
    
    /**
     * @var \Eighteentech\Eshipment\Helper\Data
     */
    protected $helper;
    
    /*
     *@param \Magento\Framework\View\Element\Template\Context $context
     *@param \Magento\Framework\App\Request\Http $request
     *@param \Magento\Sales\Api\Data\OrderInterface $order
     *@param \Magento\Customer\Model\Session $Session
     *@param \Magento\Catalog\Model\ProductFactory $_productloader
     *@param \Magento\Framework\HTTP\Client\Curl $curl
     *@param \Eighteentech\Eshipment\Helper\Data $helper
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Customer\Model\Session $Session,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Eighteentech\Eshipment\Helper\Data $helper
    ) {
        $this->order = $order;
        $this->request = $request;
        $this->session = $Session;
        $this->_productloader = $_productloader;
        $this->curl = $curl;
        $this->helper = $helper;
        parent::__construct($context);
    }

    /*
     *@get order id form URI string
     */
    public function getIddata()
    {
        $this->request->getParams(); /*all params*/
        return $this->request->getParam('oder_id');
    }
    
    /*
     *@var getOder Detail
     */
    public function getOrder()
    {
        try {
            $orderId = $this->getIddata();
            $order = $this->order->load($orderId);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('This order no longer exists.'));
        }
        return $order;
    }
    
    /*
     *@return Tracking info
     */
    public function orderTrack()
    {
        $order = $this->getOrder();
        if ($this->helper->isDynamic()==1) {
            $q_num = $order->getIncrementId();
        }
        if ($this->helper->isDynamic()==0) {
            $q_num = $this->helper->getOrderId();
        }
        $ch = $this->curl;
        $tokens = $this->helper->getEncryption();
        $ch->setOption(CURLOPT_ENCODING, 'UTF-8');
        $apiurl = $this->helper->getApiUrl();
        
        $ch->setOption(CURLOPT_RETURNTRANSFER, true);
        $ch->setOption(CURLOPT_ENCODING, '');
        $ch->setOption(CURLOPT_MAXREDIRS, 10);
        $ch->setOption(CURLOPT_TIMEOUT, 0);
        $ch->setOption(CURLOPT_FOLLOWLOCATION, true);
        $ch->setOption(CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $ch->setOption(CURLOPT_POSTFIELDS, '{"q_num":"'.$q_num.'"}');
        $ch->setOption(CURLOPT_CUSTOMREQUEST, "POST");
        $ch->addHeader("X-API-TOKEN", $tokens);
        $ch->addHeader("Content-Type", "application/json");
        $ch->addHeader("Accept", "application/json");
        $ch->get($apiurl);
        $result =  $ch->getBody();
        return $result;
    }
    
    /*
     *@return Logedin Customer data
     */
    public function getCustomerData()
    {
        return $this->session;
    }
    
    /*
     *@return Product detail
     */
    public function getLoadProduct($id)
    {
        try {
            $product = $this->_productloader->create()->load($id);
        } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('This product no longer exists.'));
        }
        return $product;
    }
}
