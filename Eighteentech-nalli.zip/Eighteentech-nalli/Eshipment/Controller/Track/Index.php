<?php
/**
 * @category   Eighteentech
 * @package    Eighteentech_Eshipment
 * @author     https://www.18thdigitech.com/
 */
 
namespace Eighteentech\Eshipment\Controller\Track;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    protected $_resultPageFactory;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $Session,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        \Magento\Framework\UrlInterface $UrlInterface,
        PageFactory $resultPageFactory,
        \Eighteentech\Eshipment\Helper\Data $helper
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_customerSession  = $Session;
        $this->redirect = $redirect;
        $this->urlInterface = $UrlInterface;
        $this->helper = $helper;
        return parent::__construct($context);
    }
    
    public function execute()
    {
        if ($this->helper->isDynamic()!=0) {
            if (!$this->_customerSession->isLoggedIn()) {
                $this->_customerSession->setAfterAuthUrl($this->urlInterface->getCurrentUrl());
                $this->_customerSession->authenticate();
            }
        }
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->addHandle('eshipment_track_index');
        //loads the layout of module_custom_customlayout.xml file with its name
        return $resultPage;
    }
}
