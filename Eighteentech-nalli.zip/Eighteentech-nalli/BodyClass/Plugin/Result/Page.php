<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @category Eighteentech
 * @package  Eighteentech_BodyClass
 *
 */
 
namespace Eighteentech\BodyClass\Plugin\Result;

use Magento\Framework\App\ResponseInterface;

class Page
{
    /*
     *@var \Magento\Framework\View\Element\Context $context
     */
    private $context;
    /*
     *@var \Magento\Framework\Registry $registry
     */
    private $registry;
    
    /*
     *@param \Magento\Framework\View\Element\Context $context
     *@param \Magento\Framework\Registry $registry
     */
    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        \Magento\Framework\Registry $registry
    ) {
        $this->context = $context;
        $this->registry = $registry;
    }
    /*
     *@return Add international-call-button class in body if product is international
     */
    public function beforeRenderResult(
        \Magento\Framework\View\Result\Page $subject,
        ResponseInterface $response
    ) {
    
        if ($this->context->getRequest()->getFullActionName() == 'catalog_product_view') {
            $product = $this->registry->registry('current_product');
            if ($product->getInternational() == 1) {
                 $subject->getConfig()->addBodyClass('international-call-button');
     
            }
        }
        return [$response];
    }
}
